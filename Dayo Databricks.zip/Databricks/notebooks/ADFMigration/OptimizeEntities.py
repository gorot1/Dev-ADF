# Databricks notebook source
# MAGIC %md
# MAGIC Queries to optimize delta tables and Order by Join columns 

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.customcreditexposuredata  ZORDER by (ID)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.quotereference  ZORDER by (quotereferenceid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.customrerdealstruture  ZORDER by (rerdealstrutureid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.contact  ZORDER by (CntctID)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.transactiontypegroup  ZORDER by (XTpeGrpXGrpID,XTpeGrpTrnsctnTypID)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.calendardate  ZORDER by (calendarid,date)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.businessassociate  ZORDER by (baid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.rawpriceheader  ZORDER by (rphdrid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.customportfolioinformation  ZORDER by (strategyid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.dealtype  ZORDER by (dltypid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.locale  ZORDER by (lcleid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.prvsn  ZORDER by (prvsnid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.pricecurveprovision  ZORDER by (prcecrvecnfgid,dldtlprvsnid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.dynamiclistbox  ZORDER by (dynlstbxid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.rawpricelocalecurrencyuom  ZORDER by (rwprcelclecrrncyuomid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.currency  ZORDER by (CrrncyID)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.rawpricelocale  ZORDER by (rwprcelcleid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.dealheader  ZORDER by (DlHdrID)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.periodtranslation  ZORDER by (vetradeperiodid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.dealuserdefinedgroup  ZORDER by (userdefinedgroupcd)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.rawprice  ZORDER by (idnty)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.calendar  ZORDER by (calendarid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.dealdetailprovision  ZORDER by (dldtlprvsnid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.generalconfiguration  ZORDER by (gnrlcnfgtblnme,gnrlcnfgqlfr,gnrlcnfghdrid,gnrlcnfgdtlid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.dealdetailprovisionrow  ZORDER by (dldtlprvsnrwid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.unitofmeasure  ZORDER by (uom)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.pricecurveprovisionbasis  ZORDER by (prcecrveprvsnbssid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.pricetype  ZORDER by (idnty)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.accountingperiod  ZORDER by (accntngprdid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.holiday  ZORDER by (holidayid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.dealheadertemplate  ZORDER by (dlhdrtmplteid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.plannedtransfer  ZORDER by (plnndtrnsfrid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.commodity  ZORDER by (cmmdtyid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.pricecurveconfiguration  ZORDER by (prcecrvecnfgid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.rawpricelocalepricingperiodcategory  ZORDER by (idnty)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.dealdetailtemplate  ZORDER by (dldtltmplteid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.vetradeperiod  ZORDER by (vetradeperiodid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.dealdetail  ZORDER by (DlDtlDlHdrID,DlDtlID)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.pricingperiodcategory  ZORDER by (pricingperiodcategoryid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.quotemacro  ZORDER by (quotemacroid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.prvsnattributetype  ZORDER by (prvsnattrtpeid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.users  ZORDER by (userid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.strategyheader  ZORDER by (strtgyid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.rawpricedetail  ZORDER by (idnty)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.transactiontype  ZORDER by (TrnsctnTypID)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.pricingperiodcategoryvetradeperiod  ZORDER by (idnty)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.pricetyperelation  ZORDER by (prcetperltnprntprcetpeidnty,prcetperltnchldprcetpeidnty)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.transactiongroup  ZORDER by (XGrpID)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.schedulingobligation  ZORDER by (schdlngoblgtnid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.snapshot  ZORDER by (P_EODSnpShtID)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.formulatabletrule  ZORDER by (FrmlaTbltRleID)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.rawpriceheaderpricetype  ZORDER by (rphdrprcetperphdrid,rphdrprcetpeidnty)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.product  ZORDER by (prdctid)

# COMMAND ----------

# MAGIC %sql
# MAGIC Optimize mtmstandardized.localeinstance  ZORDER by (lcleinstncelcletpeid,lcleinstncelcleid)