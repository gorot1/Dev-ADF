# Databricks notebook source
# MAGIC %run "../../Includes/Packages/UtilityStore"

# COMMAND ----------

# MAGIC %run "../../Includes/Dataset-Mounts"

# COMMAND ----------

from datetime import datetime
from pyspark.sql.functions import col
import json

dbutils.widgets.text("FileSuffix", "","") 
fileSuffix = dbutils.widgets.get("FileSuffix")

dbutils.widgets.text("SSFileSuffixes", "","") 
SSFileSuffixes = dbutils.widgets.get("SSFileSuffixes")
SSFileSuffixes="{" +  SSFileSuffixes + "}"
jsonFileSuffix = json.loads(SSFileSuffixes)

outputLocation = mountCrtdDir + "/PetroTranz/Liquidssplit/Dimensions/Liquidssplit/Liquidssplit.csv"
outputLocationUpdatedData = mountCrtdDir + "/PetroTranz/Liquidssplit/Dimensions/Liquidssplit/Liquidssplit_Updated.csv"

formattedDate = datetime.strptime(fileSuffix, '%Y%m%d%H%M%S')

# COMMAND ----------

import datetime
createdOn = datetime.datetime.utcnow()

# COMMAND ----------

completeDataQuery = """Select 
                          Liquidssplit.UniqueKey
                          ,Liquidssplit.Guid  
                          ,Liquidssplit.ChildProduct  
                          ,Liquidssplit.ChildvolumeTotal
                          ,Liquidssplit.TotalNetQuantity
                          ,Liquidssplit.ShipperName                       
                          ,Liquidssplit.Status
                          ,Liquidssplit.DateSubmitted
                          ,Liquidssplit.DeliveryMonth
                          ,Liquidssplit.DeliveryYear
                          ,Liquidssplit.Number
                          ,Liquidssplit.ProductType
                          ,Liquidssplit.Revision
                          ,Liquidssplit.RevisionNumber
                          ,Liquidssplit.FromFacilityCode
                          ,Liquidssplit.FromFacilityLocation
                          ,Liquidssplit.FromFacilityDescription
                          ,Liquidssplit.FromFacilityOperatorCode
                          ,Liquidssplit.FromFacilityOperatorName
                          ,Liquidssplit.FromFacilityProvince
                          ,Liquidssplit.FromFacilityType
                          ,Liquidssplit.ToFacilityCode
                          ,Liquidssplit.ToFacilityLocation
                          ,Liquidssplit.ToFacilityDescription
                          ,Liquidssplit.ToFacilityOperatorCode
                          ,Liquidssplit.ToFacilityOperatorName
                          ,Liquidssplit.ToFacilityProvince
                          ,Liquidssplit.ToFacilityType
                          ,Liquidssplit.Volume
                          ,Liquidssplit.FacilityName
                          ,'$/m3' as Unit
                          ,'CAD' as Currency
                          ,'PetroTranz' as CreatedBy
                          ,'%s' as CreatedOn
                          ,'%s' as LastPipelineUpdate 
                      from mtmstandardized.liquidssplit as Liquidssplit""" % (createdOn, formattedDate)

updatedDataQuery = """%s WHERE (Liquidssplit.FileSuffix > '%s' )""" % (completeDataQuery, jsonFileSuffix["Liquidssplit"])

completeData = spark.sql(completeDataQuery)
updatedData = spark.sql(updatedDataQuery)

utility = Utility() 
utility.writeOutputDataFile(completeData,outputLocation)
utility.writeOutputDataFile(updatedData,outputLocationUpdatedData)

# COMMAND ----------

