# Databricks notebook source
# MAGIC %run "./Includes/Packages/CuratedEntitiesDefinition"

# COMMAND ----------

# MAGIC %run "./Includes/Packages/ParallelRunConfig"

# COMMAND ----------

# MAGIC %run "./Includes/Packages/UtilityStore"

# COMMAND ----------

# MAGIC %run "./Includes/Dataset-Mounts"

# COMMAND ----------

dbutils.widgets.text("SourceSystemEntities", "","")
dbutils.widgets.text("SourceSystem", "","")
dbutils.widgets.text("CuratedEntities", "","")
dbutils.widgets.text("FileSuffix", "","")
dbutils.widgets.text("SnapshotIDs", "","")
dbutils.widgets.text("PipelineRunID", "","")

param_source_system_entities = dbutils.widgets.get("SourceSystemEntities")
param_source_system = dbutils.widgets.get("SourceSystem")
param_curated_entities = dbutils.widgets.get("CuratedEntities")
param_file_suffix = dbutils.widgets.get("FileSuffix")
param_snapshot_id = dbutils.widgets.get("SnapshotIDs")
param_pipeline_run_id = dbutils.widgets.get("PipelineRunID")

db_query_curated_entity = """SELECT CE.EntityName,CE.SchemaName,CE.JoinColumns,CE.EntityType,CE.SupportMultipleDataSet,ERL.SnapshotIDs,CE.IsPolybase,CE.IsPartition,CE.PartitionColumn,CE.PartitionType,CE.PartitionKeyCount,CE.Sequence 
FROM COMMON.CURATEDENTITIES CE
LEFT JOIN COMMON.EntityRunLog ERL ON CE.EntityName = ERL.EntityName AND ERL.ParentPipelineRunID = '%s'
""" % (param_pipeline_run_id)

if param_curated_entities:
  db_query_curated_entity = db_query_curated_entity + " WHERE CE.ENTITYNAME IN ('" + param_curated_entities.replace(",","','") + "') AND CE.Sequence <> -1"
else:
  if param_source_system_entities:
    db_query_curated_entity = "SELECT DISTINCT CE.EntityName,CE.SchemaName,CE.JoinColumns,CE.EntityType,CE.SupportMultipleDataSet,ERL.SnapshotIDs,CE.IsPolybase,CE.IsPartition,CE.PartitionColumn,CE.PartitionType,CE.PartitionKeyCount,CE.Sequence FROM Common.CuratedEntities CE LEFT JOIN Common.CuratedSourceSystemMapping CSSM ON CSSM.CuratedEntityName = CE.EntityName LEFT JOIN COMMON.ChangeTrackingInfo CTI ON CTI.TableName = CSSM.SourceSystemEntityName LEFT JOIN COMMON.EntityRunLog ERL ON ERL.EntityName = CE.EntityName AND ERL.ParentPipelineRunID = '%s' WHERE CTI.TableName IN ('%s') AND CE.Sequence <> -1" % (param_pipeline_run_id, param_source_system_entities.replace(",","','"))
  else:
    if param_source_system:
      db_query_curated_entity = "SELECT DISTINCT CE.EntityName,CE.SchemaName,CE.JoinColumns,CE.EntityType,CE.SupportMultipleDataSet,ERL.SnapshotIDs,CE.IsPolybase,CE.IsPartition,CE.PartitionColumn,CE.PartitionType,CE.PartitionKeyCount,CE.Sequence FROM Common.CuratedEntities CE LEFT JOIN Common.CuratedSourceSystemMapping CSSM ON CSSM.CuratedEntityName = CE.EntityName LEFT JOIN COMMON.ChangeTrackingInfo CTI ON CTI.TableName = CSSM.SourceSystemEntityName LEFT JOIN COMMON.EntityRunLog ERL ON ERL.EntityName = CE.EntityName AND ERL.ParentPipelineRunID = '%s' WHERE CTI.SourceSystem IN ('%s') AND CE.Sequence <> -1" % (param_pipeline_run_id, param_source_system.replace(",","','"))


db_config_object_curated_entity = DBConnConfigEntity("",sql_query = db_query_curated_entity)
data_frame_curated_entity_unsorted = Utility.get_data_azure_db_query(db_config_object_curated_entity)

data_frame_curated_entity = data_frame_curated_entity_unsorted.orderBy('Sequence')
# display(data_frame_curated_entity)

mapped_curated_entity_list=[]
notebooks=[]

for data in data_frame_curated_entity.collect():
  mapped_curated_entity_list.append(CuratedEntitiesEntity(data.EntityName, data.SchemaName, data.JoinColumns, data.EntityType, data.SupportMultipleDataSet, data.SnapshotIDs, data.IsPolybase, data.IsPartition, data.PartitionColumn, data.PartitionType, data.PartitionKeyCount, data.Sequence))

# COMMAND ----------

iterator_snapshot_id = ''
entitiesToUpdate = []
for entity in mapped_curated_entity_list:
  entitiesToUpdate.append("'"+ entity.entity_name +  "'")
  if entity.support_multiple_data_set:
    print("The entity is a multidataset i.e. IsMultiDataSet = 1")
    if param_snapshot_id:
      iterator_snapshot_id = param_snapshot_id
    else:
      if entity.snapshot_id:
        iterator_snapshot_id = entity.snapshot_id
      else:
        iterator_snapshot_id = '0'
  else:
    print("The entity is NOT a multidataset i.e. IsMultiDataSet = 0")
  
  data_frame_related_source_entities = Utility.get_data_azure_db_query(DBConnConfigEntity("",sql_query = "Select * From Common.CuratedSourceSystemMapping Where CuratedEntityName='" + entity.entity_name + "'"))
  temp_sufflix_expression = []
  for related_entity in data_frame_related_source_entities.collect():
    temp_sufflix_expression.append('"' + related_entity.SourceSystemEntityName + '":"' + related_entity.CuratedFileSuffix + '"')
  
  source_system_path = ""
  
  if param_source_system.upper() != 'RIGHTANGLE' and param_source_system.upper() != 'GAMEPLAN':
     source_system_path = param_source_system + "/"
    
  notebooks.append(NotebookData("Transformation/"+source_system_path+entity.entity_name,5400,{"SnapshotID":iterator_snapshot_id, "FileSuffix": param_file_suffix, "SSFileSuffixes":','.join(temp_sufflix_expression)}))

# COMMAND ----------

res = parallelNotebooks(notebooks, 5)
result = [f.result(timeout=5400) for f in res] # This is a blocking call.

dbutils.notebook.exit(','.join(entitiesToUpdate))




# COMMAND ----------

# db_writeTry = DBConnConfigEntity()
# filePath = mountCrtdDir + "/Common/Dimensions/Product/Product_Updated.csv"
# df =(spark
#     .read
#     .option("header", "true")
#     .option("inferSchema", "true")
#     .option("timestampFormat", "yyyy-MM-dd HH:mm:ss")
#     .csv(filePath)
#     ) 
# db_output = Utility.testTruncate(db_writeTry,df)