# Databricks notebook source
# MAGIC %md ####This notebook performs a drop and create on data transferred from CSV file source, for a list of comma separated entities

# COMMAND ----------

# MAGIC %run "./Includes/Dataset-Mounts"

# COMMAND ----------

from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.sql.functions import regexp_replace
from pyspark.sql.functions import col, trim
import pandas as pd

# COMMAND ----------

dbutils.widgets.text("FileSuffix", "","") 
dbutils.widgets.text("Entities", "","")

FileSuffix = dbutils.widgets.get("FileSuffix")
Entities = dbutils.widgets.get("Entities")




# COMMAND ----------

# MAGIC %md ####Define a function that takes a column values and removes a "\r\n" occurences

# COMMAND ----------

def trimAndRemoveCRLF(columnValue):
  trimmedValue = trim(columnValue);
  quoteReplaced = regexp_replace(trimmedValue,"[\"]","")
  crlfRemoved  = regexp_replace(quoteReplaced, "[\\r\\n]", "")
  return crlfRemoved;

# COMMAND ----------

def ReplaceAllSpecialCharacters(columnName):
  updatedColumnName = str.replace(str.replace(str.replace(str.replace(str.replace(str.replace(str.replace(str.replace(str.replace(str.replace(columnName, " ", ""), ",", ""), "\n", ""), "\t", ""), "=", ""), "(", ""), ")", ""), "{", ""), "}", ""), ";", "")
  return updatedColumnName;

# COMMAND ----------

for EntityName in Entities.split(","):  
  FullDataInputPath = mountRawDir + "/CSV/MasterEntities/" +  EntityName + "/" + EntityName + "_" + FileSuffix + ".csv"
  EntityDeltaTablePath =  "%s/CSV/MasterEntities/%s" % (mountDltaDir, EntityName)

  FullDataDF = (sqlContext       
                      .read
                      .format("com.databricks.spark.csv")
                      .option("header","true")
                      .option("multiLine", "true")
                      .option("ignoreLeadingWhiteSpace", "true")
                      .option("ignoreTrailingWhiteSpace", "true")
                      .option("parserLib","UNIVOCITY")
                      .option("escape", "\"")
                      .option("quoteMode","none")
                      .option("quote","\"")
                      .option("mode", "PERMISSIVE")
                      .option("treatEmptyValuesAsNulls", "false")
                      .load(FullDataInputPath)
                   )

  if FullDataDF.count() > 0:
    print("dropping delta table mtmstandardized.%s" %(EntityName))
    spark.sql("""DROP TABLE IF EXISTS mtmstandardized.%s""" % (EntityName))
    
    # Trim and remove CRLF characters from column values, Remove special characters (including whitespace) from column name
    SanatizedDataDF = FullDataDF.select(list(map(lambda c: trimAndRemoveCRLF(col(c)).alias(ReplaceAllSpecialCharacters(c)), FullDataDF.columns)))
    SanatizedDataDF.createOrReplaceTempView("FullEntityData")
    
    # Add 2 more columns FileSuffix, IsDeleted to main table data
    FullDataDFWithExtraColumns = spark.sql("""SELECT %s, '%s' As FileSuffix, false As IsDeleted FROM FullEntityData ED """ %(str.join(",", SanatizedDataDF.columns), FileSuffix)) 
       
    print("Loading the delta table for full dataset")
    
    FullDataDFWithExtraColumns.write.mode("overwrite").option("overwriteSchema", "true").format("delta").save("%s" % (EntityDeltaTablePath))

    TableCreateScript = """CREATE TABLE IF NOT EXISTS mtmstandardized.%s
                             USING DELTA
                             LOCATION "%s"
                              """ %(EntityName, EntityDeltaTablePath)
    spark.sql(TableCreateScript)
    