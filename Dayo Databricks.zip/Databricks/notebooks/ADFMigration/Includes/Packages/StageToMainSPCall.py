# Databricks notebook source
# MAGIC %run "./KeyVaultValues"

# COMMAND ----------

dbutils.widgets.text("EntityName", "","")
dbutils.widgets.text("SchemaName", "","")
dbutils.widgets.text("EntityType", "","")


param_entity_name = dbutils.widgets.get("EntityName")
param_schema_name = dbutils.widgets.get("SchemaName")
param_entity_type = dbutils.widgets.get("EntityType")



# COMMAND ----------

import pyodbc

key=KeyVault()
connection = ' DRIVER={ODBC Driver 17 for SQL Server};SERVER=%s;DATABASE=%s;UID=%s;PWD=%s' %(key.DW_SERVER,key.DW_DB,key.DW_USER,key.DW_PASS)
conn = pyodbc.connect(connection)
cursor = conn.cursor()
execsp = ("EXEC Common.CustomUspUpdateEntity '%s','%s','%s'")%(param_entity_name,param_schema_name,param_entity_type)
print(execsp)
conn.autocommit = True
cursor.execute(execsp)

while cursor.nextset():   # NB: This always skips the first resultset
    try:
        results = cursor.fetchall()
        break
    except pyodbc.ProgrammingError:
        continue

conn.close()