# Databricks notebook source
from concurrent.futures import ThreadPoolExecutor

class NotebookData:
  def __init__(self, path, timeout, parameters=None, retry=0):
    self.path = path
    self.timeout = timeout
    self.parameters = parameters
    self.retry = retry


# COMMAND ----------

def submitNotebook(notebook):
  print("Running notebook %s" % notebook.path)
  if (notebook.parameters):
    return dbutils.notebook.run(notebook.path, notebook.timeout, notebook.parameters)
  else:
    return dbutils.notebook.run(notebook.path, notebook.timeout)
  submitNotebook(notebook)


def parallelNotebooks(notebooks, numInParallel):
  with ThreadPoolExecutor(max_workers=numInParallel) as ec:
    return [ec.submit(submitNotebook, notebook) for notebook in notebooks]