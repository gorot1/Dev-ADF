# Databricks notebook source
# MAGIC %run "./KeyVaultValues"

# COMMAND ----------

key = KeyVault()

# COMMAND ----------

class DBConnConfigEntity:
  def __init__(self, db_table = "", sql_query = ""):
    self.read_format = key.READ_FORMAT_AZURE_SQL
    self.read_url = key.SQL_DW_URL_SMALL
    self.temp_dir = key.TEMP_DIR
    self.forward_spark_azure_storage_credentials = "forward_spark_azure_storage_credentials"
    self.db_table = db_table
    self.sql_query = sql_query
    self.blob_string = key.BLOB_CONN_STRING
    self.blob_access_key = key.BLOB_ACCESS_KEY
    self.user = key.DW_USER
    self.password = key.DW_PASS
    self.src_raw = key.SRC_RAW
    self.src_curated = key.SRC_CURATED

# COMMAND ----------

