# Databricks notebook source
# MAGIC %run "./DBConnConfigEntity"

# COMMAND ----------

# MAGIC %md
# MAGIC ##Created Functions in common notebook to overwrite/append dataframe's data to corresponding outputfile location mentioned in parameter

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.types import StringType

class Utility:
  def writeOutputDataFile(_self,DataDF, outputFileLocation):
    print("Writing Data to Curated")
    DataDF.write.option("header", "true").option("delimiter",",").mode("overwrite").option("nullValue","null").option("timestampFormat", "yyyy-MM-dd HH:mm:ss").csv(outputFileLocation);
    print("File written to Curated")
    return;
  
  def appendOutputDataFile(_self,DataDF, outputFileLocation):
    print("Writing Data to Curated")
    DataDF.write.option("header", "true").option("delimiter",",").mode("append").option("nullValue","null").option("timestampFormat", "yyyy-MM-dd HH:mm:ss").csv(outputFileLocation);
    print("File written to Curated")
    return;
  
  def get_data_azure_db_table(DBConnConfigEntity):
    spark.conf.set(DBConnConfigEntity.blob_string, DBConnConfigEntity.blob_access_key)
    df = spark.read \
    .format(DBConnConfigEntity.read_format) \
    .option("url", DBConnConfigEntity.read_url) \
    .option("tempDir", DBConnConfigEntity.temp_dir) \
    .option("forwardSparkAzureStorageCredentials", DBConnConfigEntity.forward_spark_azure_storage_credentials) \
    .option("dbTable", DBConnConfigEntity.db_table) \
    .load()
    return df
  
  def get_data_azure_db_query(DBConnConfigEntity):
    spark.conf.set(DBConnConfigEntity.blob_string, DBConnConfigEntity.blob_access_key)
    df = spark.read \
    .format(DBConnConfigEntity.read_format) \
    .option("url", DBConnConfigEntity.read_url) \
    .option("tempDir", DBConnConfigEntity.temp_dir) \
    .option("forwardSparkAzureStorageCredentials", DBConnConfigEntity.forward_spark_azure_storage_credentials) \
    .option("query", DBConnConfigEntity.sql_query) \
    .load()   
    return df
  
  def write_data_to_azure_sqldwh(DBConnConfigEntity,df):
    spark.conf.set(DBConnConfigEntity.blob_string, DBConnConfigEntity.blob_access_key)
    df.write \
    .format("jdbc") \
    .option("url", DBConnConfigEntity.read_url) \
    .option("forwardSparkAzureStorageCredentials", "true") \
    .option("dbTable", "StageCommon.Product") \
    .option("tempDir", DBConnConfigEntity.src_curated+"/Common/Dimensions/Product/Product_Updated.csv") \
    .mode("append") \
    .option("truncate","true") \
    .save()
    
  def AddDataToStageTable(DBConnConfigEntity,df,StageTableName):
    spark.conf.set(DBConnConfigEntity.blob_string, DBConnConfigEntity.blob_access_key)
    df.write \
    .jdbc(DBConnConfigEntity.read_url, StageTableName, mode = 'overwrite', properties = {'truncate' : 'true'} )
