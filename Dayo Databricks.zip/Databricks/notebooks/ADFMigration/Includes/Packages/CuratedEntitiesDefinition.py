# Databricks notebook source
class CuratedEntitiesEntity:
	def __init__(self,
entity_name, schema_name, join_columns, entity_type, support_multiple_data_set, snapshot_id, is_polybase, is_partition, partition_column, partition_type, partition_key_count, sequence):
		self.entity_name = entity_name
		self.schema_name = schema_name
		self.join_columns = join_columns
		self.entity_type = entity_type
		self.support_multiple_data_set = support_multiple_data_set
		self.snapshot_id = snapshot_id
		self.is_polybase = is_polybase
		self.is_partition = is_partition
		self.partition_column = partition_column
		self.partition_type = partition_type
		self.partition_key_count = partition_key_count
		self.sequence = sequence
