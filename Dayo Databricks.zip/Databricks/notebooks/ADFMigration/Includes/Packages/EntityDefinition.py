# Databricks notebook source
from pyspark.sql.types import *

class Entity:
  def __init__(self, entityTableName, entityTableOptimizeColumns, entitySchemaDef,fileName):
    self.etTableName = entityTableName 
    self.etDeltaTableName = "%s_Incremental" % (entityTableName)
    self.etDeleteTableName = "%s_Delete" % (entityTableName)
    self.etFullpathName = fileName 
    self.entitySchemaDef = entitySchemaDef
    self.etTableOptimize = "OPTIMIZE %s ZORDER BY (%s)" % (self.etTableName, entityTableOptimizeColumns)
    self.etDeltaTableOptimize = "OPTIMIZE %s ZORDER BY (%s)" % (self.etDeltaTableName, entityTableOptimizeColumns)
    self.finalResult = "SELECT * FROM %s" % (self.etTableName)
    self.updatedEntitySchemaDef = "%s,FileSuffix:varchar,IsDeleted:bit" % entitySchemaDef
    self.etSchema = StructType(list(map(lambda column: StructField(column.split(":")[0], self.inferType(column.split(":")[1]), True),                                   self.updatedEntitySchemaDef.split(","))))
    self.updatedEntitySchemaDef = self.updatedEntitySchemaDef.replace(":"," ").replace("varchar","string").replace("char","string").replace("timestamp","string").replace("bit","boolean").replace("datetime","smalldatetime").replace("float","double").replace("Decimal","double").replace(" int"," smallint")
    
    #delete Schema 
    self.updatedDeleteSchemaDef =  self.updatedEntitySchemaDef.split(",");
    print(self.updatedDeleteSchemaDef)
    OptiMizedDeletecolumn = entityTableOptimizeColumns.split(",")
    self.DeleteSchema = [a for a in self.updatedDeleteSchemaDef if a.split(" ")[0] in OptiMizedDeletecolumn]
    self.DeleteSchema=",".join(self.DeleteSchema)
    print(self.DeleteSchema)
    
    
    self.etTableDrop = """
                    DROP TABLE IF EXISTS %s 
                  """ % (self.etTableName)
    #self.etTableCreate = """
                    #CREATE TABLE IF NOT EXISTS %s
                    #USING DELTA 
                    #LOCATION "/delta/%s"
                  #""" % (self.etTableName,self.etTableName)
#              USING CSV 
#                             OPTIONS (path '%s', header 'true')
    self.etTableCreate = """CREATE TABLE IF NOT EXISTS %s
                           USING DELTA
                           LOCATION "%s"
                            """ %(self.etTableName,self.etFullpathName )
    self.etDeltaTableDrop = """
                    DROP TABLE IF EXISTS %s 
                  """ % (self.etDeltaTableName)
    #self.etDeltaTableCreate = """
                    #CREATE TABLE  IF NOT EXISTS %s
                    #USING DELTA 
                    #LOCATION "/delta/%s"
                  #""" % (self.etDeltaTableName,self.etDeltaTableName)
    DeltaPath=self.etFullpathName+"_Incremental"
    self.etDeltaTableCreate = """CREATE TABLE IF NOT EXISTS  %s
                            USING DELTA 
                            LOCATION "%s"
                            """ %(self.etDeltaTableName,DeltaPath )
    self.etDeleteTableDrop = """
                    DROP TABLE IF EXISTS %s 
                  """ % (self.etDeleteTableName)
    #self.etDeleteTableCreate = """
                    #CREATE TABLE  IF NOT EXISTS %s
                    #USING DELTA 
                    #LOCATION "/delta/%s"
                  #""" % (self.etDeleteTableName,self.etDeleteTableName)
    self.etDeleteTableCreate = """CREATE TABLE IF NOT EXISTS %s
                            USING DELTA 
                            LOCATION "%s"
                            """ %(self.etDeleteTableName,self.etFullpathName+"_Delete" )
        
    
    
    self.splitData = map(lambda column:  "EN2.%s = EN1.%s" % (column, column), entityTableOptimizeColumns.split(","))
    
    self.optimizeQuery = str.join(" AND ", self.splitData)
    print(self.optimizeQuery)
    self.compareArray = map(lambda column: "$TableName.%s = $IncrementalTableName.%s" % (column.split(":")[0],column.split(":")[0]),entitySchemaDef.split(","))
    
    self.insertString  = map(lambda column: "%s.%s" % (self.etDeltaTableName, column.split(":")[0]), entitySchemaDef.split(","))
    
    self.columnList = map(lambda column: column.split(":")[0],entitySchemaDef.split(","))
    self.incrementalData="""SELECT * FROM %s""" %(self.etDeltaTableName)
    self.baseData ="""SELECT * FROM %s""" %(self.etTableName)
    
    self.etDeleteQuery = "DELETE FROM %s EN1 WHERE EXISTS (SELECT 1 FROM(%s) EN2 WHERE %s)" % (self.etTableName, "DeltaDataLoad", self.optimizeQuery)
    
    self.InsertQuery = "INSERT INTO %s SELECT %s,'FileSuffixValue',0 from %s" % (self.etTableName, str.join(", ",self.insertString), self.etDeltaTableName)
    
    self.SoftDeleteQuery = "Update %s EN1 Set IsDeleted=1,FileSuffix='FileSuffixValue' Where Exists (Select 1 from %s EN2 where %s)" % (self.etTableName,self.etDeleteTableName,self.optimizeQuery)
    
    
    
  def inferType(self, type):
    if (type in ["int", "smallint"]):
      return IntegerType()
    
    if (type in ["double","float","decimal"]):
      return DoubleType()
    
    if (type in ["string", "char", "timestamp", "varchar"]):
      return StringType()
    
    if (type in ["datetime", "smalldatetime"]):
      return TimestampType()
    
    if (type in ["bit"]):
      return BooleanType()
    
    return StringType()
    