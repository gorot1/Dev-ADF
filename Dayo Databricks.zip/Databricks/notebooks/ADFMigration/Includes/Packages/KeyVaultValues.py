# Databricks notebook source
import os

# COMMAND ----------

class KeyVault:
  def __init__(self):
    self.GetKey = dbutils.secrets.get(scope = "pmc-%s-wu2-keyv-secrets" % os.environ['SecretScopeENVNAME'] , key = ("MTM-DWH-%s-CONNECTION-STRING-Databricks" % os.environ['ENVNAME']))
    self.dataLakeName = dbutils.secrets.get(scope = "pmc-%s-wu2-keyv-secrets" % os.environ['SecretScopeENVNAME'] , key = ("MTM-ADLS-%s-Name" % os.environ['ENVNAME']))
    self.a=self.GetKey.split(';')
    self.DW_SERVER = self.a[0][self.a[0].find(':')+1:self.a[0].find(',')]
    self.DW_JDBC_PORT = self.a[0][self.a[0].find(',')+1:]
    self.DW_DB = self.a[1][self.a[1].find('=')+1:]
    self.DW_USER = self.a[3][self.a[3].find('=')+1:]
    self.DW_PASS = self.a[4][self.a[4].find('=')+1:]
    self.BLOB_CONN_STRING = "fs.azure.account.key.%s.blob.core.windows.net" % self.dataLakeName
    self.BLOB_ACCESS_KEY = dbutils.secrets.get(scope = "pmc-%s-wu2-keyv-secrets" % os.environ['SecretScopeENVNAME'] , key = ("MTM-ADLS-%s-STORAGEKEY" % os.environ['ENVNAME']))
    self.SQL_DW_URL_SMALL = "jdbc:sqlserver://" + self.DW_SERVER + ":" + self.DW_JDBC_PORT + ";database=" + self.DW_DB + ";user=" + self.DW_USER + ";password=" + self.DW_PASS
    self.SRC_RAW = "wasbs://rawdata@%s.blob.core.windows.net" % self.dataLakeName
    self.TEMP_DIR = self.SRC_RAW + "/tempDirs"
    self.READ_FORMAT_AZURE_SQL = "jdbc"
    self.SRC_CURATED = "wasbs://curateddata@%s.blob.core.windows.net" % self.dataLakeName
    self.CSKey = dbutils.secrets.get(scope = "pmc-%s-wu2-keyv-secrets" % os.environ['SecretScopeENVNAME'], key = "MTM-%s-BI2-DATABRICK-APPREG-CLIENTSECRET" % (os.environ['ENVNAME']))
    self.CIDKey = dbutils.secrets.get(scope = "pmc-%s-wu2-keyv-secrets" % os.environ['SecretScopeENVNAME'], key = "MTM-%s-BI2-DATABRICK-APPREG-CLIENTID" % (os.environ['ENVNAME']))