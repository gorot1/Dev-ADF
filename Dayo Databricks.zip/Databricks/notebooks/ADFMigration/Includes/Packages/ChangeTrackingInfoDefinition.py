# Databricks notebook source
class ChangeTrackingInfoEntity:
	def __init__(self,
table_name, last_updated_version, column_names, source_system, entity_type, stored_procedure, query, is_processed, second_to_last_updated_version, row_counts):
		self.table_name = table_name
		self.last_updated_version = last_updated_version
		self.column_names = column_names
		self.source_system = source_system
		self.entity_type = entity_type
		self.stored_procedure = stored_procedure
		self.query = query
		self.is_processed = is_processed
		self.second_to_last_updated_version = second_to_last_updated_version
		self.row_counts = row_counts