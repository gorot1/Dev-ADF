# Databricks notebook source
import os

# COMMAND ----------

# MAGIC %run "./Packages/KeyVaultValues"

# COMMAND ----------

# MAGIC %md
# MAGIC ##Define the Mount Directories paths to the Data Lake as strings
# MAGIC Three different mount points are declared corresponding to each layer within Data Lake viz. Raw Layer, Standardized Raw Layer and Curated Layer

# COMMAND ----------

mountRawDir = "/mnt/MTMRawEntities"
mountStdDir = "/mnt/MTMStdEntities"
mountCrtdDir = "/mnt/MTMCrtdEntities"
mountDltaDir = "/mnt/MTMDltaEntities"

# COMMAND ----------

# dbutils.fs.unmount(mountRawDir)
# dbutils.fs.unmount(mountStdDir)
# dbutils.fs.unmount(mountCrtdDir)

# COMMAND ----------

def mount (source, extraConfigs, mountPoint):
  
  try:
    dbutils.fs.mount(source=source, mount_point=mountPoint, extra_configs=extraConfigs)
  except Exception as ex:
    try: 
      #Mount with IAM roles instead of keys for PVC
      dbutils.fs.mount(source, mountPoint)
    except Exception as e:  
      print("*** ERROR: Unable to mount %s: %s" % (mountPoint, e))
    print("There's an error in mounting the Datasets %s" % ex)
  return;

# COMMAND ----------

def autoMount():
  key = KeyVault()
  dataLakeName = key.dataLakeName
  print(dataLakeName)
  sourceRaw = "abfss://rawdata@%s.dfs.core.windows.net" % dataLakeName
  sourceStd = "abfss://standardizedrawdata@%s.dfs.core.windows.net" % dataLakeName
  sourceCrtd = "abfss://curateddata@%s.dfs.core.windows.net" % dataLakeName
  sourceDlta = "abfss://deltalayer@%s.dfs.core.windows.net" % dataLakeName
  print(sourceRaw)
  extraConfigs = {"fs.azure.account.auth.type": "OAuth",
                  "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
                  "fs.azure.account.oauth2.client.id": key.CIDKey,
                  "fs.azure.account.oauth2.client.secret": key.CSKey,
                  "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/e3267a76-a858-4ead-a71a-fa49332a6879/oauth2/token"} 
  
  if any(mount.mountPoint == mountRawDir for mount in dbutils.fs.mounts()):
    print("Already mounted Raw Layer")
    print(mountRawDir)
  else:
    print("Mounting Raw Layer")
    mount(sourceRaw, extraConfigs, mountRawDir)
  
  if any(mount.mountPoint == mountStdDir for mount in dbutils.fs.mounts()):
    print("Already mounted Std")
  else:
    print("Mounting Standardized Layer")
    mount(sourceStd, extraConfigs, mountStdDir)
  
  if any(mount.mountPoint == mountCrtdDir for mount in dbutils.fs.mounts()):
    print("Already mounted Curated Layer")
  else:
    print("Mounting Curated Layer")
    mount(sourceCrtd, extraConfigs, mountCrtdDir)  
    
  if any(mount.mountPoint == mountDltaDir for mount in dbutils.fs.mounts()):
    print("Already mounted Delta Layer")
  else:
    print("Mounting Delta Layer")
    mount(sourceDlta, extraConfigs, mountDltaDir)
  
  return;

# COMMAND ----------

autoMount()