# Databricks notebook source
# MAGIC %md
# MAGIC ### Notebook to start cluster through DataFactory 

# COMMAND ----------

# MAGIC %run "./Dataset-Mounts"