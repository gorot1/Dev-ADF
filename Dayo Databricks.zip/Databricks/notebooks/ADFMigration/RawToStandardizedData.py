# Databricks notebook source
# MAGIC %run "./Includes/Packages/EntityDefinition"

# COMMAND ----------

# MAGIC %run "./Includes/Dataset-Mounts"

# COMMAND ----------

from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.sql.functions import regexp_replace
from pyspark.sql.functions import col, trim
import pandas as pd

# COMMAND ----------

print(dbutils.widgets.get("SchemaDef"))

# COMMAND ----------

print(dbutils.widgets.get("OptimizeColumns"))

# COMMAND ----------

dbutils.widgets.text("FileSuffix", "","") 
dbutils.widgets.text("EntityName", "","")

dbutils.widgets.text("OptimizeColumns", "","")
dbutils.widgets.text("SchemaDef", "","") 
dbutils.widgets.text("LastVersion", "","") 
dbutils.widgets.text("CurrentVersion", "","") 
dbutils.widgets.text("SourceSystem", "","") 
dbutils.widgets.text("EntityType", "MasterEntities","") 

fileSuffix = dbutils.widgets.get("FileSuffix")
EntityName = dbutils.widgets.get("EntityName")
EntityType = dbutils.widgets.get("EntityType")

OptimizeColumns = dbutils.widgets.get("OptimizeColumns")
print(OptimizeColumns)
SchemaDef = dbutils.widgets.get("SchemaDef")

SourceSystem = dbutils.widgets.get("SourceSystem")

LastVersion = dbutils.widgets.get("LastVersion")
CurrentVersion = dbutils.widgets.get("CurrentVersion")

FileBasePath = "/%s/%s/" % (SourceSystem, EntityType)
BaseDeltaPath = mountDltaDir + (FileBasePath + EntityName)
FullDeltaPath = BaseDeltaPath + "/" + EntityName 

print(FileBasePath)
print(BaseDeltaPath)
print(FullDeltaPath)

entity = Entity(EntityName, OptimizeColumns, SchemaDef, FullDeltaPath)


# COMMAND ----------

# MAGIC %md ####Define a function that takes a column values and removes a "\r\n" occurences

# COMMAND ----------

def trimAndRemoveCRLF(columnValue):
  trimmedValue = trim(columnValue);
  quoteReplaced = regexp_replace(trimmedValue,"[\"]","")
  crlfRemoved  = regexp_replace(quoteReplaced, "[\\r\\n]", "")
  return crlfRemoved;

# COMMAND ----------

def loadEntityRawAndIncremental():
  
  #Setting the Path
  path = mountStdDir + FileBasePath + EntityName
  incrementalFilePath = mountRawDir + FileBasePath +  EntityName 
  
  DataInputPath = mountStdDir + FileBasePath +  EntityName + "/" + EntityName + ".csv"
  
  IncrementalDataInputPath = mountRawDir + FileBasePath +  EntityName + "/" + EntityName + "_" + fileSuffix + ".csv"  
  
  DeleteDataInputPath = mountRawDir + FileBasePath +  EntityName + "/" + EntityName + "_Delete_" + fileSuffix + ".csv"

  EntityDir = "%s.csv/" % (EntityName)
  EntityFile = "%s.csv" % (EntityName)
  IncrementalFile = "%s_%s.csv" %(EntityName,fileSuffix)
  DeleteDataFile =  "%s_Delete_%s.csv" %(EntityName,fileSuffix)
  
  if (EntityDir not in [file.name for file in dbutils.fs.ls(path)]) and (EntityFile not in [file.name for file in dbutils.fs.ls(path)]):
    print("File Does not exists")
    dbutils.fs.cp(IncrementalDataInputPath,DataInputPath)
    
  if(DeleteDataFile in [file.name for file in dbutils.fs.ls(incrementalFilePath)]):
    print("Loading Delete DF")
    DeleteDataDF = (sqlContext       
                                .read
                                .format("com.databricks.spark.csv")
                                .option("header","true")
                                .option("multiLine", "true")
                                .option("ignoreLeadingWhiteSpace", "true")
                                .option("ignoreTrailingWhiteSpace", "true")
                                .option("parserLib","UNIVOCITY")
                                .option("escape", "\"")
                                .option("quoteMode","none")
                                .option("quote","\"")
                                .option("mode", "PERMISSIVE")
                                .option("treatEmptyValuesAsNulls", "false")
                                .load(DeleteDataInputPath)
                             )
  
  
  if(IncrementalFile in [file.name for file in dbutils.fs.ls(incrementalFilePath)]):
    IncrementDataDF = (sqlContext       
                                .read
                                .format("com.databricks.spark.csv")
                                .option("header","true")
                                .option("multiLine", "true")
                                .option("ignoreLeadingWhiteSpace", "true")
                                .option("ignoreTrailingWhiteSpace", "true")
                                .option("parserLib","UNIVOCITY")
                                .option("escape", "\"")
                                .option("quoteMode","none")
                                .option("quote","\"")
                                .option("mode", "PERMISSIVE")
                                .option("treatEmptyValuesAsNulls", "false")
                                .schema(entity.etSchema)
                                .load(IncrementalDataInputPath)
                             )
  DataDF = (sqlContext       
                                .read
                                .format("com.databricks.spark.csv")
                                .option("header","true")
                                .option("multiLine", "true")
                                .option("ignoreLeadingWhiteSpace", "true")
                                .option("ignoreTrailingWhiteSpace", "true")
                                .option("parserLib","UNIVOCITY")
                                .option("escape", "\"")
                                .option("quoteMode","none")
                                .option("quote","\"")
                                .option("mode", "PERMISSIVE")
                                .option("treatEmptyValuesAsNulls", "false")
                                .schema(entity.etSchema)
                                .load(DataInputPath)
                     )
  print("printing dataframe")
  
  DataDF.printSchema()

  #DataDF = DataDF.select(list(map(lambda c: col(c).alias(c),DataDF.columns)))
  EntityDir = "%s/" % (EntityName)
  
  # Check if the File Already exists. If yes, do not load delta table for Full dataset else Load it (1st Time only)
  #if (('delta/' not in [file.name for file in dbutils.fs.ls("/")]) or (EntityDir not in [file.name for file in dbutils.fs.ls("/delta")])) :
  if (EntityDir not in [file.name for file in dbutils.fs.ls(BaseDeltaPath)]) and (EntityFile not in [file.name for file in dbutils.fs.ls(BaseDeltaPath)]):
    print("File Does not exists")
    print("Loading the delta table for full dataset")
    returnDF = DataDF.select(list(map(lambda c: trimAndRemoveCRLF(col(c)).alias(c),DataDF.columns)))
    returnDF.write.mode("overwrite").option("overwriteSchema", "true").format("delta").save("%s" % (FullDeltaPath))
  
  if(IncrementalFile in [file.name for file in dbutils.fs.ls(incrementalFilePath)]):
    print("Loading just the incremental file")
    returnIncrementDF = IncrementDataDF.select(list(map(lambda c: trimAndRemoveCRLF(col(c)).alias(c),IncrementDataDF.columns)))
    print("Writing the incremental file on overwrite mode")
    #display(returnIncrementDF)
    returnIncrementDF.write.mode("overwrite").option("overwriteSchema", "true").format("delta").save("%s/%s" % (BaseDeltaPath,entity.etDeltaTableName))
 
  if(DeleteDataFile in [file.name for file in dbutils.fs.ls(incrementalFilePath)]):
    DeleteDataDF.write.mode("overwrite").option("overwriteSchema", "true").format("delta").save("%s/%s" % (BaseDeltaPath,entity.etDeleteTableName))
    
  
  return;

# COMMAND ----------

def createDeltaTable():
  try:
    DeleteDataFile =  "%s_Delete_%s.csv" %(EntityName,fileSuffix)
    incrementalFilePath = mountRawDir + FileBasePath + EntityName
    spark.sql("CREATE DATABASE IF NOT EXISTS MTMStandardized")
    spark.sql("USE MTMStandardized")
    #spark.sql(entity.etTableDrop)
    print("Creating table")
    print(entity.etTableCreate)
    spark.sql(entity.etTableCreate)
    print("Table created")
    
    spark.sql(entity.etDeltaTableDrop)
    print(entity.etDeltaTableCreate)
    spark.sql(entity.etDeltaTableCreate)
    print("Delta table created")
    #spark.sql(entity.etDeleteTableDrop)
    if(DeleteDataFile in [file.name for file in dbutils.fs.ls(incrementalFilePath)]):
      print(entity.etDeleteTableCreate)
      spark.sql(entity.etDeleteTableCreate)
      print("Delete table created")
  
  except Exception as e:
    print("Error creating the table %s" % e)
  return;

# COMMAND ----------

def mergeIncrementalDataToStandardized():
  try:
    #spark.sql(entity.etTableOptimize)
    #spark.sql(entity.etDeltaTableOptimize)
    #spark.sql(entity.etMergeQuery.replace("$TableName",entity.etTableName)
              #.replace("$IncrementalTableName", entity.etDeltaTableName)
              #.replace("FileSuffixValue",fileSuffix))
    DeleteDataFile =  "%s_Delete_%s.csv" %(EntityName,fileSuffix)
    incrementalFilePath = mountRawDir + FileBasePath + EntityName  
    MainTableData=spark.sql(entity.baseData)
    #if(MainTableData.count()>0):
    IncrementalDataVal = entity.incrementalData
    print(entity.etDeleteQuery.replace("DeltaDataLoad",IncrementalDataVal))
    spark.sql(entity.etDeleteQuery.replace("DeltaDataLoad",IncrementalDataVal))
    print("Inserting rows")
    print(entity.InsertQuery)
    spark.sql(entity.InsertQuery.replace("FileSuffixValue",fileSuffix))
    print("Updating rows")

    if(DeleteDataFile in [file.name for file in dbutils.fs.ls(incrementalFilePath)]):
      print(entity.SoftDeleteQuery)
      spark.sql(entity.SoftDeleteQuery.replace("FileSuffixValue",fileSuffix))

    #spark.sql(entity.etTableOptimize)
    #spark.sql(entity.etDeltaTableOptimize)
    print("Getting final result")
    finalresult = spark.sql(entity.finalResult)
    #print(entity.etMergeQuery.replace("$TableName",entity.etTableName)
    #          .replace("$IncrementalTableName", entity.etDeltaTableName)
    #          .replace("FileSuffixValue",fileSuffix))
    outputLocation = mountStdDir + FileBasePath + "/%s/%s.csv" % (EntityName,EntityName)
    finalresult.write.format("com.databricks.spark.csv").option("header", "true").option("delimiter",",").mode("overwrite").csv(outputLocation)

    #finalresult.coalesce(1).write.format("com.databricks.spark.csv").option("header", "true").option("parserLib","univocity").option("multiline","true").option("quote", "\"").option("escape", "\"").option("delimiter",",").mode("overwrite").csv(outputLocation)

  except Exception as e:
    print("Error in Merging the Data %s" % e)

# COMMAND ----------

loadEntityRawAndIncremental()
 
if LastVersion != CurrentVersion:
  print("Last version is not empty")
  createDeltaTable()
  mergeIncrementalDataToStandardized()
else:
  print("Not executing anything")