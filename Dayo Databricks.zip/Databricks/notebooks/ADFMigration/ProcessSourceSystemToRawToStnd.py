# Databricks notebook source
# MAGIC %run "./Includes/Packages/ChangeTrackingInfoDefinition"

# COMMAND ----------

# MAGIC %run "./Includes/Packages/UtilityStore"

# COMMAND ----------

dbutils.widgets.text("SourceSystemEntities", "","")
dbutils.widgets.text("SourceSystem", "","")

param_source_system_entities = dbutils.widgets.get("SourceSystemEntities")
param_source_system = dbutils.widgets.get("SourceSystem")
db_query = "SELECT TableName,LastUpdatedVersion,ColumnNames,SourceSystem,EntityType,StoredProcedure,Query,IsProcessed,SecondToLastUpdatedVersion,RowCounts FROM COMMON.CHANGETRACKINGINFO"

if param_source_system_entities or param_source_system:
    if param_source_system_entities:
        db_query = db_query + " WHERE TABLENAME IN ('" + param_source_system_entities.replace(",","','") + "')"
        print("query", db_query)
    else:
        db_query = db_query + " WHERE SOURCESYSTEM IN ('" + param_source_system.replace(",","','") + "')"
        print("query", db_query)

db_config_object = DBConnConfigEntity("",sql_query = db_query)
data_frame = Utility.get_data_azure_db_query(db_config_object)

mapped_entity_list=[]

for data in data_frame.collect():
  mapped_entity_list.append(ChangeTrackingInfoEntity(data.TableName, data.LastUpdatedVersion, data.ColumnNames, data.SourceSystem, data.EntityType, data.StoredProcedure, data.Query, data.IsProcessed, data.SecondToLastUpdatedVersion, data.RowCounts))

# COMMAND ----------

import json
# for p in mapped_entity_list: print(p.table_name)
# loop on the received entities and for each of them, send them back to the ADF

data_json = json.dumps([ob.__dict__ for ob in mapped_entity_list])

dbutils.notebook.exit(data_json)