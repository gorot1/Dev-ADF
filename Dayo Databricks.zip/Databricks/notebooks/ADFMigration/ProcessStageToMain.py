# Databricks notebook source
# MAGIC %run "./Includes/Packages/CuratedEntitiesDefinition"

# COMMAND ----------

# MAGIC %run "./Includes/Packages/ParallelRunConfig"

# COMMAND ----------

# MAGIC %run "./Includes/Packages/UtilityStore"

# COMMAND ----------

# MAGIC %run "./Includes/Dataset-Mounts"

# COMMAND ----------

from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.sql.functions import regexp_replace
from pyspark.sql.functions import col, trim
import pandas as pd


dbutils.widgets.text("SourceSystemEntities", "","")
dbutils.widgets.text("SourceSystem", "","")
dbutils.widgets.text("CuratedEntities", "","")
dbutils.widgets.text("FileSuffix", "","")
dbutils.widgets.text("SnapshotIDs", "","")

param_source_system_entities = dbutils.widgets.get("SourceSystemEntities")
param_source_system = dbutils.widgets.get("SourceSystem")
param_curated_entities = dbutils.widgets.get("CuratedEntities")
param_file_suffix = dbutils.widgets.get("FileSuffix")
param_snapshot_id = dbutils.widgets.get("SnapshotIDs")
fileName = param_snapshot_id.replace(',', '_')

db_query_curated_entity = "SELECT EntityName,SchemaName,JoinColumns,EntityType,SupportMultipleDataSet,SnapshotID,IsPolybase,IsPartition,PartitionColumn,PartitionType,PartitionKeyCount,Sequence FROM COMMON.CURATEDENTITIES"

if param_curated_entities:
  db_query_curated_entity = db_query_curated_entity + " WHERE ENTITYNAME IN ('" + param_curated_entities.replace(",","','") + "')"
else:
  if param_source_system_entities:
    db_query_curated_entity = "SELECT DISTINCT CE.EntityName,CE.SchemaName,CE.JoinColumns,CE.EntityType,CE.SupportMultipleDataSet,CE.SnapshotID,CE.IsPolybase,CE.IsPartition,CE.PartitionColumn,CE.PartitionType,CE.PartitionKeyCount,CE.Sequence FROM Common.CuratedEntities CE LEFT JOIN Common.CuratedSourceSystemMapping CSSM ON CSSM.CuratedEntityName = CE.EntityName LEFT JOIN COMMON.ChangeTrackingInfo CTI ON CTI.TableName = CSSM.SourceSystemEntityName WHERE CTI.TableName IN ('" + param_source_system_entities.replace(",","','") + "')"
  else:
    if param_source_system:
      db_query_curated_entity = "SELECT DISTINCT CE.EntityName,CE.SchemaName,CE.JoinColumns,CE.EntityType,CE.SupportMultipleDataSet,CE.SnapshotID,CE.IsPolybase,CE.IsPartition,CE.PartitionColumn,CE.PartitionType,CE.PartitionKeyCount,CE.Sequence FROM Common.CuratedEntities CE LEFT JOIN Common.CuratedSourceSystemMapping CSSM ON CSSM.CuratedEntityName = CE.EntityName LEFT JOIN COMMON.ChangeTrackingInfo CTI ON CTI.TableName = CSSM.SourceSystemEntityName WHERE CTI.SourceSystem IN ('" + param_source_system.replace(",","','") + "')"


db_config_object_curated_entity = DBConnConfigEntity("",sql_query = db_query_curated_entity)
data_frame_curated_entity = Utility.get_data_azure_db_query(db_config_object_curated_entity)

mapped_curated_entity_list=[]
entityNames =[]
notebooks=[]

for data in data_frame_curated_entity.collect():
  entityNames.append(data.EntityName)
  notebooks.append(NotebookData("Includes/Packages/StageToMainSPCall",10800,{"EntityName":data.EntityName,"SchemaName":data.SchemaName,"EntityType":data.EntityType}))
  mapped_curated_entity_list.append(CuratedEntitiesEntity(data.EntityName, data.SchemaName, data.JoinColumns, data.EntityType, data.SupportMultipleDataSet, data.SnapshotID, data.IsPolybase, data.IsPartition, data.PartitionColumn, data.PartitionType, data.PartitionKeyCount, data.Sequence))

# COMMAND ----------

# MAGIC %sh
# MAGIC curl https://packages.microsoft.com/keys/microsoft.asc | apt-key add -
# MAGIC curl https://packages.microsoft.com/config/ubuntu/16.04/prod.list > /etc/apt/sources.list.d/mssql-release.list 
# MAGIC apt-get update
# MAGIC ACCEPT_EULA=Y apt-get install msodbcsql17
# MAGIC apt-get -y install unixodbc-dev
# MAGIC pip3 install --upgrade pip3
# MAGIC sudo apt-get install python3-pip -y
# MAGIC pip3 install --upgrade pyodbc
# MAGIC apt-get -y install unixodbc-dev
# MAGIC /databricks/python/bin/pip install pyodbc

# COMMAND ----------

res = parallelNotebooks(notebooks, 10)
result = [f.result(timeout=10800) for f in res] # This is a blocking call.

# COMMAND ----------

# import json
# data_json = json.dumps([ob.__dict__ for ob in mapped_entity_list])

dbutils.notebook.exit(entityNames)