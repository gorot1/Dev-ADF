﻿CREATE TABLE [dbo].[EloquaBimEmailAnalysisEntity](
	[Day] [date] NULL,
	[AssetName] [nvarchar](max) NULL,
	[CampaignId] [bigint] NULL,
	[CampaignName] [nvarchar](max) NULL,
	[TotalSends] [bigint] NULL,
	[TotalClickthroughs] [bigint] NULL,
	[UniqueClickthroughs] [bigint] NULL,
	[ExistingVisitorClickthroughs] [bigint] NULL,
	[NewVisitorClickthroughs] [bigint] NULL,
	[TotalOpens] [bigint] NULL,
	[UniqueOpens] [bigint] NULL,
	[TotalBouncebacks] [bigint] NULL,
	[TotalHardBouncebacks] [bigint] NULL,
	[TotalSoftBouncebacks] [bigint] NULL,
	[TotalFormSubmissions] [bigint] NULL,
	[UniqueFormSubmissions] [bigint] NULL,
	[TotalUnsubscribes] [bigint] NULL,
	[TotalDelivered] [bigint] NULL,
	[EloquaBimEmailAnalysisEntity_buid] [varchar](40) NOT NULL,
	[entity_start_date] [datetime] NOT NULL,
	[entity_end_date] [datetime] NOT NULL,
	[entity_is_current] [bit] NOT NULL,
	[entity_is_deleted] [bit] NOT NULL,
	[entity_created_on] [datetime] NOT NULL,
	[entity_modified_on] [datetime] NOT NULL,
	[EloquaBimEmailAnalysisEntity_uid] [varchar](40) NOT NULL
)
GO

ALTER TABLE [dbo].[EloquaBimEmailAnalysisEntity]
	ADD CONSTRAINT [XPKEloquaBimEmailAnalysisEntity] PRIMARY KEY NONCLUSTERED ([EloquaBimEmailAnalysisEntity_uid])
GO
