﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-05
-- Description: Converts string sha1 to uniqueidentifier
-- =============================================
CREATE FUNCTION dbo.fn_str2uniq(@s VARCHAR(50)) RETURNS UNIQUEIDENTIFIER
AS
BEGIN
    -- JUST IN CASE IT CAME IN WITH 0X PREFIX OR DASHES...
    SET @s = REPLACE(REPLACE(@s,'0x',''),'-','')
    -- INJECT DASHES IN THE RIGHT PLACES
    SET @s = STUFF(STUFF(STUFF(STUFF(@s,21,0,'-'),17,0,'-'),13,0,'-'),9,0,'-')
    RETURN CAST(@s AS UNIQUEIDENTIFIER)
END