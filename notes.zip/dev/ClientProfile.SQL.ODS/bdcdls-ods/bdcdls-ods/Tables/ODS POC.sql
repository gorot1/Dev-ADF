﻿--La procédure à suivre lorsqu'on modifie le schéma d'une table, ou lorsqu'on supprime une table pour la recréer, devrait être la suivante:
--	- Modifier le script de CREATE TABLE en conséquence
--	- Publier la nouvelle version du script SQL (right-click sur le projet dans Visual Studio et Publish...)
--	- Alimenter la table à partir de Spark

--Dans le cas d'une nouvelle table, il faut
--	- Créer le script SQL de CREATE TABLE de la table en faisant attention au NVARCHAR(MAX) qui doivet être remplacés par NVARCHAR(taille réelle) ou VARCHAR(taille réelle) 
--	- Inclure ce script SQL de CREATE TABLE dans celui des autres tables en conservant l'ordre alphabétique
--	- Ne pas oublier de créer les indexes sur au moins entity_start_date et entity_is_current EN RESPECTANT la convention de nommage : IX_NomDeLaTable_NomChamp1_NomChamp2_..._NomChampN
--	- Publier la nouvelle version du script SQL

CREATE TABLE [dbo].[AccountProfileEntity](
	[SourceRecordMaster] [varchar](12) NULL,
	[AccountProfileEntity_buid] [varchar](40) NULL,
	[AccountProfileEntity_uid] [varchar](40) NULL,
	[AccountProfileEntity_oid] [varchar](40) NULL,
	[entity_start_date] [datetime] NULL,
	[entity_end_date] [datetime] NULL,
	[entity_is_current] [bit] NULL,
	[entity_is_deleted] [bit] NULL,
	[AccountId] [varchar](36) NULL,
	[LeadId] [varchar](36) NULL,
	[EloquaAccountId] [varchar](20) NULL,
	[CRMAccount_CRMId] [varchar](10) NULL,
	[CRMLead_CRMId] [varchar](10) NULL,
	[AccountName] [nvarchar](100) NULL,
	[AccountResponsibleForAdjustment] [varchar](36) NULL,
	[AccountResponsibleForAdjustmentName] [nvarchar](160) NULL,
	[AccountSegmentCode] [int] NULL,
	[AccountSegmentDescrEn] [nvarchar](40) NULL,
	[AccountSegmentDescrFr] [nvarchar](40) NULL,
	[AccountTypeCode] [int] NULL,
	[AccountTypeDescrEn] [nvarchar](40) NULL,
	[AccountTypeDescrFr] [nvarchar](40) NULL,
	[AdjustedSegmentReasonCode] [int] NULL,
	[AdjustedSegmentReasonDescrEn] [nvarchar](40) NULL,
	[AdjustedSegmentReasonDescrFr] [nvarchar](40) NULL,
	[AgeGroupDescrEn] [nvarchar](20) NULL,
	[AgeGroupDescrFr] [nvarchar](20) NULL,
	[AgeGroupCode] [int] NULL,
	[AgeGroupModifiedOn] [datetime] NULL,
	[AGSStatus] [int] NULL,
	[AlertFlag] [bit] NULL,
	[AMLStatusCode] [int] NULL,
	[AMLStatusDescrEn] [nvarchar](40) NULL,
	[AMLStatusDescrFr] [nvarchar](40) NULL,
	[AnnualSales] [float] NULL,
	[ArchivedDate] [datetime] NULL,
	[AssignedOn] [date] NULL,
	[AverageBeaconScore] [float] NULL,
	[AveragePersonalNetWorth] [float] NULL,
	[BillingAddressCity] [nvarchar](100) NULL,
	[BillingAddressCountryRegion] [nvarchar](40) NULL,
	[BillingAddressPostalOrZipCode] [nvarchar](20) NULL,
	[BillingAddressStateProvince] [nvarchar](40) NULL,
	[BillingAddressStreet1] [nvarchar](160) NULL,
	[BillingAddressStreet2] [nvarchar](160) NULL,
	[BillingName1] [nvarchar](45) NULL,
	[BillingName2] [nvarchar](45) NULL,
	[BoxNumber] [nvarchar](100) NULL,
	[BPCUpdatedOn] [datetime] NULL,
	[BusinessLifestageCode] [varchar](10) NULL,
	[BusinessLifeStageDescrEn] [nvarchar](40) NULL,
	[BusinessLifestageDescrFr] [nvarchar](40) NULL,
	[BusinessPhone] [varchar](50) NULL,
	[CAPEX] [float] NULL,
	[ClientFacingOnly] [bit] NULL,
	[ClientRiskProbabilityOfDowngradingToImpai] [float] NULL,
	[ClientStatusHistoryCode] [int] NULL,
	[ClientStatusHistoryDescrEn] [nvarchar](40) NULL,
	[ClientStatusHistoryDescrFr] [nvarchar](40) NULL,
	[ClientUntil] [date] NULL,
	[CreatedBy] [nvarchar](36) NULL,
	[CreatedOn] [datetime] NULL,
	[CreditInformationScoreCIGPS] [nvarchar](2) NULL,
	[Creditscore] [float] NULL,
	[CustomerTypeCode] [int] NULL,
	[CustomerTypeDescrEn] [nvarchar](60) NULL,
	[CustomerTypeDescrFr] [nvarchar](60) NULL,
	[DateLastFSSFProductEnded] [datetime] NULL,
	[Description] [nvarchar](2000) NULL,
	[DevelopmentStageCode] [int] NULL,
	[DevelopmentStageDescrEn] [nvarchar](40) NULL,
	[DevelopmentStageDescrFr] [nvarchar](40) NULL,
	[DigitalCommunicationCode] [int] NULL,
	[DigitalCommunicationDescrEn] [nvarchar](40) NULL,
	[DigitalCommunicationDescrFr] [nvarchar](40) NULL,
	[DisbursementAnalyst] [nvarchar](200) NULL,
	[DisbursementAnalystId] [nvarchar](36) NULL,
	[DoNotPhone] [bit] NULL,
	[DoNotPostalMail] [bit] NULL,
	[EligibleforRepeatBusinessCode] [int] NULL,
	[EligibleforRepeatBusinessDescrEn] [nvarchar](40) NULL,
	[EligibleforRepeatBusinessDescrFr] [nvarchar](40) NULL,
	[EligibleforRepeatBusinessModifiedDate] [date] NULL,
	[EMailAddress1] [nvarchar](100) NULL,
	[EntrepreneurTypeCode] [int] NULL,
	[EntrepreneurTypeDescrEn] [nvarchar](60) NULL,
	[EntrepreneurTypeDescrFr] [nvarchar](60) NULL,
	[EnvironmentCode] [int] NULL,
	[EnvironmentCodeDescrEn] [nvarchar](100) NULL,
	[EnvironmentCodeDescrFr] [nvarchar](100) NULL,
	[EquifaxCILastNegativeScore] [int] NULL,
	[EquifaxID] [nvarchar](25) NULL,
	[ExclusionComments] [nvarchar](2000) NULL,
	[ExclusionExpectedDateReview] [datetime] NULL,
	[ExclusionFromPreauthorizedOffers] [bit] NULL,
	[ExclusionLastUpdated] [datetime] NULL,
	[ExclusionReasonCode] [int] NULL,
	[ExclusionReasonDescrEn] [nvarchar](80) NULL,
	[ExclusionReasonDescrFr] [nvarchar](80) NULL,
	[ExclusionServiceRequestCreated] [bit] NULL,
	[ExportsPercentageOfAnnualSales] [int] NULL,
	[FalsePositive] [bit] NULL,
	[Fax] [varchar](50) NULL,
	[FinScanProcessCode] [int] NULL,
	[FinScanProcessDescrEn] [nvarchar](40) NULL,
	[FinScanProcessDescrFr] [nvarchar](40) NULL,
	[FinScanStatusCode] [int] NULL,
	[FinScanStatusDescrEn] [nvarchar](60) NULL,
	[FinScanStatusDescrFr] [nvarchar](60) NULL,
	[FinScanStatusUpdateDate] [datetime] NULL,
	[FiscalYearEndDate] [date] NULL,
	[FSSFClientSinceDate] [datetime] NULL,
	[GPS_CurrentPaymentIndexScore] [float] NULL,
	[GPS_DeterioratedAlert] [bit] NULL,
	[GPS_FlagDate] [datetime] NULL,
	[GPS_LastUpdateDate] [date] NULL,
	[GPS_NegativeOccurrencesVsSuppliersScore] [float] NULL,
	[GPS_NumberofNegativeOccurrencesScore] [float] NULL,
	[GPS_NumberofTradePaymentReferenceScore] [float] NULL,
	[GPS_QualitativeRatingCode] [int] NULL,
	[GPS_QualitativeRatingDescrEn] [nvarchar](40) NULL,
	[GPS_QualitativeRatingDescrFr] [nvarchar](40) NULL,
	[GPS_Rating] [nvarchar](20) NULL,
	[GPS_TrendofPaymentIndicesScore] [float] NULL,
	[GPS_YearsOnFile] [int] NULL,
	[GSTHSTNumber] [nvarchar](100) NULL,
	[HighRiskOfPrepayment] [bit] NULL,
	[InBreach] [bit] NULL,
	[InDepthReviewRequired] [bit] NULL,
	[IndustryMarketing] [nvarchar](100) NULL,
	[IsExporter] [bit] NULL,
	[IsImporter] [bit] NULL,
	[LastActivityDate] [date] NULL,
	[LastArrearsAlertDate] [datetime] NULL,
	[LastDateClient] [datetime] NULL,
	[LastDateFinancialStatementReceived] [date] NULL,
	[LastOpportunityDate] [date] NULL,
	[LastUsedInCampaign] [date] NULL,
	[LastVisit] [date] NULL,
	[LastWonOpportunityDate] [date] NULL,
	[LegalStatusCode] [int] NULL,
	[LegalStatusDescrEn] [nvarchar](60) NULL,
	[LegalStatusDescrFr] [nvarchar](60) NULL,
	[LimitedAccessDueToRiskCode] [int] NULL,
	[LimitedAccessDueToRiskDescrEn] [nvarchar](40) NULL,
	[LimitedAccessDueToRiskDescrFr] [nvarchar](40) NULL,
	[MainAddressCity] [nvarchar](100) NULL,
	[MainAddressCountryRegion] [nvarchar](100) NULL,
	[MainAddressId] [nvarchar](36) NULL,
	[MainAddressPostalCode] [nvarchar](100) NULL,
	[MainAddressProvinceState] [nvarchar](50) NULL,
	[MainAddressStreet1] [nvarchar](200) NULL,
	[MainAddressStreet2] [nvarchar](200) NULL,
	[MainAddressTypeCode] [int] NULL,
	[MainChallengeCode] [varchar](10) NULL,
	[MainChallengeDescrEn] [nvarchar](80) NULL,
	[MainChallengeDescrFr] [nvarchar](80) NULL,
	[Manufactures] [bit] NULL,
	[ModifiedBy] [varchar](36) NULL,
	[ModifiedOn] [datetime] NULL,
	[ModifiedOnBehalfBy] [varchar](36) NULL,
	[NameOfEntityOnWhichEquifaxScoringIsBased] [nvarchar](100) NULL,
	[NativeStatusCode] [int] NULL,
	[NativeStatusDescrEn] [nvarchar](60) NULL,
	[NativeStatusDescrFr] [nvarchar](60) NULL,
	[NetValueofFixedAsset] [float] NULL,
	[NewFinancing] [float] NULL,
	[NumberOfActiveServiceRequests] [int] NULL,
	[NumberOfEmployees] [int] NULL,
	[NumberOfEmployeesRange] [varchar](20) NULL,
	[NumberofOpenOpportunity] [int] NULL,
	[OfferEligibilityStatus] [bit] NULL,
	[OriginatingUnitId] [varchar](5) NULL,
	[OriginatingUnitNumber] [varchar](4) NULL,
	[OriginatingUnitAreaDescrEn] [nvarchar](80) NULL,
	[OriginatingUnitAreaDescrFr] [nvarchar](80) NULL,
	[OriginatingUnitAreaId] [nvarchar](36) NULL,
	[OriginatingUnitAreaNumber] [nvarchar](10) NULL,
	[OriginatingUnitNameEn] [nvarchar](80) NULL,
	[OriginatingUnitNameFr] [nvarchar](80) NULL,
	[OriginatingUnitRegionDescrEn] [nvarchar](80) NULL,
	[OriginatingUnitRegionDescrFr] [nvarchar](80) NULL,
	[OriginatingUnitRegionId] [nvarchar](36) NULL,
	[OriginatingUnitRegionNumber] [nvarchar](10) NULL,
	[OtherRiskStatusCode] [int] NULL,
	[OtherRiskStatusDescrEn] [nvarchar](60) NULL,
	[OtherRiskStatusDescrFr] [nvarchar](60) NULL,
	[OverallOfferAmount] [float] NULL,
	[OverallRiskRating] [float] NULL,
	[OwnerId] [varchar](36) NULL,
	[OwnerIdDsc] [int] NULL,
	[OwnerIdName] [nvarchar](60) NULL,
	[OwnerIdType] [int] NULL,
	[OwnershipCode] [int] NULL,
	[OwnershipDescrEn] [nvarchar](40) NULL,
	[OwnershipDescrFr] [nvarchar](40) NULL,
	[OwnershipGenderCode] [int] NULL,
	[OwnershipGenderDescrEn] [nvarchar](40) NULL,
	[OwnershipGenderDescrFr] [nvarchar](40) NULL,
	[OwnershipGenderModifiedDate] [datetime] NULL,
	[OwningTeam] [varchar](36) NULL,
	[Owns] [bit] NULL,
	[PartnerExclusivityCode] [int] NULL,
	[PartnerExclusivityDescrEn] [nvarchar](40) NULL,
	[PartnerExclusivityDescrFr] [nvarchar](40) NULL,
	[PlansToGrowNext12Months] [bit] NULL,
	[PrimaryExportMarketCode] [int] NULL,
	[PrimaryExportMarketDescrEn] [nvarchar](60) NULL,
	[PrimaryExportMarketDescrFr] [nvarchar](60) NULL,
	[PrimaryIndustryGroupCode] [varchar](10) NULL,
	[PrimaryIndustryGroupNameEn] [nvarchar](160) NULL,
	[PrimaryIndustryGroupNameFr] [nvarchar](160) NULL,
	[PrimaryIndustrySectorCode] [varchar](10) NULL,
	[PrimaryIndustrySectorNameEn] [nvarchar](120) NULL,
	[PrimaryIndustrySectorNameFr] [nvarchar](120) NULL,
	[PrimaryIndustrySubGroupCode] [varchar](10) NULL,
	[PrimaryIndustrySubGroupNameEn] [nvarchar](160) NULL,
	[PrimaryIndustrySubGroupNameFr] [nvarchar](160) NULL,
	[PrimaryIndustrySubSectorCode] [varchar](10) NULL,
	[PrimaryIndustrySubSectorNameEn] [nvarchar](120) NULL,
	[PrimaryIndustrySubSectorNameFr] [nvarchar](120) NULL,
	[PrimaryNaicsCode] [varchar](10) NULL,
	[PrimaryNaicsNameEn] [nvarchar](160) NULL,
	[PrimaryNaicsNameFr] [nvarchar](160) NULL,
	[PrivilegedPostponementEligibility] [bit] NULL,
	[PSTNumber] [nvarchar](40) NULL,
	[RdExpenses] [float] NULL,
	[RecalculateSegment] [bit] NULL,
	[RentExpense] [float] NULL,
	[Rents] [bit] NULL,
	[Revenue] [float] NULL,
	[RevenueRange] [varchar](50) NULL,
	[SalesToNonCanadianTouristOnSales] [int] NULL,
	[SecondaryExportMarketCode] [int] NULL,
	[SecondaryExportMarketDescrEn] [nvarchar](60) NULL,
	[SecondaryExportMarketDescrFr] [nvarchar](60) NULL,
	[SecondaryIndustryGroupCode] [varchar](10) NULL,
	[SecondaryIndustryGroupNameEn] [nvarchar](160) NULL,
	[SecondaryIndustryGroupNameFr] [nvarchar](160) NULL,
	[SecondaryIndustrySectorCode] [varchar](10) NULL,
	[SecondaryIndustrySectorNameEn] [nvarchar](120) NULL,
	[SecondaryIndustrySectorNameFr] [nvarchar](120) NULL,
	[SecondaryIndustrySubGroupCode] [varchar](10) NULL,
	[SecondaryIndustrySubGroupNameEn] [nvarchar](160) NULL,
	[SecondaryIndustrySubGroupNameFr] [nvarchar](160) NULL,
	[SecondaryIndustrySubSectorCode] [varchar](10) NULL,
	[SecondaryIndustrySubSectorNameEn] [nvarchar](120) NULL,
	[SecondaryIndustrySubSectorNameFr] [nvarchar](120) NULL,
	[SecondaryNaicsCode] [varchar](10) NULL,
	[SecondaryNaicsNameEn] [nvarchar](160) NULL,
	[SecondaryNaicsNameFr] [nvarchar](160) NULL,
	[SegmentDate] [datetime] NULL,
	[SpecialAccountStatusCode] [int] NULL,
	[SpecialAccountStatusDescrEn] [nvarchar](60) NULL,
	[SpecialAccountStatusDescrFr] [nvarchar](60) NULL,
	[StatusCode] [bigint] NULL,
	[StatusDescrEn] [nvarchar](20) NULL,
	[StatusDescrFr] [nvarchar](20) NULL,
	[StatusReasonChangeDate] [datetime] NULL,
	[StatusReasonCode] [bigint] NULL,
	[StatusReasonDescrEn] [nvarchar](40) NULL,
	[StatusReasonDescrFr] [nvarchar](40) NULL,
	[SystemAdjustedSegmentCode] [int] NULL,
	[SystemAdjustedSegmentDescrEn] [nvarchar](40) NULL,
	[SystemAdjustedSegmentDescrFr] [nvarchar](40) NULL,
	[SystemCalculatedSegmentCode] [int] NULL,
	[SystemCalculatedSegmentDescrEn] [nvarchar](40) NULL,
	[SystemCalculatedSegmentDescrFr] [nvarchar](40) NULL,
	[TargetedSectorsProjectCode] [int] NULL,
	[TargetedSectorsProjectDescrEn] [nvarchar](60) NULL,
	[TargetedSectorsProjectDescrFr] [nvarchar](60) NULL,
	[TollFree] [varchar](50) NULL,
	[ToMonitoratARR] [bit] NULL,
	[TotalCommitment] [float] NULL,
	[TotalCommitmentatAutModifiedDate] [datetime] NULL,
	[TotalCommitmentatlastAuthorization] [float] NULL,
	[TradeName] [nvarchar](160) NULL,
	[UrbanorRuralSectorCode] [int] NULL,
	[UrbanorRuralSectorDescrEn] [nvarchar](20) NULL,
	[UrbanorRuralSectorDescrFr] [nvarchar](20) NULL,
	[WebSiteURL] [nvarchar](200) NULL,
	[YearEstablished] [varchar](4) NULL,
	[YearofEmployeeCount] [nvarchar](4) NULL,
	[RestrictedAccountFlag] [bit] NULL,
	[PredictedProductMeanSalesIncrease] [float] NULL,
	[PredictedProductMeanEmployeeIncrease] [float] NULL,
	[PredictedNextProduct] [nvarchar](60) NULL,
	[OwnershipGenderCalculated] [varchar](50) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_AccountProfileEntity_entity_start_date] ON [dbo].[AccountProfileEntity]
(
	[entity_start_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_AccountProfileEntity_StatusReasonCode] ON [dbo].[AccountProfileEntity]
(
	[StatusReasonCode] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_AccountProfileEntity_StatusCode] ON [dbo].[AccountProfileEntity]
(
	[StatusCode] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_AccountProfileEntity_entity_is_current] ON [dbo].[AccountProfileEntity]
(
	[entity_is_current] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [BDC_IX_AccountProfileEntity_By_entity_is_current_entity_start_date_CRMAccount_CRMId]
ON [dbo].[AccountProfileEntity] 
(
	[entity_is_current],[entity_start_date],[CRMAccount_CRMId]
) INCLUDE ([AccountSegmentDescrEn],[OverallRiskRating],[TotalCommitment])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_AccountProfileEntity_AccountEndDate] ON [dbo].[AccountProfileEntity]
( 
	[AccountId] ASC, [entity_end_date] ASC
)
INCLUDE ([CRMAccount_CRMId])
go

CREATE NONCLUSTERED INDEX [IX_AccountProfileEntity_EndDate] ON [dbo].[AccountProfileEntity]
( 
	[entity_end_date] ASC
)
INCLUDE ([entity_start_date],[entity_is_current],[AccountId],[CRMAccount_CRMId],[AccountName])
go

CREATE NONCLUSTERED INDEX [IX_AccountProfileEntity_SourceRecordMaster_entity_is_current] ON [dbo].[AccountProfileEntity](
	[SourceRecordMaster] ASC, [entity_is_current] ASC
)
GO

CREATE TABLE [dbo].[AuthorizatonTransactionMeasuresEntity](
	[TrancheNumber] [nvarchar](max) NULL,
	[AccountId] [nvarchar](max) NULL,
	[AccountOwnerId] [nvarchar](max) NULL,
	[LenderTypeCode] [nvarchar](max) NULL,
	[PrimaryObligor] [nvarchar](max) NULL,
	[TransactionEffectiveDate] [date] NULL,
	[TransactionPostingDate] [date] NULL,
	[TransactionTypeCode] [nvarchar](max) NULL,
	[TransactionClassCode] [nvarchar](max) NULL,
	[SectionId] [nvarchar](max) NULL,
	[LimitTypeCode] [nvarchar](max) NULL,
	[KeyArea] [nvarchar](max) NULL,
	[FeeSegmentId] [nvarchar](max) NULL,
	[LevelCode] [nvarchar](max) NULL,
	[TranAmount] [float] NULL,
	[TranRate] [float] NULL,
	[TranCodeValue] [nvarchar](max) NULL,
	[UserId] [nvarchar](max) NULL,
	[SourceApplicCode] [nvarchar](max) NULL,
	[SourceAccountNumber] [nvarchar](max) NULL,
	[SourceTranCode] [nvarchar](max) NULL,
	[SourceCurrencyCode] [nvarchar](max) NULL,
	[SourceTransactionAmount] [float] NULL,
	[SourceExchangeRate] [float] NULL,
	[TransactionIndividualReferenceNumber] [float] NULL,
	[entity_event_date] [date] NULL,
	[AuthorizatonTransactionMeasuresEntity_buid] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_AuthorizatonTransactionMeasuresEntity_entity_event_date] ON [dbo].[AuthorizatonTransactionMeasuresEntity]
(
	[entity_event_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE TABLE [dbo].[FinancingProductEntity](
	[FinancingProduct_CrmID] [nvarchar](max) NULL,
	[FinancingProductId] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[LoanMultiple] [int] NULL,
	[AcceptedAmount] [float] NULL,
	[AcceptedAmountBase] [float] NULL,
	[AcceptedDate] [date] NULL,
	[Account] [nvarchar](max) NULL,
	[AccountManager] [nvarchar](max) NULL,
	[AccountManagerAtAuthorization] [nvarchar](max) NULL,
	[AccountManagerAtAuthorizationName] [nvarchar](max) NULL,
	[AccountManagerName] [nvarchar](max) NULL,
	[AccountName] [nvarchar](max) NULL,
	[AuthorizationDate] [date] NULL,
	[BranchManager] [nvarchar](max) NULL,
	[BranchManageratAuthorization] [nvarchar](max) NULL,
	[BranchManageratAuthorizationName] [nvarchar](max) NULL,
	[BranchManagerName] [nvarchar](max) NULL,
	[CccFollowup] [bit] NULL,
	[CurrentM2mDate] [datetime] NULL,
	[CurrentM2mFairValue] [float] NULL,
	[CurrentM2mFairValueBase] [float] NULL,
	[CurrentM2mPerformanceRatingCode] [int] NULL,
	[DebitAdviceTypeCode] [int] NULL,
	[DisbursementLevelOfAnalysisCode] [int] NULL,
	[DisbursementStatusCode] [int] NULL,
	[DisbursementToDate] [float] NULL,
	[ExchangeRate] [float] NULL,
	[ExternalReference] [nvarchar](max) NULL,
	[FirstDisbursementDate] [date] NULL,
	[HasDisbursementServiceRequest] [bit] NULL,
	[Impaired] [bit] NULL,
	[InterestAdjustmentDate] [date] NULL,
	[InterimFairValue] [int] NULL,
	[InterimM2MDate] [datetime] NULL,
	[IrrAtAuthorization] [float] NULL,
	[ModifiedIRR] [float] NULL,
	[ModifiedIRRDate] [datetime] NULL,
	[IsPreQualified] [bit] NULL,
	[IsRestructuredLoan] [bit] NULL,
	[IsSecurityCompleted] [bit] NULL,
	[Lapsingdate] [date] NULL,
	[LastAuthorizedAmount] [float] NULL,
	[LastDisbursementDate] [date] NULL,
	[LoanAmount] [float] NULL,
	[LoanPurposeCode] [int] NULL,
	[LoanTypeCode] [int] NULL,
	[MaturityDate] [date] NULL,
	[NameOfSolicitor] [nvarchar](max) NULL,
	[NewMoney] [float] NULL,
	[OnPap] [bit] NULL,
	[OperatingUnitAtAuthorizationId] [nvarchar](max) NULL,
	[OperatingUnitId] [nvarchar](max) NULL,
	[Opportunity] [nvarchar](max) NULL,
	[OpportunityName] [nvarchar](max) NULL,
	[OriginatingUnitAtAuthorizationId] [nvarchar](max) NULL,
	[OriginatingUnitId] [nvarchar](max) NULL,
	[OutstandingBalance] [float] NULL,
	[PartnershipAllianceCode] [int] NULL,
	[PreAuthorizedLoanAmount] [float] NULL,
	[PreviousM2mDate] [datetime] NULL,
	[PreviousM2mFairValue] [float] NULL,
	[PreviousM2mPerformanceRatingCode] [int] NULL,
	[ProductCategoryCode] [int] NULL,
	[ProductFeatureTypeCode] [int] NULL,
	[ProductId] [nvarchar](max) NULL,
	[ProductIdName] [nvarchar](max) NULL,
	[ProductInitiativeCode] [int] NULL,
	[RealizedIRR] [float] NULL,
	[RealizedIRRDate] [datetime] NULL,
	[RenewalDate] [date] NULL,
	[ReturnTypeCode] [int] NULL,
	[SalesStage] [nvarchar](max) NULL,
	[SalesStageName] [nvarchar](max) NULL,
	[SecurityTakingMethodCode] [int] NULL,
	[StandbyFeeDate] [date] NULL,
	[StatusCode] [int] NULL,
	[StatusReasonCode] [int] NULL,
	[StatusChangeDate] [datetime] NULL,
	[TransactionCurrencyId] [nvarchar](max) NULL,
	[Undisbursed] [float] NULL,
	[Variance] [float] NULL,
	[WrittenOffDate] [date] NULL,
	[OwnerId] [nvarchar](max) NULL,
	[OwnerIdName] [nvarchar](max) NULL,
	[OwnerIdType] [int] NULL,
	[CreatedBy] [nvarchar](max) NULL,
	[CreatedByName] [nvarchar](max) NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedOnBehalfBy] [nvarchar](max) NULL,
	[CreatedOnBehalfByName] [nvarchar](max) NULL,
	[ModifiedBy] [nvarchar](max) NULL,
	[ModifiedByName] [nvarchar](max) NULL,
	[ModifiedOn] [datetime] NULL,
	[FinancingProductEntity_buid] [nvarchar](max) NULL,
	[FinancingProductEntity_oid] [nvarchar](max) NULL,
	[CurrentM2mPerformanceRatingDescrEn] [nvarchar](max) NULL,
	[CurrentM2mPerformanceRatingDescrFr] [nvarchar](max) NULL,
	[DebitAdviceTypeDescrEn] [nvarchar](max) NULL,
	[DebitAdviceTypeDescrFr] [nvarchar](max) NULL,
	[DisbursementLevelOfAnalysisDescrEn] [nvarchar](max) NULL,
	[DisbursementLevelOfAnalysisDescrFr] [nvarchar](max) NULL,
	[DisbursementStatusDescrEn] [nvarchar](max) NULL,
	[DisbursementStatusDescrFr] [nvarchar](max) NULL,
	[LoanPurposeDescrEn] [nvarchar](max) NULL,
	[LoanPurposeDescrFr] [nvarchar](max) NULL,
	[LoanTypeDescrEn] [nvarchar](max) NULL,
	[LoanTypeDescrFr] [nvarchar](max) NULL,
	[PartnershipAllianceDescrEn] [nvarchar](max) NULL,
	[PartnershipAllianceDescrFr] [nvarchar](max) NULL,
	[PreviousM2mPerformanceRatingDescrEn] [nvarchar](max) NULL,
	[PreviousM2mPerformanceRatingDescrFr] [nvarchar](max) NULL,
	[ProductCategoryDescrEn] [nvarchar](max) NULL,
	[ProductCategoryDescrFr] [nvarchar](max) NULL,
	[ProductFeatureTypeDescrEn] [nvarchar](max) NULL,
	[ProductFeatureTypeDescrFr] [nvarchar](max) NULL,
	[ProductInitiativeDescrEn] [nvarchar](max) NULL,
	[ProductInitiativeDescrFr] [nvarchar](max) NULL,
	[ReturnTypeDescrEn] [nvarchar](max) NULL,
	[ReturnTypeDescrFr] [nvarchar](max) NULL,
	[SecurityTakingMethodDescrEn] [nvarchar](max) NULL,
	[SecurityTakingMethodDescrFr] [nvarchar](max) NULL,
	[StatusDescrEn] [nvarchar](max) NULL,
	[StatusDescrFr] [nvarchar](max) NULL,
	[StatusReasonDescrEn] [nvarchar](max) NULL,
	[StatusReasonDescrFr] [nvarchar](max) NULL,
	[entity_start_date] [datetime] NULL,
	[entity_end_date] [datetime] NULL,
	[FinancingProductEntity_uid] [nvarchar](max) NULL,
	[entity_is_deleted] [bit] NULL,
	[entity_is_current] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_FinancingProductEntity_entity_start_date] ON [dbo].[FinancingProductEntity]
(
	[entity_start_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_FinancingProductEntity_entity_is_current] ON [dbo].[FinancingProductEntity]
(
	[entity_is_current] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE TABLE [dbo].[IndustryRefEntity](
	[DateBegIndus] [date] NULL,
	[SicN] [nvarchar](max) NULL,
	[IndustryType] [nvarchar](max) NULL,
	[Exporter] [nvarchar](max) NULL,
	[IndustryDescEnglish] [nvarchar](max) NULL,
	[IndustryDescFrench] [nvarchar](max) NULL,
	[BDCGroup45] [nvarchar](max) NULL,
	[BDCDescription45EnglishLong] [nvarchar](max) NULL,
	[BDCDescription45FrenchLong] [nvarchar](max) NULL,
	[BDCDescription45EnglishShort] [nvarchar](max) NULL,
	[BDCDescription45FrenchShort] [nvarchar](max) NULL,
	[MarketingGroup17Code] [nvarchar](max) NULL,
	[MarketingGroup17English] [nvarchar](max) NULL,
	[MarketingGroup17French] [nvarchar](max) NULL,
	[Analytix11Code] [nvarchar](max) NULL,
	[Analytix11English] [nvarchar](max) NULL,
	[Analytix11French] [nvarchar](max) NULL,
	[FinanceGroup10] [nvarchar](max) NULL,
	[FinanceGroupDescription10English] [nvarchar](max) NULL,
	[FinanceGroupDescription10French] [nvarchar](max) NULL,
	[SequenceMktgGroup] [nvarchar](max) NULL,
	[SequenceAnalytix] [nvarchar](max) NULL,
	[IndustrySubGroupCode] [nvarchar](max) NULL,
	[IndustrySubGroupDescrEN] [nvarchar](max) NULL,
	[IndustrySubGroupDescrFR] [nvarchar](max) NULL,
	[IndustrySubGroupShortDescrEN] [nvarchar](max) NULL,
	[IndustrySubGroupShortDescrFR] [nvarchar](max) NULL,
	[IndustryPRMGroupCode] [nvarchar](max) NULL,
	[IndustryPRMGroupDescrEN] [nvarchar](max) NULL,
	[IndustryPRMGroupDescrFR] [nvarchar](max) NULL,
	[NAICSUSFlag] [nvarchar](max) NULL,
	[entity_lineage_id] [nvarchar](max) NULL,
	[entity_load_timestamp] [datetime] NULL,
	[IndustryRefEntity_oid] [nvarchar](max) NULL,
	[IndustryRefEntity_buid] [nvarchar](max) NULL,
	[entity_start_date] [datetime] NULL,
	[entity_end_date] [datetime] NULL,
	[entity_is_current] [bit] NULL,
	[entity_is_deleted] [bit] NULL,
	[entity_created_on] [datetime] NULL,
	[entity_modified_on] [datetime] NULL,
	[IndustryRefEntity_uid] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_IndustryRefEntity_entity_start_date] ON [dbo].[IndustryRefEntity]
(
	[entity_start_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_IndustryRefEntity_entity_is_current] ON [dbo].[IndustryRefEntity]
(
	[entity_is_current] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE TABLE [dbo].[LoanCustomerEntity](
	[CustomerNumber] [nvarchar](max) NULL,
	[AccountBusinessKey] [nvarchar](max) NULL,
	[OriginatingUnitCode] [nvarchar](max) NULL,
	[OperatingUnitCode] [nvarchar](max) NULL,
	[CustomerCommitment] [nvarchar](max) NULL,
	[CustomerTotalCommitment] [float] NULL,
	[CustomerTotalCommitmentCloselyRelated] [float] NULL,
	[LoanCustomerEntity_buid] [nvarchar](max) NULL,
	[LoanCustomerEntity_oid] [nvarchar](max) NULL,
	[entity_start_date] [datetime] NULL,
	[entity_end_date] [datetime] NULL,
	[LoanCustomerEntity_uid] [nvarchar](max) NULL,
	[entity_is_deleted] [bit] NULL,
	[entity_is_current] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LoanCustomerEntity_entity_start_date] ON [dbo].[LoanCustomerEntity]
(
	[entity_start_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LoanCustomerEntity_entity_is_current] ON [dbo].[LoanCustomerEntity]
(
	[entity_is_current] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE TABLE [dbo].[LoanEntity](
	[AccountNumber] [nvarchar](max) NULL,
	[AbacusCustomerNumber] [nvarchar](max) NULL,
	[LoanMultiple] [nvarchar](max) NULL,
	[ActiveLoanFlag] [bit] NULL,
	[CustomerTypeCode] [int] NULL,
	[AuthorizationDate] [datetime] NULL,
	[MaturityDate] [date] NULL,
	[ReductionDate] [date] NULL,
	[CancellationDate] [date] NULL,
	[CancellationAmount] [float] NULL,
	[AcceptanceDate] [date] NULL,
	[GrossLoanAmount] [float] NULL,
	[NetLoanAmount] [float] NULL,
	[NewMoneyAmount] [float] NULL,
	[ProductId] [bigint] NULL,
	[FinancingProductBusinessKey] [nvarchar](max) NULL,
	[RequestType] [nvarchar](max) NULL,
	[ServiceRequestBusinessKey] [nvarchar](max) NULL,
	[TotalCommitmentCloselyRelatedAtAuthorization] [float] NULL,
	[AccountBusinessKey] [nvarchar](max) NULL,
	[LoanPurposeDescr] [nvarchar](max) NULL,
	[LoanPurposeCode] [nvarchar](max) NULL,
	[AdministrativeTypeDescr] [nvarchar](max) NULL,
	[AdministrativeTypeCode] [nvarchar](max) NULL,
	[LoanProductDescr] [nvarchar](max) NULL,
	[LoanProductCode] [nvarchar](max) NULL,
	[AllianceDescr] [nvarchar](max) NULL,
	[AllianceCode] [nvarchar](max) NULL,
	[LoanInitiativeDescr] [nvarchar](max) NULL,
	[LoanInitiativeTypeCode] [nvarchar](max) NULL,
	[LoanAuthorizationDateBooked] [date] NULL,
	[GLAlliancePortfolioCode] [nvarchar](max) NULL,
	[PortfolioId] [nvarchar](max) NULL,
	[DateInactive] [date] NULL,
	[OriginatingUnitNumberAtAuthorization] [nvarchar](max) NULL,
	[OriginatingUnitAtAuthName] [nvarchar](max) NULL,
	[OperatingUnitNumberAtAuthorization] [nvarchar](max) NULL,
	[OperatingUnitAtAuthName] [nvarchar](max) NULL,
	[ManagementUnitIdAtAuthorization] [nvarchar](max) NULL,
	[ChangedDate] [date] NULL,
	[LoanEntity_buid] [nvarchar](max) NULL,
	[LoanEntity_oid] [nvarchar](max) NULL,
	[AcceptedAmount] [float] NULL,
	[OpportunityBusinessKey] [nvarchar](max) NULL,
	[ApplicationDate] [datetime] NULL,
	[entity_start_date] [datetime] NULL,
	[entity_end_date] [datetime] NULL,
	[LoanEntity_uid] [nvarchar](max) NULL,
	[entity_is_deleted] [bit] NULL,
	[entity_is_current] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LoanEntity_entity_start_date] ON [dbo].[LoanEntity]
(
	[entity_start_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LoanEntity_entity_is_current] ON [dbo].[LoanEntity]
(
	[entity_is_current] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [BDC_IX_LoanEntity_By_entity_is_current_AccountBusinessKey] ON [dbo].[LoanEntity]
(
	[entity_is_current] ASC
) INCLUDE (AccountBusinessKey, AbacusCustomerNumber) 
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE TABLE [dbo].[LoanPurposeTableRefEntity](
	[LoanPurposeCode] [nvarchar](max) NULL,
	[LoanPurposeDescription] [nvarchar](max) NULL,
	[LoanPurposeGroupId] [nvarchar](max) NULL,
	[LoanPurposeGroupDescr] [nvarchar](max) NULL,
	[LoanPurpGrpMarketingId] [nvarchar](max) NULL,
	[LoanPurpGrpMarketingDescrEn] [nvarchar](max) NULL,
	[LoanPurpGrpMarketingDescrFr] [nvarchar](max) NULL,
	[LoanPurposeGroupDescrFr] [nvarchar](max) NULL,
	[entity_lineage_id] [nvarchar](max) NULL,
	[entity_load_timestamp] [datetime] NULL,
	[LoanPurposeTableRefEntity_oid] [nvarchar](max) NULL,
	[LoanPurposeTableRefEntity_buid] [nvarchar](max) NULL,
	[entity_start_date] [datetime] NULL,
	[entity_end_date] [datetime] NULL,
	[entity_is_current] [bit] NULL,
	[entity_is_deleted] [bit] NULL,
	[entity_created_on] [datetime] NULL,
	[entity_modified_on] [datetime] NULL,
	[LoanPurposeTableRefEntity_uid] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LoanPurposeTableRefEntity_entity_start_date] ON [dbo].[LoanPurposeTableRefEntity]
(
	[entity_start_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LoanPurposeTableRefEntity_entity_is_current] ON [dbo].[LoanPurposeTableRefEntity]
(
	[entity_is_current] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE TABLE [dbo].[LoanTrancheAttributesEntity](
	[PortfolioId] [nvarchar](max) NULL,
	[TrancheNumber] [nvarchar](max) NULL,
	[Tranche] [nvarchar](max) NULL,
	[HasLoan] [nvarchar](max) NULL,
	[AccountNumber] [nvarchar](max) NULL,
	[AccrualScheduleId] [nvarchar](max) NULL,
	[AccrualScheduleStatusCode] [int] NULL,
	[AccrualCategoryCode] [nvarchar](max) NULL,
	[BalanceCategoryCode] [nvarchar](max) NULL,
	[BaseBalanceToAccrueOn] [nvarchar](max) NULL,
	[FloatingRateIndexCode] [nvarchar](max) NULL,
	[AccountStructureCode] [nvarchar](max) NULL,
	[PricingTemplateId] [nvarchar](max) NULL,
	[CurrencyCode] [nvarchar](max) NULL,
	[DateBooked] [date] NULL,
	[EffectiveDate] [date] NULL,
	[InterestRate] [float] NULL,
	[BaseRate] [float] NULL,
	[InterestRateVariance] [float] NULL,
	[CostOfFundsRate] [float] NULL,
	[CurrentPrincipalBalance] [float] NULL,
	[InterestBalance] [float] NULL,
	[StatusCode] [int] NULL,
	[InstrumentTypeCode] [int] NULL,
	[MaturityDate] [date] NULL,
	[InterestAdjustmentDate] [date] NULL,
	[PortfolioType] [nvarchar](max) NULL,
	[ServicingUnit] [nvarchar](max) NULL,
	[BranchIdentification] [nvarchar](max) NULL,
	[ServicingUnitSection] [nvarchar](max) NULL,
	[BankLiabilityTypeCode] [int] NULL,
	[CustomerLiabilityTypeCode] [int] NULL,
	[LoanTrancheAttributesEntity_buid] [nvarchar](max) NULL,
	[LoanTrancheAttributesEntity_oid] [nvarchar](max) NULL,
	[entity_start_date] [datetime] NULL,
	[entity_end_date] [datetime] NULL,
	[LoanTrancheAttributesEntity_uid] [nvarchar](max) NULL,
	[entity_is_deleted] [bit] NULL,
	[entity_is_current] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LoanTrancheAttributesEntity_entity_start_date] ON [dbo].[LoanTrancheAttributesEntity]
(
	[entity_start_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LoanTrancheAttributesEntity_entity_is_current] ON [dbo].[LoanTrancheAttributesEntity]
(
	[entity_is_current] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE TABLE [dbo].[LoanTrancheMeasuresEntity](
	[AccountId] [nvarchar](max) NULL,
	[TrancheNumber] [nvarchar](max) NULL,
	[HasLoan] [nvarchar](max) NULL,
	[PrincipalOutstanding] [float] NULL,
	[SpecificProvision] [float] NULL,
	[LoanTrancheMeasuresEntity_buid] [nvarchar](max) NULL,
	[LoanTrancheMeasuresEntity_oid] [nvarchar](max) NULL,
	[entity_start_date] [datetime] NULL,
	[entity_end_date] [datetime] NULL,
	[LoanTrancheMeasuresEntity_uid] [nvarchar](max) NULL,
	[entity_is_deleted] [bit] NULL,
	[entity_is_current] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LoanTrancheMeasuresEntity_entity_start_date] ON [dbo].[LoanTrancheMeasuresEntity]
(
	[entity_start_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LoanTrancheMeasuresEntity_entity_is_current] ON [dbo].[LoanTrancheMeasuresEntity]
(
	[entity_is_current] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE TABLE [dbo].[LoanTrancheTransactionEntity](
	[PortfolioId] [nvarchar](max) NULL,
	[TrancheNumber] [nvarchar](max) NULL,
	[TransactionNumber] [float] NULL,
	[GroupNumber] [float] NULL,
	[UpdateIdentifier] [float] NULL,
	[InterestSchedule] [nvarchar](max) NULL,
	[BalanceCategoryCode] [nvarchar](max) NULL,
	[AccountId] [nvarchar](max) NULL,
	[TransactionClassCode] [nvarchar](max) NULL,
	[TransactionCode] [nvarchar](max) NULL,
	[TransactionDescription] [nvarchar](max) NULL,
	[TransactionAmount] [float] NULL,
	[TransactionRate] [float] NULL,
	[TransactionPercentageValue] [float] NULL,
	[ReversalFlag] [nvarchar](max) NULL,
	[TransactionDate] [date] NULL,
	[DatePosted] [date] NULL,
	[LoanTrancheTransactionEntity_buid] [nvarchar](max) NULL,
	[LoanTrancheTransactionEntity_oid] [nvarchar](max) NULL,
	[entity_start_date] [datetime] NULL,
	[entity_end_date] [datetime] NULL,
	[LoanTrancheTransactionEntity_uid] [nvarchar](max) NULL,
	[entity_is_deleted] [bit] NULL,
	[entity_is_current] [bit] NULL,
	[entity_created_on] [datetime] NULL,
	[entity_modified_on] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LoanTrancheTransactionEntity_entity_start_date] ON [dbo].[LoanTrancheTransactionEntity]
(
	[entity_start_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LoanTrancheTransactionEntity_entity_is_current] ON [dbo].[LoanTrancheTransactionEntity]
(
	[entity_is_current] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE TABLE [dbo].[LoanTransactionMeasuresEntity](
	[LoanTransactionMeasuresEntity_buid] [nvarchar](max) NULL,
	[LoanTransactionMeasuresEntity_oid] [nvarchar](max) NULL,
	[TrancheNumber] [nvarchar](max) NULL,
	[AccountId] [nvarchar](max) NULL,
	[AccountOwnerId] [nvarchar](max) NULL,
	[LenderTypeCode] [nvarchar](max) NULL,
	[PrimaryObligor] [nvarchar](max) NULL,
	[TransactionEffectiveDate] [date] NULL,
	[TransactionPostingDate] [date] NULL,
	[TransactionTypeCode] [nvarchar](max) NULL,
	[TransactionClassCode] [nvarchar](max) NULL,
	[SectionId] [nvarchar](max) NULL,
	[LimitTypeCode] [nvarchar](max) NULL,
	[KeyArea] [nvarchar](max) NULL,
	[FeeSegmentId] [nvarchar](max) NULL,
	[LevelCode] [nvarchar](max) NULL,
	[TranAmount] [float] NULL,
	[TranRate] [float] NULL,
	[TranCodeValue] [nvarchar](max) NULL,
	[UserId] [nvarchar](max) NULL,
	[SourceApplicCode] [nvarchar](max) NULL,
	[SourceAccountNumber] [nvarchar](max) NULL,
	[SourceTranCode] [nvarchar](max) NULL,
	[SourceCurrencyCode] [nvarchar](max) NULL,
	[SourceTransactionAmount] [float] NULL,
	[SourceExchangeRate] [float] NULL,
	[TransactionIndividualReferenceNumber] [float] NULL,
	[TransactionDescription] [nvarchar](max) NULL,
	[entity_start_date] [datetime] NULL,
	[entity_end_date] [datetime] NULL,
	[entity_is_current] [bit] NULL,
	[entity_is_deleted] [bit] NULL,
	[entity_created_on] [datetime] NULL,
	[entity_modified_on] [datetime] NULL,
	[LoanTransactionMeasuresEntity_uid] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LoanTransactionMeasuresEntity_entity_start_date] ON [dbo].[LoanTransactionMeasuresEntity]
(
	[entity_start_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LoanTransactionMeasuresEntity_entity_is_current] ON [dbo].[LoanTransactionMeasuresEntity]
(
	[entity_is_current] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE TABLE [dbo].[LoanTypeEntity](
	[id] [bigint] NULL,
	[changeddate] [datetime] NULL,
	[crmid] [nvarchar](max) NULL,
	[loantype] [nvarchar](max) NULL,
	[createddate] [datetime] NULL,
	[abacusid] [nvarchar](max) NULL,
	[system_owner] [bigint] NULL,
	[system_changedby] [bigint] NULL,
	[active] [bit] NULL,
	[entity_load_timestamp] [datetime] NULL,
	[LoanTypeEntity_oid] [nvarchar](max) NULL,
	[LoanTypeEntity_buid] [nvarchar](max) NULL,
	[entity_start_date] [datetime] NULL,
	[LoanTypeEntity_uid] [nvarchar](max) NULL,
	[entity_is_deleted] [bit] NULL,
	[entity_is_current] [bit] NULL,
	[entity_end_date] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LoanTypeEntity_entity_start_date] ON [dbo].[LoanTypeEntity]
(
	[entity_start_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LoanTypeEntity_entity_is_current] ON [dbo].[LoanTypeEntity]
(
	[entity_is_current] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE TABLE [dbo].[OdsWatermarks](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[TableName] [varchar](255) NOT NULL,
	[ModifiedOn] [datetime2](7) NOT NULL
) ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX [IX_OdsWatermarks_TableName] ON [dbo].[OdsWatermarks]
(
	[TableName] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE TABLE [dbo].[OfferEntity](
	[LoanOfferId] [nvarchar](max) NULL,
	[CreatedBy] [nvarchar](max) NULL,
	[CreatedByName] [nvarchar](max) NULL,
	[CreatedOn] [datetime] NULL,
	[ExchangeRate] [float] NULL,
	[Account] [nvarchar](max) NULL,
	[AccountName] [nvarchar](max) NULL,
	[FinalLoanPurposeAmount] [float] NULL,
	[FinalLoanPurposeAmountBase] [float] NULL,
	[LoanPurposeCode] [int] NULL,
	[MinLoanPurposeAmount] [float] NULL,
	[MinLoanPurposeAmountBase] [float] NULL,
	[LoanOfferDescription] [nvarchar](max) NULL,
	[OfferAmountContractVersion] [int] NULL,
	[OfferAmountLoggingID] [int] NULL,
	[OfferQualificationLoggingID] [int] NULL,
	[OfferQualificationStatusCode] [bit] NULL,
	[OpportunityId] [nvarchar](max) NULL,
	[OpportunityName] [nvarchar](max) NULL,
	[OverallOfferAmount] [float] NULL,
	[OverallOfferAmountBase] [float] NULL,
	[Source] [int] NULL,
	[ModifiedBy] [nvarchar](max) NULL,
	[ModifiedByName] [nvarchar](max) NULL,
	[ModifiedOn] [datetime] NULL,
	[OwnerId] [nvarchar](max) NULL,
	[OwnerIdDsc] [int] NULL,
	[OwnerIdName] [nvarchar](max) NULL,
	[OwnerIdType] [int] NULL,
	[OwningBusinessUnit] [nvarchar](max) NULL,
	[OwningTeam] [nvarchar](max) NULL,
	[OwningUser] [nvarchar](max) NULL,
	[StatusCode] [int] NULL,
	[StatusReasonCode] [int] NULL,
	[TransactionCurrencyId] [nvarchar](max) NULL,
	[TransactionCurrencyIdName] [nvarchar](max) NULL,
	[OfferEntity_buid] [nvarchar](max) NULL,
	[OfferEntity_oid] [nvarchar](max) NULL,
	[OfferQualificationStatusDescrEn] [nvarchar](max) NULL,
	[OfferQualificationStatusDescrFr] [nvarchar](max) NULL,
	[LoanPurposeDescrEn] [nvarchar](max) NULL,
	[LoanPurposeDescrFr] [nvarchar](max) NULL,
	[StatusDescrEn] [nvarchar](max) NULL,
	[StatusDescrFr] [nvarchar](max) NULL,
	[StatusReasonDescrEn] [nvarchar](max) NULL,
	[StatusReasonDescrFr] [nvarchar](max) NULL,
	[entity_start_date] [datetime] NULL,
	[entity_end_date] [datetime] NULL,
	[OfferEntity_uid] [nvarchar](max) NULL,
	[entity_is_deleted] [bit] NULL,
	[entity_is_current] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_OfferEntity_entity_start_date] ON [dbo].[OfferEntity]
(
	[entity_start_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_OfferEntity_entity_is_current] ON [dbo].[OfferEntity]
(
	[entity_is_current] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE TABLE [dbo].[OperatingUnitRefEntity](
	[AdminDeptAbacusId] [nvarchar](max) NULL,
	[AdminDeptId] [int] NULL,
	[AdminDeptName] [nvarchar](max) NULL,
	[AdminDeptShortName] [nvarchar](max) NULL,
	[AdminDeptType] [nvarchar](max) NULL,
	[AdminDeptAreaId] [nvarchar](max) NULL,
	[AdminDeptAreaName] [nvarchar](max) NULL,
	[AdminDeptRegionId] [nvarchar](max) NULL,
	[AdminDeptRegionName] [nvarchar](max) NULL,
	[OperatingModel] [nvarchar](max) NULL,
	[OperatingUnitRefEntity_buid] [nvarchar](max) NULL,
	[OperatingUnitRefEntity_oid] [nvarchar](max) NULL,
	[entity_start_date] [datetime] NULL,
	[entity_end_date] [datetime] NULL,
	[entity_is_current] [bit] NULL,
	[entity_is_deleted] [bit] NULL,
	[entity_created_on] [datetime] NULL,
	[entity_modified_on] [datetime] NULL,
	[OperatingUnitRefEntity_uid] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_OperatingUnitRefEntity_entity_start_date] ON [dbo].[OperatingUnitRefEntity]
(
	[entity_start_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_OperatingUnitRefEntity_entity_is_current] ON [dbo].[OperatingUnitRefEntity]
(
	[entity_is_current] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE TABLE [dbo].[OrganizationRefEntity](
	[OriginatingUnitNumberAbacus] [nvarchar](max) NULL,
	[OriginatingUnitNumberCREM] [nvarchar](max) NULL,
	[OriginatingUnitNameEnglish] [nvarchar](max) NULL,
	[OriginatingUnitNameFrench] [nvarchar](max) NULL,
	[OriginatingUnitStatusFlag] [nvarchar](max) NULL,
	[Originating_Unit_Sequence_Id] [nvarchar](max) NULL,
	[ConsolidatedOriginatingUnitNumber] [nvarchar](max) NULL,
	[ConsolidatedOriginatingUnit] [nvarchar](max) NULL,
	[ConsolidatedOriginatingUnitFrench] [nvarchar](max) NULL,
	[AreaNumber] [nvarchar](max) NULL,
	[AreaNameEnglish] [nvarchar](max) NULL,
	[AreaNameFrench] [nvarchar](max) NULL,
	[Area_Sequence_Id] [nvarchar](max) NULL,
	[SubRegionNumber] [nvarchar](max) NULL,
	[SubRegionName] [nvarchar](max) NULL,
	[SubRegionNameFrench] [nvarchar](max) NULL,
	[OperationRegionNumber] [nvarchar](max) NULL,
	[OperationRegionName] [nvarchar](max) NULL,
	[OperationRegionNameFrench] [nvarchar](max) NULL,
	[TotalBankNumber] [nvarchar](max) NULL,
	[TotalBankName] [nvarchar](max) NULL,
	[ProvinceTerritoryId] [nvarchar](max) NULL,
	[Province/Territory] [nvarchar](max) NULL,
	[StatusId] [nvarchar](max) NULL,
	[StatusDescr] [nvarchar](max) NULL,
	[TypeId] [nvarchar](max) NULL,
	[TypeDescr] [nvarchar](max) NULL,
	[SeqOriginatingUnit] [nvarchar](max) NULL,
	[SeqConsolidatedUnit] [nvarchar](max) NULL,
	[SeqArea] [nvarchar](max) NULL,
	[SeqSubRegion] [nvarchar](max) NULL,
	[SeqOperatingReg] [nvarchar](max) NULL,
	[SeqBank] [nvarchar](max) NULL,
	[SeqDistrict] [nvarchar](max) NULL,
	[DistrictNumber] [nvarchar](max) NULL,
	[DistrictNameEnglish] [nvarchar](max) NULL,
	[DistrictNameFrench] [nvarchar](max) NULL,
	[DisplayFlagOriginatingUnit] [nvarchar](max) NULL,
	[DisplayFlagConsolidatedUnit] [nvarchar](max) NULL,
	[DisplayFlagDistrict] [nvarchar](max) NULL,
	[DisplayFlagArea] [nvarchar](max) NULL,
	[DisplayFlagSubRegion] [nvarchar](max) NULL,
	[DisplayFlagOperatingRegion] [nvarchar](max) NULL,
	[GMAFlag] [nvarchar](max) NULL,
	[entity_lineage_id] [nvarchar](max) NULL,
	[entity_load_timestamp] [datetime] NULL,
	[OrganizationRefEntity_oid] [nvarchar](max) NULL,
	[OrganizationRefEntity_buid] [nvarchar](max) NULL,
	[entity_start_date] [datetime] NULL,
	[entity_end_date] [datetime] NULL,
	[entity_is_current] [bit] NULL,
	[entity_is_deleted] [bit] NULL,
	[entity_created_on] [datetime] NULL,
	[entity_modified_on] [datetime] NULL,
	[OrganizationRefEntity_uid] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_OrganizationRefEntity_entity_start_date] ON [dbo].[OrganizationRefEntity]
(
	[entity_start_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_OrganizationRefEntity_entity_is_current] ON [dbo].[OrganizationRefEntity]
(
	[entity_is_current] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE TABLE [dbo].[RiskFinancialStatementCurrentEntity](
	[RiskFinancialStatementCurrentEntity_buid] [nvarchar](max) NULL,
	[RiskFinancialStatementCurrentEntity_oid] [nvarchar](max) NULL,
	[RiskFinancialStatementCurrentEntity_uid] [nvarchar](max) NULL,
	[entity_start_date] [datetime] NULL,
	[entity_end_date] [datetime] NULL,
	[entity_is_current] [bit] NULL,
	[entity_is_deleted] [bit] NULL,
	[AccountCrmId] [nvarchar](max) NULL,
	[ServiceRequestCrmId] [int] NULL,
	[RiskEvaluationId] [bigint] NULL,
	[ServiceRequestAuthorizationDate] [datetime] NULL,
	[AdditionalCptdAmount] [float] NULL,
	[AdditionalInterestamount] [float] NULL,
	[AdjustedEbitdaFromGuarantorsAmount] [float] NULL,
	[AvailableFundsFromGuarantorsAmount] [float] NULL,
	[CptdSavingsAmount] [float] NULL,
	[CurrentLiabilitiesAmount] [float] NULL,
	[CurrentLiabilitiesToSales] [float] NULL,
	[CurrentLiabilitiesToSalesDisplay] [float] NULL,
	[CurrentLiabilitiesToSalesOver10RiskCalc] [float] NULL,
	[DeferredTaxAmount] [float] NULL,
	[DepreciationAmount] [float] NULL,
	[DividendsAmount] [float] NULL,
	[ExistingCptdAdjFromGuarantorsAmount] [float] NULL,
	[ExistingCptdAmount] [float] NULL,
	[ExistingCptdFromGuarantorsAmount] [float] NULL,
	[ExtraordinaryItems] [float] NULL,
	[FccrNumeratorFromGuarantorsAmount] [float] NULL,
	[FinancialStatementDate] [datetime] NULL,
	[GainsLossesOnSalesOfAssetsAmount] [float] NULL,
	[IncomeTaxExpenseRecoveryAmount] [float] NULL,
	[InterestExpenseAmount] [float] NULL,
	[InterestExpenseFromGuarantorsAmount] [float] NULL,
	[InterestSavingsAmount] [float] NULL,
	[InventoryToSales] [float] NULL,
	[NetOperatingIncomeAmount] [float] NULL,
	[NetProfitAmount] [float] NULL,
	[NewLoansToShareholders] [float] NULL,
	[OriginalAdditionalCptdAmount] [float] NULL,
	[OriginalAdditionalInterestAmount] [float] NULL,
	[ProformaCptdIncludingGuarantors] [float] NULL,
	[ProformaInterestIncludingGuarantors] [float] NULL,
	[ReimbursementOfLoansFromShareholders] [float] NULL,
	[RentalIncomeAmount] [float] NULL,
	[RentSavingsAmount] [float] NULL,
	[RentSavingsFromGuarantorsAmount] [float] NULL,
	[SubmetaObjectName] [nvarchar](max) NULL,
	[SuggestedAdjEbitda] [float] NULL,
	[SuggestedAdjustedEbitdaIncludingGuarantors] [float] NULL,
	[SuggestedAvailableFundsAmount] [float] NULL,
	[SuggestedAvailableFundsFromMainBorrower] [float] NULL,
	[SuggestedCoverageWithoutProgramAmount] [float] NULL,
	[SuggestedCoverageWithProgramFullAmount] [float] NULL,
	[SuggestedEbitda] [float] NULL,
	[SuggestedFccrIncludingGuarantors] [float] NULL,
	[SuggestedFccrNumerator] [float] NULL,
	[SuggestedFccrNumeratorIncludingGuarantors] [float] NULL,
	[SuggestedProformaCoverageRatio] [float] NULL,
	[SuggestedTotalAdjustmentsToAvailableFundsAmount] [float] NULL,
	[SuggestedTotalAdjustmentsToExistingCptdAmount] [float] NULL,
	[SuggestedTotalAdjustmentToAdditionalCptdAndInterestAmount] [float] NULL,
	[SuggestedTotalDebtService] [float] NULL,
	[SuggestedTotalExistingCptd] [float] NULL,
	[TotalAssets] [float] NULL,
	[TotalCptd12MonthsAmount] [float] NULL,
	[TotalInterest12MonthsAmount] [float] NULL,
	[TotalInventoryAmount] [float] NULL,
	[TotalLiabilities] [float] NULL,
	[TotalSalesAmount] [float] NULL,
	[UnfundedCapex] [float] NULL,
	[CreatedDate] [datetime] NULL,
	[ChangedDate] [datetime] NULL,
	[SystemChangedBy] [bigint] NULL,
	[SystemOwner] [bigint] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_RiskFinancialStatementCurrentEntity_entity_start_date] ON [dbo].[RiskFinancialStatementCurrentEntity]
(
	[entity_start_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_RiskFinancialStatementCurrentEntity_entity_is_current] ON [dbo].[RiskFinancialStatementCurrentEntity]
(
	[entity_is_current] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE TABLE [dbo].[RiskFinancialStatementGtcCurrentEntity](
	[RiskFinancialStatementGtcCurrentEntity_buid] [nvarchar](max) NULL,
	[RiskFinancialStatementGtcCurrentEntity_oid] [nvarchar](max) NULL,
	[RiskFinancialStatementGtcCurrentEntity_uid] [nvarchar](max) NULL,
	[entity_start_date] [datetime] NULL,
	[entity_end_date] [datetime] NULL,
	[entity_is_current] [bit] NULL,
	[entity_is_deleted] [bit] NULL,
	[AccountCrmId] [nvarchar](max) NULL,
	[ServiceRequestCrmId] [int] NULL,
	[RiskEvaluationId] [bigint] NULL,
	[SuggestedEbitAmount] [float] NULL,
	[TotalAdjustedEbitFromOtherGuarantorsAmount] [float] NULL,
	[TotalAvailableFundsFromOtherGuarantorsAmount] [float] NULL,
	[SuggestedAdjustedEbitAmount] [float] NULL,
	[ShorttermInterestExpenseAmount] [float] NULL,
	[LongtermInterestExpenseAmount] [float] NULL,
	[SuggestedGrowthPercentage] [float] NULL,
	[TotalShorttermInterestExpenseFromOtherGuarantorsAmount] [float] NULL,
	[SuggestedAvailableFundsCoverageRatio] [float] NULL,
	[SuggestedTotalShorttermInterestAmount] [float] NULL,
	[CurrentTaxAmount] [float] NULL,
	[SuggestedAdjustedEbitdaAmount] [float] NULL,
	[SuggestedEbitMarginPercentage] [float] NULL,
	[SuggestedAdjustedEbitdaDebtServiceCoveragePercentage] [float] NULL,
	[TotalDepreciationFromOtherGuarantorsAmount] [float] NULL,
	[SuggestedAdjustedEbitInterestCoveragePercentage] [float] NULL,
	[TotalExistingCptdFromOtherGuarantorsAmount] [float] NULL,
	[TotalLongtermInterestExpenseFromOtherGuarantorsAmount] [float] NULL,
	[SuggestedTotalLongtermInterestAmount] [float] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_RiskFinancialStatementGtcCurrentEntity_entity_start_date] ON [dbo].[RiskFinancialStatementGtcCurrentEntity]
(
	[entity_start_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_RiskFinancialStatementGtcCurrentEntity_entity_is_current] ON [dbo].[RiskFinancialStatementGtcCurrentEntity]
(
	[entity_is_current] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE TABLE [dbo].[RiskFinancialStatementGtcPreviousEntity](
	[RiskFinancialStatementGtcPreviousEntity_buid] [nvarchar](max) NULL,
	[RiskFinancialStatementGtcPreviousEntity_oid] [nvarchar](max) NULL,
	[RiskFinancialStatementGtcPreviousEntity_uid] [nvarchar](max) NULL,
	[entity_start_date] [datetime] NULL,
	[entity_end_date] [datetime] NULL,
	[entity_is_current] [bit] NULL,
	[entity_is_deleted] [bit] NULL,
	[AccountCrmId] [nvarchar](max) NULL,
	[ServiceRequestCrmId] [int] NULL,
	[RiskEvaluationId] [bigint] NULL,
	[SuggestedEbitAmount] [float] NULL,
	[TotalAdjustedEbitFromOtherGuarantorsAmount] [float] NULL,
	[TotalAvailableFundsFromOtherGuarantorsAmount] [float] NULL,
	[SuggestedAdjustedEbitAmount] [float] NULL,
	[ShorttermInterestExpenseAmount] [float] NULL,
	[LongtermInterestExpenseAmount] [float] NULL,
	[SuggestedGrowthPercentage] [float] NULL,
	[TotalShorttermInterestExpenseFromOtherGuarantorsAmount] [float] NULL,
	[SuggestedAvailableFundsCoverageRatio] [float] NULL,
	[SuggestedTotalShorttermInterestAmount] [float] NULL,
	[CurrentTaxAmount] [float] NULL,
	[SuggestedAdjustedEbitdaAmount] [float] NULL,
	[SuggestedEbitMarginPercentage] [float] NULL,
	[SuggestedAdjustedEbitdaDebtServiceCoveragePercentage] [float] NULL,
	[TotalDepreciationFromOtherGuarantorsAmount] [float] NULL,
	[SuggestedAdjustedEbitInterestCoveragePercentage] [float] NULL,
	[TotalExistingCptdFromOtherGuarantorsAmount] [float] NULL,
	[TotalLongtermInterestExpenseFromOtherGuarantorsAmount] [float] NULL,
	[SuggestedTotalLongtermInterestAmount] [float] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_RiskFinancialStatementGtcPreviousEntity_entity_start_date] ON [dbo].[RiskFinancialStatementGtcPreviousEntity]
(
	[entity_start_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_RiskFinancialStatementGtcPreviousEntity_entity_is_current] ON [dbo].[RiskFinancialStatementGtcPreviousEntity]
(
	[entity_is_current] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE TABLE [dbo].[RiskFinancialStatementPreviousEntity](
	[RiskFinancialStatementPreviousEntity_buid] [nvarchar](max) NULL,
	[RiskFinancialStatementPreviousEntity_oid] [nvarchar](max) NULL,
	[RiskFinancialStatementPreviousEntity_uid] [nvarchar](max) NULL,
	[entity_start_date] [datetime] NULL,
	[entity_end_date] [datetime] NULL,
	[entity_is_current] [bit] NULL,
	[entity_is_deleted] [bit] NULL,
	[AccountCrmId] [nvarchar](max) NULL,
	[ServiceRequestCrmId] [int] NULL,
	[RiskEvaluationId] [bigint] NULL,
	[ServiceRequestAuthorizationDate] [datetime] NULL,
	[AdditionalCptdAmount] [float] NULL,
	[AdditionalInterestamount] [float] NULL,
	[AdjustedEbitdaFromGuarantorsAmount] [float] NULL,
	[AvailableFundsFromGuarantorsAmount] [float] NULL,
	[CptdSavingsAmount] [float] NULL,
	[CurrentLiabilitiesAmount] [float] NULL,
	[CurrentLiabilitiesToSales] [float] NULL,
	[CurrentLiabilitiesToSalesDisplay] [float] NULL,
	[CurrentLiabilitiesToSalesOver10RiskCalc] [float] NULL,
	[DeferredTaxAmount] [float] NULL,
	[DepreciationAmount] [float] NULL,
	[DividendsAmount] [float] NULL,
	[ExistingCptdAdjFromGuarantorsAmount] [float] NULL,
	[ExistingCptdAmount] [float] NULL,
	[ExistingCptdFromGuarantorsAmount] [float] NULL,
	[ExtraordinaryItems] [float] NULL,
	[FccrNumeratorFromGuarantorsAmount] [float] NULL,
	[FinancialStatementDate] [datetime] NULL,
	[GainsLossesOnSalesOfAssetsAmount] [float] NULL,
	[IncomeTaxExpenseRecoveryAmount] [float] NULL,
	[InterestExpenseAmount] [float] NULL,
	[InterestExpenseFromGuarantorsAmount] [float] NULL,
	[InterestSavingsAmount] [float] NULL,
	[InventoryToSales] [float] NULL,
	[NetOperatingIncomeAmount] [float] NULL,
	[NetProfitAmount] [float] NULL,
	[NewLoansToShareholders] [float] NULL,
	[OriginalAdditionalCptdAmount] [float] NULL,
	[OriginalAdditionalInterestAmount] [float] NULL,
	[ProformaCptdIncludingGuarantors] [float] NULL,
	[ProformaInterestIncludingGuarantors] [float] NULL,
	[ReimbursementOfLoansFromShareholders] [float] NULL,
	[RentalIncomeAmount] [float] NULL,
	[RentSavingsAmount] [float] NULL,
	[RentSavingsFromGuarantorsAmount] [float] NULL,
	[SubmetaObjectName] [nvarchar](max) NULL,
	[SuggestedAdjEbitda] [float] NULL,
	[SuggestedAdjustedEbitdaIncludingGuarantors] [float] NULL,
	[SuggestedAvailableFundsAmount] [float] NULL,
	[SuggestedAvailableFundsFromMainBorrower] [float] NULL,
	[SuggestedCoverageWithoutProgramAmount] [float] NULL,
	[SuggestedCoverageWithProgramFullAmount] [float] NULL,
	[SuggestedEbitda] [float] NULL,
	[SuggestedFccrIncludingGuarantors] [float] NULL,
	[SuggestedFccrNumerator] [float] NULL,
	[SuggestedFccrNumeratorIncludingGuarantors] [float] NULL,
	[SuggestedProformaCoverageRatio] [float] NULL,
	[SuggestedTotalAdjustmentsToAvailableFundsAmount] [float] NULL,
	[SuggestedTotalAdjustmentsToExistingCptdAmount] [float] NULL,
	[SuggestedTotalAdjustmentToAdditionalCptdAndInterestAmount] [float] NULL,
	[SuggestedTotalDebtService] [float] NULL,
	[SuggestedTotalExistingCptd] [float] NULL,
	[TotalAssets] [float] NULL,
	[TotalCptd12MonthsAmount] [float] NULL,
	[TotalInterest12MonthsAmount] [float] NULL,
	[TotalInventoryAmount] [float] NULL,
	[TotalLiabilities] [float] NULL,
	[TotalSalesAmount] [float] NULL,
	[UnfundedCapex] [float] NULL,
	[CreatedDate] [datetime] NULL,
	[ChangedDate] [datetime] NULL,
	[SystemChangedBy] [bigint] NULL,
	[SystemOwner] [bigint] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_RiskFinancialStatementPreviousEntity_entity_start_date] ON [dbo].[RiskFinancialStatementPreviousEntity]
(
	[entity_start_date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_RiskFinancialStatementPreviousEntity_entity_is_current] ON [dbo].[RiskFinancialStatementPreviousEntity]
(
	[entity_is_current] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO
