﻿CREATE TABLE [dbo].[PsBimProjectResource](
	[BusinessUnit] [varchar](5) NOT NULL,
	[ProjectId] [varchar](15) NOT NULL,
	[ActivityId] [varchar](15) NOT NULL,
	[ResourceId] [varchar](40) NOT NULL,
	[BusinessUnitGL] [varchar](5) NOT NULL,
	[JournalId] [varchar](10) NOT NULL,
	[JournalDate] [date] NULL,
	[JournalLine] [int] NOT NULL,
	[FiscalYear] [smallint] NOT NULL,
	[AccountingPeriod] [smallint] NOT NULL,
	[Account] [varchar](10) NOT NULL,
	[DepartmentId] [varchar](10) NOT NULL,
	[OperatingUnit] [varchar](8) NOT NULL,
	[Product] [varchar](6) NOT NULL,
	[ProgramCode] [varchar](5) NOT NULL,
	[CurrencyCode] [varchar](3) NOT NULL,
	[LedgerGroup] [varchar](10) NOT NULL,
	[AnalysisType] [varchar](3) NOT NULL,
	[ResourceType] [varchar](5) NOT NULL,
	[ResourceCategory] [varchar](5) NOT NULL,
	[ResourceSubCat] [varchar](5) NOT NULL,
	[TransactionDate] [date] NULL,
	[AccountingDate] [date] NULL,
	[DTTM_STAMP] [datetime] NULL,
	[JournalLineDate] [date] NULL,
	[CurEffDate] [date] NULL,
	[ResourceStatus] [varchar](1) NOT NULL,
	[EmplId] [varchar](11) NOT NULL,
	[DueDate] [date] NULL,
	[BillingDate] [date] NULL,
	[ResourceQty] [float] NOT NULL,
	[ResourceAmt] [float] NOT NULL,
	[Ledger] [varchar](10) NULL,
	[DT_TIMESTAMP] [datetime] NULL,
	[PsBimProjectResource_buid] [varchar](40) NOT NULL,
	[PsBimProjectResource_uid] [varchar](40) NOT NULL,
	[PsBimProjectResource_oid] [varchar](40) NOT NULL,
	[entity_start_date] [datetime] NOT NULL,
	[entity_end_date] [datetime] NOT NULL,
	[entity_is_current] [bit] NOT NULL,
	[entity_is_deleted] [bit] NOT NULL
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
GO
ALTER TABLE [dbo].[PsBimProjectResource]
	ADD CONSTRAINT [XPKPsBimProjectResource] PRIMARY KEY NONCLUSTERED ([PsBimProjectResource_uid])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectResource_Key] ON [dbo].[PsBimProjectResource]
( 
	[ProjectId] ASC, [BusinessUnit] ASC, [ActivityId] ASC, [ResourceId] ASC
)
INCLUDE ([entity_start_date], [entity_end_date], [entity_is_current], [entity_is_deleted])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectResource_AnalysisType] ON [dbo].[PsBimProjectResource]
(
	[AnalysisType], [entity_is_current]
)
INCLUDE ([BusinessUnit], [JournalLineDate], [ProjectId], [ResourceAmt], [entity_start_date])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectResource_StartEndDate] ON [dbo].[PsBimProjectResource]
( 
	[entity_start_date] ASC, [entity_end_date] ASC
)
INCLUDE ([BusinessUnit], [ProjectId], [ActivityId], [ResourceId])
GO
