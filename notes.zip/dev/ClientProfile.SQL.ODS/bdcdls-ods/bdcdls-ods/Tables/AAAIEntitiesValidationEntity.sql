CREATE TABLE [dbo].[AAAIEntitiesValidationEntity](
	[ref_uid] [nvarchar] (50) NULL,
	[validated_field] [nvarchar] (50) NULL,
	[field_value] [nvarchar] (50) NULL,
	[validation_operation] [nvarchar] (50) NULL,
	[validation_value] [float] NULL,
	[reference_value] [float] NULL,
	[validated_table] [nvarchar](max) NULL,
	[crmId_list] [nvarchar] (max) NULL,
	[execution_timestamp] [datetime] NULL,
	[entity_event_date] [date] NOT NULL,
	[AAAIEntitiesValidationEntity_buid] [varchar](40) NOT NULL,
)
GO
CREATE NONCLUSTERED INDEX [IX_AAAIEntitiesValidationEntity_execution_timestamp] ON [dbo].[AAAIEntitiesValidationEntity]
(
	[execution_timestamp] ASC
)
GO
