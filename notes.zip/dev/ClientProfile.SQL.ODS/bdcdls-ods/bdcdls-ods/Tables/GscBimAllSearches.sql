﻿CREATE TABLE [dbo].[GscBimAllSearches](
	[responseAggregationType] [varchar](20) NOT NULL,
	[searchType] [varchar](5) NOT NULL,
	[siteURL] [varchar](50) NULL,
	[date] [date] NOT NULL,
	[country] [varchar](50) NULL,
	[device] [varchar](50) NULL,
	[page] [nvarchar](2000) NULL,
	[query] [nvarchar](2000) NULL,
	[clicks] [float] NULL,
	[ctr] [float] NULL,
	[impressions] [float] NULL,
	[position] [float] NULL,
	[entity_event_date] [date] NOT NULL,
	[GscBimAllSearches_buid] [varchar](40) NOT NULL
)
GO
ALTER TABLE [dbo].[GscBimAllSearches]
	ADD CONSTRAINT [XPKGscBimAllSearches] PRIMARY KEY NONCLUSTERED ([GscBimAllSearches_buid] ASC,[entity_event_date] ASC)
GO
CREATE NONCLUSTERED INDEX [IX_GscBimAllSearches_entity_event_date] ON [dbo].[GscBimAllSearches]
(
	[entity_event_date] ASC
)
GO
