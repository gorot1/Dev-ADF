﻿CREATE TABLE [dbo].[OpportunitySalesStagesHistoryEntity]
(
	[mcs_opportunitysalesstageshistoryId] [nvarchar](300)	NOT NULL,
	[OrganizationIdName] [nvarchar](300) NULL,
	[mcs_OpportunityIdName] [nvarchar](300) NULL,
	[ModifiedOnBehalfByName] [nvarchar](300) NULL,
	[mcs_SalesStageIdName] [nvarchar](300) NULL,
	[mcs_OpportunityOwnerIdName] [nvarchar](300) NULL,
	[OrganizationId] [nvarchar](300) NULL,
	[StatusCode] [int] NULL,
	[StatusReasonCode] [int] NULL,
	[VersionNumber] [varbinary](max) NULL,
	[OverriddenCreatedOn] [datetime] NULL,
	[TimeZoneRuleVersionNumber] [int] NULL,
	[UTCConversionTimeZoneCode] [int] NULL,
	[Name] [nvarchar](300) NULL,
	[ConsultingStateCode] [int] NULL,
	[CrmId] [nvarchar](300) NULL,
	[OpportunityId] [nvarchar](300) NULL,
	[OpportunityModifiedOn] [datetime] NULL,
	[OpportunityOwnerId] [nvarchar](300) NULL,
	[OpportunityStatus] [nvarchar](300) NULL,
	[SalesStageId] [nvarchar](300) NULL,
	[OpportunitySalesStageNameEn] [nvarchar](300) NULL,
	[OpportunitySalesStageNameFr] [nvarchar](300) NULL,
	[OpportunitySalesStageId] [nvarchar](300) NULL,
	[ConsultingStateDescEn] [nvarchar](300) NULL,
	[ConsultingStateDescFr] [nvarchar](300) NULL,
	[StatusDescrEn] [nvarchar](300) NULL,
	[StatusDescrFr] [nvarchar](300) NULL,
	[StatusReasonDescrEn] [nvarchar](300) NULL,
	[StatusReasonDescrFr] [nvarchar](300) NULL,
	[CreatedByName] [nvarchar](300) NULL,
	[ModifiedByName] [nvarchar](300) NULL,
	[ModifiedOnBehalfBy] [nvarchar](300) NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [nvarchar](300) NULL,
	[ModifiedOn] [datetime] NULL,
	[ModifiedBy] [nvarchar](300) NULL,
	[OpportunitySalesStagesHistoryEntity_buid] 	varchar(40) 	NOT NULL,
	[OpportunitySalesStagesHistoryEntity_oid] 	varchar(40) 	NOT NULL,
	[OpportunitySalesStagesHistoryEntity_uid] 	varchar(40) 	NOT NULL,
	[entity_start_date] 						datetime 		NOT NULL,
	[entity_end_date] 							datetime 		NOT NULL,
	[entity_is_current] 						bit 			NOT NULL,
	[entity_is_deleted] 						bit 			NOT NULL
	,CONSTRAINT [PK_OpportunitySalesStagesHistoryEntity] PRIMARY KEY NONCLUSTERED ([OpportunitySalesStagesHistoryEntity_uid] ASC)
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
go

CREATE NONCLUSTERED INDEX [IX_OpportunitySalesStagesHistoryEntity_Key] ON [dbo].[OpportunitySalesStagesHistoryEntity]
( 
	[mcs_opportunitysalesstageshistoryId] ASC
)
INCLUDE ([entity_start_date], [entity_end_date], [entity_is_current], [entity_is_deleted])
go

CREATE NONCLUSTERED INDEX [IX_OpportunitySalesStagesHistoryEntity_StartEndDate] ON [dbo].[OpportunitySalesStagesHistoryEntity]
( 
	[entity_start_date] ASC, [entity_end_date] ASC
)
INCLUDE ([mcs_opportunitysalesstageshistoryId])
go
