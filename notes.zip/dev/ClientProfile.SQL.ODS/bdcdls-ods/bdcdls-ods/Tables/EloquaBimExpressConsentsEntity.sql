﻿CREATE TABLE [dbo].[EloquaBimExpressConsentsEntity](
	[Date] [date] NULL,
	[ExpressConsents] [bigint] NULL,
	[InBusiness] [bigint] NULL,
	[LeadNurturing] [bigint] NULL,
	[ClientNurturing] [bigint] NULL,
	[MEL] [bigint] NULL,
	[Newsletters] [bigint] NULL,
	[Partners] [bigint] NULL,
	[Profits] [bigint] NULL,
	[UniqueEmailSubscribers] [bigint] NULL,
	[LeadAndClientNurturingCombined] [bigint] NULL,
	[entity_event_date] [date] NOT NULL,
	[EloquaBimExpressConsentsEntity_buid] [varchar](40) NOT NULL,
	[entity_start_date] [datetime] NOT NULL,
	[entity_end_date] [datetime] NOT NULL,
	[entity_is_current] [bit] NOT NULL,
	[entity_is_deleted] [bit] NOT NULL,
	[entity_created_on] [datetime] NOT NULL,
	[entity_modified_on] [datetime] NOT NULL,
	[EloquaBimExpressConsentsEntity_uid] [varchar](40) NOT NULL
)
GO
ALTER TABLE [dbo].[EloquaBimExpressConsentsEntity]
	ADD CONSTRAINT [XPKEloquaBimExpressConsentsEntity] PRIMARY KEY NONCLUSTERED ([EloquaBimExpressConsentsEntity_buid] ASC, [entity_event_date] ASC)
GO
CREATE NONCLUSTERED INDEX [IX_EloquaBimExpressConsentsEntity_entity_modified_on] ON [dbo].[EloquaBimExpressConsentsEntity]
(
	[entity_modified_on] ASC
)
GO