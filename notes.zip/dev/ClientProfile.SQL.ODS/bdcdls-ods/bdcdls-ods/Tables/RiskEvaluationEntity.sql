﻿CREATE TABLE [dbo].[RiskEvaluationEntity](
	[AccountId] [bigint] NULL,
	[ServiceRequestId] [bigint] NULL,
	[RiskEvaluationId] [bigint] NULL,
	[ServiceRequestCrmId] [nvarchar](max) NULL,
	[ServiceRequestAuthorizationDate] [datetime] NULL,
	[AuthorizationDate] [datetime] NULL,
	[AuthorizedBy] [nvarchar](max) NULL,
	[ChangedDate] [datetime] NULL,
	[Comment] [nvarchar](max) NULL,
	[CreatedDate] [datetime] NULL,
	[CustomerNaicsCodeUsedForRisk] [nvarchar](max) NULL,
	[CustomerNaicsDescriptionEnglish] [nvarchar](max) NULL,
	[CustomerNaicsDescriptionFrench] [nvarchar](max) NULL,
	[USIndustryUsedForFisk] [nvarchar](max) NULL,
	[USIndustryUsedForRiskDescriptionEnglish] [nvarchar](max) NULL,
	[UsIndustryUsedForRiskDescriptionFrench] [nvarchar](max) NULL,
	[DirectOverrideRiskRating] [float] NULL,
	[DirectOverrideRiskRatingPd] [float] NULL,
	[FinalProbabilityOfDowngradingToImpairedPercentage] [float] NULL,
	[FinalRiskRating] [float] NULL,
	[CRMid_FinancialStatementUsedForRisk] [nvarchar](max) NULL,
	[IsContactFinancialStatementUsedForRisk] [bit] NULL,
	[IsFinancialStatementUsedForRisk] [bit] NULL,
	[NameFinancialStatementUsedForRisk] [nvarchar](max) NULL,
	[IsGtcRiskMethodInvolved] [bit] NULL,
	[IsOtherAccountLinkedToFinancialStatementAdjustment] [bit] NULL,
	[IsPartiallyRestrictedAccount] [bit] NULL,
	[IsSuggestedRiskOverridden] [bit] NULL,
	[LastCalculationDate] [datetime] NULL,
	[LastModifiedBy] [nvarchar](max) NULL,
	[LastResetDateForOffer] [datetime] NULL,
	[NeedsRecalculating] [bit] NULL,
	[NeedsToDetermineRiskMethodAtLoanOrigination] [bit] NULL,
	[OverriddenBy] [nvarchar](max) NULL,
	[OverriddenProbabilityOfDowngradingToImpairedBasePercentage] [float] NULL,
	[OverriddenProbabilityOfDowngradingToImpairedPercentage] [float] NULL,
	[OverriddenRiskRatingBase] [float] NULL,
	[OverrideCategory] [nvarchar](max) NULL,
	[OverridenRiskRating] [float] NULL,
	[OverrideReason] [nvarchar](max) NULL,
	[PartiallyRestrictedAccountChangeDate] [datetime] NULL,
	[PartiallyRestrictedAccountRationale] [nvarchar](max) NULL,
	[PdAdjustmentAssetSize] [float] NULL,
	[PdAdjustmentCrCommitmentSize] [float] NULL,
	[PdAdjustmentIndustry] [float] NULL,
	[PdAdjustmentPurpose] [float] NULL,
	[PdAdjustmentSolution] [float] NULL,
	[PdForRiskRatingScore] [float] NULL,
	[RepeatBusinessCanEditComment] [bit] NULL,
	[RiskEvaluationMethodType] [nvarchar](max) NULL,
	[RiskEvaluationReason] [nvarchar](max) NULL,
	[RiskEvaluationVersion] [int] NULL,
	[RiskType] [nvarchar](max) NULL,
	[SuggestedCoverageWithProgramFullAmountAtLastResetDateForOffer] [float] NULL,
	[SuggestedGrowth] [float] NULL,
	[SuggestedProbabilityOfDowngradingToImpairedBasePercentage] [float] NULL,
	[SuggestedProbabilityOfDowngradingToImpairedPercentage] [float] NULL,
	[SuggestedRiskRating] [float] NULL,
	[SuggestedRiskRatingBase] [float] NULL,
	[SystemChangedBy] [bigint] NULL,
	[SystemOwner] [bigint] NULL,
	[TotalCommitmentAtAuthorizationmrgAtLastResetDateForOffer] [float] NULL,
	[TotalPdAdjustmentFactor] [float] NULL,
	[RiskEvaluationEntity_buid] [varchar](40) NOT NULL,
	[AccountCrmId] [varchar](20) NOT NULL,
	[RiskEvaluationEntity_oid] [varchar](40) NOT NULL,
	[entity_start_date] [datetime] NOT NULL,
	[entity_end_date] [datetime] NOT NULL,
	[RiskEvaluationEntity_uid] [varchar](40) NOT NULL,
	[entity_is_current] [bit] NOT NULL,
	[entity_is_deleted] [bit] NOT NULL
)
GO

CREATE NONCLUSTERED INDEX [IX_RiskEvaluationEntity_entity_start_date] ON [dbo].[RiskEvaluationEntity]
(
	[entity_start_date] ASC
)
GO

CREATE NONCLUSTERED INDEX [IX_RiskEvaluationEntity_entity_is_current] ON [dbo].[RiskEvaluationEntity]
(
	[entity_is_current] ASC
)
GO

CREATE NONCLUSTERED INDEX [IX_RiskEvaluationEntity_AccountCrmId] ON [dbo].[RiskEvaluationEntity]
(
	[AccountCrmId] ASC
)
GO