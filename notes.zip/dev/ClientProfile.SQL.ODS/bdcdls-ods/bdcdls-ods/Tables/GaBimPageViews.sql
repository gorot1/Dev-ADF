﻿CREATE TABLE [dbo].[GaBimPageViews](
	[campaign] [nvarchar](1000) NULL,
	[dateHourMinute] [datetime] NULL,
	[deviceCategory] [nvarchar](10) NULL,
	[hostname] [nvarchar](255) NULL,
	[pagePath] [nvarchar](2000) NULL,
	[cityid] [bigint] NULL,
	[source] [nvarchar](500) NULL,
	[medium] [nvarchar](100) NULL,
	[segment] [nvarchar](100) NULL,
	[entrances] [bigint] NULL,
	[exits] [bigint] NULL,
	[pageValue] [bigint] NULL,
	[pageviews] [bigint] NULL,
	[timeOnPage] [bigint] NULL,
	[uniquePageviews] [bigint] NULL,
	[accountID] [int] NOT NULL,
	[viewID] [int] NOT NULL,
	[profileID] [int] NOT NULL,
	[webPropertyID] [varchar](20) NOT NULL,
	[entity_event_date] [date] NOT NULL,
	[GaBimPageViews_buid] [varchar](40) NOT NULL
)
GO
ALTER TABLE [dbo].[GaBimPageViews]
	ADD CONSTRAINT [XPKGaBimPageViews] PRIMARY KEY NONCLUSTERED ([GaBimPageViews_buid] ASC,[entity_event_date] ASC)
GO
CREATE NONCLUSTERED INDEX [IX_GaBimPageViews_entity_event_date] ON [dbo].[GaBimPageViews]
(
	[entity_event_date] ASC
)
GO
