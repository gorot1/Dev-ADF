﻿CREATE TABLE [dbo].[EloquaBimVBCEntity](
	[Date] [date] NULL,
	[OnboardedClients] [bigint] NULL,
	[ActiveClients] [bigint] NULL,
	[ClientsRemainingToOnboardUnsupportedAms] [bigint] NULL,
	[ClientsRemainingToOnboardSupportedAms] [bigint] NULL,
	[VBCClients] [bigint] NULL,
	[AutomatedOnboardableClients] [bigint] NULL,
	[entity_event_date] [date] NOT NULL,
	[EloquaBimVBCEntity_buid] [varchar](40) NOT NULL,
	[entity_start_date] [datetime] NOT NULL,
	[entity_end_date] [datetime] NOT NULL,
	[entity_is_current] [bit] NOT NULL,
	[entity_is_deleted] [bit] NOT NULL,
	[entity_created_on] [datetime] NOT NULL,
	[entity_modified_on] [datetime] NOT NULL,
	[EloquaBimVBCEntity_uid] [varchar](40) NOT NULL
)
GO
ALTER TABLE [dbo].[EloquaBimVBCEntity]
	ADD CONSTRAINT [XPKEloquaBimVBCEntity] PRIMARY KEY NONCLUSTERED ([EloquaBimVBCEntity_buid] ASC, [entity_event_date] ASC)
GO
CREATE NONCLUSTERED INDEX [IX_EloquaBimVBCEntity_entity_modified_on] ON [dbo].[EloquaBimVBCEntity]
(
	[entity_modified_on] ASC
)
GO
