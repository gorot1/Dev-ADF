﻿CREATE TABLE [dbo].[GaBimPages](
	[contentGroup5] [nvarchar](max) NULL,
	[hostname] [nvarchar](max) NULL,
	[pagePath] [nvarchar](max) NULL,
	[pagePathLevel2] [nvarchar](max) NULL,
	[pagePathLevel3] [nvarchar](max) NULL,
	[pageTitle] [nvarchar](max) NULL,
	[segment] [nvarchar](max) NULL,
	[pageviews] [bigint] NULL,
	[accountID] [int] NOT NULL,
	[viewID] [int] NOT NULL,
	[profileID] [int] NOT NULL,
	[webPropertyID] [varchar](20) NOT NULL,
	[GaBimPages_buid] [varchar](40) NOT NULL,
	[entity_start_date] [datetime] NOT NULL,
	[entity_end_date] [datetime] NOT NULL,
	[entity_is_current] [bit] NOT NULL,
	[entity_is_deleted] [bit] NOT NULL,
	[entity_created_on] [datetime] NOT NULL,
	[entity_modified_on] [datetime] NOT NULL,
	[GaBimPages_uid] [varchar](40) NOT NULL
)
GO
ALTER TABLE [dbo].[GaBimPages]
	ADD CONSTRAINT [XPKGaBimPages] PRIMARY KEY NONCLUSTERED ([GaBimPages_uid])
GO
CREATE NONCLUSTERED INDEX [IX_GaBimPages_entity_modified_on] ON [dbo].[GaBimPages]
(
	[entity_modified_on] ASC
)
GO