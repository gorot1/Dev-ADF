﻿CREATE TABLE [dbo].[GaBimGoalsEntity](
	[campaign] [nvarchar](1000) NULL,
	[dateHourMinute] [datetime] NULL,
	[deviceCategory] [nvarchar](10) NULL,
	[hostname] [nvarchar](255) NULL,
	[landingPagePath] [nvarchar](2000) NULL,
	[cityid] [bigint] NULL,
	[source] [nvarchar](500) NULL,
	[medium] [nvarchar](100) NULL,
	[segment] [nvarchar](100) NULL,
	[accountID] [int] NOT NULL,
	[viewID] [int] NOT NULL,
	[profileID] [int] NOT NULL,
	[webPropertyID] [varchar](20) NOT NULL,
	[goalNumber] [int] NULL,
	[goalStarts] [bigint] NULL,
	[goalCompletions] [bigint] NULL,
	[entity_event_date] [date] NOT NULL,
	[GaBimGoalsEntity_buid] [varchar](40) NOT NULL
)
GO
ALTER TABLE [dbo].[GaBimGoalsEntity]
	ADD CONSTRAINT [XPKGaBimGoalsEntity] PRIMARY KEY NONCLUSTERED ([GaBimGoalsEntity_buid] ASC,[entity_event_date] ASC)
GO
CREATE NONCLUSTERED INDEX [IX_GaBimGoalsEntity_entity_event_date] ON [dbo].[GaBimGoalsEntity]
(
	[entity_event_date] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_GaBimGoalsEntity_goalNumber] ON [dbo].[GaBimGoalsEntity]
(
	[goalNumber] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_GaBimGoalsEntity_goalStarts] ON [dbo].[GaBimGoalsEntity]
(
	[goalStarts] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_GaBimGoalsEntity_goalCompletions] ON [dbo].[GaBimGoalsEntity]
(
	[goalCompletions] ASC
)
GO

CREATE NONCLUSTERED INDEX [IX_GaBimGoalsEntity_segment] ON [dbo].[GaBimGoalsEntity]
(
	[segment] ASC
)
GO
