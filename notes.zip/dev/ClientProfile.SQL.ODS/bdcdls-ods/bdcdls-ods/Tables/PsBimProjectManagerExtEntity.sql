﻿CREATE TABLE [dbo].[PsBimProjectManagerExtEntity](
	[CustomerId] [varchar](15) NOT NULL,
	[BusinessUnit] [varchar](5) NOT NULL,
	[ProjectId] [varchar](15) NOT NULL,
	[ProjectManagerPIN] [varchar](11) NOT NULL,
	[ProjectRole] [varchar](15) NOT NULL,
	[ProjectManagerName] [varchar](50) NOT NULL,
	[CustomerName] [varchar](40) NOT NULL,
	[Status] [varchar](1) NOT NULL,
	[ProductId] [varchar](6) NOT NULL,
	[ProductDesc] [varchar](30) NOT NULL,
	[ProjectTypeId] [varchar](5) NOT NULL,
	[DepartmentId] [varchar](10) NOT NULL,
	[BDC_SALES_MTD] [float] NOT NULL,
	[BDC_SALES_YTD] [float] NOT NULL,
	[BDC_REV_MTD] [float] NOT NULL,
	[BDC_REV_YTD] [float] NOT NULL,
	[BDC_DEF_REV_MTD] [float] NOT NULL,
	[BDC_DEF_REV_YTD] [float] NOT NULL,
	[BDC_BUD_EXP_MTD] [float] NOT NULL,
	[BDC_BUD_EXP_YTD] [float] NOT NULL,
	[BDC_B_A_EXP_MTD] [float] NOT NULL,
	[BDC_B_A_EXP_YTD] [float] NOT NULL,
	[BDC_B_A_F_EXP_MTD] [float] NOT NULL,
	[BDC_B_A_F_EXP_YTD] [float] NOT NULL,
	[BDC_DIR_EXP_MTD] [float] NOT NULL,
	[BDC_DIR_EXP_YTD] [float] NOT NULL,
	[BDC_BUD_INT_MTD] [float] NOT NULL,
	[BDC_BUD_INT_YTD] [float] NOT NULL,
	[BDC_BUD_INT_NB_MTD] [float] NOT NULL,
	[BDC_BUD_INT_NB_YTD] [float] NOT NULL,
	[BDC_B_A_INT_MTD] [float] NOT NULL,
	[BDC_B_A_INT_YTD] [float] NOT NULL,
	[BDC_B_A_F_INT_MTD] [float] NOT NULL,
	[BDC_B_A_F_INT_YTD] [float] NOT NULL,
	[BDC_B_A_INT_NB_MTD] [float] NOT NULL,
	[BDC_B_A_INT_NB_YTD] [float] NOT NULL,
	[BDC_INT_EXP_MTD] [float] NOT NULL,
	[BDC_INT_EXP_YTD] [float] NOT NULL,
	[BDC_INT_EXP_NB_MTD] [float] NOT NULL,
	[BDC_INT_EXP_NB_YTD] [float] NOT NULL,
	[BDC_PFC_MTD] [float] NOT NULL,
	[BDC_PFC_YTD] [float] NOT NULL,
	[BDC_PFC_OVERFLOW] [bit] NULL,
	[BDC_OOP_EXP_MTD] [float] NOT NULL,
	[BDC_OOP_EXP_YTD] [float] NOT NULL,
	[BDC_OOP_BLD_MTD] [float] NOT NULL,
	[BDC_OOP_BLD_YTD] [float] NOT NULL,
	[BDC_BLD_MTD] [float] NOT NULL,
	[BDC_BLD_YTD] [float] NOT NULL,
	[BDC_CONT_EXP_MTD] [float] NOT NULL,
	[BDC_CONT_EXP_YTD] [float] NOT NULL,
	[BDC_BAD_DEBTS_MTD] [float] NOT NULL,
	[BDC_BAD_DEBTS_YTD] [float] NOT NULL,
	[BDC_DEBTS_BAL_MTD] [float] NOT NULL,
	[BDC_DEBTS_BAL_YTD] [float] NOT NULL,
	[BDC_DEBTS_TOT_MTD] [float] NOT NULL,
	[BDC_DEBTS_TOT_YTD] [float] NOT NULL,
	[BDC_UNEARNED] [float] NOT NULL,
	[BDC_AR_ADJUSTMENT] [float] NOT NULL,
	[BDC_MANDATE_MTD] [float] NOT NULL,
	[BDC_MANDATE_YTD] [float] NOT NULL,
	[BDC_NBR_CUST_MTD] [float] NOT NULL,
	[BDC_NBR_CUST_YTD] [float] NOT NULL,
	[BDC_REF_CUST_MTD] [float] NOT NULL,
	[BDC_REF_CUST_YTD] [float] NOT NULL,
	[CRMAccount_CRMId] [varchar](10) NULL,
	[entity_start_date] [datetime] NOT NULL,
	[PsBimProjectManagerExtEntity_buid] [varchar](40) NOT NULL,
	[PsBimProjectManagerExtEntity_oid] [varchar](40) NOT NULL,
	[PsBimProjectManagerExtEntity_uid] [varchar](40) NOT NULL,
	[entity_is_deleted] [bit] NOT NULL,
	[entity_is_current] [bit] NOT NULL,
	[entity_end_date] [datetime] NOT NULL
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
GO
ALTER TABLE [dbo].[PsBimProjectManagerExtEntity]
	ADD CONSTRAINT [XPKPsBimProjectManagerExtEntity] PRIMARY KEY NONCLUSTERED ([PsBimProjectManagerExtEntity_uid])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectManagerExtEntity_Key] ON [dbo].[PsBimProjectManagerExtEntity]
( 
	[ProjectId] ASC, [ProjectManagerPIN] ASC, [BusinessUnit] ASC
)
INCLUDE ([entity_start_date], [entity_end_date], [entity_is_current], [entity_is_deleted])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectManagerExtEntity_IsCurrent] ON [dbo].[PsBimProjectManagerExtEntity]
(
	[entity_is_current]
)
INCLUDE ([ProjectId], [BDC_UNEARNED], [entity_start_date])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectManagerExtEntity_StartEndDate] ON [dbo].[PsBimProjectManagerExtEntity]
( 
	[entity_start_date] ASC, [entity_end_date] ASC
)
INCLUDE ([BusinessUnit], [ProjectId], [ProjectManagerPIN])
GO
