CREATE TABLE [dbo].[PrepaymentPredictionsEntity](
	[probability_3_month] [float] NULL,
	[probability_6_month] [float] NULL,
	[probability_12_month] [float] NULL,
	[probability_variation] [float] NULL,
	[star_rating] [float] NULL,
	[most_important_feature_1] [varchar](90) NULL,
	[most_important_feature_2] [varchar](90) NULL,
	[most_important_feature_3] [varchar](90) NULL,
	[most_important_feature_4] [varchar](90) NULL,
	[most_important_feature_5] [varchar](90) NULL,
	[most_important_feature_6] [varchar](90) NULL,
	[most_important_feature_7] [varchar](90) NULL,
	[most_important_feature_8] [varchar](90) NULL,
	[most_important_feature_9] [varchar](90) NULL,
	[most_important_feature_10] [varchar](90) NULL,
	[shap_value_feature_1] [float] NULL,
	[shap_value_feature_2] [float] NULL,
	[shap_value_feature_3] [float] NULL,
	[shap_value_feature_4] [float] NULL,
	[shap_value_feature_5] [float] NULL,
	[shap_value_feature_6] [float] NULL,
	[shap_value_feature_7] [float] NULL,
	[shap_value_feature_8] [float] NULL,
	[shap_value_feature_9] [float] NULL,
	[shap_value_feature_10] [float] NULL,
	[AbacusCustId] [float] NULL,
	[AccountNumber] [float] NULL,
	[security_coverage_amount] [float] NULL,
	[security_coverage_variation] [float] NULL,
	[BaseRate] [float] NULL,
	[WIRVRate] [float] NULL,
	[InterestRate] [float] NULL,
	[InterestRate_variation] [float] NULL,
	[potential_revenue_loss] [float] NULL,
	[estimated_penalty] [float] NULL,
	[interest_differential_penalty] [float] NULL,
	[penalty_calculation_date] [date] NULL,
	[bdc_rate] [float] NULL,
	[security_shortfall_amount] [float] NULL,
	[loan_outstanding_balance] [float] NULL,
	[isActive] [bit] NULL,
	[PrepaymentPredictionsEntity_oid] [varchar](40) NOT NULL,
	[PrepaymentPredictionsEntity_buid] [varchar](40) NOT NULL,
	[entity_start_date] [datetime] NOT NULL,
	[PrepaymentPredictionsEntity_uid] [varchar](40) NOT NULL,
	[entity_is_deleted] [bit] NOT NULL,
	[entity_is_current] [bit] NOT NULL,
	[entity_end_date] [datetime] NOT NULL
)
GO
CREATE NONCLUSTERED INDEX [IX_PrepaymentPredictionsEntity_entity_start_date] ON [dbo].[PrepaymentPredictionsEntity]
(
	[entity_start_date] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_PrepaymentPredictionsEntity_entity_is_current] ON [dbo].[PrepaymentPredictionsEntity]
(
	[entity_is_current] ASC
)
GO