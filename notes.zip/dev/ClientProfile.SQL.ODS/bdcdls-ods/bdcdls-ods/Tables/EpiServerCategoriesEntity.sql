﻿CREATE TABLE [dbo].[EpiServerCategoriesEntity](
	[analyticsValue] [nvarchar](max) NULL,
	[changed] [nvarchar](max) NULL,
	[id] [bigint] NULL,
	[contentType] [nvarchar](max) NULL,
	[language] [nvarchar](max) NULL,
	[name] [nvarchar](max) NULL,
	[parentId] [bigint] NULL,
	[routeSegment] [nvarchar](max) NULL,
	[entity_load_timestamp] [datetime] NOT NULL,
	[EpiServerCategoriesEntity_oid] [varchar](40) NOT NULL,
	[EpiServerCategoriesEntity_buid] [varchar](40) NOT NULL,
	[entity_start_date] [datetime] NOT NULL,
	[entity_end_date] [datetime] NOT NULL,
	[entity_is_current] [bit] NOT NULL,
	[entity_is_deleted] [bit] NOT NULL,
	[entity_created_on] [datetime] NOT NULL,
	[entity_modified_on] [datetime] NOT NULL,
	[EpiServerCategoriesEntity_uid] [varchar](40) NOT NULL
)
GO

ALTER TABLE [dbo].[EpiServerCategoriesEntity]
	ADD CONSTRAINT [XPKEpiServerCategoriesEntity] PRIMARY KEY NONCLUSTERED ([EpiServerCategoriesEntity_buid])
GO
