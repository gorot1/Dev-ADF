﻿CREATE TABLE [dbo].[GaReferenceCityMapping] (
	[entity_lineage_id] [nvarchar](max) NULL,
	[entity_load_timestamp] [datetime] NOT NULL,
	[ETag] [nvarchar](max) NULL,
	[pivotValueRegions] [nvarchar](max) NULL,
	[cityid] [bigint] NULL,
	[city] [nvarchar](max) NULL,
	[metroId] [bigint] NULL,
	[metro] [nvarchar](max) NULL,
	[regionid] [bigint] NULL,
	[region] [nvarchar](max) NULL,
	[countryISOCode] [nvarchar](max) NULL,
	[Country] [nvarchar](max) NULL,
	[GaReferenceCityMapping_oid] [varchar](40) NOT NULL,
	[GaReferenceCityMapping_buid] [varchar](40) NOT NULL,
	[entity_start_date] [datetime] NOT NULL,
	[entity_end_date] [datetime] NOT NULL,
	[entity_is_current] [bit] NOT NULL,
	[entity_is_deleted] [bit] NOT NULL,
	[entity_created_on] [datetime] NOT NULL,
	[entity_modified_on] [datetime] NOT NULL,
	[GaReferenceCityMapping_uid] [varchar](40) NOT NULL,
	CONSTRAINT [PK_GaReferenceCityMappingODSEntity] PRIMARY KEY NONCLUSTERED ([GaReferenceCityMapping_buid])
)
GO
CREATE NONCLUSTERED INDEX [IX_GaReferenceCityMapping_entity_modified_on] ON [dbo].[GaReferenceCityMapping]
(
	[entity_modified_on] ASC
)
GO
