﻿CREATE TABLE [dbo].[WorkItemEntity](
	[WorkItemId] [nvarchar] (50) NULL,
	[ServiceRequestId] [nvarchar] (50) NULL,
	[ServiceRequestCrmId] [nvarchar] (50) NULL,
	[ChangedDate] [datetime] NULL,
	[OriginationRequestState] [nvarchar](59) NULL,
	[AdministrationRequestState] [nvarchar](50) NULL,
	[AnnualReviewRequestState] [nvarchar](50) NULL,
	[GeneralAdminRequestState] [nvarchar](50) NULL,
	[DisbursementRequestState] [nvarchar](100) NULL,
	[CreatedDate] [varchar](40) NULL,
	[SystemOwner] [nvarchar](50) NULL,
	[SystemChangedBy] [nvarchar](50) NULL,
	[InHouseSecurityState] [nvarchar](50) NULL,
	[AuthorizeStateTransition] [nvarchar](50) NULL,
	[SkipHistory] [nvarchar](50) NULL,
	[AllowWriteAccess] [bit] NULL,
	[RequestId] [nvarchar](50) NULL,
	[LoanPaymentRemittanceRequestState] [nvarchar](50) NULL,
	[WriteOffRequestState] [nvarchar](50) NULL,
	[SundryDisbursementRequestState] [nvarchar](50) NULL,
	[WorkItemEntity_buid] [varchar](40) NOT NULL,
	[WorkItemEntity_oid] [varchar](40) NOT NULL,
	[entity_start_date] [datetime] NOT NULL,
	[entity_end_date] [datetime] NOT NULL,
	[WorkItemEntity_uid] [varchar](40) NOT NULL,
	[entity_is_deleted] [bit] NOT NULL,
	[entity_is_current] [bit] NOT NULL,
)
GO
CREATE NONCLUSTERED INDEX [IX_WorkItemEntity_Key] ON [dbo].[WorkItemEntity]
( 
	[WorkItemId] ASC
)
INCLUDE ([entity_start_date], [entity_end_date], [entity_is_current], [entity_is_deleted])
go

CREATE NONCLUSTERED INDEX [IX_WorkItemEntity_StartEndDate] ON [dbo].[WorkItemEntity]
( 
	[entity_start_date] ASC, [entity_end_date] ASC
)
INCLUDE ([WorkItemId])
go
