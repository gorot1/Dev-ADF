﻿CREATE TABLE [dbo].[PsBimProjectStatusHistory](
	[BusinessUnit] [varchar](5) NOT NULL,
	[ProjectId] [varchar](15) NOT NULL,
	[EffectiveDate] [datetime] NULL,
	[EffectiveSeq] [smallint] NOT NULL,
	[ProjectStatus] [varchar](1) NOT NULL,
	[ProjectPriority] [smallint] NOT NULL,
	[CompletePct] [float] NOT NULL,
	[PsBimProjectStatusHistory_buid] [varchar](40) NOT NULL,
	[PsBimProjectStatusHistory_uid] [varchar](40) NOT NULL,
	[PsBimProjectStatusHistory_oid] [varchar](40) NOT NULL,
	[entity_start_date] [datetime] NOT NULL,
	[entity_is_deleted] [bit] NOT NULL,
	[entity_is_current] [bit] NOT NULL,
	[entity_end_date] [datetime] NOT NULL
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
GO
ALTER TABLE [dbo].[PsBimProjectStatusHistory]
	ADD CONSTRAINT [XPKPsBimProjectStatusHistory] PRIMARY KEY NONCLUSTERED ([PsBimProjectStatusHistory_uid])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectStatusHistory_Key] ON [dbo].[PsBimProjectStatusHistory]
( 
	[ProjectId] ASC, [BusinessUnit] ASC
)
INCLUDE ([entity_start_date], [entity_end_date], [entity_is_current], [entity_is_deleted])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectStatusHistory_IsCurrent] ON [dbo].[PsBimProjectStatusHistory]
( 
	[entity_is_current] ASC
)
INCLUDE ([BusinessUnit], [ProjectId])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectStatusHistory_StartEndDate] ON [dbo].[PsBimProjectStatusHistory]
( 
	[entity_start_date] ASC, [entity_end_date] ASC
)
INCLUDE ([BusinessUnit], [ProjectId])
GO
