﻿CREATE TABLE [dbo].[GaBimEventContainer](
	[campaign] [nvarchar](max) NULL,
	[dateHourMinute] [datetime] NULL,
	[dimension25] [nvarchar](max) NULL,
	[eventAction] [nvarchar](max) NULL,
	[eventCategory] [nvarchar](max) NULL,
	[eventLabel] [nvarchar](max) NULL,
	[hostname] [nvarchar](max) NULL,
	[pagePath] [nvarchar](max) NULL,
	[source] [nvarchar](500) NULL,
	[medium] [nvarchar](100) NULL,
	[eventValue] [bigint] NULL,
	[totalEvents] [bigint] NULL,
	[accountID] [int] NOT NULL,
	[viewID] [int] NOT NULL,
	[profileID] [int] NOT NULL,
	[webPropertyID] [varchar](20) NOT NULL,
	[entity_event_date] [date] NOT NULL,
	[GaBimEventContainer_buid] [varchar](40) NOT NULL
)
GO
ALTER TABLE [dbo].[GaBimEventContainer]
	ADD CONSTRAINT [XPKGaBimEventContainer] PRIMARY KEY NONCLUSTERED ([GaBimEventContainer_buid] ASC,[entity_event_date] ASC)
GO
CREATE NONCLUSTERED INDEX [IX_GaBimEventContainer_entity_event_date] ON [dbo].[GaBimEventContainer]
(
	[entity_event_date] ASC
)
GO
