﻿CREATE TABLE [dbo].[GaBimEvents](
	[campaign] [nvarchar](1000) NULL,
	[dateHourMinute] [datetime] NULL,
	[eventAction] [nvarchar](2500) NULL,
	[eventCategory] [nvarchar](200) NULL,
	[eventLabel] [nvarchar](max) NULL,
	[hostname] [nvarchar](255) NULL,
	[pagePath] [nvarchar](2000) NULL,
	[source] [nvarchar](500) NULL,
	[medium] [nvarchar](100) NULL,
	[segment] [nvarchar](100) NULL,
	[totalEvents] [bigint] NULL,
	[uniqueEvents] [bigint] NULL,
	[accountID] [int] NOT NULL,
	[viewID] [int] NOT NULL,
	[profileID] [int] NOT NULL,
	[webPropertyID] [varchar](20) NOT NULL,
	[entity_event_date] [date] NOT NULL,
	[GaBimEvents_buid] [varchar](40) NOT NULL
)
GO
ALTER TABLE [dbo].[GaBimEvents]
	ADD CONSTRAINT [XPKGaBimEvents] PRIMARY KEY NONCLUSTERED ([GaBimEvents_buid] ASC,[entity_event_date] ASC)
GO
CREATE NONCLUSTERED INDEX [IX_GaBimEvents_entity_event_date] ON [dbo].[GaBimEvents]
(
	[entity_event_date] ASC
)
GO