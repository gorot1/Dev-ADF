﻿CREATE TABLE [dbo].[PsBimProjectManager](
	[BusinessUnit] [varchar](5) NOT NULL,
	[ProjectId] [varchar](15) NOT NULL,
	[ProjectManagerPIN] [varchar](11) NOT NULL,
	[EffectiveDate] [date] NULL,
	[RoleType] [varchar](6) NULL,
	[ProjectRole] [varchar](15) NULL,
	[ContributionPct] [float] NULL,
	[StartDate] [date] NULL,
	[EndDate] [date] NULL,
	[SchedNum] [int] NULL,
	[DescrLong] [varchar](100) NULL,
	[entity_start_date] [datetime] NOT NULL,
	[PsBimProjectManager_buid] [varchar](40) NOT NULL,
	[PsBimProjectManager_oid] [varchar](40) NOT NULL,
	[PsBimProjectManager_uid] [varchar](40) NOT NULL,
	[entity_is_deleted] [bit] NOT NULL,
	[entity_is_current] [bit] NOT NULL,
	[entity_end_date] [datetime] NOT NULL
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
GO
ALTER TABLE [dbo].[PsBimProjectManager]
	ADD CONSTRAINT [XPKPsBimProjectManager] PRIMARY KEY NONCLUSTERED ([PsBimProjectManager_uid])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectManager_Key] ON [dbo].[PsBimProjectManager]
( 
	[ProjectId] ASC, [ProjectManagerPIN] ASC, [BusinessUnit] ASC
)
INCLUDE ([entity_start_date], [entity_end_date], [entity_is_current], [entity_is_deleted])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectManager_IsCurrent] ON [dbo].[PsBimProjectManager]
( 
	[entity_is_current] ASC
)
INCLUDE ([BusinessUnit], [ProjectId])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectManager_StartEndDate] ON [dbo].[PsBimProjectManager]
( 
	[entity_start_date] ASC, [entity_end_date] ASC
)
INCLUDE ([BusinessUnit], [ProjectId], [ProjectManagerPIN])
GO
