﻿CREATE TABLE [dbo].[IrisUaUserListBasic](
	[User_Unique_ID] [int] NULL,
	[Security_Profile_Unique_ID] [int] NULL,
	[User_Name] [nvarchar](300) NULL,
	[User_First_Name] [nvarchar](300) NULL,
	[User_Last_Name] [nvarchar](300) NULL,
	[User_Logon_Name] [nvarchar](300) NULL,
	[User_ID] [nvarchar](300) NULL,
	[User_Email] [nvarchar](300) NULL,
	[User_Title] [nvarchar](300) NULL,
	[User_Is_Active] [int] NULL,
	[User_Is_Suspended] [int] NULL,
	[User_Is_Decommissioned] [int] NULL,
	[User_Gender] [nvarchar](300) NULL,
	[User_Can_Report_On_Any_Client] [int] NULL,
	[User_Can_Report_On_Any_Group] [int] NULL,
	[User_Can_Report_On_Any_Project] [int] NULL,
	[User_Can_Report_On_Any_User] [int] NULL,
	[User_Approval_Group_Unique_ID] [int] NULL,
	[User_Functional_Group_Unique_ID] [int] NULL,
	[User_Resource_Group_Unique_ID] [int] NULL,
	[User_Hire_Date] [nvarchar](300) NULL,
	[User_Security_Role] [nvarchar](300) NULL,
	[User_Resource_Type] [nvarchar](300) NULL,
	[User_Resource_Type_ID] [nvarchar](300) NULL,
	[User_Master_Site_Unique_ID] [int] NULL,
	[User_Active_Site_Unique_ID] [int] NULL,
	[User_Primary_Role] [nvarchar](300) NULL,
	[User_Description] [nvarchar](300) NULL,
	[User_Language] [nvarchar](300) NULL,
	[User_Last_Evaluation_Date] [nvarchar](300) NULL,
	[User_Next_Evaluation_Date] [nvarchar](300) NULL,
	[User_Termination_Date] [nvarchar](300) NULL,
	[User_Business_Phone] [nvarchar](300) NULL,
	[User_Mobile] [nvarchar](300) NULL,
	[User_Alternate_Phone] [nvarchar](300) NULL,
	[User_Pager] [nvarchar](300) NULL,
	[User_Fax] [nvarchar](300) NULL,
	[User_Service_Date] [nvarchar](300) NULL,
	[User_Holiday_Set] [nvarchar](300) NULL,
	[User_type] [nvarchar](300) NULL,
	[User_Address] [nvarchar](300) NULL,
	[User_Firm_ID] [nvarchar](300) NULL,
	[User_Firm_Name] [nvarchar](300) NULL,
	[Send_Error_Notifications] [bit] NULL,
	[Consultant_Status] [nvarchar](300) NULL,
	[Consultant_Status_ID] [nvarchar](300) NULL,
	[BDC_Email] [nvarchar](300) NULL,
	[entity_lineage_id] [varchar](2000) NOT NULL,
	[entity_load_timestamp] [datetime] NOT NULL,
	[IrisUaUserListBasic_oid] [varchar](40) NOT NULL,
	[IrisUaUserListBasic_buid] [varchar](40) NOT NULL,
	[entity_start_date] [datetime] NOT NULL,
	[IrisUaUserListBasic_uid] [varchar](40) NOT NULL,
	[entity_is_deleted] [bit] NOT NULL,
	[entity_is_current] [bit] NOT NULL,
	[entity_end_date] [datetime] NOT NULL
)
GO
ALTER TABLE [dbo].[IrisUaUserListBasic]
	ADD CONSTRAINT [XPKIrisUaUserListBasic] PRIMARY KEY NONCLUSTERED ([IrisUaUserListBasic_uid])
GO

CREATE NONCLUSTERED INDEX [IX_IrisUaUserListBasic_Key] ON [dbo].[IrisUaUserListBasic]
( 
	[User_Unique_ID] ASC
)
INCLUDE ([entity_start_date], [entity_end_date], [entity_is_current], [entity_is_deleted])
go

CREATE NONCLUSTERED INDEX [IX_IrisUaUserListBasic_StartEndDate] ON [dbo].[IrisUaUserListBasic]
( 
	[entity_start_date] ASC, [entity_end_date] ASC
)
INCLUDE ([User_Unique_ID])
go
