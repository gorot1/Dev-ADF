﻿CREATE TABLE [dbo].[EpiServerContentListEntity](
	[parentId] [bigint] NULL,
	[element] [nvarchar](max) NULL,
	[path] [nvarchar](max) NULL,
	[target] [nvarchar](max) NULL,
	[parentType] [nvarchar](max) NULL,
	[elementType] [nvarchar](max) NULL,
	[entity_modified_on] [datetime] NOT NULL,
	[EpiServerContentListEntity_buid] [varchar](40) NOT NULL,
	[EpiServerContentListEntity_oid] [varchar](40) NOT NULL,
	[EpiServerContentListEntity_uid] [nvarchar](40) NOT NULL
)
GO

ALTER TABLE [dbo].[EpiServerContentListEntity]
	ADD CONSTRAINT [XPKEpiServerContentListEntity] PRIMARY KEY NONCLUSTERED ([EpiServerContentListEntity_buid])
GO
