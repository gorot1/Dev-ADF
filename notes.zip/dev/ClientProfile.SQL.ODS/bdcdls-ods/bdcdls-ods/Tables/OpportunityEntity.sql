﻿CREATE TABLE [dbo].[OpportunityEntity]
(
	[OpportunityId] [nvarchar](300) 	NOT NULL,
	[Opportunity_CrmId] [nvarchar](300) NULL,
	[AccountId] [nvarchar](300) NULL,
	[AccountIdName] [nvarchar](300) NULL,
	[CampaignId] [nvarchar](300) NULL,
	[CampaignIdName] [nvarchar](300) NULL,
	[CloseProbability] [int] NULL,
	[CustomerId] [nvarchar](300) NULL,
	[CustomerIdName] [nvarchar](300) NULL,
	[CustomerIdTypeCode] [int] NULL,
	[Description] [nvarchar](2000) NULL,
	[EstimatedCloseDate] [date] NULL,
	[EstimatedValue] [float] NULL,
	[EstimatedValue_Base] [float] NULL,
	[IsRevenueSystemCalculated] [bit] NULL,
	[AccountingOfficer] [nvarchar](300) NULL,
	[AccountingOfficerName] [nvarchar](300) NULL,
	[AssignedDate] [datetime] NULL,
	[Authorizer] [nvarchar](300) NULL,
	[AuthorizerName] [nvarchar](300) NULL,
	[CCCSource] [nvarchar](300) NULL,
	[CCCSourceName] [nvarchar](300) NULL,
	[CGSolution] [nvarchar](300) NULL,
	[Client150kmfromHub] [bit] NULL,
	[ClientReferral] [nvarchar](300) NULL,
	[ClientReferralName] [nvarchar](300) NULL,
	[ConsultingStateCode] [int] NULL,
	[ConsultingStateChangeDate] [datetime] NULL,
	[ContactId] [nvarchar](300) NULL,
	[ContactName] [nvarchar](300) NULL,
	[DeliveryHours] [int] NULL,
	[DeliveryTypeCode] [int] NULL,
	[DesignatedHubBusinessCentre] [nvarchar](300) NULL,
	[DesignatedHubBusinessCentreName] [nvarchar](300) NULL,
	[DevelopmentStageCode] [int] NULL,
	[EntryChannelCode] [int] NULL,
	[EstimatedProjectStartDate] [datetime] NULL,
	[ExpensesBillableToClient] [bit] NULL,
	[ExpensesBillableToClientAmount] [float] NULL,
	[ExternalConsultantHoursOrFees] [int] NULL,
	[ExternalSourceOutcome] [nvarchar](2000) NULL,
	[FinancingTypeCode] [int] NULL,
	[ImprovementPriority] [nvarchar](2000) NULL,
	[InboundReferral] [nvarchar](300) NULL,
	[InboundReferralName] [nvarchar](300) NULL,
	[InternalConsultantHours] [int] NULL,
	[InternalReferrer] [nvarchar](300) NULL,
	[InternalReferrerName] [nvarchar](300) NULL,
	[LendingInstitutionContact] [nvarchar](300) NULL,
	[LendingInstitutionContactName] [nvarchar](300) NULL,
	[LendingInstitutionReferral] [nvarchar](300) NULL,
	[LendingInstitutionReferralName] [nvarchar](300) NULL,
	[MarketExpansionCode] [int] NULL,
	[NetAmount] [float] NULL,
	[NetAmountBase] [float] NULL,
	[NewRepeatBusiness] [int] NULL,
	[NotbillableJustification] [nvarchar](2000) NULL,
	[NumberOfPerDiem] [int] NULL,
	[NumberOfTrips] [int] NULL,
	[OperatingUnitId] [nvarchar](300) NULL,
	[OperatingUnitIdName] [nvarchar](300) NULL,
	[OriginatingUnitId] [nvarchar](300) NULL,
	[OriginatingUnitIdName] [nvarchar](300) NULL,
	[OtherExpenses] [float] NULL,
	[OtherExpensesDescription] [nvarchar](2000) NULL,
	[PartnerAgreement] [nvarchar](300) NULL,
	[PartnerAgreementId] [nvarchar](300) NULL,
	[PartnerAgreementIdName] [nvarchar](300) NULL,
	[PartnerAgreementName] [nvarchar](300) NULL,
	[PresentationDate] [datetime] NULL,
	[PrimaryIndustry] [nvarchar](300) NULL,
	[PrimaryIndustryName] [nvarchar](300) NULL,
	[SourceOfReferralCode] [int] NULL,
	[RequestedByContact] [nvarchar](300) NULL,
	[RequestedByContactName] [nvarchar](300) NULL,
	[ReuseBankingInfo] [int] NULL,
	[SalesStageChangeDate] [datetime] NULL,
	[SaleStageCode] [nvarchar](300) NULL,
	[SecondaryIndustry] [nvarchar](300) NULL,
	[SecondaryIndustryName] [nvarchar](300) NULL,
	[SourceOfAwarenessCode] [int] NULL,
	[StatusReasonChangeDate] [datetime] NULL,
	[StrategicAlliance] [nvarchar](300) NULL,
	[StrategicAllianceName] [nvarchar](300) NULL,
	[SubmissionDate] [datetime] NULL,
	[TotalEstimatedAirfare] [int] NULL,
	[UrgencyToImproveBusiness] [nvarchar](2000) NULL,
	[WebLead] [nvarchar](300) NULL,
	[WebLeadName] [nvarchar](300) NULL,
	[WeightedValue] [float] NULL,
	[WeightedValueBase] [float] NULL,
	[YearEstablished] [nvarchar](300) NULL,
	[YearsInBusiness] [float] NULL,
	[SubmissionTypeCode] [int] NULL,
	[ModifiedByName] [nvarchar](300) NULL,
	[Name] [nvarchar](300) NULL,
	[OpportunityRatingCode] [int] NULL,
	[OwnerId] [nvarchar](300) NULL,
	[OwnerIdName] [nvarchar](300) NULL,
	[ParentContactId] [nvarchar](300) NULL,
	[ParentContactIdName] [nvarchar](300) NULL,
	[StatusCode] [int] NULL,
	[StatusReasonCode] [int] NULL,
	[GoogleAnalyticsId] [nvarchar](300) NULL,
	[LineOfBusinessNameEn] [nvarchar](300) NULL,
	[LineOfBusinessNameFr] [nvarchar](300) NULL,
	[Lob_CrmID] [nvarchar](300) NULL,
	[LineOfBusinessCode] [nvarchar](300) NULL,
	[CGSolutionNameEn] [nvarchar](300) NULL,
	[CGSolutionNameFr] [nvarchar](300) NULL,
	[SaleStageDescrEn] [nvarchar](300) NULL,
	[SaleStageDescrFr] [nvarchar](300) NULL,
	[CustomerIdTypeDescrEn] [nvarchar](300) NULL,
	[CustomerIdTypeDescrFr] [nvarchar](300) NULL,
	[ConsultingStateDescrEn] [nvarchar](300) NULL,
	[ConsultingStateDescrFr] [nvarchar](300) NULL,
	[DeliveryTypeDescrEn] [nvarchar](300) NULL,
	[DeliveryTypeDescrFr] [nvarchar](300) NULL,
	[DevelopmentStageDescrEn] [nvarchar](300) NULL,
	[DevelopmentStageDescrFr] [nvarchar](300) NULL,
	[EntryChannelDescrEn] [nvarchar](300) NULL,
	[EntryChannelDescrFr] [nvarchar](300) NULL,
	[FinancingTypeDescrEn] [nvarchar](300) NULL,
	[FinancingTypeDescrFr] [nvarchar](300) NULL,
	[MarketExpansionDescrEn] [nvarchar](300) NULL,
	[MarketExpansionDescrFr] [nvarchar](300) NULL,
	[SourceOfReferralDescrEn] [nvarchar](300) NULL,
	[SourceOfReferralDescrFr] [nvarchar](300) NULL,
	[SourceOfAwarenessDescrEn] [nvarchar](300) NULL,
	[SourceOfAwarenessDescrFr] [nvarchar](300) NULL,
	[SubmissionTypeDescrEn] [nvarchar](300) NULL,
	[SubmissionTypeDescrFr] [nvarchar](300) NULL,
	[OpportunityRatingDescrEn] [nvarchar](300) NULL,
	[OpportunityRatingDescrFr] [nvarchar](300) NULL,
	[StatusDescrEn] [nvarchar](300) NULL,
	[StatusDescrFr] [nvarchar](300) NULL,
	[StatusReasonDescrEn] [nvarchar](300) NULL,
	[StatusReasonDescrFr] [nvarchar](300) NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [nvarchar](300) NULL,
	[ModifiedOn] [datetime] NULL,
	[ModifiedBy] [nvarchar](300) NULL,
	[OpportunityEntity_buid] 	varchar(40) 	NOT NULL,
	[OpportunityEntity_oid] 	varchar(40) 	NOT NULL,
	[OpportunityEntity_uid] 	varchar(40) 	NOT NULL,
	[entity_start_date] 		datetime 		NOT NULL,
	[entity_end_date] 			datetime 		NOT NULL,
	[entity_is_current] 		bit 			NOT NULL,
	[entity_is_deleted] 		bit 			NOT NULL
	,CONSTRAINT [PK_OpportunityEntity] PRIMARY KEY NONCLUSTERED ([OpportunityEntity_uid] ASC)
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
go

CREATE NONCLUSTERED INDEX [IX_OpportunityEntity_Key] ON [dbo].[OpportunityEntity]
( 
	[OpportunityId] ASC
)
INCLUDE ([entity_start_date], [entity_end_date], [entity_is_current], [entity_is_deleted])
go

CREATE NONCLUSTERED INDEX [IX_OpportunityEntity_IsCurrent] ON [dbo].[OpportunityEntity]
( 
	[entity_is_current] ASC
)
INCLUDE ([LineOfBusinessNameEn], [OpportunityId])
go

CREATE NONCLUSTERED INDEX [IX_OpportunityEntity_StartEndDate] ON [dbo].[OpportunityEntity]
( 
	[entity_start_date] ASC, [entity_end_date] ASC
)
INCLUDE ([OpportunityId])
go

CREATE NONCLUSTERED INDEX [IX_OpportunityEntity_EndDateLineOfBusiness] ON [dbo].[OpportunityEntity]
( 
	[entity_end_date] ASC, [LineOfBusinessNameEn] ASC
)
INCLUDE ([AccountId])
go
