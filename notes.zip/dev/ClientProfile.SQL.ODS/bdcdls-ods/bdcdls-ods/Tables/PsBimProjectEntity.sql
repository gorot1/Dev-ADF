﻿CREATE TABLE [dbo].[PsBimProjectEntity](
	[BusinessUnit] [varchar](5) NOT NULL,
	[ProjectId] [varchar](15) NOT NULL,
	[LastActivityId] [int] NOT NULL,
	[EffectiveStatus] [varchar](1) NOT NULL,
	[IntegrationTemplate] [varchar](15) NOT NULL,
	[ProjectName] [varchar](30) NOT NULL,
	[ProjectType] [varchar](5) NOT NULL,
	[SystemSource] [varchar](3) NOT NULL,
	[CurrencyCode] [varchar](3) NOT NULL,
	[CurEffDtType] [varchar](1) NOT NULL,
	[CompletePerc] [float] NOT NULL,
	[CustomerId] [varchar](15) NULL,
	[RelatedProjectId] [varchar](15) NULL,
	[DeliveryTypeCode] [varchar](4) NULL,
	[ProjectFinFlag] [varchar](2) NULL,
	[CustomerServicesId] [varchar](15) NULL,
	[CRMAccount_CRMId] [varchar](15) NULL,
	[CRMProjectNo] [varchar](15) NULL,
	[CRMOpportunity_CRMId] [varchar](15) NULL,
	[JobFamilyId] [varchar](2) NULL,
	[RefEmployeeId] [varchar](11) NULL,
	[RefDepartmentId] [varchar](10) NULL,
	[PaidPerc] [float] NOT NULL,
	[StartDate] [date] NOT NULL,
	[EndDate] [date] NOT NULL,
	[ProjectTypeName] [varchar](30) NULL,
	[ProjectStatusDate] [date] NULL,
	[ProjectStatus] [varchar](1) NULL,
	[PsBimProjectEntity_buid] [varchar](40) NOT NULL,
	[PsBimProjectEntity_uid] [varchar](40) NOT NULL,
	[PsBimProjectEntity_oid] [varchar](40) NOT NULL,
	[entity_start_date] [datetime] NOT NULL,
	[entity_is_deleted] [bit] NOT NULL,
	[entity_is_current] [bit] NOT NULL,
	[entity_end_date] [datetime] NOT NULL
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
GO
ALTER TABLE [dbo].[PsBimProjectEntity]
	ADD CONSTRAINT [XPKPsBimProjectEntity] PRIMARY KEY NONCLUSTERED ([PsBimProjectEntity_uid])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectEntity_Key] ON [dbo].[PsBimProjectEntity]
( 
	[ProjectId] ASC, [BusinessUnit] ASC
)
INCLUDE ([entity_start_date], [entity_end_date], [entity_is_current], [entity_is_deleted])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectEntity_IsCurrent] ON [dbo].[PsBimProjectEntity]
( 
	[entity_is_current] ASC
)
INCLUDE ([BusinessUnit], [CustomerId], [ProjectId])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectEntity_StartEndDate] ON [dbo].[PsBimProjectEntity]
( 
	[entity_start_date] ASC, [entity_end_date] ASC
)
INCLUDE ([BusinessUnit], [ProjectId])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectEntity_BusinessUnitIsCurrent] ON [dbo].[PsBimProjectEntity]
( 
	[BusinessUnit] ASC, [entity_is_current] ASC
)
INCLUDE ([CustomerId], [ProjectId], [StartDate])
GO
