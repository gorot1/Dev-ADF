﻿CREATE TABLE [dbo].[IrisUaProjectWorkflowHistory](
	[Project_Unique_Id] [int] NULL,
	[Project_Workflow_History_Source_State] [nvarchar](300) NULL,
	[Project_Workflow_History_Destination_State] [nvarchar](300) NULL,
	[Project_Workflow_History_Modified_By] [int] NULL,
	[Project_Workflow_History_Action] [nvarchar](300) NULL,
	[Project_Workflow_History_Date_Modified] [nvarchar](300) NULL,
	[entity_lineage_id] [varchar](255) NOT NULL,
	[entity_load_timestamp] [datetime] NOT NULL,
	[entity_event_date] [date] NOT NULL,
	[IrisUaProjectWorkflowHistory_buid] [varchar](40) NOT NULL
)
GO
ALTER TABLE [dbo].[IrisUaProjectWorkflowHistory]
	ADD CONSTRAINT [XPKIrisUaProjectWorkflowHistory] PRIMARY KEY NONCLUSTERED ([IrisUaProjectWorkflowHistory_buid] ASC,[entity_event_date] ASC)
GO

CREATE NONCLUSTERED INDEX [IX_IrisUaProjectWorkflowHistory_Key] ON [dbo].[IrisUaProjectWorkflowHistory]
( 
	[Project_Unique_Id] ASC
)
go
