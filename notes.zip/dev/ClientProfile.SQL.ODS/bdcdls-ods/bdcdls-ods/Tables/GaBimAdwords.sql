﻿CREATE TABLE [dbo].[GaBimAdwords](
	[campaign] [nvarchar](1000) NULL,
	[date] [date] NULL,
	[source] [nvarchar](500) NULL,
	[medium] [nvarchar](100) NULL,
	[adContent] [nvarchar](max) NULL,
	[keyword] [nvarchar](max) NULL,
	[adCost] [float] NULL,
	[adClicks] [bigint] NULL,
	[impressions] [bigint] NULL,
	[timeOnPage] [float] NULL,
	[accountID] [int] NOT NULL,
	[viewID] [int] NOT NULL,
	[profileID] [int] NOT NULL,
	[webPropertyID] [varchar](20) NOT NULL,
	[entity_event_date] [date] NOT NULL,
	[GaBimAdwords_buid] [varchar](40) NOT NULL
)
GO
ALTER TABLE [dbo].[GaBimAdwords]
	ADD CONSTRAINT [XPKGaBimAdwords] PRIMARY KEY NONCLUSTERED ([GaBimAdwords_buid] ASC,[entity_event_date] ASC)
GO
CREATE NONCLUSTERED INDEX [IX_GaBimAdwords_entity_event_date] ON [dbo].[GaBimAdwords]
(
	[entity_event_date] ASC
)
GO
