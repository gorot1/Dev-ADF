﻿CREATE TABLE [dbo].[OpportunitySalesStagesEntity]
(
	[OpportunitySaleStageId_CrmId] [nvarchar](300) 	NOT NULL,
	[OrganizationIdName] [nvarchar](300) NULL,
	[OpportunitySaleStageId] [nvarchar](300) NULL,
	[OrganizationId] [nvarchar](300) NULL,
	[StatusCode] [int] NULL,
	[StatusReasonCode] [int] NULL,
	[VersionNumber] [varbinary](max) NULL,
	[ImportSequenceNumber] [int] NULL,
	[NameEn] [nvarchar](300) NULL,
	[LobId] [nvarchar](300) NULL,
	[NameFr] [nvarchar](300) NULL,
	[Probability] [int] NULL,
	[LobNameEn] [nvarchar](300) NULL,
	[LobNameFr] [nvarchar](300) NULL,
	[StatusDescrEn] [nvarchar](300) NULL,
	[StatusDescrFr] [nvarchar](300) NULL,
	[StatusReasonDescrEn] [nvarchar](300) NULL,
	[StatusReasonDescrFr] [nvarchar](300) NULL,
	[CreatedByName] [nvarchar](300) NULL,
	[ModifiedByName] [nvarchar](300) NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [nvarchar](300) NULL,
	[ModifiedOn] [datetime] NULL,
	[ModifiedBy] [nvarchar](300) NULL,
	[OpportunitySalesStagesEntity_buid] 	varchar(40) 	NOT NULL,
	[OpportunitySalesStagesEntity_oid] 		varchar(40) 	NOT NULL,
	[OpportunitySalesStagesEntity_uid] 		varchar(40) 	NOT NULL,
	[entity_start_date] 					datetime 		NOT NULL,
	[entity_end_date] 						datetime 		NOT NULL,
	[entity_is_current] 					bit 			NOT NULL,
	[entity_is_deleted] 					bit 			NOT NULL
	,CONSTRAINT [PK_OpportunitySalesStagesEntity] PRIMARY KEY NONCLUSTERED ([OpportunitySalesStagesEntity_uid] ASC)
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
go

CREATE NONCLUSTERED INDEX [IX_OpportunitySalesStagesEntity_Key] ON [dbo].[OpportunitySalesStagesEntity]
( 
	[OpportunitySaleStageId] ASC
)
INCLUDE ([entity_start_date], [entity_end_date], [entity_is_current], [entity_is_deleted])
go

CREATE NONCLUSTERED INDEX [IX_OpportunitySalesStagesEntity_StartEndDate] ON [dbo].[OpportunitySalesStagesEntity]
( 
	[entity_start_date] ASC, [entity_end_date] ASC
)
INCLUDE ([OpportunitySaleStageId])
go
