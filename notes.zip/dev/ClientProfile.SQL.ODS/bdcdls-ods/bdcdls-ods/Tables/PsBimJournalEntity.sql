﻿CREATE TABLE [dbo].[PsBimJournalEntity](
	[BusinessUnit] [varchar](5) NOT NULL,
	[JournalId] [varchar](10) NOT NULL,
	[JournalDate] [date] NOT NULL,
	[UnpostSeq] [smallint] NOT NULL,
	[JournalLine] [int] NOT NULL,
	[Ledger] [varchar](10) NOT NULL,
	[Account] [varchar](10) NOT NULL,
	[DepartmentId] [varchar](10) NOT NULL,
	[OperatingUnit] [varchar](8) NOT NULL,
	[Product] [varchar](6) NOT NULL,
	[ProgramCode] [varchar](5) NULL,
	[Affiliate] [varchar](5) NULL,
	[ProjectId] [varchar](15) NULL,
	[CurrencyCode] [varchar](3) NULL,
	[MonetaryAmt] [float] NOT NULL,
	[StatisticAmt] [float] NOT NULL,
	[JournalLineRef] [varchar](10) NULL,
	[LineDescr] [varchar](30) NULL,
	[JournalLineDate] [date] NOT NULL,
	[ForeignCurrencyCode] [varchar](3) NULL,
	[ForeignAmt] [float] NOT NULL,
	[RateDiv] [float] NOT NULL,
	[RateMult] [float] NOT NULL,
	[JournalLineSource] [varchar](3) NOT NULL,
	[AccountName] [varchar](10) NULL,
	[AccountDescription] [varchar](30) NULL,
	[ProductName] [varchar](10) NULL,
	[ProductDescription] [varchar](30) NULL,
	[PsBimJournalEntity_buid] [varchar](40) NOT NULL,
	[entity_event_date] [date] NOT NULL
)
GO
ALTER TABLE [dbo].[PsBimJournalEntity]
	ADD CONSTRAINT [XPKPsBimJournalEntity] PRIMARY KEY NONCLUSTERED ([PsBimJournalEntity_buid] ASC,[entity_event_date] ASC)
GO

CREATE NONCLUSTERED INDEX [IX_PsBimJournalEntity_BusinessUnitProject] ON [dbo].[PsBimJournalEntity]
( 
	[ProjectId] ASC, [BusinessUnit] ASC
)
INCLUDE ([Account], [JournalDate], [MonetaryAmt], [StatisticAmt])
GO
