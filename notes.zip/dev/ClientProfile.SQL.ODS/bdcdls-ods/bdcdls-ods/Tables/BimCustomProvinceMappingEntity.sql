﻿CREATE TABLE [dbo].[BimCustomProvinceMappingEntity](
	[Province] [nvarchar](max) NULL,
	[RegionBDC] [nvarchar](max) NULL,
	[ProvinceCode] [nvarchar](max) NULL,
	[FSAProvince] [bigint] NULL,
	[ProvinceFr] [nvarchar](max) NULL,
	[RegionBDCFr] [nvarchar](max) NULL,
	[entity_lineage_id] [varchar](255) NOT NULL,
	[entity_load_timestamp] [datetime] NOT NULL,
	[BimCustomProvinceMappingEntity_oid] [varchar](40) NOT NULL,
	[BimCustomProvinceMappingEntity_buid] [varchar](40) NOT NULL,
	[entity_start_date] [datetime] NOT NULL,
	[entity_end_date] [datetime] NOT NULL,
	[entity_is_current] [bit] NOT NULL,
	[entity_is_deleted] [bit] NOT NULL,
	[entity_created_on] [datetime] NOT NULL,
	[entity_modified_on] [datetime] NOT NULL,
	[BimCustomProvinceMappingEntity_uid] [varchar](40) NOT NULL
)
GO

ALTER TABLE [dbo].[BimCustomProvinceMappingEntity]
	ADD CONSTRAINT [XPKBimCustomProvinceMappingEntity] PRIMARY KEY NONCLUSTERED ([BimCustomProvinceMappingEntity_buid])
GO

CREATE NONCLUSTERED INDEX [IX_BimCustomProvinceMappingEntity_entity_modified_on] ON [dbo].[BimCustomProvinceMappingEntity]
(
	[entity_modified_on] ASC
)
GO
