﻿CREATE TABLE [dbo].[GaBimChannelGrouping](
	[campaign] [nvarchar](max) NULL,
	[source] [nvarchar](500) NULL,
	[medium] [nvarchar](100) NULL,
	[segment] [nvarchar](max) NULL,
	[sessions] [bigint] NULL,
	[accountID] [int] NOT NULL,
	[viewID] [int] NOT NULL,
	[profileID] [int] NOT NULL,
	[webPropertyID] [varchar](20) NOT NULL,
	[GaBimChannelGrouping_buid] [varchar](40) NOT NULL,
	[entity_start_date] [datetime] NOT NULL,
	[entity_end_date] [datetime] NOT NULL,
	[entity_is_current] [bit] NOT NULL,
	[entity_is_deleted] [bit] NOT NULL,
	[entity_created_on] [datetime] NOT NULL,
	[entity_modified_on] [datetime] NOT NULL,
	[GaBimChannelGrouping_uid] [varchar](40) NOT NULL
)
GO
ALTER TABLE [dbo].[GaBimChannelGrouping]
	ADD CONSTRAINT [XPKGaBimChannelGrouping] PRIMARY KEY NONCLUSTERED ([GaBimChannelGrouping_uid])
GO
CREATE NONCLUSTERED INDEX [IX_GaBimChannelGrouping_entity_modified_on] ON [dbo].[GaBimChannelGrouping]
(
	[entity_modified_on] ASC
)
GO
