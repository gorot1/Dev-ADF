﻿CREATE TABLE [dbo].[PsBimProjectPtd](
	[BusinessUnit] [varchar](5) NOT NULL,
	[ProjectId] [varchar](15) NOT NULL,
	[BDC_BUD_REV_AMT] [float] NOT NULL,
	[BDC_BUD_EXP_AMT] [float] NOT NULL,
	[BDC_B_A_EXP_AMT] [float] NOT NULL,
	[BDC_B_A_F_EXP_AMT] [float] NOT NULL,
	[BDC_BUD_INT_AMT] [float] NOT NULL,
	[BDC_BUD_INT_NB_AMT] [float] NOT NULL,
	[BDC_B_A_INT_AMT] [float] NOT NULL,
	[BDC_B_A_F_INT_AMT] [float] NOT NULL,
	[BDC_B_A_INT_NB_AMT] [float] NOT NULL,
	[BDC_BUD_HRS] [float] NOT NULL,
	[BDC_BUD_EXP_HRS] [float] NOT NULL,
	[BDC_BUD_EXP_ADJ_HR] [float] NOT NULL,
	[BDC_B_A_EXP_HRS] [float] NOT NULL,
	[BDC_BUD_INT_HRS] [float] NOT NULL,
	[BDC_BUD_INT_ADJ_HR] [float] NOT NULL,
	[BDC_BUD_INT_NB_HRS] [float] NOT NULL,
	[BDC_B_A_INT_HRS] [float] NOT NULL,
	[BDC_B_A_INT_NB_HRS] [float] NOT NULL,
	[BDC_BUD_PKT2_EXP] [float] NOT NULL,
	[BDC_BUD_PKT2_BLD] [float] NOT NULL,
	[BDC_ACT_REV_AMT] [float] NOT NULL,
	[BDC_DEF_REV_AMT] [float] NOT NULL,
	[BDC_ACT_EXP_AMT] [float] NOT NULL,
	[BDC_ACT_EXP_ADJ_HR] [float] NOT NULL,
	[BDC_ACT_INT_AMT] [float] NOT NULL,
	[BDC_ACT_INT_NB_AMT] [float] NOT NULL,
	[BDC_ACT_HRS] [float] NOT NULL,
	[BDC_ACT_INT_HRS] [float] NOT NULL,
	[BDC_ACT_INT_ADJ_HR] [float] NOT NULL,
	[BDC_ACT_INT_NB_HRS] [float] NOT NULL,
	[BDC_ACT_PKT2_EXP] [float] NOT NULL,
	[BDC_ACT_PKT2_BLD] [float] NOT NULL,
	[BDC_BLD_AMT] [float] NOT NULL,
	[BDC_OUT_PKT_EXP] [float] NOT NULL,
	[BDC_OUT_PKT_BLD] [float] NOT NULL,
	[BDC_PTD_PFC_AMT] [float] NOT NULL,
	[BDC_PFC_OVERFLOW] [bit] NOT NULL,
	[FirstActivityDate] [date] NULL,
	[LastActivityDate] [date] NULL,
	[BDC_PROVISIONS] [float] NOT NULL,
	[PsBimProjectPtd_buid] [varchar](40) NOT NULL,
	[PsBimProjectPtd_uid] [varchar](40) NOT NULL,
	[PsBimProjectPtd_oid] [varchar](40) NOT NULL,
	[entity_start_date] [datetime] NOT NULL,
	[entity_end_date] [datetime] NOT NULL,
	[entity_is_current] [bit] NOT NULL,
	[entity_is_deleted] [bit] NOT NULL
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
GO
ALTER TABLE [dbo].[PsBimProjectPtd]
	ADD CONSTRAINT [XPKPsBimProjectPtd] PRIMARY KEY NONCLUSTERED ([PsBimProjectPtd_uid])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectPtd_Key] ON [dbo].[PsBimProjectPtd]
( 
	[ProjectId] ASC, [BusinessUnit] ASC
)
INCLUDE ([entity_start_date], [entity_end_date], [entity_is_current], [entity_is_deleted])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectPtd_IsCurrent] ON [dbo].[PsBimProjectPtd]
( 
	[entity_is_current] ASC
)
INCLUDE ([BusinessUnit], [ProjectId])
GO

CREATE NONCLUSTERED INDEX [IX_PsBimProjectPtd_StartEndDate] ON [dbo].[PsBimProjectPtd]
( 
	[entity_start_date] ASC, [entity_end_date] ASC
)
INCLUDE ([BusinessUnit], [ProjectId])
GO
