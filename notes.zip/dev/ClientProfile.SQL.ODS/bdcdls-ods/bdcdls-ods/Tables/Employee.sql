﻿CREATE TABLE [dbo].[Employee]
(
	[CRM_SystemUserId] [nvarchar](100) NULL,
	[EmployeePIN] [nvarchar](100) NULL,
	[FullName] [nvarchar](100) NULL,
	[FirstName] [nvarchar](100) NULL,
	[LastName] [nvarchar](100) NULL,
	[JobTitle] [varchar](100) NULL,
	[ManagerPIN] [nvarchar](100) NULL,
	[ManagerFullName] [nvarchar](100) NULL,
	[DepartmentCode] [nvarchar](100) NULL,
	[DepartmentName] [nvarchar](100) NULL,
	[ManagementUnitCode] [nvarchar](100) NULL,
	[ManagementUnitName] [nvarchar](100) NULL,
	[LineOfBusinessName] [nvarchar](100) NULL,
	[IsActive] [bit] NULL,
	[entity_start_date] [datetime] NOT NULL,
	[Employee_buid] [varchar](40) NOT NULL,
	[Employee_oid] [varchar](40) NOT NULL,
	[Employee_uid] [varchar](40) NOT NULL,
	[entity_is_deleted] [bit] NOT NULL,
	[entity_is_current] [bit] NOT NULL,
	[entity_end_date] [datetime] NOT NULL,
	CONSTRAINT [PK_Employee] PRIMARY KEY NONCLUSTERED ([Employee_uid] ASC)
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
go

CREATE NONCLUSTERED INDEX [IX_Employee_Key] ON [dbo].[Employee]
( 
	[CRM_SystemUserId] ASC
)
INCLUDE ([entity_start_date], [entity_end_date], [entity_is_current], [entity_is_deleted])
go

CREATE NONCLUSTERED INDEX [IX_Employee_IsCurrent] ON [dbo].[Employee]
( 
	[entity_is_current] ASC
)
INCLUDE ([CRM_SystemUserId], [EmployeePIN])
go

CREATE NONCLUSTERED INDEX [IX_Employee_StartEndDate] ON [dbo].[Employee]
( 
	[entity_start_date] ASC, [entity_end_date] ASC
)
INCLUDE ([CRM_SystemUserId])
go
