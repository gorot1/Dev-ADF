﻿CREATE TABLE [dbo].[AccountActivity]
(
    ActivityId	                varchar(36)		NOT NULL
    ,ActivityTypeCode	        int	
    ,ActivityTypeName	        varchar(50)
    ,CRM_AccountId	            varchar(36)
    ,AccountName	            varchar(100)
    ,CRM_OwnerSystemUserId	    varchar(36)
    ,OwnerName	                varchar(100)
    ,CRM_OwningSystemUserId	    varchar(36)
    ,CRM_OwningTeamId	        varchar(36)
    ,CRM_OwningBusinessUnitId	varchar(36)
    ,StateCode	                int	
    ,StateName	                varchar(50)
    ,StatusCode	                int	
    ,StatusName	                varchar(50)
    ,PriorityCode	            int	
    ,PriorityName	            varchar(50)
    ,Subject	                varchar(200)
    ,SenderMailBoxName	        varchar(100)
    ,ScheduledStartDate	        datetime2	
    ,ScheduledEndDate	        datetime2	
    ,ScheduledDurationMinutes	int	
    ,ActualStartDate	        datetime2	
    ,ActualEndDate	            datetime2	
    ,ActualDurationMinutes	    int	
    ,IsRegularActivity	        bit	
    ,CRM_TransactionCurrencyId	varchar(36)
    ,TransactionCurrencyCode	varchar(10)
    ,CRM_PartyId	            varchar(36)
    ,PartyObjectTypeCode	    int	
    ,ParticipationTypeMask	    int	
    ,PartyName	                varchar(100)
    ,IsPartyDeleted	            bit	
    ,CreatedOnDate	            datetime2	
    ,AccountActivity_buid		varchar(40)		NOT NULL
    ,AccountActivity_uid		varchar(40)		NOT NULL
    ,AccountActivity_oid		varchar(40)		NOT NULL
    ,entity_start_date	        datetime		NOT NULL
    ,entity_end_date	        datetime		NOT NULL
    ,entity_is_current	        bit				NOT NULL
    ,entity_is_deleted	        bit				NOT NULL
	,CONSTRAINT [PK_AccountActivity] PRIMARY KEY NONCLUSTERED ([AccountActivity_uid] ASC)
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
go

CREATE NONCLUSTERED INDEX [IX_AccountActivity_Key] ON [dbo].[AccountActivity]
( 
	[ActivityId] ASC
)
INCLUDE ([entity_start_date], [entity_end_date], [entity_is_current], [entity_is_deleted])
go

CREATE NONCLUSTERED INDEX [IX_AccountActivity_IsCurrent] ON [dbo].[AccountActivity]
( 
	[entity_is_current] ASC
)
INCLUDE ([ActivityId], [CRM_AccountId], [CRM_OwnerSystemUserId])
go

CREATE NONCLUSTERED INDEX [IX_AccountActivity_StartEndDate] ON [dbo].[AccountActivity]
( 
	[entity_start_date] ASC, [entity_end_date] ASC
)
INCLUDE ([ActivityId], [CRM_AccountId], [ActivityTypeCode], [CRM_OwnerSystemUserId], [ScheduledStartDate], [ScheduledEndDate], [ActualStartDate], [ActualEndDate])
go
