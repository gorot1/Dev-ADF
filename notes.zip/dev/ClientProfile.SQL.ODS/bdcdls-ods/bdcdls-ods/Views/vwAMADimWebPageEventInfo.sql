﻿CREATE VIEW [dbo].[vwAMADimWebPageEventInfo]
AS
SELECT ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Id, *
FROM
(
	SELECT
		HASHBYTES('SHA1', 'events' + ISNULL(eventCategory, '') + ISNULL(eventAction, '') + ISNULL(eventLabel, '') + '') WebPageEventInfoHash
		,'events' EventEntityType
		,eventCategory
		,eventAction
		,eventLabel
		,'' EventContainer
		,entity_event_date
	FROM dbo.GaBimEvents
	WHERE dateHourMinute >= '2021-01-01'
UNION ALL
	SELECT
		HASHBYTES('SHA1', 'eventContainer' + ISNULL(eventCategory, '') + ISNULL(eventAction, '') + ISNULL(eventLabel, '') + dimension25) WebPageEventInfoHash
		,'eventContainer' EventEntityType
		,eventCategory
		,eventAction
		,eventLabel
		,dimension25 EventContainer
		,entity_event_date
	FROM dbo.GaBimEventContainer
	WHERE dateHourMinute >= '2021-01-01'
) X
GO