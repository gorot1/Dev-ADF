﻿CREATE view [dbo].[vwPBIml_dimension_at_loan_New]  AS
select
ppp.AccountNumber as AccountNumber_int,
replicate('0', 6-len(ppp.AbacusCustId)) + cast(cast(ppp.AbacusCustId as int) as nvarchar)
    + '-' + substring(cast(cast(ppp.AccountNumber as int) as nvarchar), len(cast(cast(ppp.AccountNumber as int) as nvarchar))-1, 2) as AccountNumber,
le.LoanPurposeDescr,
ppp.security_coverage_amount,
lta.InterestAdjustmentDate,
lta.FloatingRateIndexCode,
rb.current_risk_rating as risk_rating,
rb.FinalRiskRating_variation as risk_rating_variation,
finstat.var_totalAssets                        as total_assets_variation,
finstat.var_TotalLiabilities                as total_liabilities_variation,
finstat.var_NetProfitAmount                    as total_profit_variation,
finstat.var_TotalSalesAmount                as total_sales_variation,
finstat.var_SuggestedAvailableFundsAmount    as available_funds_variation,
finstat.var_NetProfitMargin                    as kpi_Net_profit_margin_perc_variation,
finstat.NetProfitMargin                        as kpi_Net_profit_margin_perc,
finstat.FinancialStatementDate                as last_financialStatement_calculation,
rb.AbacusCustId, 
rb.mcs_BusinessDevelopmentLeadName,
rb.AccountCRMId,
rb.AccountName,
ou.[OriginatingUnitNameEnglish],
ou.[AreaNameEnglish],
ou.[OperationRegionName],
ppp.probability_12_month as prepayment_probability_12_month,
ppp.star_rating as prepayment_star_rating,
rb.star_rating as repeat_star_rating,
rb.RestrictedAccountFlag
from dbo.PrepaymentPredictionsEntity ppp
inner join  RepeatBusinessPredictionsEntity rb on rb.AbacusCustId = ppp.AbacusCustId
left join (select
    [OriginatingUnitNameEnglish],
    [AreaNameEnglish],
    [OperationRegionName],
    CustomerNumber
    from dbo.LoanCustomerEntity lc
inner join dbo.OrganizationRefEntity ou on ou.[OriginatingUnitNumberAbacus] = lc.OriginatingUnitCode
where lc.entity_is_current = 1 and ou.entity_is_current = 1)  ou on cast(ou.CustomerNumber as float) = rb.AbacusCustId
left join(select
    AccountNumber,
    cast(replace(AccountNumber, '-', '') as float) as Account,
    CustomerTypeCode, GrossLoanAmount,
    MaturityDate,
    LoanPurposeDescr
    from dbo.LoanEntity where entity_is_current = 1 and (ActiveLoanFlag is null or ActiveLoanFlag = 1)) le on le.account = ppp.AccountNumber
inner join (select
    AccountNumber,
    InterestAdjustmentDate,
    entity_start_date,
    entity_is_current,
    TrancheNumber,
    FloatingRateIndexCode,
    row_number() over(partition by AccountNumber order by AccrualScheduleId desc) as rnk_lta
    from dbo.LoanTrancheAttributesEntity
    where isnumeric(TrancheNumber) = 1 and entity_is_current = 1) lta
    on lta.AccountNumber = ppp.AccountNumber and lta.rnk_lta = 1
    /*
inner join (select
    re_a.AccountCrmId,
    FinalRiskRating,
    previous_risk_rating,
	row_number() over(partition by re_a.AccountCrmId order by ServiceRequestAuthorizationDate desc) as last_date,
    (FinalRiskRating - previous_risk_rating) / nullif(previous_risk_rating, 0) * 100 as FinalRiskRating_variation
    from dbo.RiskEvaluationEntity re_a
    inner join (select		
		ServiceRequestCrmId
		from dbo.WorkItemEntity
		where entity_is_current = 1 AND (
			OriginationRequestState in ('Accepted_by_Client', 'Waiting_for_Client_Acceptance', 'Cancelled')
			or AdministrationRequestState = 'Completered'
			or AnnualReviewRequestState = 'Completed'
			or GeneralAdminRequestState = 'Completed'
			or DisbursementRequestState = 'Completed'
			or InHouseSecurityState = 'Completed'
			or LoanPaymentRemittanceRequestState = 'Completed'
			or WriteOffRequestState = 'Completed'
			or SundryDisbursementRequestState = 'Completed')) wie on wie.ServiceRequestCrmId = re_a.ServiceRequestCrmId
    inner join ( select
        AccountCrmId,
        FinalRiskRating as previous_risk_rating,
        row_number() over(partition by AccountCrmId order by RiskEvaluationVersion desc, ServiceRequestAuthorizationDate desc) before_last
        from dbo.RiskEvaluationEntity
        where entity_is_current = 1) re_max_bef
        on re_max_bef.before_last = 2 and re_max_bef.AccountCrmId = re_a.AccountCrmId
    where re_a.entity_is_current = 1) re
    on re.AccountCrmId = rb.AccountCRMId and re.last_date = 1
    */
inner join(select
    cur.AccountCrmId,
    cur.FinancialStatementDate,
    cur.TotalAssets,
    cur.TotalLiabilities,
    cur.NetProfitAmount,
    cur.TotalSalesAmount,
    cur.SuggestedAvailableFundsAmount,
    cur.SuggestedTotalDebtService,
    cur.CurrentLiabilitiesAmount,
    cur.NetProfitAmount / nullif(cur.TotalSalesAmount, 0) as NetProfitMargin,
    (cur.TotalAssets - prev.TotalAssets)/ nullif(prev.TotalAssets, 0) as var_totalAssets,
    (cur.TotalLiabilities - prev.TotalLiabilities)/ nullif(prev.TotalLiabilities, 0) as var_TotalLiabilities,
    (cur.NetProfitAmount - prev.NetProfitAmount)/ nullif(prev.NetProfitAmount, 0) as var_NetProfitAmount,
    (cur.TotalSalesAmount - prev.TotalSalesAmount)/ nullif(prev.TotalSalesAmount, 0) as var_TotalSalesAmount,
    (cur.SuggestedAvailableFundsAmount - prev.SuggestedAvailableFundsAmount)/ nullif(prev.SuggestedAvailableFundsAmount, 0) as var_SuggestedAvailableFundsAmount,
    (cur.SuggestedTotalDebtService - prev.SuggestedTotalDebtService)/ nullif(prev.SuggestedTotalDebtService, 0) as var_SuggestedTotalDebtService,
    ((cur.NetProfitAmount / nullif(cur.TotalSalesAmount, 0)) - prev.NetProfitMargin)/ nullif(prev.NetProfitMargin, 0) as var_NetProfitMargin
    from dbo.RiskFinancialStatementCurrentEntity cur
left join (select
        prev.AccountCrmId,
        prev.TotalAssets,
        prev.TotalLiabilities,
        prev.NetProfitAmount,
        prev.TotalSalesAmount,
        prev.SuggestedAvailableFundsAmount,
        prev.SuggestedTotalDebtService,
        prev.FinancialStatementDate,
        prev.NetProfitAmount / nullif(prev.TotalSalesAmount, 0) as NetProfitMargin
        from dbo.RiskFinancialStatementPreviousEntity prev
        where entity_is_current = 1) prev
        inner join (select
            AccountCrmId,
            max(FinancialStatementDate) as last_fs
            from dbo.RiskFinancialStatementPreviousEntity
            where entity_is_current = 1
            group by AccountCrmId) last_prev
            on prev.FinancialStatementDate = last_prev.last_fs and prev.AccountCrmId = last_prev.AccountCrmId
        on cur.AccountCrmId = prev.AccountCrmId
        where entity_is_current = 1) finstat
        on rb.AccountCRMId = finstat.AccountCrmId
	/*	left join(select
    RestrictedAccountFlag,
	CRMAccount_CRMID 
    from dbo.AccountProfileEntity where RestrictedAccountFlag = 0 and entity_is_current = 1 and CRMAccount_CRMID IS NOT NULL) ape on ape.CRMAccount_CRMID = rb.AccountCRMId */
where rb.entity_is_current = 1 and ppp.entity_is_current = 1 and ppp.loan_outstanding_balance <> 0
GO


