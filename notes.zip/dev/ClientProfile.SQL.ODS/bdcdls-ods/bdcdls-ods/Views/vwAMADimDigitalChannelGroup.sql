﻿CREATE VIEW [dbo].[vwAMADimDigitalChannelGroup]
AS
SELECT
	ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Id
	,source
	,medium
	,campaign
FROM
	dbo.GaBimChannelGrouping
WHERE
	entity_is_current = 1
GO


