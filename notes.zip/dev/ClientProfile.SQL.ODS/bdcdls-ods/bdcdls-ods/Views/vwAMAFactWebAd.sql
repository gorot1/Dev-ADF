﻿CREATE VIEW [dbo].[vwAMAFactWebAd]
AS
SELECT
	ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Id
	,entity_event_date
	,source
	,medium
	,campaign
	,accountID
	,profileID
	--,segment
	,adContent AdContent
	,keyword AdKeyword
	,ISNULL(adCost, 0) AdCost
	,ISNULL(adClicks, 0) AdClickCount
	,ISNULL(impressions, 0) AdImpressionCount
	,ISNULL(timeOnPage, 0) AdSecondsOnPage
FROM
	dbo.GaBimAdwords
WHERE
	date >= '2021-01-01'
GO