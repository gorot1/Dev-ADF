﻿CREATE VIEW [dbo].[vwAMAFactWebPageEvent]
AS
SELECT
	Id = ROW_NUMBER() OVER (ORDER BY (SELECT NULL))
	,*
FROM
(
	SELECT entity_event_date
		,cast(replace(convert(VARCHAR(5), dateHourMinute, 108), ':', '') AS INT) TimeKey
		,hostname
		,pagePath
		,source
		,medium
		,campaign
		,accountID
		,profileID
		,segment
		,'events' EventEntityType
		,eventCategory
		,eventAction
		,eventLabel
		,'' EventContainer
		,ISNULL(totalEvents, 0) EventCount
		,ISNULL(uniqueEvents, 0) EventUniqueCount
	FROM dbo.GaBimEvents
	WHERE dateHourMinute >= '2021-01-01'
	
	UNION ALL
	
	SELECT entity_event_date
		,cast(replace(convert(VARCHAR(5), dateHourMinute, 108), ':', '') AS INT) TimeKey
		,hostname
		,pagePath
		,source
		,medium
		,campaign
		,accountID
		,profileID
		,'All Users' segment
		,'eventContainer' EventEntityType
		,eventCategory
		,eventAction
		,eventLabel
		,dimension25 EventContainer
		,ISNULL(totalEvents, 0) EventCount
		,0 EventUniqueCount
	FROM dbo.GaBimEventContainer
	WHERE dateHourMinute >= '2021-01-01'
) a
GO