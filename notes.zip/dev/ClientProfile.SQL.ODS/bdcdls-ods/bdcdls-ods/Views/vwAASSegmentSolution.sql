﻿CREATE VIEW [dbo].[vwAASSegmentSolution]
AS
/*
    AAS.DimSegmentSolution
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash for the same _KeyHash
        Then Update record
        Else skip record
*/
--DECLARE @LastLoadDateTime DATETIME2 = ? -- Last successful load datetime
--DECLARE @ExtractDateTime DATETIME2 = ?  -- As of datetime, typically SYSTEMDATETIME()
SELECT SolutionCode
	,SolutionName
	,'N/A' AS PracticeAbbr
	,'N/A' ASPracticeName
	,'N/A' ASSubSegmentAbbr
	,'N/A' ASSubSegmentName
	,'N/A' ASSegmentAbbr
	,'N/A' ASSegmentName
	,CAST(1 AS BIT) AS _CurrentFlag
	,HASHBYTES('SHA2_256', SolutionCode) AS _KeyHash
	,HASHBYTES('SHA2_256', SolutionName) AS _ValueHash
	,entity_start_date
	,entity_end_date
	,_StartDate = SYSDATETIME()
	,_EndDate = CAST('9999-12-31' AS DATE)
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (
		PARTITION BY SolutionCode ORDER BY Entity_start_date DESC
		) rn
FROM (
	SELECT DISTINCT CGSolution AS SolutionCode
		,CGSolutionNameEn AS SolutionName
		,entity_start_date
		,entity_end_date
	FROM dbo.OpportunityEntity
	WHERE
		--entity_start_date >= @LastLoadDateTime
		--AND entity_end_date > @ExtractDateTime AND
		LineOfBusinessNameEn = 'Consulting' -- Advisory related only
		--AND StatusCode <> '803750012'
		AND CGSolution IS NOT NULL
	) X
GO