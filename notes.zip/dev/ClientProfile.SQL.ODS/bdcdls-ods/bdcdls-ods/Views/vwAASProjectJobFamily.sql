﻿/*
    AAS.DimProjectJobFamily
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash for the same _KeyHash
        Then Update record
        Else skip record
*/
CREATE VIEW [dbo].[vwAASProjectJobFamily] AS

SELECT ProjectJobFamilyCode
	,ProjectJobFamilyName
	,HASHBYTES('SHA2_256', ProjectJobFamilyCode) AS _KeyHash
	,HASHBYTES('SHA2_256', ProjectJobFamilyName) AS _ValueHash
	,Entity_start_date
	,Entity_end_date
	,CAST(1 AS BIT) AS CurrentFlag
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (
		PARTITION BY ProjectJobFamilyCode ORDER BY Entity_start_date DESC
		) rn
FROM (
	SELECT DISTINCT JobFamilyId AS ProjectJobFamilyCode
		,JobFamilyId AS ProjectJobFamilyName
		,entity_start_date
		,entity_end_date
	FROM dbo.PsBimProjectEntity
	WHERE JobFamilyId IS NOT NULL AND JobFamilyId <>'' -- Exclude NULL BK
	) X
GO