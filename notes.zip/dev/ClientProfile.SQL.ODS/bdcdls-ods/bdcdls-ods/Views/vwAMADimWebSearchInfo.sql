﻿CREATE VIEW [dbo].[vwAMADimWebSearchInfo]
AS
SELECT
	ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Id
	,HASHBYTES('SHA1', ISNULL(query, '')+ISNULL(country, '')+ISNULL(searchType, '')) WebSearchInfoHash
	,query SearchQuery
	,country SearchCountry
	,searchType SearchType
	,entity_event_date
FROM
	dbo.GscBimAllSearches
WHERE
	date >= '2021-01-01'
GO