﻿CREATE VIEW [dbo].[vwAMADimDigitalProvinceMapping]
AS
SELECT
	ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Id
	,Province ProvinceNameEn
	,ProvinceCode
	,RegionBDC RegionBDCEn
	,FSAProvince
	,ProvinceFr ProvinceNameFr
	,RegionBDCFr
	,entity_modified_on
FROM
	dbo.BimCustomProvinceMappingEntity
WHERE
	entity_is_current = 1
GO