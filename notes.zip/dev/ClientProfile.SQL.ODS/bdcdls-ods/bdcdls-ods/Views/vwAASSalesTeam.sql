﻿/*
    **************************************************************************
    AAS.FactSalesTeam
    This script returns rows effective at @ExtractDateTime.
    **************************************************************************
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash of previous record for the same _KeyHash
        Then set _EndDate of previous record, and Insert new record
        Else skip record
    If lookup on Dim table returns no match, assign N/A.
*/


CREATE VIEW [dbo].[vwAASFactSalesTeam]
AS
(
    SELECT 
    
	RIGHT(CONCAT('00000000000', ClientPartnerPIN), 11) AS FactSalesTeamKey
	,BranchCode
	,ClientPartnerPIN
	,DirectorPIN  AS DirectorPIN
	,VicePresidentPIN
	
	/* Sys Columns */
	,SYSDATETIME() AS _StartDate
	,'9999-12-31' AS _EndDate
	,entity_start_date   
	,entity_end_date   	
	,HASHBYTES('SHA2_256', RIGHT(CONCAT('00000000000', ClientPartnerPIN), 11))	AS _KeyHash

	,HASHBYTES('SHA2_256', CONCAT(
		BranchCode
		,'-'
		, ClientPartnerPIN
		,'-'
		, DirectorPIN 
		,'-'
		, VicePresidentPIN
		
		)) AS _ValueHash
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME() 
	,_UpdateBy = SYSTEM_USER
	, ROW_NUMBER() OVER (PARTITION BY RIGHT(CONCAT('00000000000', ClientPartnerPIN), 11) ORDER BY entity_start_date DESC) as rn

  FROM
(
	SELECT DISTINCT
		RIGHT(CONCAT('0000', E.DepartmentCode), 4)	AS BranchCode	-- Pad to 4 digits with 0 prefix for join with DimRegionBranch.BranchCode.
		,CAST(E.EmployeePIN	AS INT)		AS ClientPartnerPIN
		,CAST(M.EmployeePIN	AS INT)		AS DirectorPIN
		,CAST(V.EmployeePIN	AS INT)		AS VicePresidentPIN
		,E.entity_start_date   
	    ,E.entity_end_date   
	
	FROM
		dbo.Employee E
		LEFT JOIN dbo.Employee M ON E.ManagerPIN = M.EmployeePIN
        	AND M.entity_end_date > SYSDATETIME()
		LEFT JOIN dbo.Employee V ON M.ManagerPIN = V.EmployeePIN
        	AND V.entity_end_date > SYSDATETIME()
	WHERE
        E.entity_end_date > SYSDATETIME()
		AND E.EmployeePIN IS NOT NULL
		AND E.LineOfBusinessName = 'Consulting'

) AS A
)
GO


