﻿
CREATE VIEW [dbo].[vwAASRegionBranch]
AS
/*
    AAS.DimRegionBranch
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash for the same _KeyHash
        Then Update record
        Else skip record
*/
SELECT
	BranchCode
	,BranchName
	,AreaCode
	,AreaName
	,SubRegionName
	,RegionCode
	,RegionAbbr
	,RegionName
	,VPRegionAbbr
	,VPRegionName
	,CAST(CASE WHEN entity_is_current = 1 AND entity_is_deleted = 0 THEN 1 ELSE 0 END AS BIT) AS _CurrentFlag
	,HASHBYTES('SHA2_256', BranchCode) AS _KeyHash
	,HASHBYTES('SHA2_256', CONCAT(BranchName
		,'-', AreaCode
		,'-', AreaName
		,'-', SubRegionName
		,'-', RegionCode
		,'-', RegionAbbr
		,'-', RegionName
		,'-', VPRegionAbbr
		,'-', VPRegionName)) AS _ValueHash
	,entity_start_date
	,entity_end_date
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,rn
FROM
(
	SELECT
		BranchCode
		,BranchName
		,COALESCE(AreaCode, 'N/A') AS AreaCode
		,COALESCE(AreaName, 'N/A') AS AreaName
		,'N/A' AS SubRegionName
		,COALESCE(RegionCode, 'N/A') AS RegionCode
		,'N/A' AS RegionAbbr
		,COALESCE(RegionName, 'N/A') AS RegionName
		,'N/A' AS VPRegionAbbr
		,'N/A' AS VPRegionName
		,entity_is_current
		,entity_is_deleted
		,entity_start_date
		,entity_end_date
		,ROW_NUMBER() OVER (PARTITION BY BranchCode ORDER BY PriorityId) AS rn
	FROM
	(
		SELECT -- Get dept/branch from OrganizationRefEntity.
			1 AS PriorityId
			,ORE.OriginatingUnitNumberCREM AS BranchCode
			,ORE.OriginatingUnitNameEnglish AS BranchName
			,ORE.AreaNumber AS AreaCode
			,ORE.AreaNameEnglish AS AreaName
			,ORE.OperationRegionNumber AS RegionCode
			,ORE.OperationRegionName AS RegionName
			,ORE.entity_is_current
			,ORE.entity_is_deleted
			,ORE.entity_start_date
			,ORE.entity_end_date
		FROM
			dbo.OrganizationRefEntity ORE
		WHERE
			ORE.entity_end_date >= SYSDATETIME()
		UNION
		SELECT	-- Get dept/branch from Employee.
			2
			,RIGHT(CONCAT('0000', DepartmentCode), 4)
			,DepartmentName
			,NULL, NULL
			,NULL, NULL
			,MAX(CAST(entity_is_current AS INT))
			,MIN(CAST(entity_is_deleted AS INT))
			,MIN(entity_start_date)
			,MAX(entity_end_date)
		FROM dbo.Employee
		WHERE entity_end_date >= SYSDATETIME() AND DepartmentCode IS NOT NULL
		GROUP BY DepartmentCode, DepartmentName
	) X
) X
--WHERE rn = 1
/* -- Previous query.
SELECT ORE.OriginatingUnitNumberCREM AS BranchCode
	,ORE.OriginatingUnitNameEnglish AS BranchName
	,ORE.AreaNumber AS AreaCode
	,ORE.AreaNameEnglish AS AreaName
	,'N/A' AS SubRegionName
	,ORE.OperationRegionNumber AS RegionCode
	,'N/A' AS RegionAbbr
	,ORE.OperationRegionName AS RegionName
	,'N/A' AS VPRegionAbbr
	,'N/A' AS VPRegionName
	/* Sys Columns */
	,CAST(CASE 
			WHEN ORE.entity_is_current = 1
				AND ORE.entity_is_deleted = 0
				THEN 1
			ELSE 0
			END AS BIT) AS _CurrentFlag
	,HASHBYTES('SHA2_256', ORE.OriginatingUnitNumberCREM) AS _KeyHash
	,HASHBYTES('SHA2_256', CONCAT (
			ORE.OriginatingUnitNameEnglish
			,'-'
			,ORE.AreaNumber
			,'-'
			,ORE.AreaNameEnglish
			--, '-', RS.SubRegionName
			,'-'
			,ORE.OperationRegionNumber
			--, '-', RS.RegionAbbr
			,'-'
			,ORE.OperationRegionName
			--, '-', RS.VPRegionAbbr
			--, '-', RS.VPRegionName
			)) AS _ValueHash
	,ORE.entity_start_date
	,ORE.entity_end_date
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (
		PARTITION BY ORE.OriginatingUnitNumberCREM ORDER BY Entity_start_date DESC
		) rn
FROM dbo.OrganizationRefEntity ORE
	--WHERE
	--ORE.entity_start_date >= @LastLoadDateTime
	--AND ORE.entity_end_date > @ExtractDateTime
*/
GO