﻿/*
    AAS.DimOpportunityStatus
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash for the same _KeyHash
        Then Update record
        Else skip record
*/
CREATE VIEW [dbo].[vwAASOpportunityStatus]
AS
SELECT OpportunityStatusCode
	,OpportunityStatusName
	,OpportunityStatusSeq
	,entity_start_date
	,entity_end_date
	/* Sys Columns */
	,CAST(1 AS BIT) AS _CurrentFlag
	,HASHBYTES('SHA2_256', CONCAT (
			''
			,OpportunityStatusCode
			)) AS _KeyHash
	,HASHBYTES('SHA2_256', CONCAT (
			OpportunityStatusName
			,'-'
			,OpportunityStatusSeq
			)) AS _ValueHash
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (
		PARTITION BY OpportunityStatusCode ORDER BY entity_start_date DESC
		) rn
FROM (
	SELECT DISTINCT StatusReasonCode AS OpportunityStatusCode
		,StatusReasonDescrEn AS OpportunityStatusName
		,0 AS OpportunityStatusSeq
		,entity_start_date
		,entity_end_date
	FROM dbo.OpportunityEntity
	WHERE LineOfBusinessNameEn = 'Consulting' -- Advisory related only
		--AND StatusCode <> '803750012'
		AND StatusReasonCode IS NOT NULL -- Exclude NULL BK
		AND entity_end_date > SYSDATETIME()
	) X
GO