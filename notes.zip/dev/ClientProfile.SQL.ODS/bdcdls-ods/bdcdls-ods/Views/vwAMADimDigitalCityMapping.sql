﻿CREATE VIEW [dbo].[vwAMADimDigitalFormInfo]
AS
SELECT
	ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Id
	,Landing_Page_Origin as FormName
	,FormType
	,Landing_Page_Origin as FormOfficialName
	,entity_modified_on
FROM
	dbo.EloquaBimFormEntity
WHERE
	entity_is_current = 1
	AND submittedAt >= '2021-01-01'
GO