﻿CREATE VIEW [dbo].[vwAASEmployee]
AS
/*
    AAS.DimEmployee   
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash for the same _KeyHash
        Then Update record
        Else skip record
*/
SELECT CAST(EmployeePIN AS INT) AS EmployeePIN,
	EmployeePIN AS EmployeeCode
	,FullName AS EmployeeName
	,LastName AS EmployeeLastName
	,FirstName AS EmployeeFirstName
	,entity_start_date
	,entity_end_date
	,CAST(CASE 
			WHEN entity_is_current = 1
				AND entity_is_deleted = 0
				THEN '1'
			ELSE '0'
			END AS BIT) AS _CurrentFlag
	,HASHBYTES('SHA2_256', CONCAT (
			''
			,CRM_SystemUserId
			)) AS _KeyHash
	,HASHBYTES('SHA2_256', CONCAT (
			EmployeePIN
			,'-'
			,FullName
			,'-'
			,LastName
			,'-'
			,FirstName
			)) AS _ValueHash
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (
		PARTITION BY EmployeePIN ORDER BY Entity_start_date DESC
		) rn
FROM dbo.Employee /*Entity*/
WHERE EmployeePIN IS NOT NULL
	AND entity_end_date > SYSDATETIME()
	--AND LineOfBusinessName = 'Consulting' -- Get all employees.
GO