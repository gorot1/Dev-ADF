﻿CREATE VIEW [dbo].[vwAASLineOfBusiness]
AS
/*
    AAS.DimLineOfBusiness
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash for the same _KeyHash
        Then Update record
        Else skip record
--*/
SELECT LineOfBusinessCode AS LineOfBusinessCode
	,LineOfBusinessNameEn AS LineOfBusinessName
	,CAST(IsConsulting AS BIT) AS IsConsulting
	/* Sys Columns */
	,CAST(1 AS BIT) AS _CurrentFlag
	,HASHBYTES('SHA2_256', LineOfBusinessCode) AS _KeyHash
	,HASHBYTES('SHA2_256', CONCAT (
			LineOfBusinessNameEn
			,'-'
			,IsConsulting
			)) AS _ValueHash
	,entity_start_date
	,entity_end_date
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (
		PARTITION BY LineOfBusinessCode ORDER BY entity_start_date DESC
		) rn
FROM (
	SELECT
		LineOfBusinessCode
		,LineOfBusinessNameEn
		,MIN(entity_start_date) AS entity_start_date
		,MAX(entity_end_date) AS entity_end_date
		,CASE 
			WHEN LineOfBusinessNameEn = 'Consulting'
				THEN 1
			ELSE 0
			END AS IsConsulting
	FROM dbo.OpportunityEntity
	WHERE entity_end_date > SYSDATETIME()
	GROUP BY LineOfBusinessCode, LineOfBusinessNameEn
	) X
GO