﻿CREATE VIEW [dbo].[vwAMAFactWebGoal]
AS
SELECT
	ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Id
	,entity_event_date
	,cast(replace(convert(varchar(5), dateHourMinute, 108), ':', '') as int) TimeKey
	,hostname
	,landingPagePath
	,source
	,medium
	,campaign
	,accountID
	,profileID
	/*,segment*/
	,deviceCategory
	,cityid
	,goalNumber
	,ISNULL(goalStarts, 0) as goalStarts
	,ISNULL(goalCompletions, 0) as goalCompletions
FROM
	dbo.GaBimGoalsEntity
WHERE
	dateHourMinute >= '2021-01-01' AND( ISNULL(goalStarts, 0) > 0 OR ISNULL(goalCompletions, 0) > 0)
GO