﻿CREATE VIEW [dbo].[vwAMADimDigitalChannel]
AS
SELECT ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Id, *
FROM
(
	SELECT
		source as ChannelSource
		,medium as ChannelMedium
		,campaign as ChannelCampaign
		,entity_modified_on
	FROM
		dbo.GaBimChannelGrouping
	WHERE
		entity_is_current = 1
UNION ALL
	SELECT
		source as ChannelSource
		,medium as ChannelMedium
		,campaign as ChannelCampaign
		,entity_event_date
	FROM
		dbo.GaBimGoalsEntity
	WHERE
		dateHourMinute >= '2021-01-01'
UNION ALL
	SELECT
		source as ChannelSource
		,medium as ChannelMedium
		,campaign as ChannelCampaign
		,entity_event_date
	FROM
		dbo.GaBimAdwords
	WHERE
		date >= '2021-01-01'
UNION ALL
	SELECT
		source as ChannelSource
		,medium as ChannelMedium
		,campaign as ChannelCampaign
		,entity_event_date
	FROM
		dbo.GaBimEventContainer
	WHERE
		dateHourMinute >= '2021-01-01'
UNION ALL
	SELECT
		source as ChannelSource
		,medium as ChannelMedium
		,campaign as ChannelCampaign
		,entity_event_date
	FROM
		dbo.GaBimEvents
	WHERE
		dateHourMinute >= '2021-01-01'
UNION ALL
	SELECT
		source as ChannelSource
		,medium as ChannelMedium
		,campaign as ChannelCampaign
		,entity_event_date
	FROM
		dbo.GaBimPageViews
	WHERE
		dateHourMinute >= '2021-01-01'
UNION ALL
	SELECT
		source as ChannelSource
		,medium as ChannelMedium
		,campaign as ChannelCampaign
		,entity_event_date
	FROM
		dbo.GaBimVisitsEntity
	WHERE
		dateHourMinute >= '2021-01-01'
) X
GO