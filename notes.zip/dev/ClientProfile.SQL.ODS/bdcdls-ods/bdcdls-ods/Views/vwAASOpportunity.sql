﻿/*
    AAS.DimOpportunity 
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash for the same _KeyHash
        Then Update record
        Else skip record
*/
CREATE VIEW [dbo].[vwAASOpportunity]
AS
/*WITH DirEmp AS
(
	SELECT DISTINCT CRM_SystemUserId
	FROM dbo.Employee
	WHERE entity_end_date > SYSDATETIME()
		AND JobTitle = 'Director, Business Development, BDC Advisory Services'
)*/
SELECT Opportunity_CrmId AS OpportunityCode
	,OE.Name AS OpportunityName
	,OE.entity_start_date
	,OE.entity_end_date
	,CASE 
		WHEN OE.entity_is_current = 1
			AND OE.entity_is_deleted = 0
			THEN 'True'
		ELSE 'False'
		END AS _CurrentFlag
	,HASHBYTES('SHA2_256', OE.Opportunity_CrmId) AS _KeyHash
	,HASHBYTES('SHA2_256', OE.Name) AS _ValueHash
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (
      PARTITION BY OE.Opportunity_CrmId
      ORDER BY OE.entity_start_date DESC
   ) rn
FROM dbo.OpportunityEntity OE
WHERE OE.LineOfBusinessNameEn = 'Consulting' -- Advisory related only
	--AND OE.StatusCode <> '803750012'
	AND OE.entity_end_date > SYSDATETIME()
	--AND EXISTS (SELECT 1 FROM DirEmp WHERE DirEmp.CRM_SystemUserId = OE.OwnerId)
GO