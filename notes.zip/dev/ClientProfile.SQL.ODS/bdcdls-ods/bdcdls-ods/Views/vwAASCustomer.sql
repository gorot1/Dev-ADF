﻿/*
    AAS.AASDimCustomer
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash for the same _KeyHash
        Then Update record
        Else skip record
*/
CREATE VIEW [dbo].[vwAASCustomer]
AS
WITH ConsultingAccounts
AS (
	SELECT DISTINCT OE.AccountId
	FROM dbo.OpportunityEntity OE
	WHERE OE.entity_end_date > SYSDATETIME()
		AND OE.LineOfBusinessNameEn = 'Consulting'
	)
SELECT CRMAccount_CRMId AS CustomerCode
	,AccountName AS CustomerName
	/*,CAST(CASE 
		WHEN entity_is_current = 1
			AND entity_is_deleted = 0
			THEN '1'
		ELSE '0'
		END AS BIT) AS _CurrentFlag*/
	,entity_is_current AS _CurrentFlag
	,entity_start_date
	,entity_end_date
	,HASHBYTES('SHA2_256', CRMAccount_CRMId) AS _KeyHash
	,HASHBYTES('SHA2_256', AccountName) AS _ValueHash
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (
      PARTITION BY CRMAccount_CRMId
      ORDER BY Entity_start_date DESC
   ) rn
FROM dbo.AccountProfileEntity APE
WHERE
	APE.entity_end_date > SYSDATETIME()
	AND EXISTS (
		SELECT 1
		FROM ConsultingAccounts CA
		WHERE CA.AccountId = APE.AccountId
		)
GO