﻿CREATE VIEW [dbo].[vwAMAFactWebPageVisit]
AS
SELECT
	ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Id
	,entity_event_date
	,cast(replace(convert(varchar(5), dateHourMinute, 108), ':', '') as int) TimeKey
	,hostname
	,landingPagePath
	,pagePath
	,source
	,medium
	,campaign
	,accountID
	,profileID
	,segment
	,deviceCategory
	,cityid
	,ISNULL(sessions, 0) VisitSessionCount
	,ISNULL(sessionDuration, 0) VisitSessionDurationSeconds
	,ISNULL(bounces, 0) VisitBouncesCount
FROM
	dbo.GaBimVisitsEntity
WHERE
	dateHourMinute >= '2021-01-01'
GO