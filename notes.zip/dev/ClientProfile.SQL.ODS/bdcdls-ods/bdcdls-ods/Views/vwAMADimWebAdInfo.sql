﻿CREATE VIEW [dbo].[vwAMADimWebAdInfo]
AS
SELECT
	ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Id
	,adContent as AdContent
	,keyword as adKeyword
	,entity_event_date
FROM
	dbo.GaBimAdwords
WHERE
	date >= '2021-01-01'
GO