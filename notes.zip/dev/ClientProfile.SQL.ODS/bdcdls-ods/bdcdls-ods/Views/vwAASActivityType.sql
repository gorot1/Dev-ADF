﻿CREATE VIEW [dbo].[vwAASActivityType]
AS
/*
    AAS.DimActivityType  
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash for the same _KeyHash
        Then Update record
        Else skip record
*/

SELECT
     CAST( ActivityTypeCode AS  varchar) as ActivityTypeCode
    ,ActivityTypeName
    ,CAST(IsConsulting AS  BIT) AS IsConsulting
    ,CAST(1 AS BIT) AS _CurrentFlag
    ,HASHBYTES('SHA2_256', CONCAT('', ActivityTypeCode))	AS _KeyHash
    ,HASHBYTES('SHA2_256', CONCAT(ActivityTypeName, '-', IsConsulting)) AS _ValueHash   
     ,SYSDATETIME() AS _StartDate
	,'9999-12-31' AS _EndDate
	,entity_start_date
	,entity_end_date
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME() 
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (PARTITION BY CAST( ActivityTypeCode AS  varchar) ORDER BY entity_start_date DESC) rn 
FROM
(
  SELECT
         ActivityTypeCode
        ,ActivityTypeName
        ,CASE WHEN ActivityTypeCode IN ('4201', '4210') THEN 1 ELSE 0 END   AS IsConsulting
		,MIN(entity_start_date) AS entity_start_date
		,MAX(entity_end_date) AS entity_end_date
FROM
        dbo.AccountActivity
    WHERE
		entity_end_date > SYSDATETIME()
       AND ActivityTypeCode IS NOT NULL
	GROUP BY ActivityTypeCode, ActivityTypeName
) AS A
GO