﻿CREATE VIEW [dbo].[vwAASCampaign]
AS
SELECT
	CampaignCode
	,CampaignName
	,entity_start_date
	,entity_end_date
	,CAST(1 AS BIT) AS _CurrentFlag
	,HASHBYTES('SHA2_256', CampaignCode) AS _KeyHash
	,HASHBYTES('SHA2_256', CampaignName) AS _ValueHash
	,_StartDate = SYSDATETIME()
	,_EndDate = CAST('9999-12-31' AS DATE)
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (PARTITION BY CampaignCode ORDER BY entity_start_date DESC) rn
FROM
(
	SELECT
		CampaignId AS CampaignCode
		,CampaignIdName AS CampaignName
		,MIN(entity_start_date) AS entity_start_date
		,MIN(entity_end_date) AS entity_end_date
	FROM dbo.OpportunityEntity
	WHERE
		entity_end_date > SYSDATETIME()
		AND LineOfBusinessNameEn = 'Consulting' -- Advsory related
		--AND StatusCode <> '803750012' -- Advisory specific exclusion
		AND CampaignId IS NOT NULL -- Exclude NULL BK
	GROUP BY CampaignId, CampaignIdName
) X
GO