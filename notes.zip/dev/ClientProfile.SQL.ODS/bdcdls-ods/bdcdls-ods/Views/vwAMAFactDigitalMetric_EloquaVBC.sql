﻿CREATE VIEW [dbo].[vwAMAFactDigitalMetric_EloquaVBC]
AS
SELECT
	ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Id
	,entity_event_date MetricStartDate
	,entity_event_date MetricEndDate
	,'dbo.EloquaBimVBCEntity' MetricSourceTableName
	,OnboardedClients
	,ActiveClients
	,ClientsRemainingToOnboardUnsupportedAms
	,ClientsRemainingToOnboardSupportedAms
	,AutomatedOnboardableClients
	,VBCClients
	,entity_modified_on
FROM
	dbo.EloquaBimVBCEntity
WHERE
	date >= '2021-01-01'
GO