﻿CREATE VIEW [dbo].[vwAASFactOpportunityStage]
AS
/*2,178,862
    AAS.FactOpportunityStage
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash of previous record for the same _KeyHash
        Then set _EndDate of previous record, and Insert new record
        Else skip record
    If lookup on Dim table returns no match, assign N/A.
*/
--DECLARE @LastLoadDateTime DATETIME2 = ? -- Last successful load datetime
--DECLARE @ExtractDateTime DATETIME2 = ?  -- As of datetime, typically SYSTEMDATETIME()
WITH DirEmp AS
(
	SELECT DISTINCT CP.CRM_SystemUserId
	FROM dbo.Employee CP
		INNER JOIN dbo.Employee DIR ON CP.ManagerPIN = DIR.EmployeePIN
			AND DIR.entity_end_date > SYSDATETIME()
	WHERE CP.entity_end_date > SYSDATETIME()
		AND DIR.JobTitle = 'Director, Business Development, BDC Advisory Services'
)
,OppStg
AS (
	SELECT OE.Opportunity_CrmId AS OpportunityCode
		,OSSHE.CreatedOn AS CreatedOn
		,OSSHE.OpportunitySalesStageId AS OpportunityStageCode
		,ROW_NUMBER() OVER (
			PARTITION BY OE.Opportunity_CrmId ORDER BY OSSHE.CreatedOn
				,OSSHE.OpportunitySalesStageId
			) AS _RowNumber
		,OE.entity_start_date
		,OE.entity_end_date

	FROM dbo.OpportunitySalesStagesHistoryEntity OSSHE
	INNER JOIN dbo.OpportunityEntity OE ON OSSHE.OpportunityId = OE.OpportunityId
	WHERE OSSHE.entity_end_date > SYSDATETIME() -- Get all effective rows.
		--AND OE.entity_start_date >= @LastLoadDateTime   -- Filter on changed opportunities since last load.
		AND OE.entity_end_date > SYSDATETIME() AND  LineOfBusinessNameEn = 'Consulting' -- Advisory related only To Discuss with Eric tomorrow
		--AND OE.OpportunityId = '9c29a60a-9471-e411-909b-005056b805fe' -- Test case with changing stage back and forth.
		AND EXISTS (SELECT 1 FROM DirEmp WHERE DirEmp.CRM_SystemUserId = OE.OwnerId)
	)
SELECT CONCAT (
		RIGHT(CONCAT (
				'0000000000'
				,OpportunityCode
				), 10)
		,'-'
		,RIGHT(CONCAT (
				'000'
				,OpportunityStageSeq
				), 3)
		) AS FactOpportunityStageKey
	,OpportunityCode
	,OpportunityStageCode
	,OpportunityStageFirstDateId
	,OpportunityStageLastDateId
	,OpportunityStageSeq
	,OpportunityStageDays
	,entity_start_date
	,entity_end_date
	/* Sys Columns */
	,_StartDate = SYSDATETIME()
	,_EndDate = CAST('9999-12-31' AS DATE)
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,HASHBYTES('SHA2_256', CONCAT (
			RIGHT(CONCAT (
					'0000000000'
					,OpportunityCode
					), 10)
			,'-'
			,RIGHT(CONCAT (
					'000'
					,OpportunityStageSeq
					), 3)
			)) AS _KeyHash
	,HASHBYTES('SHA2_256', CONCAT (
			OpportunityCode
			,'-'
			,OpportunityStageCode
			,'-'
			,OpportunityStageFirstDateId
			,'-'
			,OpportunityStageLastDateId
			,'-'
			,OpportunityStageDays
			)) AS _ValueHash
FROM (
	SELECT OpportunityCode
		,CAST(FORMAT(MIN(cast(CreatedOn as datetimeoffset) at time zone 'Eastern Standard Time'), 'yyyyMMdd') AS INT) AS OpportunityStageFirstDateId
		,OpportunityStageCode
		,CAST(FORMAT(COALESCE(cast(NextStageDate as datetimeoffset) at time zone 'Eastern Standard Time', '9999-12-31'), 'yyyyMMdd') AS INT) AS OpportunityStageLastDateId
		,ROW_NUMBER() OVER (
			PARTITION BY OpportunityCode ORDER BY MIN(CreatedOn)
			) AS OpportunityStageSeq
		,DATEDIFF(DAY, MIN(CreatedOn), NextStageDate) AS OpportunityStageDays
		,entity_start_date
		,entity_end_date
	FROM (
		SELECT A.OpportunityCode
			,A.CreatedOn
			,A.OpportunityStageCode
			,A._RowNumber
			,MIN(B.CreatedOn) AS NextStageDate
			,MIN(B._RowNumber) AS NextStageRowNumber
			,A.entity_start_date
			,A.entity_end_date
		FROM OppStg A
		LEFT OUTER JOIN OppStg B ON A.OpportunityCode = B.OpportunityCode
			AND A._RowNumber < B._RowNumber
			AND A.OpportunityStageCode <> B.OpportunityStageCode
		GROUP BY A.OpportunityCode
			,A.CreatedOn
			,A.OpportunityStageCode
			,A._RowNumber
			,A.entity_start_date
			,A.entity_end_date
		) X
	GROUP BY OpportunityCode
		,OpportunityStageCode
		,NextStageDate
		,entity_start_date
		,entity_end_date
	) X
GO