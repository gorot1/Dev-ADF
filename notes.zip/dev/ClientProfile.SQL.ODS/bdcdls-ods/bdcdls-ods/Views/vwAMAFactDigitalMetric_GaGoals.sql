﻿CREATE VIEW [dbo].[vwAMAFactDigitalMetric_GaGoals]
AS
SELECT
	ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Id
	,entity_event_date MetricStartDate
	,entity_event_date MetricEndDate
	,'dbo.GaBimGoalsEntity' MetricSourceTableName
	,source
	,medium
	,campaign
	,CASE goalNumber
		WHEN 12 THEN 'Consulting Form Goal Completions'
		WHEN 18 THEN 'Financing Form Goal Completions'
		WHEN 16 THEN 'SBL BDC Goal Completions'
		WHEN 17 THEN 'SBL Connex Goal Completions'
		END MetricName
	,NULL MetricRowKey
	,ISNULL(goalCompletions, 0) MetricActualValue
	,NULL MetricTargetValue
	,entity_event_date
FROM
	dbo.GaBimGoalsEntity
WHERE
	ISNULL(goalCompletions, 0)>0 AND segment = 'All Users' AND goalNumber in (12, 16, 17, 18)
	AND dateHourMinute >= '2021-01-01'
GO