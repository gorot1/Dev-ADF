﻿CREATE VIEW [dbo].[vwAASFactProjectStatus]
AS
/*
    **************************************************************************
    AAS.FactProjectStatus
    This script returns rows effective at @ExtractDateTime.
    **************************************************************************
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash of previous record for the same _KeyHash
        Then set _EndDate of previous record, and Insert new record
        Else skip record
    If lookup on Dim table returns no match, assign N/A.
*/
--DECLARE @LastLoadDateTime DATETIME2 = ? -- Last successful load datetime
--DECLARE @ExtractDateTime DATETIME2 = ?  -- As of datetime, typically SYSTEMDATETIME()
WITH Proj
AS (
	SELECT DISTINCT PE.ProjectId
	FROM dbo.PsBimProjectEntity PE
	WHERE PE.entity_is_current = 1
		--AND PE.IntegrationTemplate = 'CONSULT_GROUP'
		AND PE.BusinessUnit = 'CG/GC'
	)
SELECT CONCAT (
		ProjectCode
		,'-'
		,RIGHT(CONCAT (
				'000'
				,ProjectStatusSeq
				), 3)
		) AS FactProjectStatusKey
	,ProjectCode
	,ProjectStatusCode
	,CAST(ProjectStatusFirstDateId AS VARCHAR) AS ProjectStatusFirstDateId
	,CAST(ProjectStatusLastDateId AS VARCHAR) AS ProjectStatusLastDateId
	,ProjectStatusSeq
	,HASHBYTES('SHA2_256', CONCAT (
			ProjectCode
			,'-'
			,RIGHT(CONCAT (
					'000'
					,ProjectStatusSeq
					), 3)
			)) AS _KeyHash
	,HASHBYTES('SHA2_256', CONCAT (
			ProjectCode
			,'-'
			,ProjectStatusCode
			,'-'
			,ProjectStatusFirstDateId
			,'-'
			,ProjectStatusLastDateId
			)) AS _ValueHash
	,_StartDate = SYSDATETIME()
	,_EndDate = CAST('9999-12-31' AS DATE)
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,entity_start_date
	,ROW_NUMBER() OVER (
		PARTITION BY CONCAT (
			ProjectCode
			,'-'
			,RIGHT(CONCAT (
					'000'
					,ProjectStatusSeq
					), 3)
			) ORDER BY entity_start_date DESC
		) rn
FROM (
	SELECT PSH.ProjectId AS ProjectCode
		,PSH.ProjectStatus AS ProjectStatusCode
		,CAST(FORMAT(PSH.EffectiveDate, 'yyyyMMdd') AS INT) AS ProjectStatusFirstDateId
		,LEAD(CAST(FORMAT(PSH.EffectiveDate, 'yyyyMMdd') AS INT), 1, - 1) OVER (
			PARTITION BY PSH.ProjectId ORDER BY PSH.EffectiveDate
			) AS ProjectStatusLastDateId
		,ROW_NUMBER() OVER (
			PARTITION BY PSH.ProjectId ORDER BY PSH.EffectiveDate
			) AS ProjectStatusSeq
		,PSH.entity_start_date
	FROM dbo.PsBimProjectStatusHistory PSH
	WHERE
		--PSH.entity_end_date > SYSDATETIME()
		PSH.entity_is_current = 1
		AND EXISTS (SELECT 1 FROM Proj WHERE Proj.ProjectId = PSH.ProjectId)
	) X
GO