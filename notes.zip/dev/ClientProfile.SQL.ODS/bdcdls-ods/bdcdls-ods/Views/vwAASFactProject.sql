﻿
/*
    **************************************************************************
    AAS.FactProject
    This script returns rows effective at @ExtractDateTime.
    **************************************************************************
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash of previous record for the same _KeyHash
        Then set _EndDate of previous record, and Insert new record
        Else skip record
    If lookup on Dim table returns no match, assign N/A.
*/
CREATE VIEW [dbo].[vwAASFactProject]
AS
WITH Proj AS
(	-- Retrieve list of ConsultingProjects.
	SELECT
		PE.BusinessUnit
        ,PE.ProjectId
		,LAG(PE.ProjectId, 1, NULL) OVER (PARTITION BY PE.CustomerId ORDER BY PE.StartDate, PE.ProjectId) AS CustomerPrevProjectId
	FROM
		dbo.PsBimProjectEntity PE
	WHERE
		PE.entity_is_current = 1
		AND PE.BusinessUnit = 'CG/GC'
)
,Ext AS
(
    SELECT
        PME.ProjectId
        ,SUM(PME.BDC_UNEARNED) AS UnearnedAmt
		,SUM(PME.BDC_NBR_CUST_YTD) AS ClientNbrYTD
		,SUM(PME.BDC_MANDATE_YTD) AS MandateNbrYTD
		,SUM(PME.BDC_SALES_YTD) AS SalesAmtYTD
		,SUM(PME.BDC_REV_YTD) AS RevenueAmtYTD
		,SUM(PME.BDC_REV_YTD - PME.BDC_DIR_EXP_YTD - PME.BDC_INT_EXP_YTD - PME.BDC_OOP_EXP_YTD + PME.BDC_OOP_BLD_YTD) AS GrossMarginYTD
		,SUM(PME.BDC_REV_YTD - PME.BDC_DIR_EXP_YTD - PME.BDC_INT_EXP_YTD - PME.BDC_BAD_DEBTS_YTD) AS BadDebtsYTD
		,SUM(PME.BDC_REV_YTD - PME.BDC_DIR_EXP_YTD - PME.BDC_INT_EXP_YTD - PME.BDC_CONT_EXP_YTD - PME.BDC_BAD_DEBTS_YTD - PME.BDC_OOP_EXP_YTD + PME.BDC_OOP_BLD_YTD) AS NetMarginYTD
        ,MAX(entity_start_date) AS entity_start_date
    FROM dbo.PsBimProjectManagerExtEntity PME
    WHERE EXISTS (SELECT 1 FROM Proj WHERE Proj.ProjectId = PME.ProjectId)
        AND PME.entity_is_current = 1
    GROUP BY PME.ProjectId
)
,ResNonRev AS
(   -- RESOURCE_AMOUNT of non "REV" ANALYSIS_TYPE.
    SELECT
        PR.BusinessUnit
        ,PR.ProjectId
        ,SUM(PR.ResourceAmt) AS ResourceNonRevAmt
        ,MAX(PR.entity_start_date) AS entity_start_date
    FROM dbo.PsBimProjectResource PR
    WHERE EXISTS (SELECT 1 FROM Proj WHERE Proj.BusinessUnit = PR.BusinessUnit AND Proj.ProjectId = PR.ProjectId)
        AND PR.entity_is_current = 1
        AND PR.AnalysisType <> 'REV'
    GROUP BY PR.BusinessUnit, PR.ProjectId
)
,ResRev AS
(   -- RESOURCE_AMOUNT of only "REV" ANALYSIS_TYPE.
    SELECT
        PR.BusinessUnit
        ,PR.ProjectId
        ,SUM(PR.ResourceAmt) AS ResourceRevAmt
        ,MAX(PR.entity_start_date) AS entity_start_date
    FROM dbo.PsBimProjectResource PR
    WHERE EXISTS (SELECT 1 FROM Proj WHERE Proj.BusinessUnit = PR.BusinessUnit AND Proj.ProjectId = PR.ProjectId)
        AND PR.entity_is_current = 1
        AND PR.AnalysisType = 'REV'
    GROUP BY PR.BusinessUnit, PR.ProjectId
)
,Jrnl AS
(
	SELECT
		ProjectId
		,SUM(CASE WHEN Account IN ('K49', 'K40', 'K40IU') THEN StatisticAmt ELSE -MonetaryAmt END)	AS ProjectAmt
		,SUM(CASE WHEN Account IN ('K49') THEN StatisticAmt ELSE 0 END)								AS NumberOfMandates
		,SUM(CASE WHEN Account IN ('K40', 'K40IU') THEN StatisticAmt ELSE 0 END)					AS NetSalesAmt
		,SUM(CASE WHEN Account IN ('43000', '42180') THEN -MonetaryAmt ELSE 0 END)					AS RevenueAmt
		,SUM(CASE WHEN Account IN ('70200', '70201') THEN -MonetaryAmt ELSE 0 END)					AS ExternalConsultingFeeAmt
		,SUM(CASE WHEN Account IN ('70210', '70211') THEN -MonetaryAmt ELSE 0 END)					AS InternalConsultingFeeAmt
		,SUM(CASE WHEN Account IN ('43000', '42180', '70200', '70201', '70210', '70211', '73657', '73658') THEN -MonetaryAmt ELSE 0 END)	AS GrossMarginAmt
        ,MAX(entity_event_date) AS entity_event_date
	FROM dbo.PsBimJournalEntity JE
	WHERE EXISTS (SELECT 1 FROM Proj WHERE Proj.ProjectId = JE.ProjectId)
		AND JE.Ledger = 'ACTUALS'
        AND JE.Account IN ('K49', 'K40', 'K40IU', '43000', '42180', '70200', '70201', '70210', '70211', '73657', '73658')
        AND JE.JournalDate < CAST(SYSDATETIME() AS DATE)    -- Up to last close date.
		AND JE.JournalLineSource <> 'CLO'
	GROUP BY ProjectId
)
SELECT
	FactProjectKey
	,ProjectCode
	,OpportunityCode
	,ProjectTypeCode
	,CustomerCode
	,ProjectStateName
	,ProjectStatusCode
	,ProjectStatusDateId
	,RefEmployeePIN
	,BranchCode
	,SolutionName
	,ProjectJobFamilyCode
	,CustomerPrevProjectCode
	,ProjectStartDateId
	,ProjectEndDateId
	,FirstActivityDateId
	,LastActivityDateId
    ,ClientNbrYTD
    ,MandateNbrYTD
    ,SalesAmtYTD
    ,RevenueAmtYTD
    ,GrossMarginYTD
    ,BadDebtsYTD
    ,NetMarginYTD
	,UnearnedAmt
	,ProjectAmt
	,NumberOfMandates
	,NetSalesAmt
	,RevenueAmt
	,ExternalConsultingFeeAmt as ExternalConsultingFeeAmt
	,InternalConsultingFeeAmt as InternalConsultingFeeAmt
	,GrossMarginAmt as GrossMarginAmt 
	,ResourceNonRevAmt as ResourceNonRevAmt 
	,ResourceRevAmt as ResourceRevAmt
    ,HASHBYTES('SHA2_256', FactProjectKey) AS _KeyHash
    ,HASHBYTES('SHA2_256', CONCAT(ProjectCode
		,'-', OpportunityCode
		,'-', ProjectTypeCode
		,'-', CustomerCode
		,'-', ProjectStateName
		,'-', ProjectStatusCode
		,'-', ProjectStatusDateId
		,'-', RefEmployeePIN
		,'-', BranchCode
		,'-', SolutionName
		,'-', ProjectJobFamilyCode
		,'-', CustomerPrevProjectCode
		,'-', ProjectStartDateId
		,'-', ProjectEndDateId
		,'-', FirstActivityDateId
		,'-', LastActivityDateId
        ,'-', ClientNbrYTD
        ,'-', MandateNbrYTD
        ,'-', SalesAmtYTD
        ,'-', RevenueAmtYTD
        ,'-', GrossMarginYTD
        ,'-', BadDebtsYTD
        ,'-', NetMarginYTD
		,'-', UnearnedAmt
		,'-', ProjectAmt
		,'-', NumberOfMandates
		,'-', NetSalesAmt
		,'-', RevenueAmt
		,'-', ExternalConsultingFeeAmt
		,'-', InternalConsultingFeeAmt
		,'-', GrossMarginAmt
		,'-', ResourceNonRevAmt
		,'-', ResourceRevAmt
		)) AS _ValueHash
	,entity_start_date
	,entity_end_date
	,SYSDATETIME() AS _StartDate
	,cast('9999-12-31' as datetime2) AS _EndDate
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (PARTITION BY FactProjectKey ORDER BY entity_start_date DESC) rn
FROM
(
	SELECT 
		RIGHT(CONCAT('000000000000000', PE.ProjectId), 15)		AS FactProjectKey
		,PE.ProjectId				AS ProjectCode
		,PE.CRMOpportunity_CRMId	AS OpportunityCode
		,CONCAT(PE.ProjectType, '-', PE.ProjectTypeName)		AS ProjectTypeCode
		,PE.CRMAccount_CRMId		AS CustomerCode
		,PL.Project_State			AS ProjectStateName
		,UPPER(PE.ProjectStatus)	AS ProjectStatusCode
		,CAST(FORMAT(PE.ProjectStatusDate, 'yyyyMMdd') AS INT)	AS ProjectStatusDateId
		,PE.RefEmployeeId			AS RefEmployeePIN
		,PE.RefDepartmentId			AS BranchCode
		,UPPER(PE.ProjectTypeName)	AS SolutionName
		,PE.JobFamilyId				AS ProjectJobFamilyCode
		,Proj.CustomerPrevProjectId	AS CustomerPrevProjectCode
		,CAST(FORMAT(PE.StartDate, 'yyyyMMdd') AS INT)	AS ProjectStartDateId
		,CAST(FORMAT(PE.EndDate, 'yyyyMMdd') AS INT)	AS ProjectEndDateId
		,CAST(FORMAT(PPE.FirstActivityDate, 'yyyyMMdd') AS INT)	AS FirstActivityDateId
		,CAST(FORMAT(PPE.LastActivityDate, 'yyyyMMdd') AS INT)	AS LastActivityDateId
		,COALESCE(Ext.ClientNbrYTD, 0) AS ClientNbrYTD
		,COALESCE(Ext.MandateNbrYTD, 0) AS MandateNbrYTD
		,COALESCE(Ext.SalesAmtYTD, 0) AS SalesAmtYTD
		,COALESCE(Ext.RevenueAmtYTD, 0) AS RevenueAmtYTD
		,COALESCE(Ext.GrossMarginYTD, 0) AS GrossMarginYTD
		,COALESCE(Ext.BadDebtsYTD, 0) AS BadDebtsYTD
		,COALESCE(Ext.NetMarginYTD, 0) AS NetMarginYTD
        ,COALESCE(Ext.UnearnedAmt, 0) AS UnearnedAmt
		,COALESCE(Jrnl.ProjectAmt, 0) AS ProjectAmt
		,COALESCE(Jrnl.NumberOfMandates, 0) AS NumberOfMandates
		,COALESCE(Jrnl.NetSalesAmt, 0) AS NetSalesAmt
		,COALESCE(Jrnl.RevenueAmt, 0) AS RevenueAmt
		,COALESCE(Jrnl.ExternalConsultingFeeAmt, 0) AS ExternalConsultingFeeAmt
		,COALESCE(Jrnl.InternalConsultingFeeAmt, 0) AS InternalConsultingFeeAmt
		,COALESCE(Jrnl.GrossMarginAmt, 0) AS GrossMarginAmt
        ,COALESCE(ResNonRev.ResourceNonRevAmt, 0) AS ResourceNonRevAmt
        ,COALESCE(ResRev.ResourceRevAmt, 0) AS ResourceRevAmt
        ,(SELECT MAX(entitystartdate) FROM (
            VALUES (PE.entity_start_date), (Jrnl.entity_event_date), (Ext.entity_start_date), (ResNonRev.entity_start_date), (ResRev.entity_start_date)
            ) AS VALUE(entitystartdate)
        ) AS entity_start_date
		,PE.entity_end_date
	FROM
		dbo.PsBimProjectEntity PE
		INNER JOIN Proj ON PE.BusinessUnit = Proj.BusinessUnit
			AND PE.ProjectId = Proj.ProjectId
		LEFT JOIN dbo.IrisUaProjectList PL ON PE.ProjectId = PL.Project_Code
			AND PL.entity_is_current = 1
		LEFT JOIN dbo.PsBimProjectPtd PPE ON PE.BusinessUnit = PPE.BusinessUnit
			AND PE.ProjectId = PPE.ProjectId
			AND PPE.entity_is_current = 1
		LEFT OUTER JOIN Ext ON PE.ProjectId = Ext.ProjectId
        LEFT OUTER JOIN ResNonRev ON PE.ProjectId = ResNonRev.ProjectId AND PE.BusinessUnit = ResNonRev.BusinessUnit
        LEFT OUTER JOIN ResRev ON PE.ProjectId = ResRev.ProjectId AND PE.BusinessUnit = ResRev.BusinessUnit
        LEFT OUTER JOIN Jrnl ON PE.ProjectId = Jrnl.ProjectId
    WHERE
		PE.entity_is_current = 1
		AND PE.BusinessUnit = 'CG/GC'
) AS A
GO
