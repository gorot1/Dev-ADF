﻿CREATE VIEW [dbo].[vwAASOpportunitySource]
AS
/*
    AAS.DimOpportunitySource
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash for the same _KeyHash
        Then Update record
        Else skip record
--*/
--DECLARE @LastLoadDateTime DATETIME2 = ? -- Last successful load datetime
--DECLARE @ExtractDateTime DATETIME2 = ?  -- As of datetime, typically SYSTEMDATETIME()
SELECT CAST(OpportunitySourceCode AS VARCHAR) AS OpportunitySourceCode
	,OpportunitySourceName
	/* Sys Columns */
	,CAST(1 AS BIT) AS _CurrentFlag
	,HASHBYTES('SHA2_256', CONCAT (
			''
			,OpportunitySourceCode
			)) AS _KeyHash
	,HASHBYTES('SHA2_256', OpportunitySourceName) AS _ValueHash
	,entity_start_date
	,entity_end_date
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (
		PARTITION BY OpportunitySourceCode ORDER BY Entity_start_date DESC
		) rn
FROM (
	SELECT DISTINCT SourceOfReferralCode AS OpportunitySourceCode
		,SourceOfReferralDescrEn AS OpportunitySourceName
		,entity_start_date
		,entity_end_date
	FROM dbo.OpportunityEntity
	WHERE
		LineOfBusinessNameEn = 'Consulting' -- Advisory related only
		--AND StatusCode <> '803750012'
		AND SourceOfReferralCode IS NOT NULL -- Exclude NULL BK
		AND entity_end_date > SYSDATETIME()
	) X
GO