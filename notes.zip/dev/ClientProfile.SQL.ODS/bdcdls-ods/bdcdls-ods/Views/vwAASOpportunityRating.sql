﻿CREATE VIEW [dbo].[vwAASOpportunityRating]
AS
/*
    AAS.DimOpportunityRating   
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash for the same _KeyHash
        Then Update record
        Else skip record
*/

SELECT
     cast (OpportunityRatingCode as varchar) as OpportunityRatingCode
    ,OpportunityRatingName
    ,OpportunityRatingSeq
    ,CAST(IsHotRating AS  BIT) AS IsHotRating
    /* Sys Columns */
    ,CAST(1 AS BIT) AS _CurrentFlag
	, SYSDATETIME() AS _StartDate
	,'9999-12-31' AS _EndDate
    ,HASHBYTES('SHA2_256', CONCAT(
		''
		, OpportunityRatingCode
		))   AS _KeyHash
    ,HASHBYTES('SHA2_256', CONCAT(
		OpportunityRatingName
		,'-'
		, OpportunityRatingSeq
		,'-'
		, IsHotRating
		))    AS _ValueHash
	, entity_start_date
	 , entity_end_date
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME() 
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (
		PARTITION BY cast (OpportunityRatingCode as varchar) ORDER BY Entity_start_date DESC
		) rn
FROM
(
  SELECT
        OpportunityRatingCode       AS OpportunityRatingCode
        ,OpportunityRatingDescrEn   AS OpportunityRatingName
        ,0                          AS OpportunityRatingSeq
        ,CASE WHEN UPPER(OpportunityRatingDescrEn) = 'HOT' THEN 1 ELSE 0 END   AS IsHotRating
	  	, entity_start_date
	 	, entity_end_date
    FROM
        dbo.OpportunityEntity
    WHERE
        LineOfBusinessNameEn = 'Consulting'   -- Advisory related only
        --AND StatusCode <> '803750012'
		AND entity_is_current =1
        AND OpportunityRatingCode IS NOT NULL 
		AND entity_end_date > SYSDATETIME()
) AS A
GO