﻿
/*
    **************************************************************************
    AAS.FactProjectWorkflow
    This script returns rows effective at @ExtractDateTime.
    **************************************************************************
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash of previous record for the same _KeyHash
        Then set _EndDate of previous record, and Insert new record
        Else skip record
    If lookup on Dim table returns no match, assign N/A.
*/

CREATE VIEW [dbo].[vwAASFactProjectWorkflow]
AS
WITH Proj AS
(	-- Retrieve list of ConsultingProjects that changed or are new since last load date.
	SELECT DISTINCT BusinessUnit, ProjectId
	FROM dbo.PsBimProjectEntity PE
	WHERE entity_is_current = 1
		--AND PE.IntegrationTemplate = 'CONSULT_GROUP'
		AND PE.BusinessUnit = 'CG/GC'
)
SELECT 
	CONCAT (ISNULL(ProjectId,''),'-',ISNULL(ProjectWorkflowSeq,0)) FactProjectWorkflowKey	
	,ProjectId
	,ProjectWorkflowSeq
	,ProjectWorkflowCode
	,Project_Workflow_History_Date_Modified
	/* Sys Columns */
	,SYSDATETIME() AS _StartDate
	,'9999-12-31' AS _EndDate
	,entity_start_date
	,entity_end_date
	,HASHBYTES('SHA2_256', CONCAT (ISNULL(ProjectId,''),'-',ISNULL(ProjectWorkflowSeq,0)) )	AS _KeyHash
	,HASHBYTES('SHA2_256', CONCAT(
	     ProjectId 		
		,'-'
		, ProjectWorkflowSeq 
		,'-'
		, ProjectWorkflowCode
		,'-'
		,Project_Workflow_History_Date_Modified
		)) AS _ValueHash
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME() 
	,_UpdateBy = SYSTEM_USER	
	,ROW_NUMBER() OVER (
		PARTITION BY CONCAT (ISNULL(ProjectId,''),'-',ISNULL(ProjectWorkflowSeq,0)) ORDER BY entity_start_date DESC
		) rn
FROM
(
	SELECT 
		PE.ProjectId 	
		,row_number() over (partition by PE.ProjectId order by PW.Project_Workflow_History_Date_Modified) ProjectWorkflowSeq
		,CONCAT(ISNULL(UPPER(PW.Project_Workflow_History_Source_State),'')
		,'-'
		,ISNULL(UPPER(PW.Project_Workflow_History_Destination_State),'')
		,'-'
		,ISNULL(UPPER(PW.Project_Workflow_History_Action),''))	 AS ProjectWorkflowCode
		,PW.Project_Workflow_History_Date_Modified
		,PE.entity_start_date
		,PE.entity_end_date
	FROM
		dbo.PsBimProjectEntity PE 
		LEFT JOIN dbo.IrisUaProjectList PL ON PL.Project_Code = PE.ProjectId
			AND PL.entity_is_current = 1
		LEFT JOIN dbo.IrisUaProjectWorkflowHistory PW ON PW.Project_Unique_Id = PL.Project_Unique_ID
    WHERE     	
		--PL.entity_end_date > SYSDATETIME() AND
		--PE.entity_end_date > SYSDATETIME() AND
		PE.entity_is_current = 1
		AND EXISTS (SELECT 1 FROM Proj WHERE Proj.BusinessUnit = PE.BusinessUnit AND Proj.ProjectId = PE.ProjectId)
) AS A
GO


