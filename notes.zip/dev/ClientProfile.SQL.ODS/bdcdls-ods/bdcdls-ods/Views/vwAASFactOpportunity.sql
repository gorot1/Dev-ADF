﻿CREATE VIEW [dbo].[vwAASFactOpportunity]
AS
WITH DirEmp AS
(
	SELECT DISTINCT EmployeePIN
	FROM dbo.Employee
	WHERE entity_end_date > SYSDATETIME()
		AND JobTitle = 'Director, Business Development, BDC Advisory Services' -- To be removed and integrated into ADS.
)
SELECT FactOpportunityKey
	,OpportunityCode
	,OpportunityCreatedDateId
	,CustomerCode
	,BranchCode
	,SolutionName
	,OpportunityRatingCode
	,OpportunityStageCode
	,OpportunityStageDateId
	,OpportunityStateCode
	,OpportunityStateDateId
	,OpportunityStatusCode
	,CAST(ClientPartnerEmployeePIN AS VARCHAR) AS ClientPartnerEmployeePIN
	,ReferrerEmployeePIN
	,LineOfBusinessCode
	,CampaignCode
	,OpportunitySourceCode
	,EstimatedCloseDate
	,ReferrerLineOfBusinessName
	,(OpportunityEstimatedAmt  ) as OpportunityEstimatedAmt  --To delete stesting SD2 Functionality
	,entity_start_date
	,HASHBYTES('SHA2_256', FactOpportunityKey) AS _KeyHash
	,HASHBYTES('SHA2_256', CONCAT (
			OpportunityCode
			,'-'
			,OpportunityCreatedDateId
			,'-'
			,CustomerCode
			,'-'
			,BranchCode
			,'-'
			,SolutionName
			,'-'
			,OpportunityRatingCode
			,'-'
			,OpportunityStageCode
			,'-'
			,OpportunityStageDateId
			,'-'
			,OpportunityStateCode
			,'-' , OpportunityStateDateId
			,'-'
			,OpportunityStatusCode
			,'-'
			,ClientPartnerEmployeePIN
			,'-'
			,ReferrerEmployeePIN
			,'-'
			,LineOfBusinessCode
			,'-'
			,CampaignCode
			,'-'
			,OpportunitySourceCode
			,'-'
			,EstimatedCloseDate
			,'-'
			,ReferrerLineOfBusinessName
			,'-'
			,OpportunityEstimatedAmt --To delete stesting SD2 Functionality
			)) AS _ValueHash
	,_StartDate = SYSDATETIME()
	,_EndDate = CAST('9999-12-31' AS DATE)
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (
		PARTITION BY FactOpportunityKey ORDER BY Entity_start_date DESC
		) rn
FROM (
	SELECT RIGHT(CONCAT (
				'0000000000'
				,OE.Opportunity_CrmId
				), 10) AS FactOpportunityKey
		,OE.Opportunity_CrmId AS OpportunityCode
		,CAST(FORMAT(cast(OE.CreatedOn as datetimeoffset) at time zone 'Eastern Standard Time', 'yyyyMMdd') AS INT) AS OpportunityCreatedDateId
		,APE.CRMAccount_CRMId AS CustomerCode
		,RIGHT(CONCAT('0000', OEE.DepartmentCode), 4) AS BranchCode	-- Pad to 4 digits with 0 prefix for join with DimRegionBranch.BranchCode.
		,OE.CGSolutionNameEn AS SolutionName
		,OE.OpportunityRatingCode AS OpportunityRatingCode
		,OSSE.OpportunitySaleStageId_CrmId AS OpportunityStageCode
		,CAST(FORMAT(cast(OE.SalesStageChangeDate as datetimeoffset) at time zone 'Eastern Standard Time', 'yyyyMMdd') AS INT) AS OpportunityStageDateId
        ,OE.StatusCode                                          AS OpportunityStateCode
        ,CAST(FORMAT(cast(OE.ConsultingStateChangeDate as datetimeoffset) at time zone 'Eastern Standard Time', 'yyyyMMdd') AS INT)  AS OpportunityStateDateId
		,OE.StatusReasonCode AS OpportunityStatusCode
		,CAST(OEE.EmployeePIN AS INT) AS ClientPartnerEmployeePIN
		,CAST(REE.EmployeePIN AS INT) AS ReferrerEmployeePIN
		,OE.LineOfBusinessCode AS LineOfBusinessCode
		,OE.CampaignId AS CampaignCode
		,OE.SourceOfReferralCode AS OpportunitySourceCode
		,OE.EstimatedCloseDate AS EstimatedCloseDate
		,REE.LineOfBusinessName AS ReferrerLineOfBusinessName
		,OE.EstimatedValue AS OpportunityEstimatedAmt
		,OE.entity_start_date
		,OE.entity_end_date
	FROM dbo.OpportunityEntity OE
	LEFT OUTER JOIN dbo.AccountProfileEntity APE ON OE.AccountId = APE.AccountId
		AND APE.entity_end_date > SYSDATETIME()
	INNER JOIN dbo.Employee OEE ON OE.OwnerId = OEE.CRM_SystemUserId
		AND OEE.entity_end_date > SYSDATETIME()
	INNER JOIN dbo.OpportunitySalesStagesEntity OSSE ON OE.SaleStageCode = OSSE.OpportunitySaleStageId
		AND OSSE.entity_end_date > SYSDATETIME()
	LEFT OUTER JOIN dbo.Employee REE ON OE.InternalReferrer = REE.CRM_SystemUserId
		AND REE.entity_end_date > SYSDATETIME()
	WHERE
		OE.entity_end_date > SYSDATETIME()
		AND OE.LineOfBusinessNameEn = 'Consulting' -- Advisory related only
		--AND OE.StatusCode <> '803750012'
		AND EXISTS (SELECT 1 FROM DirEmp WHERE DirEmp.EmployeePIN = OEE.ManagerPIN)
	) X
GO