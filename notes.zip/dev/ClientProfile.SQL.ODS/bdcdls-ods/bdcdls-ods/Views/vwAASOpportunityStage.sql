﻿/*
    AAS.DimOpportunityStage
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash for the same _KeyHash
        Then Update record
        Else skip record
*/
CREATE VIEW [dbo].[vwAASOpportunityStage]
AS
SELECT CAST(OpportunityStageCode AS VARCHAR) AS OpportunityStageCode
	,CAST(OpportunityStageName AS VARCHAR) AS OpportunityStageName
	,CAST(OpportunityStageSeq AS VARCHAR) AS OpportunityStageSeq
	,CAST(IsQualifiedStage AS BIT) AS IsQualifiedStage
	,CAST(IsProposedStage AS BIT) AS IsProposedStage
	,CAST(IsSalesStage AS BIT) AS IsSalesStage
	/* Sys Columns */
	,entity_start_date
	,entity_end_date
	,CAST(1 AS BIT) AS _CurrentFlag
	,HASHBYTES('SHA2_256', OpportunityStageCode) AS _KeyHash
	,HASHBYTES('SHA2_256', CONCAT (
			OpportunityStageName
			,'-'
			,OpportunityStageSeq
			,'-'
			,IsQualifiedStage
			,'-'
			,IsProposedStage
			,'-'
			,IsSalesStage
			)) AS _ValueHash
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (
		PARTITION BY OpportunityStageCode ORDER BY Entity_start_date DESC
		) rn
FROM (
	SELECT OpportunityStageCode
		,OpportunityStageName
		,OpportunityStageSeq
		,CASE 
			WHEN OpportunityStageSeq IN (
					1
					,2
					)
				THEN 1
			ELSE 0
			END AS IsQualifiedStage
		,CASE 
			WHEN OpportunityStageSeq IN (
					3
					,4
					)
				THEN 1
			ELSE 0
			END AS IsProposedStage
		,CASE 
			WHEN OpportunityStageSeq IN (
					1
					,2
					,3
					)
				THEN 1
			ELSE 0
			END AS IsSalesStage
		,entity_start_date
		,entity_end_date
	FROM (
		SELECT OpportunitySaleStageId_CrmId AS OpportunityStageCode
			,NameEn AS OpportunityStageName
			,entity_start_date
			,entity_end_date
			,CAST(SUBSTRING(NameEn, 0, CHARINDEX('.', NameEn)) AS INT) AS OpportunityStageSeq
		FROM dbo.OpportunitySalesStagesEntity
		WHERE LobNameEn = 'Consulting' -- Advisory only.
			AND entity_end_date > SYSDATETIME()
		) X
	) X
GO