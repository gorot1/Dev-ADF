﻿create view [dbo].[vwPBIrole_level_security]  AS
select
replicate('0', 6-len(ppp.AbacusCustId)) + cast(cast(ppp.AbacusCustId as int) as nvarchar) 
	+ '-' + substring(cast(cast(ppp.AccountNumber as int) as nvarchar), len(cast(cast(ppp.AccountNumber as int) as nvarchar))-1, 2) as AccountNumber,
rb.AbacusCustId,
rb.AccountId,
rb.mcs_BusinessDevelopmentLeadName,
rb.AccountCRMId,
rb.AccountName,
rb.InternalEMailAddress
from dbo.PrepaymentPredictionsEntity ppp 
inner join dbo.RepeatBusinessPredictionsEntity rb
	on rb.AbacusCustId = ppp.AbacusCustId 
where ppp.entity_is_current = 1 and rb.entity_is_current = 1 and ppp.loan_outstanding_balance <> 0
GO
