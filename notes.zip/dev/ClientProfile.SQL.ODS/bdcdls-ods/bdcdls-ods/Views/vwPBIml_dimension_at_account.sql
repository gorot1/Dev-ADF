﻿CREATE view [dbo].[vwPBIml_dimension_at_account]  AS  
select 
replicate('0', 6-len(ppp.AbacusCustId)) + cast(cast(ppp.AbacusCustId as int) as nvarchar) 
	+ '-' + substring(cast(cast(ppp.AccountNumber as int) as nvarchar), len(cast(cast(ppp.AccountNumber as int) as nvarchar))-1, 2) as AccountNumber,
rb.AbacusCustId,
rb.AccountId,
rb.mcs_BusinessDevelopmentLeadName,
rb.AccountCRMId,
rb.AccountName, 
ou.[OriginatingUnitNameEnglish], 
ou.[AreaNameEnglish], 
ou.[OperationRegionName],
pphr.highest_prepayment_risk, 
pphr.highest_prepayment_probability_12_month,
opu.OperatingModel,
acc.AccountSegmentDescrEn,
rb.nb_opp_Open_last_6_months, 
rb.nb_opp_Lost_last_6_months, 
rb.star_rating as repeat_star_rating,
rb.remaining_commitment,
rb.probability_12_month as repeat_probability,
rb.current_risk_rating as risk_rating,
rb.FinalRiskRating_variation as risk_rating_variation,
--re.FinalRiskRating as risk_rating,
finstat.NetProfitMargin                        as kpi_Net_profit_margin_perc, 
finstat.FinancialStatementDate                as last_financialStatement_calculation
from dbo.PrepaymentPredictionsEntity ppp
inner join  RepeatBusinessPredictionsEntity rb on rb.AbacusCustId = ppp.AbacusCustId
left join(select 
	AbacusCustId, 
	max(star_rating) as highest_prepayment_risk, 
	max(probability_12_month) as highest_prepayment_probability_12_month 
	from dbo.PrepaymentPredictionsEntity 
	where entity_is_current = 1 
	group by AbacusCustId) pphr 
	on pphr.AbacusCustId = rb.AbacusCustId 
left join(select 
	[OriginatingUnitNameEnglish], 
	[AreaNameEnglish], 
	[OperationRegionName], 
	CustomerNumber 
	from dbo.LoanCustomerEntity lc 
	inner join dbo.OrganizationRefEntity ou on ou.[OriginatingUnitNumberAbacus] = lc.OriginatingUnitCode 
	where lc.entity_is_current = 1 and ou.entity_is_current = 1) ou on cast(ou.CustomerNumber as float) = rb.AbacusCustId 
left join(select 
    distinct AccountNumber,
    cast(replace(AccountNumber, '-', '') as float) as Account, 
    CustomerTypeCode, GrossLoanAmount, 
    MaturityDate, 
    LoanPurposeDescr  
    from dbo.LoanEntity 
	where entity_is_current = 1 and (ActiveLoanFlag is null or ActiveLoanFlag = 1)) le on le.account = ppp.AccountNumber /*
inner join (select
	AccountNumber,
	InterestAdjustmentDate,
	entity_start_date,
	entity_is_current,
	TrancheNumber,
	FloatingRateIndexCode,
	row_number() over(partition by AccountNumber order by AccrualScheduleId desc) as rnk_lta
	from dbo.LoanTrancheAttributesEntity
	where isnumeric(TrancheNumber) = 1 and entity_is_current = 1) lta
	on lta.AccountNumber = ppp.AccountNumber and lta.rnk_lta = 1
	inner join (select
	re_a.AccountCrmId,
	FinalRiskRating,
	previous_risk_rating,
	(FinalRiskRating - previous_risk_rating) / nullif(previous_risk_rating, 0) * 100 as FinalRiskRating_variation
	from dbo.RiskEvaluationEntity re_a
	inner join (select
		AccountCrmId,
		max(ServiceRequestAuthorizationDate) as max_date
		from dbo.RiskEvaluationEntity 
		where entity_is_current = 1
		group by AccountCrmId) re_last
		on re_last.max_date = re_a.ServiceRequestAuthorizationDate and re_last.AccountCrmId = re_a.AccountCrmId
	inner join ( select
		AccountCrmId,
		max(RiskEvaluationVersion) as max_ver
		from dbo.RiskEvaluationEntity
		where entity_is_current = 1
		group by AccountCrmId) re_max
		on re_max.max_ver = re_a.RiskEvaluationVersion and re_max.AccountCrmId = re_a.AccountCrmId
	inner join ( select
		AccountCrmId,
		FinalRiskRating as previous_risk_rating,
		row_number() over(partition by AccountCrmId order by RiskEvaluationVersion desc, ServiceRequestAuthorizationDate desc) before_last
		from dbo.RiskEvaluationEntity
		where entity_is_current = 1) re_max_bef
		on re_max_bef.before_last = 2 and re_max_bef.AccountCrmId = re_a.AccountCrmId
	where re_a.entity_is_current = 1) re
	on re.AccountCrmId = rb.AccountCRMId */
inner join(select 
    cur.AccountCrmId, 
    cur.FinancialStatementDate, 
    cur.NetProfitAmount, 
    cur.TotalSalesAmount, 
    cur.SuggestedAvailableFundsAmount, 
    cur.SuggestedTotalDebtService, 
	cur.CurrentLiabilitiesAmount, 
    cur.NetProfitAmount / nullif(cur.TotalSalesAmount, 0) as NetProfitMargin, 
    (cur.NetProfitAmount - prev.NetProfitAmount)/ nullif(prev.NetProfitAmount, 0) as var_NetProfitAmount, 
    (cur.TotalSalesAmount - prev.TotalSalesAmount)/ nullif(prev.TotalSalesAmount, 0) as var_TotalSalesAmount, 
    (cur.SuggestedAvailableFundsAmount - prev.SuggestedAvailableFundsAmount)/ nullif(prev.SuggestedAvailableFundsAmount, 0) as var_SuggestedAvailableFundsAmount, 
    (cur.SuggestedTotalDebtService - prev.SuggestedTotalDebtService)/ nullif(prev.SuggestedTotalDebtService, 0) as var_SuggestedTotalDebtService, 
    ((cur.NetProfitAmount / nullif(cur.TotalSalesAmount, 0)) - prev.NetProfitMargin)/ nullif(prev.NetProfitMargin, 0) as var_NetProfitMargin 
    from dbo.RiskFinancialStatementCurrentEntity cur 
    left join (select 
        prev.AccountCrmId, 
        prev.NetProfitAmount, 
        prev.TotalSalesAmount, 
        prev.SuggestedAvailableFundsAmount, 
        prev.SuggestedTotalDebtService, 
		prev.FinancialStatementDate,
        prev.NetProfitAmount / nullif(prev.TotalSalesAmount, 0) as NetProfitMargin
        from dbo.RiskFinancialStatementPreviousEntity prev 
        where entity_is_current = 1) prev 
		inner join (select
			AccountCrmId,
			max(FinancialStatementDate) as last_fs
			from dbo.RiskFinancialStatementPreviousEntity
			where entity_is_current = 1
			group by AccountCrmId) last_prev
			on prev.FinancialStatementDate = last_prev.last_fs and prev.AccountCrmId = last_prev.AccountCrmId 
        on cur.AccountCrmId = prev.AccountCrmId 
        where entity_is_current = 1) finstat 
        on rb.AccountCRMId = finstat.AccountCrmId
inner join (select
	ape.AccountSegmentDescrEn,
	--ape.CRMAccount_CRMId,
	--ape.OverallRiskRating,
	--ape.TotalCommitment,
	le.AbacusCustomerNumber as AbacusCustId
	from ( select AccountSegmentDescrEn,
            CRMAccount_CRMId,
            OverallRiskRating,
            TotalCommitment,
            entity_start_date
        from dbo.AccountProfileEntity
        where entity_is_current = 1)  ape
	inner join (
		select distinct 
		AbacusCustomerNumber, AccountBusinessKey 
		from dbo.LoanEntity where entity_is_current = 1) le 
		on le.AccountBusinessKey = ape.CRMAccount_CRMId
	inner join (
		select 
		max(entity_start_date) maxDate, 
		CRMAccount_CRMId 
		from AccountProfileEntity 
		where entity_is_current = 1 
		group by CRMAccount_CRMId) MaxStart 
		on ape.CRMAccount_CRMId = MaxStart.CRMAccount_CRMId
		where ape.entity_start_date = MaxStart.maxDate) acc
	on acc.AbacusCustId = ppp.AbacusCustId 
left join(select
	lc.CustomerNumber as AbacusCustId,
	ou.OperatingModel
	from dbo.LoanCustomerEntity lc
	inner join dbo.OperatingUnitRefEntity ou on ou.AdminDeptAbacusId = lc.OperatingUnitCode
	where lc.entity_is_current = 1 and ou.entity_is_current = 1) opu
	on opu.AbacusCustId = ppp.AbacusCustId
where rb.entity_is_current = 1 and ppp.entity_is_current = 1 and ppp.loan_outstanding_balance <> 0


GO


