/*
    **************************************************************************
    AAS.FactMandate
    This script returns rows effective at @ExtractDateTime.
    **************************************************************************
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash of previous record for the same _KeyHash
        Then set _EndDate of previous record, and Insert new record
        Else skip record
    If lookup on Dim table returns no match, assign N/A.
*/
CREATE VIEW [dbo].[vwAASFactMandate]
AS
WITH Proj AS
(	-- Retrieve list of ConsultingProjects.
	SELECT
		PE.BusinessUnit
        ,PE.ProjectId
		,LAG(PE.ProjectId, 1, NULL) OVER (PARTITION BY PE.CustomerId ORDER BY PE.StartDate, PE.ProjectId) AS CustomerPrevProjectId
	FROM
		dbo.PsBimProjectEntity PE
	WHERE
		PE.entity_is_current = 1
		AND PE.BusinessUnit = 'CG/GC'
)
,Mand AS
(
    SELECT
        BusinessUnit
        ,ProjectId
        ,ProjectManagerPIN
        ,CASE WHEN EffectiveDate = PrjMaxEffectiveDate THEN ContributionPct ELSE 0 END AS ContributionPct
        ,entity_start_date
        ,entity_end_date
    FROM
    (
        SELECT
            PM.BusinessUnit
            ,PM.ProjectId
            ,PM.ProjectManagerPIN
            ,PM.EffectiveDate
            ,PM.ContributionPct
            ,PM.entity_start_date
            ,PM.entity_end_date
            ,MAX(PM.EffectiveDate) OVER (PARTITION BY PM.BusinessUnit, PM.ProjectId) AS PrjMaxEffectiveDate
            ,ROW_NUMBER() OVER (PARTITION BY PM.BusinessUnit, PM.ProjectId, PM.ProjectManagerPIN ORDER BY PM.EffectiveDate DESC) AS RowNum
        FROM dbo.PsBimProjectManager PM
        WHERE PM.entity_is_current = 1
            AND EXISTS (SELECT 1 FROM Proj WHERE Proj.BusinessUnit = PM.BusinessUnit AND Proj.ProjectId = PM.ProjectId)
            AND PM.EffectiveDate < SYSDATETIME()
    ) X
    WHERE RowNum = 1
)
,Ext AS
(
    SELECT
        PME.ProjectId
		,PME.ProjectManagerPIN
        ,SUM(PME.BDC_UNEARNED) AS UnearnedAmt
		,SUM(PME.BDC_NBR_CUST_YTD) AS ClientNbrYTD
		,SUM(PME.BDC_MANDATE_YTD) AS MandateNbrYTD
		,SUM(PME.BDC_SALES_YTD) AS SalesAmtYTD
		,SUM(PME.BDC_REV_YTD) AS RevenueAmtYTD
		,SUM(PME.BDC_REV_YTD - PME.BDC_DIR_EXP_YTD - PME.BDC_INT_EXP_YTD - PME.BDC_OOP_EXP_YTD + PME.BDC_OOP_BLD_YTD) AS GrossMarginYTD
		,SUM(PME.BDC_REV_YTD - PME.BDC_DIR_EXP_YTD - PME.BDC_INT_EXP_YTD - PME.BDC_BAD_DEBTS_YTD) AS BadDebtsYTD
		,SUM(PME.BDC_REV_YTD - PME.BDC_DIR_EXP_YTD - PME.BDC_INT_EXP_YTD - PME.BDC_CONT_EXP_YTD - PME.BDC_BAD_DEBTS_YTD - PME.BDC_OOP_EXP_YTD + PME.BDC_OOP_BLD_YTD) AS NetMarginYTD
        ,MAX(entity_start_date) AS entity_start_date
    FROM dbo.PsBimProjectManagerExtEntity PME
    WHERE EXISTS (SELECT 1 FROM Proj WHERE Proj.ProjectId = PME.ProjectId)
        AND PME.entity_is_current = 1
    GROUP BY PME.ProjectId, PME.ProjectManagerPIN
)
,ResNonRev AS
(   -- RESOURCE_AMOUNT of non "REV" ANALYSIS_TYPE.
    SELECT
        PR.BusinessUnit
        ,PR.ProjectId
        ,PR.JournalLineDate
        ,SUM(PR.ResourceAmt) AS ResourceNonRevAmt
        ,MAX(PR.entity_start_date) AS entity_start_date
    FROM dbo.PsBimProjectResource PR
    WHERE EXISTS (SELECT 1 FROM Proj WHERE Proj.BusinessUnit = PR.BusinessUnit AND Proj.ProjectId = PR.ProjectId)
        AND PR.entity_is_current = 1
        AND PR.AnalysisType <> 'REV'
    GROUP BY PR.BusinessUnit, PR.ProjectId, PR.JournalLineDate
)
,ResRev AS
(   -- RESOURCE_AMOUNT of only "REV" ANALYSIS_TYPE.
    SELECT
        PR.BusinessUnit
        ,PR.ProjectId
        ,PR.JournalLineDate
        ,SUM(PR.ResourceAmt) AS ResourceRevAmt
        ,MAX(PR.entity_start_date) AS entity_start_date
    FROM dbo.PsBimProjectResource PR
    WHERE EXISTS (SELECT 1 FROM Proj WHERE Proj.BusinessUnit = PR.BusinessUnit AND Proj.ProjectId = PR.ProjectId)
        AND PR.entity_is_current = 1
        AND PR.AnalysisType = 'REV'
    GROUP BY PR.BusinessUnit, PR.ProjectId, PR.JournalLineDate
)
,Jrnl AS
(
	SELECT
		ProjectId
        ,DepartmentId
        ,JournalLineDate
		,SUM(CASE WHEN Account IN ('K49', 'K40', 'K40IU') THEN StatisticAmt ELSE -MonetaryAmt END)	AS ProjectAmt
		,SUM(CASE WHEN Account IN ('K49') THEN StatisticAmt ELSE 0 END)								AS NumberOfMandates
		,SUM(CASE WHEN Account IN ('K40', 'K40IU') THEN StatisticAmt ELSE 0 END)					AS NetSalesAmt
		,SUM(CASE WHEN Account IN ('43000', '42180') THEN -MonetaryAmt ELSE 0 END)					AS RevenueAmt
		,SUM(CASE WHEN Account IN ('70200', '70201') THEN -MonetaryAmt ELSE 0 END)					AS ExternalConsultingFeeAmt
		,SUM(CASE WHEN Account IN ('70210', '70211') THEN -MonetaryAmt ELSE 0 END)					AS InternalConsultingFeeAmt
		,SUM(CASE WHEN Account IN ('43000', '42180', '70200', '70201', '70210', '70211', '73657', '73658') THEN -MonetaryAmt ELSE 0 END)	AS GrossMarginAmt
        ,MAX(entity_event_date) AS entity_event_date
	FROM dbo.PsBimJournalEntity JE
	WHERE EXISTS (SELECT 1 FROM Proj WHERE Proj.ProjectId = JE.ProjectId)
		AND JE.Ledger = 'ACTUALS'
        AND JE.Account IN ('K49', 'K40', 'K40IU', '43000', '42180', '70200', '70201', '70210', '70211', '73657', '73658')
        AND JE.JournalLineDate < CAST(SYSDATETIME() AS DATE)    -- Up to last close date.
		AND JE.JournalLineSource <> 'CLO'
	GROUP BY ProjectId, DepartmentId, JournalLineDate
)

SELECT
    FactMandateKey
	,CAST(JournalLineDate AS INT) AS JournalLineDateId
    ,ProjectCode
    ,ProjectManagerPIN
    ,BranchCode
    ,ContributionPct
    ,ClientNbrYTD
    ,MandateNbrYTD
    ,SalesAmtYTD
    ,RevenueAmtYTD
    ,GrossMarginYTD
    ,BadDebtsYTD
    ,NetMarginYTD
    ,UnearnedAmt
	,ProjectAmt
	,NumberOfMandates
	,NetSalesAmt
	,RevenueAmt
	,ExternalConsultingFeeAmt
	,InternalConsultingFeeAmt
	,GrossMarginAmt
    ,ResourceNonRevAmt
    ,ResourceRevAmt
    ,HASHBYTES('SHA2_256', FactMandateKey) AS _KeyHash
    ,HASHBYTES('SHA2_256', CONCAT(JournalLineDate
		,'-', ProjectCode
        ,'-', ProjectManagerPIN
        ,'-', BranchCode
        ,'-', ContributionPct
        ,'-', ClientNbrYTD
        ,'-', MandateNbrYTD
        ,'-', SalesAmtYTD
        ,'-', RevenueAmtYTD
        ,'-', GrossMarginYTD
        ,'-', BadDebtsYTD
        ,'-', NetMarginYTD
        ,'-', UnearnedAmt
		,'-', ProjectAmt
		,'-', NumberOfMandates
		,'-', NetSalesAmt
		,'-', RevenueAmt
		,'-', ExternalConsultingFeeAmt
		,'-', InternalConsultingFeeAmt
		,'-', GrossMarginAmt
        ,'-', ResourceNonRevAmt
        ,'-', ResourceRevAmt
        )) AS _ValueHash
    ,entity_start_date
	,entity_end_date
    ,SYSDATETIME() AS _StartDate
    ,cast ('9999-12-31' as datetime2) AS _EndDate
	,_InsertDate = SYSDATETIME()
    ,_InsertBy = SYSTEM_USER
    ,_UpdateDate = SYSDATETIME() 
    ,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (PARTITION BY FactMandateKey ORDER BY entity_start_date DESC) rn
FROM
(
SELECT
    CONCAT(FORMAT(Jrnl.JournalLineDate, 'yyyyMMdd'), '-', RIGHT(CONCAT('000000000000000', Mand.ProjectId), 15), '-', RIGHT(CONCAT('00000000000', Mand.ProjectManagerPIN), 11)) AS FactMandateKey
	,FORMAT(Jrnl.JournalLineDate, 'yyyyMMdd') AS JournalLineDate
    ,Mand.ProjectId AS ProjectCode
    ,Mand.ProjectManagerPIN
    ,Jrnl.DepartmentId AS BranchCode
    ,Mand.ContributionPct
    ,COALESCE(Ext.ClientNbrYTD, 0) AS ClientNbrYTD
    ,COALESCE(Ext.MandateNbrYTD, 0) AS MandateNbrYTD
    ,COALESCE(Ext.SalesAmtYTD, 0) AS SalesAmtYTD
    ,COALESCE(Ext.RevenueAmtYTD, 0) AS RevenueAmtYTD
    ,COALESCE(Ext.GrossMarginYTD, 0) AS GrossMarginYTD
    ,COALESCE(Ext.BadDebtsYTD, 0) AS BadDebtsYTD
    ,COALESCE(Ext.NetMarginYTD, 0) AS NetMarginYTD
    ,COALESCE(Ext.UnearnedAmt, 0) AS UnearnedAmt
	,COALESCE(Jrnl.ProjectAmt * (Mand.ContributionPct/100), 0) AS ProjectAmt
	,COALESCE(Jrnl.NumberOfMandates * (Mand.ContributionPct/100), 0) AS NumberOfMandates
	,COALESCE(Jrnl.NetSalesAmt * (Mand.ContributionPct/100), 0) AS NetSalesAmt
	,COALESCE(Jrnl.RevenueAmt * (Mand.ContributionPct/100), 0) AS RevenueAmt
	,COALESCE(Jrnl.ExternalConsultingFeeAmt * (Mand.ContributionPct/100), 0) AS ExternalConsultingFeeAmt
	,COALESCE(Jrnl.InternalConsultingFeeAmt * (Mand.ContributionPct/100), 0) AS InternalConsultingFeeAmt
	,COALESCE(Jrnl.GrossMarginAmt * (Mand.ContributionPct/100), 0) AS GrossMarginAmt
    ,COALESCE(ResNonRev.ResourceNonRevAmt * (Mand.ContributionPct/100), 0) AS ResourceNonRevAmt
    ,COALESCE(ResRev.ResourceRevAmt * (Mand.ContributionPct/100), 0) AS ResourceRevAmt
    ,(SELECT MAX(entitystartdate) FROM (
        VALUES (Mand.entity_start_date), (Jrnl.entity_event_date), (Ext.entity_start_date), (ResNonRev.entity_start_date), (ResRev.entity_start_date)
        ) AS VALUE(entitystartdate)
    ) AS entity_start_date
	,Mand.entity_end_date
FROM
    Mand
    JOIN Jrnl ON Mand.ProjectId = Jrnl.ProjectId
	LEFT OUTER JOIN Ext ON Mand.ProjectId = Ext.ProjectId AND Mand.ProjectManagerPIN = Ext.ProjectManagerPIN
    LEFT OUTER JOIN ResNonRev ON Mand.ProjectId = ResNonRev.ProjectId AND Mand.BusinessUnit = ResNonRev.BusinessUnit AND Jrnl.JournalLineDate = ResNonRev.JournalLineDate
    LEFT OUTER JOIN ResRev ON Mand.ProjectId = ResRev.ProjectId AND Mand.BusinessUnit = ResRev.BusinessUnit AND Jrnl.JournalLineDate = ResRev.JournalLineDate
) AS A
GO
