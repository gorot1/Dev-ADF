﻿CREATE VIEW [dbo].[vwAMAFactDigitalMetric_EloquaExpressConsents]
AS
SELECT
	ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Id
	,entity_event_date MetricStartDate
	,entity_event_date MetricEndDate
	,'dbo.EloquaBimExpressConsentsEntity' MetricSourceTableName
	,ExpressConsents
	,InBusiness
	,LeadNurturing
	,ClientNurturing
	,MEL
	,Newsletters
	,Partners
	,Profits
	,UniqueEmailSubscribers
	,ISNULL(LeadAndClientNurturingCombined, 0) Nurturing
	,entity_modified_on
FROM
	dbo.EloquaBimExpressConsentsEntity
WHERE
	entity_is_current = 1
	AND Date >= '2021-01-01'
GO