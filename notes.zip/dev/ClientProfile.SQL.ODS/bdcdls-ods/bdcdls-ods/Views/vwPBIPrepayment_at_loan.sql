﻿CREATE view [dbo].[vwPBIPrepayment_at_loan]  AS
with cpb_val(AccountNumber, InterestRate,  entity_start_date, InterestAdjustmentDate, FloatingRateIndexCode)
as
(select
AccountNumber,
InterestRate,
entity_start_date,
InterestAdjustmentDate,
FloatingRateIndexCode
from dbo.LoanTrancheAttributesEntity
where entity_is_current = 1
and (substring(TrancheNumber, 7, 1) = '0'
                or substring(TrancheNumber, 7, 1) = '1'
                or substring(TrancheNumber, 7, 1) = '2'
                or substring(TrancheNumber, 7, 1) = '3'
                or substring(TrancheNumber, 7, 1) = '4'
                or substring(TrancheNumber, 7, 1) = '5'
                or substring(TrancheNumber, 7, 1) = 'P')
),
rnk_lta
as
(select
AccountNumber,
InterestAdjustmentDate,
entity_start_date,
entity_is_current,
TrancheNumber,
FloatingRateIndexCode,
row_number() over(partition by AccountNumber order by entity_start_date desc) as rnk
from (select
    AccountNumber,
                TrancheNumber,
    entity_start_date,
                entity_is_current,
    InterestAdjustmentDate,
    FloatingRateIndexCode
    from dbo.LoanTrancheAttributesEntity
    where isnumeric(TrancheNumber) = 1
    ) cpb_val
) ,/*
rnk_re
as
(select
    re_a.AccountCrmId,
    FinalRiskRating,
    previous_risk_rating,
	row_number() over(partition by re_a.AccountCrmId order by ServiceRequestAuthorizationDate desc) as last_date,
    (FinalRiskRating - previous_risk_rating) / nullif(previous_risk_rating, 0) * 100 as FinalRiskRating_variation
    from dbo.RiskEvaluationEntity re_a
    inner join (select		
		ServiceRequestCrmId
		from dbo.WorkItemEntity
		where entity_is_current = 1 AND (
			OriginationRequestState in ('Accepted_by_Client', 'Waiting_for_Client_Acceptance', 'Cancelled')
			or AdministrationRequestState = 'Completered'
			or AnnualReviewRequestState = 'Completed'
			or GeneralAdminRequestState = 'Completed'
			or DisbursementRequestState = 'Completed'
			or InHouseSecurityState = 'Completed'
			or LoanPaymentRemittanceRequestState = 'Completed'
			or WriteOffRequestState = 'Completed'
			or SundryDisbursementRequestState = 'Completed')) wie on wie.ServiceRequestCrmId = re_a.ServiceRequestCrmId
    inner join ( select
        AccountCrmId,
        FinalRiskRating as previous_risk_rating,
        row_number() over(partition by AccountCrmId order by RiskEvaluationVersion desc, ServiceRequestAuthorizationDate desc) before_last
        from dbo.RiskEvaluationEntity
        where entity_is_current = 1) re_max_bef
        on re_max_bef.before_last = 2 and re_max_bef.AccountCrmId = re_a.AccountCrmId
    where re_a.entity_is_current = 1), */
prepay_var
as
(select
probability_12_month,
probability_variation,
star_rating,
entity_is_current,
AccountNumber,
AbacusCustId,
estimated_penalty,
penalty_calculation_date,
security_coverage_amount,
security_coverage_variation,
potential_revenue_loss,
BaseRate,
WIRVRate,
InterestRate,
InterestRate_variation,
loan_outstanding_balance,
security_shortfall_amount
from dbo.PrepaymentPredictionsEntity
where isActive = 1 and entity_is_current = 1),
nb_loan as (
select
AbacusCustId,
count(distinct AccountNumber) as current_number_of_loans
from dbo.PrepaymentPredictionsEntity
where entity_is_current = 1 and loan_outstanding_balance <> 0
group by AbacusCustId)


 

SELECT
distinct
ppp.AccountNumber as AccountNumber_int,
replicate('0', 6-len(ppp.AbacusCustId)) + cast(cast(ppp.AbacusCustId as int) as nvarchar) 
    + '-' + substring(cast(cast(ppp.AccountNumber as int) as nvarchar), len(cast(cast(ppp.AccountNumber as int) as nvarchar))-1, 2) as AccountNumber,
le.GrossLoanAmount,
ppp.loan_outstanding_balance,
le.MaturityDate,
le.LoanPurposeDescr,
ppp.AbacusCustId,
ppp.probability_12_month as prepayment_risk,
ppp.probability_variation as prepayment_probability_variation,
ppp.star_rating as star_rating_prepayment,
ppp.security_coverage_amount,
ppp.security_coverage_variation,
ppp.potential_revenue_loss,
ppp.estimated_penalty,
rb.current_risk_rating as risk_rating,
rb.current_risk_rating as current_risk_rating,
rb.FinalRiskRating_variation as risk_rating_variation,
ppp.security_shortfall_amount,
ppp.BaseRate,
ppp.WirvRate,
ppp.InterestRate,
lta.InterestAdjustmentDate,
lta.FloatingRateIndexCode,
rb.AccountName,
rb.AccountCRMId,
rb.CRMAccount_CRMId,
rb.probability_12_month as repeat_chance_probability_12_months,
rb.last_repeat_business_prediction ,
(rb.last_repeat_business_prediction - rb.probability_12_month) / rb.last_repeat_business_prediction as repeat_variation,
ppnb.current_number_of_loans,
rb.remaining_commitment,
rb.mcs_FinalLoanPurposeAmount as express_loan_amount,
rb.kpi_Current_ratio,
rb.kpi_Current_ratio_variation,
rb.kpi_Debt_to_equity_ratio,
rb.kpi_Debt_to_equity_ratio_variation,
rb.have_kpiBenchmarks,
finstat.NetProfitAmount                        as total_profit, 
finstat.TotalSalesAmount                    as total_sales, 
finstat.SuggestedAvailableFundsAmount        as AvailableFunds, 
finstat.var_NetProfitAmount                    as total_profit_variation, 
finstat.var_TotalSalesAmount                as total_sales_variation, 
finstat.var_SuggestedAvailableFundsAmount    as available_funds_variation, 
finstat.NetProfitMargin                        as kpi_Net_profit_margin_perc, 
finstat.var_NetProfitMargin                    as kpi_Net_profit_margin_perc_variation
FROM prepay_var ppp
inner join dbo.RepeatBusinessPredictionsEntity rb on rb.AbacusCustId = ppp.AbacusCustId
left join(select 
    AccountNumber,
    cast(replace(AccountNumber, '-', '') as float) as Account, 
    CustomerTypeCode, GrossLoanAmount, 
    MaturityDate, 
    LoanPurposeDescr  
    from dbo.LoanEntity where entity_is_current = 1 and (ActiveLoanFlag is null or ActiveLoanFlag = 1)) le on le.account = ppp.AccountNumber
left join (select * from rnk_lta where rnk = 1) lta on lta.AccountNumber = ppp.AccountNumber
--left join (select * from rnk_re) re on re.AccountCrmId = rb.AccountCRMId and re.last_date = 1
inner join nb_loan ppnb on ppnb.AbacusCustId = ppp.AbacusCustId
inner join(select 
    cur.AccountCrmId, 
    cur.NetProfitAmount, 
    cur.TotalSalesAmount, 
    cur.SuggestedAvailableFundsAmount, 
    cur.NetProfitAmount / nullif(cur.TotalSalesAmount, 0) as NetProfitMargin, 
    (cur.NetProfitAmount - prev.NetProfitAmount)/ nullif(prev.NetProfitAmount, 0) as var_NetProfitAmount, 
    (cur.TotalSalesAmount - prev.TotalSalesAmount)/ nullif(prev.TotalSalesAmount, 0) as var_TotalSalesAmount, 
    (cur.SuggestedAvailableFundsAmount - prev.SuggestedAvailableFundsAmount)/ nullif(prev.SuggestedAvailableFundsAmount, 0) as var_SuggestedAvailableFundsAmount, 
    ((cur.NetProfitAmount / nullif(cur.TotalSalesAmount, 0)) - prev.NetProfitMargin)/ nullif(prev.NetProfitMargin, 0) as var_NetProfitMargin 
    from dbo.RiskFinancialStatementCurrentEntity cur 
    left join (select 
        prev.AccountCrmId, 
        prev.NetProfitAmount, 
        prev.TotalSalesAmount, 
        prev.SuggestedAvailableFundsAmount, 
        prev.SuggestedTotalDebtService, 
        prev.FinancialStatementDate,
        prev.NetProfitAmount / nullif(prev.TotalSalesAmount, 0) as NetProfitMargin
        from dbo.RiskFinancialStatementPreviousEntity prev 
        where entity_is_current = 1) prev 
        inner join (select
            AccountCrmId,
            max(FinancialStatementDate) as last_fs
            from dbo.RiskFinancialStatementPreviousEntity
            where entity_is_current = 1
            group by AccountCrmId) last_prev
            on prev.FinancialStatementDate = last_prev.last_fs and prev.AccountCrmId = last_prev.AccountCrmId 
        on cur.AccountCrmId = prev.AccountCrmId 
        where entity_is_current = 1) finstat 
        on rb.AccountCRMId = finstat.AccountCrmId
where ppp.entity_is_current = 1 and ppp.loan_outstanding_balance > 0 and rb.entity_is_current = 1
GO


