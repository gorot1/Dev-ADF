﻿CREATE VIEW [dbo].[vwAASOpportunityState]
AS
/*
    AAS.DimvwAASOpportunityState 
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash for the same _KeyHash
        Then Update record
        Else skip record
*/
SELECT CAST(OpportunityStateCode AS NVARCHAR) AS OpportunityStateCode
	,OpportunityStateName
	,OpportunityStateSeq
	,CAST(IsOpenState AS BIT) AS IsOpenState
	,CAST(IsWonState AS BIT) AS IsWonState
	,CAST(IsLostState AS BIT) AS IsLostState
	/* Sys Columns */
	,CAST(1 AS BIT) AS _CurrentFlag
	, SYSDATETIME() AS _StartDate
	,cast ('9999-12-31' AS datetime2) as _EndDate
	,entity_start_date
	,entity_end_date
	,HASHBYTES('SHA2_256', CONCAT (
			''
			,OpportunityStateCode
			)) AS _KeyHash
	,HASHBYTES('SHA2_256', CONCAT (
			OpportunityStateName
			,'-'
			,OpportunityStateSeq
			,'-'
			,IsOpenState
			,'-'
			,IsWonState
			,'-'
			,IsLostState
			)) AS _ValueHash
   	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER

	,ROW_NUMBER() OVER (
		PARTITION BY CAST(OpportunityStateCode AS NVARCHAR) ORDER BY entity_start_date DESC
		) rn
FROM (
	SELECT DISTINCT StatusCode AS OpportunityStateCode
		,StatusDescrEn AS OpportunityStateName
		,0 AS OpportunityStateSeq
		,CASE 
			WHEN UPPER(StatusDescrEn) = 'OPEN'
				THEN 1
			ELSE 0
			END AS IsOpenState
		,CASE 
			WHEN UPPER(StatusDescrEn) = 'WON'
				THEN 1
			ELSE 0
			END AS IsWonState
		,CASE 
			WHEN UPPER(StatusDescrEn) = 'LOST'
				THEN 1
			ELSE 0
			END AS IsLostState
		,entity_start_date
		,entity_end_date
	FROM dbo.OpportunityEntity
	WHERE LineOfBusinessNameEn = 'Consulting' -- Advisory related only
		--AND StatusCode <> '803750012'
		AND StatusCode IS NOT NULL -- Exclude NULL BK
		AND entity_end_date > SYSDATETIME()
	) AS A
GO