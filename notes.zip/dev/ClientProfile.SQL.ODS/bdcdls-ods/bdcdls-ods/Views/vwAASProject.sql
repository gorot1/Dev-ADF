﻿CREATE VIEW [dbo].[vwAASProject]
AS

/*
    AAS.DimProject
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash for the same _KeyHash
        Then Update record
        Else skip record
*/
SELECT
     ProjectCode
    ,ProjectName
    ,ProjectStartDate
    ,ProjectEndDate
    ,FirstActivityDate
    ,LastActivityDate
	,CAST(1 AS BIT) AS _CurrentFlag
	,SYSDATETIME() AS _StartDate
	,CAST('9999-12-31' AS datetime2) AS _EndDate
    ,HASHBYTES('SHA2_256', ProjectCode)	AS _KeyHash
    ,HASHBYTES('SHA2_256', CONCAT(ProjectName
        ,'-', ProjectStartDate
        ,'-', ProjectEndDate
        ,'-', FirstActivityDate
        ,'-', LastActivityDate
        )) AS _ValueHash
   	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,entity_start_date
	,entity_end_date
    ,RowNum AS rn
FROM (
	SELECT
        PE.ProjectId AS ProjectCode
        ,PE.ProjectName
        ,PE.StartDate AS ProjectStartDate
        ,PE.EndDate AS ProjectEndDate
        ,PPE.FirstActivityDate AS FirstActivityDate
        ,PPE.LastActivityDate AS LastActivityDate
        ,ROW_NUMBER() OVER (PARTITION BY PE.ProjectId ORDER BY PE.entity_start_date DESC) AS RowNum
		,PE.entity_start_date
		,PE.entity_end_date
    FROM
        dbo.PsBimProjectEntity PE
		LEFT JOIN dbo.PsBimProjectPtd PPE ON PE.BusinessUnit = PPE.BusinessUnit
			AND PE.ProjectId = PPE.ProjectId
			AND PPE.entity_is_current = 1
    WHERE
		PE.entity_is_current = 1
        AND PE.ProjectId IS NOT NULL    -- Exclude NULL BK
	) AS A
WHERE RowNum = 1
GO
