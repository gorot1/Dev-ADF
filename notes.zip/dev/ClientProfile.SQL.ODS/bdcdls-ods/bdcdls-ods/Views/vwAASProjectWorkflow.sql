﻿/*
    AAS.DimProjectWorkflow
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash for the same _KeyHash
        Then Update record
        Else skip record
*/
--DECLARE @LastLoadDateTime DATETIME2 = ? -- Last successful load datetime
--DECLARE @ExtractDateTime DATETIME2 = ?  -- As of datetime, typically SYSTEMDATETIME()
CREATE VIEW [dbo].[vwAASProjectWorkflow]
AS
SELECT ProjectWorkflowCode
	,ProjectWorkflowSource
	,ProjectWorkflowDestination
	,ProjectWorkflowAction
	,CAST(1 AS BIT) AS _CurrentFlag
	,HASHBYTES('SHA2_256', ProjectWorkflowCode) AS _KeyHash
	,HASHBYTES('SHA2_256', CONCAT (
			ProjectWorkflowSource
			,'-'
			,ProjectWorkflowDestination
			,'-'
			,ProjectWorkflowAction
			)) AS _ValueHash
	,Entity_load_timestamp 
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (
		PARTITION BY ProjectWorkflowCode ORDER BY Entity_load_timestamp DESC
		) rn
FROM (
	SELECT DISTINCT CONCAT (
			UPPER(Project_Workflow_History_Source_State)
			,'-'
			,UPPER(Project_Workflow_History_Destination_State)
			,'-'
			,UPPER(Project_Workflow_History_Action)
			) AS ProjectWorkflowCode
		,Project_Workflow_History_Source_State AS ProjectWorkflowSource
		,Project_Workflow_History_Destination_State AS ProjectWorkflowDestination
		,Project_Workflow_History_Action AS ProjectWorkflowAction
		,entity_load_timestamp
	FROM dbo.IrisUaProjectWorkflowHistory
	WHERE Project_Workflow_History_Source_State IS NOT NULL -- Exclude NULL BK
	) X
GO