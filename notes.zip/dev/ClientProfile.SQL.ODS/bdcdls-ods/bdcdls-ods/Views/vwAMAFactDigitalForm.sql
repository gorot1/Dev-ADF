﻿CREATE VIEW [dbo].[vwAMAFactDigitalForm]
AS
SELECT
	ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Id
	,Landing_Page_Origin as FormName
	,FormType
	,cast(submittedAt as date) FormSubmissionDate
	,entity_modified_on
FROM
	dbo.EloquaBimFormEntity
WHERE
	entity_is_current = 1
	AND Email_Address IS NOT NULL
	AND submittedAt >= '2021-01-01'

GO