﻿CREATE VIEW [dbo].[vwAMAEmailAnalysis]
AS
SELECT DISTINCT AssetName AS EmailName
	,CampaignName AS EmailCampaign
FROM dbo.EloquaBimEmailAnalysisEntity
WHERE entity_is_current = 1