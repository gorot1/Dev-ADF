﻿CREATE VIEW [dbo].[vwAASProjectState]
AS
/*
    AAS.DimProjectState
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash for the same _KeyHash
        Then Update record
        Else skip record
*/
SELECT
     ProjectStateCode
    ,ProjectStateName   
	,CAST(1 AS BIT) AS _CurrentFlag
   	, SYSDATETIME() AS _StartDate
	,CAST ('9999-12-31' AS datetime2) as _EndDate
	,entity_start_date
	,entity_end_date
    ,HASHBYTES('SHA2_256', ProjectStateCode)	AS _KeyHash
    ,HASHBYTES('SHA2_256', ProjectStateName)    AS _ValueHash
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME() 
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (
		PARTITION BY ProjectStateCode ORDER BY Entity_start_date DESC
		) rn
FROM
(
	SELECT DISTINCT
		Project_State AS ProjectStateCode  
		,Project_State AS ProjectStateName
		,entity_start_date
		,entity_end_date
	FROM
		dbo.IrisUaProjectList
	WHERE
		Project_State IS NOT NULL 
		AND TRIM(Project_State) <> ''
) AS PS
GO