﻿CREATE VIEW [dbo].[vwAASProjectType]
AS
/*
    AAS.DimvwAASProjectType
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash for the same _KeyHash
        Then Update record
        Else skip record
*/
SELECT  
     ProjectTypeCode
    ,ProjectTypeNo
    ,ProjectTypeName
	/* Sys Columns */
	,CAST(1 AS BIT) AS _CurrentFlag
	,SYSDATETIME() AS _StartDate
	,cast ('9999-12-31' AS datetime2) as _EndDate
	,entity_start_date
	,entity_end_date
    ,HASHBYTES('SHA2_256', ProjectTypeCode)	AS _KeyHash
    ,HASHBYTES('SHA2_256', CONCAT(ProjectTypeNo, '-', ProjectTypeName)) AS _ValueHash
   	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME()
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (
		PARTITION BY ProjectTypeCode ORDER BY entity_start_date DESC
		) rn
FROM (
	



	 SELECT DISTINCT
        CONCAT(ProjectType, '-', ProjectTypeName)   AS ProjectTypeCode
        ,ProjectType        AS ProjectTypeNo
        ,ProjectTypeName    AS ProjectTypeName
		,entity_start_date
		,entity_end_date
    FROM
        dbo.PsBimProjectEntity

	WHERE ProjectType IS NOT NULL  
	AND ProjectTypeName IS NOT NULL 
	
	) AS A
GO