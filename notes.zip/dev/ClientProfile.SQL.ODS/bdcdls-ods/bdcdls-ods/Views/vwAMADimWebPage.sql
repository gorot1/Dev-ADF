﻿CREATE VIEW [dbo].[vwAMADimWebPage]
AS
SELECT ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Id, *
FROM
(
	SELECT
		HASHBYTES('SHA1', ISNULL(hostname, '') + ISNULL(pagePath, '')) WebPageHash
		,hostname
		,pagePath
		,CAST(NULL AS BINARY(20)) AS NewWebPageHash
		,entity_modified_on
	FROM dbo.GaBimPages
	WHERE entity_is_current = 1
UNION ALL
	SELECT
		HASHBYTES('SHA1', ISNULL(hostname, '') + ISNULL(landingPagePath, '')) WebPageHash
		,hostname
		,landingPagePath as pagePath
		,CAST(NULL AS BINARY(20)) AS NewWebPageHash
		,entity_event_date
	FROM dbo.GaBimGoalsEntity
	WHERE dateHourMinute >= '2021-01-01'
UNION ALL
	SELECT
		HASHBYTES('SHA1', ISNULL(hostname, '') + ISNULL(pagePath, '')) WebPageHash
		,hostname
		,pagePath
		,CAST(NULL AS BINARY(20)) AS NewWebPageHash
		,entity_event_date
	FROM dbo.GaBimEventContainer
	WHERE dateHourMinute >= '2021-01-01'
UNION ALL
	SELECT
		HASHBYTES('SHA1', ISNULL(hostname, '') + ISNULL(pagePath, '')) WebPageHash
		,hostname
		,pagePath
		,CAST(NULL AS BINARY(20)) AS NewWebPageHash
		,entity_event_date
	FROM dbo.GaBimEvents
	WHERE dateHourMinute >= '2021-01-01'
UNION ALL
	SELECT
		HASHBYTES('SHA1', ISNULL(hostname, '') + ISNULL(pagePath, '')) WebPageHash
		,hostname
		,pagePath
		,CAST(NULL AS BINARY(20)) AS NewWebPageHash
		,entity_event_date
	FROM dbo.GaBimPageViews
	WHERE dateHourMinute >= '2021-01-01'
UNION ALL
	SELECT
		HASHBYTES('SHA1', ISNULL(hostname, '') + ISNULL(pagePath, '')) WebPageHash
		,hostname
		,pagePath
		,CAST(NULL AS BINARY(20)) AS NewWebPageHash
		,entity_event_date
	FROM dbo.GaBimVisitsEntity
	WHERE dateHourMinute >= '2021-01-01'
UNION ALL
	SELECT
		HASHBYTES('SHA1', ISNULL(hostname, '') + ISNULL(landingPagePath, '')) WebPageHash
		,hostname
		,landingPagePath as pagePath
		,CAST(NULL AS BINARY(20)) AS NewWebPageHash
		,entity_event_date
	FROM dbo.GaBimVisitsEntity
	WHERE dateHourMinute >= '2021-01-01'
UNION ALL
	SELECT
		HASHBYTES('SHA1', ISNULL(page, '')) WebPageHash
		,LEFT(siteURL, 18) hostname
		,RIGHT(page, LEN(page)-18) pagePath
		,CAST(NULL AS BINARY(20)) AS NewWebPageHash
		,entity_event_date
	FROM dbo.GscBimAllSearches
	WHERE date >= '2020-01-01'
UNION ALL
	SELECT
		HASHBYTES('SHA1', 'bdc.ca'+ISNULL(NEW_relative_URL, '')) WebPageHash
		,'bdc.ca' hostname
		,NEW_relative_URL AS pagePath
		,CAST(NULL AS BINARY(20)) AS NewWebPageHash
		,entity_modified_on
	FROM dbo.BimCustomTaxonomyWebPagesEntity
	WHERE entity_is_current = 1
		AND NEW_relative_URL IS NOT NULL
UNION ALL
	SELECT
		HASHBYTES('SHA1', 'bdc.ca'+ISNULL(Page_path, '')) WebPageHash
		,'bdc.ca' hostname
		,Page_path AS pagePath
		,HASHBYTES('SHA1', 'bdc.ca'+ISNULL(NEW_relative_URL, '')) NewWebPageHash
		,entity_modified_on
	FROM dbo.BimCustomTaxonomyWebPagesEntity
	WHERE entity_is_current = 1
		AND Page_path IS NOT NULL
UNION ALL
	SELECT
		HASHBYTES('SHA1', 'bdc.ca'+ISNULL(page_en, '')) WebPageHash
		,'bdc.ca' hostname
		,page_en AS pagePath
		,CAST(NULL AS BINARY(20)) AS NewWebPageHash
		,entity_modified_on
	FROM dbo.BimCustomAcademyMatrixEntity
	WHERE entity_is_current = 1
		AND page_en IS NOT NULL
UNION ALL
	SELECT
		HASHBYTES('SHA1', 'bdc.ca'+ISNULL(page_fr, '')) WebPageHash
		,'bdc.ca' hostname
		,page_fr AS pagePath
		,CAST(NULL AS BINARY(20)) AS NewWebPageHash
		,entity_modified_on
	FROM dbo.BimCustomAcademyMatrixEntity
	WHERE entity_is_current = 1
		AND page_fr IS NOT NULL
) X
GO