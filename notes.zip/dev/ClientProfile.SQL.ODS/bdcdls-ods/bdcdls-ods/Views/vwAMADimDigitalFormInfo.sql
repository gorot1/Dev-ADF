﻿
CREATE VIEW [dbo].[vwAMADimDigitalCityMapping]
AS
SELECT ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Id, *
FROM
(
	SELECT
		cityid DigitalCityMappingKey
		,city CityName
		,region ProvinceName
		,entity_modified_on
	FROM
		dbo.GaReferenceCityMapping
UNION ALL
	SELECT
		cityid DigitalCityMappingKey
		,NULL CityName
		,NULL ProvinceName
		,entity_event_date
	FROM
		dbo.GaBimGoalsEntity
	WHERE
		dateHourMinute >= '2021-01-01'
UNION ALL
	SELECT
		cityid DigitalCityMappingKey
		,NULL CityName
		,NULL ProvinceName
		,entity_event_date
	FROM
		dbo.GaBimPageViews
	WHERE
		dateHourMinute >= '2021-01-01'
UNION ALL
	SELECT
		cityid DigitalCityMappingKey
		,NULL CityName
		,NULL ProvinceName
		,entity_event_date
	FROM
		dbo.GaBimVisitsEntity
	WHERE
		dateHourMinute >= '2021-01-01'
) X
GO