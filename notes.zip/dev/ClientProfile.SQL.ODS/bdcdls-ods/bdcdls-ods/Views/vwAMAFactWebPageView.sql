﻿CREATE VIEW [dbo].[vwAMAFactWebPageView]
AS
SELECT
	ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Id
	,entity_event_date
	,cast(replace(convert(varchar(5), dateHourMinute, 108), ':', '') as int) TimeKey
	,hostname
	,pagePath
	,source
	,medium
	,campaign
	,accountID
	,profileID
	,segment
	,deviceCategory
	,cityid
	,ISNULL(entrances, 0) PageViewEntrances
	,ISNULL(exits, 0) PageViewExits
	,ISNULL(pageviews, 0) PageViewCount
	,ISNULL(uniquePageviews, 0) PageViewUniqueCount
FROM
	dbo.GaBimPageViews
WHERE
	dateHourMinute >= '2021-01-01'
GO