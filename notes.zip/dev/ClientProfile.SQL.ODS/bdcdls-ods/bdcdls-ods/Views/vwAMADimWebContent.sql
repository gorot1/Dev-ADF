﻿CREATE VIEW [dbo].[vwAMADimWebContent] AS
WITH 
Transform_Episerver_ContentURL AS
(
    SELECT 
            inv.hostname,
			RIGHT(inv.[existingLanguages 1 link], LEN(inv.[existingLanguages 1 link])-18) urlshortpath,
		    inv.lang,
            inv.[contentLink id] contentid,
            inv.[contentType 1],
            inv.[contentType 2],
		    inv.name,
		    inv.[title value],
		    inv.[titleSEO value],
			inv.[entity_modified_on]
    FROM
    (
        --fr-CA
        SELECT 'bdc.ca' hostname,
               CASE CHARINDEX('|', [existingLanguagesLink]) WHEN 0 THEN [existingLanguagesLink] 
			        ELSE LEFT([existingLanguagesLink], CHARINDEX('|', [existingLanguagesLink])-1) 
               END [existingLanguages 1 link],
			   'fr' lang,
               id [contentLink id],
               LEFT(contentType, CHARINDEX('|', contentType)-1) [contentType 1],
               RIGHT(contentType,LEN(contentType)-(CHARINDEX('|',contentType))) [contentType 2],
			   name,
			   title [title value],
			   titleSEO [titleSEO value],
			   entity_modified_on
        FROM dbo.EpiServerPageContentEntity
        WHERE LEN([existingLanguagesLink]) > 0 AND entity_end_date > SYSDATETIME()
        -- AND [contentLink id] = 7636   	    

        UNION ALL
        --en-CA
        SELECT 'bdc.ca' hostname,
               CASE WHEN CHARINDEX('|', [existingLanguagesLink]) = 0 THEN ''
			        ELSE RIGHT([existingLanguagesLink],LEN([existingLanguagesLink])-(CHARINDEX('|',[existingLanguagesLink]))) END [existingLanguages 2 link],
			   'en' lang,
               id [contentLink id],
               LEFT(contentType, CHARINDEX('|', contentType)-1) [contentType 1],
               RIGHT(contentType,LEN(contentType)-(CHARINDEX('|',contentType))) [contentType 2],
			   name,
			   title [title value],
			   titleSEO [titleSEO value],
			   entity_modified_on
        FROM dbo.EpiServerPageContentEntity
        WHERE CHARINDEX('|', [existingLanguagesLink]) > 0 AND entity_end_date > SYSDATETIME()
    ) inv
)
,Transform_Episerver_PageToMetadata AS
(
	SELECT
		cl.element AS MetadataId
		,cl.elementType AS MetadataType
		,cl.target AS MetadataTarget
		,cl.parentId AS PageId
		,cl.path AS Path
		,c.contentType AS ContentType
		,c.analyticsValue AS ContentName
	FROM
		dbo.EpiServerContentListEntity cl
		LEFT OUTER JOIN dbo.EpiServerCategoriesEntity c ON cl.element = CAST(c.id AS NVARCHAR)
			AND c.entity_is_current = 1
	WHERE
		cl.parentType = 'Page'
		AND cl.elementType = 'category'
		AND cl.target = 'categories'
)
,Transform_Episerver_ContentToCategoryLevel AS
(
	SELECT 
		md.hostname
		,md.contentid
		,MAX(ISNULL(md.category_level1,'-')) category_level1
		,MAX(ISNULL(md.category_level2,'-')) category_level2
		,MAX(ISNULL(md.category_level3,'-')) category_level3
		,MAX(ISNULL(md.category_level4,'-')) category_level4
		,MAX(ISNULL(md.category_level5,'-')) category_level5
	FROM
	(
		SELECT DISTINCT
			cu.hostname
			,cu.urlshortpath
			,cu.lang
			,cu.contentid
			,cu.[contentType 1]
			,cu.[contentType 2]
			,cu.name
			,CASE SiteSection.ContentName
				WHEN 'articles-tools' THEN 'content'
				WHEN 'financing' THEN 'solutions'
				WHEN 'bdc-capital' THEN 'solutions'
				WHEN 'advisory-services' THEN 'solutions'
				ELSE SiteSection.ContentName
				END category_level1
			,CASE
				WHEN SiteSection.ContentName IN ( 'financing', 'bdc-capital', 'advisory-services', 'articles-tools' ) THEN SiteSection.ContentName
				WHEN SiteSection.ContentName = 'industries' AND Metadata.ContentType = 'IndustryName' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = 'microsite' AND Metadata.ContentType = 'MicrositeName' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = 'careers' AND Metadata.ContentType = 'CareerCategory' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = 'i-am' AND Metadata.ContentType = 'IamCategory' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = 'testimonials' AND Metadata.ContentType = 'solutionlob' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = 'about' AND Metadata.ContentType = 'AboutCategory' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = '' THEN ''
				ELSE NULL
				END category_level2
			,CASE
				WHEN SiteSection.ContentName = 'financing' AND Metadata.ContentType = 'LoanFormat' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = 'bdc-capital' AND Metadata.ContentType = 'CapitalType' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = 'advisory-services' AND Metadata.ContentType = 'AdviceObjective' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = 'articles-tools' AND SectionType.ContentName = '_none_' THEN '_none_'
				WHEN SectionType.ContentName = 'articles' AND Metadata.ContentType = 'TopicCategory' THEN Metadata.ContentName
				WHEN SectionType.ContentName IN ( 'blog', 'entrepreneur-toolkit' ) THEN SectionType.ContentName
				WHEN SiteSection.ContentName = 'industries' AND Metadata.ContentType = 'solutionlob' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = 'microsite'  THEN SectionType.ContentName
				WHEN SiteSection.ContentName = 'careers'  THEN '_none_'
				WHEN SiteSection.ContentName = 'i-am' AND Metadata.ContentType = 'solutionlob' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = 'testimonials' AND Metadata.ContentType = 'SolutionName' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = 'about' AND Metadata.ContentType = 'AboutSubcategory' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = '' THEN ''
				ELSE NULL
				END category_level3
			,CASE
				WHEN SiteSection.ContentName = 'financing' AND Metadata.ContentType = 'LoanPurpose' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = 'bdc-capital'  THEN SectionType.ContentName
				WHEN SiteSection.ContentName = 'advisory-services' AND Metadata.ContentType = 'AdviceSubject' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = 'articles-tools' AND SectionType.ContentName = '_none_' THEN '_none_'
				WHEN SectionType.ContentName = 'articles' AND Metadata.ContentType = 'SubtopicCategory' THEN Metadata.ContentName
				WHEN SectionType.ContentName = 'blog' AND Metadata.ContentType = 'BlogCategory' THEN Metadata.ContentName
				WHEN SectionType.ContentName = 'entrepreneur-toolkit' AND Metadata.ContentType = 'ToolkitCategory' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = 'industries' AND Metadata.ContentType = 'SolutionName' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = 'microsite' AND Metadata.ContentType = 'PageTypeCategory' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = 'careers' THEN '_none_'
				WHEN SiteSection.ContentName = 'i-am' AND Metadata.ContentType = 'SolutionName' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = 'testimonials' AND Metadata.ContentType = 'IndustryName' THEN Metadata.ContentName
				WHEN SiteSection.ContentName = 'about' THEN SectionType.ContentName
				WHEN SiteSection.ContentName = '' THEN ''
				ELSE NULL
				END category_level4
			,CASE
				WHEN SiteSection.ContentName = 'financing' AND Metadata.ContentType = 'LoanAmount' THEN MetaData.ContentName
				WHEN SiteSection.ContentName = 'bdc-capital' AND Metadata.ContentType = 'ContentTypeCategory' THEN MetaData.ContentName
				WHEN SiteSection.ContentName = 'advisory-services' AND Metadata.ContentType = 'ContentTypeCategory'  THEN MetaData.ContentName
				WHEN SiteSection.ContentName = 'articles-tools' AND SectionType.ContentName = '_none_' THEN '_none_'
				WHEN SectionType.ContentName = 'articles' AND Metadata.ContentType = 'ChallengeCategory' THEN MetaData.ContentName
				WHEN SectionType.ContentName = 'blog'  THEN ''
				WHEN SectionType.ContentName = 'entrepreneur-toolkit' AND Metadata.ContentType = 'ContentTypeCategory' THEN MetaData.ContentName
				WHEN SiteSection.ContentName = 'industries' AND Metadata.ContentType = 'ContentTypeCategory' THEN MetaData.ContentName
				WHEN SiteSection.ContentName = 'microsite' AND Metadata.ContentType = 'ContentTypeCategory' THEN MetaData.ContentName
				WHEN SiteSection.ContentName = 'careers' THEN '_none_'
				WHEN SiteSection.ContentName = 'i-am'  AND Metadata.ContentType = 'ContentTypeCategory' THEN MetaData.ContentName
				WHEN SiteSection.ContentName = 'testimonials' AND Metadata.ContentType = 'Province' THEN MetaData.ContentName
				WHEN SiteSection.ContentName = 'about' AND Metadata.ContentType = 'ContentTypeCategory' THEN MetaData.ContentName
				WHEN SiteSection.ContentName = '' THEN ''
				ELSE NULL
				END category_level5
		FROM Transform_Episerver_ContentURL cu
			LEFT JOIN Transform_Episerver_PageToMetadata Metadata ON cu.contentid = Metadata.PageId
			LEFT JOIN Transform_Episerver_PageToMetadata SiteSection ON cu.contentid = SiteSection.PageId AND SiteSection.ContentType = 'SiteSectionCategory'
			LEFT JOIN Transform_Episerver_PageToMetadata SectionType ON cu.contentid = SectionType.Pageid AND SectionType.ContentType = 'SectionTypeCategory'
	) md
	GROUP BY
		md.hostname
		,md.contentid

)
,Academy_Matrix AS
(
	SELECT DISTINCT 
		'AcademyMatrix' contentVersion,
		'bdc.ca' hostname,
		page_en page,
		CASE WHEN CHARINDEX('~', Type) > 0 THEN LEFT(Type, CHARINDEX('~', Type) - 1) ELSE Type END Type,
		Hub,
		NULL name,
		Titre_en Title,
		NULL TitleSEO,
		Level1,
		Level2,
		Level3,
		Level4,
		Level5,
		Gated is_gated,
		NULL is_covid19,
		row_number() over (Partition by [page_en]  order by [page_en] asc) as duplicateRecCount
	FROM dbo.BimCustomAcademyMatrixEntity
	where entity_end_date > SYSDATETIME()
	UNION
	SELECT DISTINCT 
		'AcademyMatrix' contentVersion,
		'bdc.ca' hostname,
		page_fr page,
		CASE WHEN CHARINDEX('~', Type) > 0 THEN LEFT(Type, CHARINDEX('~', Type) - 1) ELSE Type END Type,
		Hub,
		NULL name,
		Titre_fr Title,
		NULL TitleSEO,
		Level1,
		Level2,
		Level3,
		Level4,
		Level5,
		Gated is_gated,
		NULL is_covid19,
		row_number() over (Partition by [page_fr]  order by [page_fr] asc) as duplicateRecCount
	FROM dbo.BimCustomAcademyMatrixEntity
	where entity_end_date > SYSDATETIME()
)
SELECT DISTINCT
	'EpiServer' contentVersion
	,cu.hostname
	,cu.urlshortpath
	,cu.[contentType 1]
	--,cu.[contentType 2]
	,cu.name
	,cu.[title value]
	,cu.[titleSEO value]
	,ccl.category_level1
	,ccl.category_level2
	,ccl.category_level3
	,ccl.category_level4
	,ccl.category_level5
	,NULL is_gated
	,NULL is_covid19
	--,cu.lang
	--,cu.contentid
FROM Transform_Episerver_ContentURL cu
	LEFT JOIN Transform_Episerver_ContentToCategoryLevel ccl ON ccl.hostname = cu.hostname AND ccl.contentid = cu.contentid
UNION
SELECT DISTINCT 
	'TaxonomyWebPages' contentVersion,
	'bdc.ca' hostname,
	Page_path,
	A_Content_Type,
	A_Name,
	Title,
	TitleSEO,
	category_level_1,
	category_level_2,
	category_level_3,
	category_level_4,
	category_level_5,
	is_gated,
	is_covid19
FROM dbo.BimCustomTaxonomyWebPagesEntity
WHERE entity_end_date > SYSDATETIME()
UNION
SELECT DISTINCT 
	contentVersion,
	hostname,
	page,
	Type,
	name,
	Title,
	TitleSEO,
	Level1,
	Level2,
	Level3,
	Level4,
	Level5,
	is_gated,
	is_covid19
FROM Academy_Matrix
WHERE ([Type] NOT LIKE 'Challenge' OR [Hub] LIKE 'Hub') AND duplicateRecCount<2
GO