﻿CREATE VIEW [dbo].[vwAMAFactWebSearch]
AS
SELECT
	ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Id
	,entity_event_date
	,searchType SearchType
	,page AS pageFullPath
	,LOWER(device) AS DeviceCategoryName
	,country SearchCountry
	,query SearchQuery
	,clicks SearchClickCount
	,ctr SearchClickthroughRate
	,impressions SearchImpressionCount
	,position SearchPosition
FROM
	dbo.GscBimAllSearches
WHERE
	date >= '2021-01-01'
GO