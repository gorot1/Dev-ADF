﻿/*
    **************************************************************************
    AAS.FactCustomerActivity
    This script returns rows effective at @ExtractDateTime.
    **************************************************************************
    If _KeyHash does not exist Then Insert record
    If _ValueHash differs from _ValueHash of previous record for the same _KeyHash
        Then set _EndDate of previous record, and Insert new record
        Else skip record
    If lookup on Dim table returns no match, assign N/A.
*/

CREATE VIEW [dbo].[vwAASFactCustomerActivity]
AS
WITH ConsultingAccounts
AS (
	SELECT DISTINCT OE.AccountId
	FROM dbo.OpportunityEntity OE
	WHERE OE.entity_end_date > SYSDATETIME()
		AND OE.LineOfBusinessNameEn = 'Consulting'
	)
    SELECT
      
	 ISNULL(cast (AAE.ActivityId as varchar),'N/A')             AS FactCustomerActivityKey
    ,ISNULL(cast (APE.CRMAccount_CRMId as varchar),'N/A')       AS CustomerCode
 	,ISNULL(cast (AAE.ActivityTypeCode as varchar) ,'N/A') AS ActivityTypeCode
    ,ISNULL(cast (EE.EmployeePIN as varchar) ,'N/A')            AS OwnerEmployeePIN
    ,ISNULL(RIGHT(CONCAT('0000', EE.DepartmentCode), 4),'N/A')         AS BranchCode	-- Pad to 4 digits with 0 prefix for join with DimRegionBranch.BranchCode.
    ,ISNULL(CAST(FORMAT(cast(AAE.ScheduledStartDate as datetimeoffset) at time zone 'Eastern Standard Time', 'yyyyMMdd') AS INT),-1)   AS ScheduledStartDateId
    ,ISNULL(CAST(FORMAT(cast(AAE.ScheduledEndDate as datetimeoffset) at time zone 'Eastern Standard Time', 'yyyyMMdd') AS INT),-1)       AS ScheduledEndDateId
    ,ISNULL(CAST(FORMAT(cast(AAE.ActualStartDate as datetimeoffset) at time zone 'Eastern Standard Time', 'yyyyMMdd') AS INT),-1)        AS ActualStartDateId
    ,ISNULL(CAST(FORMAT(cast(AAE.ActualEndDate as datetimeoffset) at time zone 'Eastern Standard Time', 'yyyyMMdd') AS INT) ,-1)        AS ActualEndDateId
	/* Sys Columns */
	, SYSDATETIME() AS _StartDate
	,cast ('9999-12-31' as datetime2) AS _EndDate
    ,HASHBYTES('SHA2_256', AAE.ActivityId)      AS _KeyHash
    ,HASHBYTES('SHA2_256', CONCAT(APE.CRMAccount_CRMId
        ,'-' , AAE.ActivityTypeCode
        ,'-' , EE.EmployeePIN
        ,'-' , RIGHT(CONCAT('0000', EE.DepartmentCode), 4)
        ,'-' , FORMAT(cast(AAE.ScheduledStartDate as datetimeoffset) at time zone 'Eastern Standard Time', 'yyyyMMdd')
        ,'-' , FORMAT(cast(AAE.ScheduledEndDate as datetimeoffset) at time zone 'Eastern Standard Time', 'yyyyMMdd')
        ,'-' , FORMAT(cast(AAE.ActualStartDate as datetimeoffset) at time zone 'Eastern Standard Time', 'yyyyMMdd')
        ,'-' , FORMAT(cast(AAE.ActualEndDate as datetimeoffset) at time zone 'Eastern Standard Time', 'yyyyMMdd')))  AS _ValueHash
	,_InsertDate = SYSDATETIME()
	,_InsertBy = SYSTEM_USER
	,_UpdateDate = SYSDATETIME() 
	,_UpdateBy = SYSTEM_USER
	,ROW_NUMBER() OVER (PARTITION BY ISNULL(cast (AAE.ActivityId as varchar),'N/A') ORDER BY AAE.entity_start_date DESC) rn
	,AAE.entity_start_date
	,AAE.entity_end_date
	

  FROM
    dbo.AccountActivity AAE
    Left JOIN dbo.AccountProfileEntity APE ON AAE.CRM_AccountId = APE.AccountId
        AND APE.entity_end_date > SYSDATETIME()
    left JOIN dbo.Employee EE ON AAE.CRM_OwnerSystemUserId = EE.CRM_SystemUserId
        AND EE.entity_end_date > SYSDATETIME()
  WHERE
     AAE.entity_end_date >= SYSDATETIME()
	 AND EE.LineOfBusinessName = 'Consulting'
	 AND EXISTS (
		SELECT 1
		FROM ConsultingAccounts CA
		WHERE CA.AccountId = AAE.CRM_AccountId
		)
GO


