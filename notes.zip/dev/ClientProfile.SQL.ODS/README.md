# Introduction 
This repo contains the tables for the ODS database.

# Way of working for ODS Entities
1. Call `SqlExportJob.toCreateTableDDL(<targetTable>)(spark)` from Databricks to retrieve the Sql Server DDL.
2. Paste the script in a new **Table** in the SQL project
3. Don't forget to add the DDL reference to the [.sqlproj file](bdcdls-ods/bdcdls-ods/bdcdls-ods.sqlproj)

# Build and Test
Local build: Right click on solution > Build/Rebuild to ensure SQL code is correct.

# DevOps
## PRs
PRs to the dev branch trigger a build which generates a DacPac, a [DeployReport](https://docs.microsoft.com/en-us/azure/devops/pipelines/targets/azure-sqldb?view=azure-devops&tabs=yaml#deployreport) and a [Incremental Update Script](ClientProfile.SQL.ODS\bdcdls-ods\bdcdls-ods\bdcdls-ods.sqlproj) of trying to deploy that DacPac to the dev DB (which should be up to date with the dev branch). The pipeline will raise a warning if there are destructive changes.

## Dev Branch
All changes to the dev branch trigger the pipeline, which builds the DacPac and deploys it to the dev DB

[] TODO: Figure out how to handle destructive changes.

# Contribute
TODO: Explain how other users and developers can contribute to make your code better. 

If you want to learn more about creating good readme files then refer the following [guidelines](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)