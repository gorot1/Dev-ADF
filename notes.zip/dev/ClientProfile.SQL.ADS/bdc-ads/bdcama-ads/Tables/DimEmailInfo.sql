﻿CREATE TABLE [dbo].[DimEmailInfo]
(
	[DimEmailInfoId]	int				NOT NULL IDENTITY(1,1),
	[DimEmailInfoKey]	varchar(310)	NOT NULL,
	[EmailName]			varchar(200)	NULL,
	[EmailCampaign]		varchar(100)	NULL,
	[_KeyHash]			binary(32)		NOT NULL,
	[_ValueHash]		binary(32)		NOT NULL,
	[_InsertedDate]		datetime2		NOT NULL CONSTRAINT DF_DimEmailInfo_InsertedDate	DEFAULT SYSDATETIME(),
	[_InsertedBy]		varchar(128)	NOT NULL CONSTRAINT DF_DimEmailInfo_InsertedBy		DEFAULT SUSER_SNAME(),
	[_UpdatedDate]		datetime2		NOT NULL CONSTRAINT DF_DimEmailInfo_UpdatedDate		DEFAULT SYSDATETIME(),
	[_UpdatedBy]		varchar(128)	NOT NULL CONSTRAINT DF_DimEmailInfo_UpdatedBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_DimEmailInfo]		PRIMARY KEY CLUSTERED ([DimEmailInfoId] ASC),
	CONSTRAINT [UX_DimEmailInfo]		UNIQUE ([DimEmailInfoKey] ASC)
)
WITH (DATA_COMPRESSION = ROW)
GO

CREATE NONCLUSTERED INDEX [IX_DimEmailInfo_Hash] ON [dbo].[DimEmailInfo]
( 
	[_KeyHash] ASC
)
INCLUDE( [_ValueHash] )
GO
