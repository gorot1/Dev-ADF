﻿CREATE TABLE [dbo].[FactEmailSent]
(
	[FactEmailSentId]							int				NOT NULL IDENTITY(1,1),
	[FactEmailSentKey]							varchar(350)	NOT NULL,
	[EmailDateId]								int				NOT NULL,
	[EmailInfoId]								int				NOT NULL,
	[EmailSentCount]							int				NOT NULL,
	[EmailClickthroughCount]					int				NOT NULL,
	[EmailUniqueClickthroughCount]				int				NOT NULL,
	[EmailExistingVisitorClickthroughCount]		int				NOT NULL,
	[EmailNewVisitorClickthroughCount]			int				NOT NULL,
	[EmailOpenCount]							int				NOT NULL,
	[EmailUniqueOpenCount]						int				NOT NULL,
	[EmailBouncebackCount]						int				NOT NULL,
	[EmailHardBouncebackCount]					int				NOT NULL,
	[EmailSoftBouncebackCount]					int				NOT NULL,
	[EmailFormSubmissionCount]					int				NOT NULL,
	[EmailUniqueFormSubmissionCount]			int				NOT NULL,
	[EmailUnsubscribedCount]					int				NOT NULL,
	[EmailDeliveredCount]						int				NOT NULL,
	[_KeyHash]			binary(32)		NOT NULL,
	[_ValueHash]		binary(32)		NOT NULL,
	[_InsertedDate]		datetime2		NOT NULL CONSTRAINT DF_FactEmailSent_InsertedDate	DEFAULT SYSDATETIME(),
	[_InsertedBy]		varchar(128)	NOT NULL CONSTRAINT DF_FactEmailSent_InsertedBy		DEFAULT SUSER_SNAME(),
	[_UpdatedDate]		datetime2		NOT NULL CONSTRAINT DF_FactEmailSent_UpdatedDate	DEFAULT SYSDATETIME(),
	[_UpdatedBy]		varchar(128)	NOT NULL CONSTRAINT DF_FactEmailSent_UpdatedBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_FactEmailSent]				PRIMARY KEY CLUSTERED ([FactEmailSentId] ASC),
	CONSTRAINT [UX_FactEmailSent_Key]			UNIQUE ([FactEmailSentKey]  ASC),
	CONSTRAINT [FK_FactEmailSent_DimEmailInfo]	FOREIGN KEY ([EmailInfoId]) REFERENCES [dbo].[DimEmailInfo]([DimEmailInfoId]),
)
WITH (DATA_COMPRESSION = PAGE)
GO

CREATE NONCLUSTERED INDEX [IX_FactEmailSent_Hash] ON [dbo].[FactEmailSent]
( 
	[_KeyHash] ASC
)
INCLUDE( [_ValueHash] )
GO

CREATE NONCLUSTERED INDEX [IX_FactEmailSent_Date] ON [dbo].[FactEmailSent]
( 
	[EmailDateId] ASC
)
INCLUDE( [EmailInfoId] )
GO
