﻿-- =============================================
-- Author:      David Sun
-- Create Date: 2021-01-19
-- Description: Table script for AdsWatermarks
-- =============================================
CREATE TABLE [dbo].[AdsWatermarksBIM](
	[LOB] [varchar](255) NULL,
	[TargetSystem] [varchar](255) NULL DEFAULT 'ADS Azure SQL Database',
	[TargetTableName] [varchar](255) NOT NULL,
	[TargetTableType] [varchar](20) NULL,
	[SourceSystem] [varchar](255) NULL DEFAULT 'ODS Azure SQL Database',
	[SourceTableName] [varchar](255) NULL,
	[SourceWatermarkColumn] [varchar](255) NULL,
	[SourceWatermarkValue] [varchar](30) NULL,
	[SourceColumns] [varchar](6000) NULL,  -- [SourceColumns]: columns of the source table needed to be copied (except [SourceWatermarkColumn])
	[SourceFilter] [varchar](6000) NULL,  -- Where clause
	[RawSourceSystem] [varchar](255) NULL,
	[Enabled] [bit] NULL, -- 1: enabled, 0: disabled 
	[LoadType] [varchar](20) NULL,
	[LoadSequence] [integer] NULL,
	[Status] [varchar](20) NULL,
	[Comment] [varchar](255) NULL,
	[InsertedDate]		[datetime]	NULL,
	[InsertedBy]		[varchar](50) NULL,
	[ModifiedDate]		[datetime]	NULL,
	[ModifiedBy]		[varchar](50)	NULL
) ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX [IX_AdsWatermarksBIM] ON [dbo].[AdsWatermarksBIM]
(
	[TargetTableName] ASC, [SourceTableName] ASC, [SourceColumns] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO
