CREATE TABLE [dbo].[DimDigitalChannel]
( 
	[DigitalChannelKey]		int  NOT NULL IDENTITY(1,1),
	[DigitalChannelHash]			binary(20) NOT NULL,
	[DigitalChannelGroupKey]		int  NOT NULL ,
	[ChannelSource]		nvarchar(500)  NULL ,
	[ChannelMedium]		nvarchar(100)  NULL ,
	[ChannelCampaign]		nvarchar(max)  NULL ,
	[ChannelIsBranded]		nvarchar(200)  NULL ,
	[ChannelBusinessLine]		nvarchar(200)  NULL ,
	[ChannelProductType]		nvarchar(200)  NULL ,
	[ChannelTargetAudience]		nvarchar(200)  NULL ,
	[ChannelReferringSite]		nvarchar(200)  NULL ,
	[ChannelEmailGroup]		nvarchar(200)  NULL ,
	[ChannelLeadNurturingGroup]		nvarchar(200)  NULL ,
	[ChannelLeadNurturingStage]		nvarchar(200)  NULL ,
	[ChannelMeledition]		nvarchar(200)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[DimDigitalChannel]
       ADD CONSTRAINT [XPKDimDigitalChannel] PRIMARY KEY  CLUSTERED ([DigitalChannelKey] ASC)
go

CREATE UNIQUE INDEX [XAK1DimDigitalChannel]
ON [dbo].[DimDigitalChannel]([DigitalChannelHash]) INCLUDE ([DigitalChannelKey])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go



CREATE TABLE [dbo].[DimDigitalChannelGroup]
( 
	[DigitalChannelGroupKey]		int  NOT NULL IDENTITY(1,1),
	[ChannelGroupName]		nvarchar(200)  NOT NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[DimDigitalChannelGroup]
       ADD CONSTRAINT [XPKDimDigitalChannelGroup] PRIMARY KEY  CLUSTERED ([DigitalChannelGroupKey] ASC)
go

CREATE UNIQUE INDEX [XAK1DimDigitalChannelGroup]
ON [dbo].[DimDigitalChannelGroup]([ChannelGroupName]) INCLUDE ([DigitalChannelGroupKey])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go



CREATE TABLE [dbo].[DimDigitalDeviceCategory]
( 
	[DigitalDeviceCategoryKey]		int  NOT NULL IDENTITY(1,1),
	[DeviceCategoryName]		nvarchar(200)  NOT NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[DimDigitalDeviceCategory]
       ADD CONSTRAINT [XPKDimDigitalDeviceCategory] PRIMARY KEY  CLUSTERED ([DigitalDeviceCategoryKey] ASC)
go

CREATE UNIQUE INDEX [XAK1DimDigitalDeviceCategory]
ON [dbo].[DimDigitalDeviceCategory]([DeviceCategoryName]) INCLUDE ([DigitalDeviceCategoryKey])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go


CREATE TABLE [dbo].[DimDigitalTouchpointGroup]
( 
	[DigitalTouchpointGroupKey]		int  NOT NULL IDENTITY(1,1),
	[TouchpointSourceTableName]		nvarchar(200)  NOT NULL ,
	[TouchpointGroupName]		nvarchar(200)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[DimDigitalTouchpointGroup]
       ADD CONSTRAINT [XPKDimDigitalTouchpointGroup] PRIMARY KEY  CLUSTERED ([DigitalTouchpointGroupKey] ASC)
go

CREATE UNIQUE INDEX [XAK1DimDigitalTouchpointGroup]
ON [dbo].[DimDigitalTouchpointGroup]([TouchpointSourceTableName]) INCLUDE ([DigitalTouchpointGroupKey])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go



CREATE TABLE [dbo].[DimDigitalTouchpointMetadata]
( 
	[DigitalTouchpointMetadataKey]		int  NOT NULL IDENTITY(1,1),
	[DigitalTouchpointMetadataHash] binary(20) NOT NULL,
	[DigitalChannelKey]		int  NOT NULL ,
	[TouchpointAccountId]		int  NULL ,
	[TouchpointProfileId]		int  NULL ,
	[TouchpointSegment]		varchar(max)  NULL ,
	[DigitalDeviceCategoryKey]		int  NOT NULL ,
	[TouchpointCityId]		int  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[DimDigitalTouchpointMetadata]
       ADD CONSTRAINT [XPKDimDigitalTouchpointMetadata] PRIMARY KEY  CLUSTERED ([DigitalTouchpointMetadataKey] ASC)
go

CREATE UNIQUE INDEX [XAK1DimDigitalTouchpointMetadata]
ON [dbo].[DimDigitalTouchpointMetadata]([DigitalTouchpointMetadataHash]) INCLUDE ([DigitalTouchpointMetadataKey])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go


CREATE TABLE [dbo].[DimDigitalTouchpointMetrics]
( 
	[DigitalTouchpointMetricKey]		int  NOT NULL IDENTITY(1,1),
	[MetricName1]		nvarchar(200)  NOT NULL ,
	[MetricName2]		nvarchar(200)  NULL ,
	[MetricName3]		nvarchar(200)  NULL ,
	[MetricName4]		nvarchar(200)  NULL ,
	[MetricName5]		nvarchar(200)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[DimDigitalTouchpointMetrics]
       ADD CONSTRAINT [XPKDimDigitalTouchpointMetrics] PRIMARY KEY  CLUSTERED ([DigitalTouchpointMetricKey] ASC)
go

CREATE UNIQUE INDEX [XAK1DimDigitalTouchpointMetrics]
ON [dbo].[DimDigitalTouchpointMetrics]([MetricName1]) INCLUDE ([DigitalTouchpointMetricKey])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go

CREATE TABLE [dbo].[DimWebAdInfo]
( 
	[WebAdInfoKey]		int  NOT NULL IDENTITY(1,1),
	[WebAdInfoHash] binary(20) NOT NULL,
	[AdContent]		nvarchar(max)  NULL ,
	[AdKeyword]		nvarchar(max)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[DimWebAdInfo]
       ADD CONSTRAINT [XPKDimWebAdInfo] PRIMARY KEY  CLUSTERED ([WebAdInfoKey] ASC)
go

CREATE TABLE [dbo].[DimWebContent]
( 
	[WebContentKey]			int  NOT NULL IDENTITY(1,1),
	[ContentDateKey]		int  NULL,
	[ContentTimeKey]		int  NULL ,
	[ContentPageKey]		int  NULL ,
	[ContentGroupName]		nvarchar(1000)  NULL ,
	[ContentTaxonomyVersionName]		nvarchar(1000)  NULL ,
	[ContentName]		nvarchar(1000)  NULL ,
	[ContentTitle]		nvarchar(1000)  NULL ,
	[ContentSEOTitle]		nvarchar(1000)  NULL ,
	[ContentTypeName]		nvarchar(1000)  NULL ,
	[ContentLevel1Name]		nvarchar(1000)  NULL ,
	[ContentLevel2Name]		nvarchar(1000)  NULL ,
	[ContentLevel3Name]		nvarchar(1000)  NULL ,
	[ContentLevel4Name]		nvarchar(1000)  NULL ,
	[ContentLevel5Name]		nvarchar(1000)  NULL ,
	[ContentIsGated]		bit  NULL ,
	[ContentIsCovid19]		bit  NULL ,
	[ContentIsSMEResearch]	bit  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL
)
go

ALTER TABLE [dbo].[DimWebContent]
       ADD CONSTRAINT [XPKDimWebContent] PRIMARY KEY  CLUSTERED ([WebContentKey] ASC)
go

CREATE UNIQUE INDEX [XAK1DimWebContent]
ON [dbo].[DimWebContent]([ContentDateKey], [ContentTimeKey], [ContentPageKey]) INCLUDE ([WebContentKey])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go


CREATE TABLE [dbo].[DimWebPage]
( 
	[WebPageKey]		int  NOT NULL IDENTITY(1,1),
	[WebPageHash]		binary(20) NOT NULL,
	[PageFullPath]		nvarchar(max)  NULL ,
	[PageDomain]		nvarchar(max)  NULL ,
	[PageRelativePathWithoutParameters]		nvarchar(max)  NULL ,
	[PageParameters]	nvarchar(max)  NULL ,
	[PageLevel1]		nvarchar(max)  NULL ,
	[PageLevel2]		nvarchar(max)  NULL ,
	[PageLevel3]		nvarchar(max)  NULL ,
	[PageLevel4]		nvarchar(max)  NULL ,
	[PageLevel5]		nvarchar(max)  NULL ,
	[PageIsNew]			bit NULL,
	[PageMappingKey]	int NULL,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL
)
go

ALTER TABLE [dbo].[DimWebPage]
       ADD CONSTRAINT [XPKDimWebPage] PRIMARY KEY  CLUSTERED ([WebPageKey] ASC)
go

CREATE TABLE [dbo].[DimWebPageEventInfo]
( 
	[WebPageEventInfoKey]		int  NOT NULL IDENTITY(1,1),
	[WebPageEventInfoHash]	binary(20) NOT NULL,
	[EventEntityType]		varchar(20) NOT NULL,
	[EventCategory]		nvarchar(max)  NULL ,
	[EventAction]		nvarchar(max)  NULL ,
	[EventLabel]		nvarchar(max)  NULL ,
	[EventContainer]	nvarchar(max) NULL,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL
)
go


ALTER TABLE [dbo].[DimWebPageEventInfo]
       ADD CONSTRAINT [XPKDimWebPageEventInfo] PRIMARY KEY  CLUSTERED ([WebPageEventInfoKey] ASC)
go

CREATE UNIQUE INDEX [XAK1DimWebPageEventInfo]
ON [dbo].[DimWebPageEventInfo]([WebPageEventInfoHash]) INCLUDE ([WebPageEventInfoKey])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go


CREATE TABLE [dbo].[DimWebPageParameterGroup]
( 
	[WebPageParameterGroupKey]		int  NOT NULL IDENTITY(1,1),
	[PageParametersGroupName]		nvarchar(200)  NOT NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[DimWebPageParameterGroup]
       ADD CONSTRAINT [XPKDimWebPageParameterGroup] PRIMARY KEY  CLUSTERED ([WebPageParameterGroupKey] ASC)
go

CREATE UNIQUE INDEX [XAK1DimWebPageParameterGroup]
ON [dbo].[DimWebPageParameterGroup]([PageParametersGroupName]) INCLUDE ([WebPageParameterGroupKey])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go


CREATE TABLE [dbo].[DimDigitalProvinceMapping]
( 
	[DigitalProvinceMappingKey]		int  NOT NULL IDENTITY(1,1),
	[ProvinceNameEn]	nvarchar(100)  NULL ,
	[ProvinceCode]		nvarchar(10)  NULL,
	[FSAProvince]		int  NULL ,
	[RegionBDCEn]		nvarchar(100)  NULL,
	[ProvinceNameFr]	nvarchar(100)  NULL ,
	[RegionBDCFr]		nvarchar(100)  NULL,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[DimDigitalProvinceMapping]
       ADD CONSTRAINT [XPKDimDigitalProvinceMapping] PRIMARY KEY  CLUSTERED ([DigitalProvinceMappingKey] ASC)
go

CREATE UNIQUE INDEX [XAK1DimDigitalProvinceMapping]
ON [dbo].[DimDigitalProvinceMapping]([ProvinceNameEn]) INCLUDE ([DigitalProvinceMappingKey])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go


CREATE TABLE [dbo].[DimDigitalCityMapping]
( 
	[DigitalCityMappingKey]		int  NOT NULL,
	[CityName]			nvarchar(max)  NULL ,
	[ProvinceId]		int  NULL,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[DimDigitalCityMapping]
       ADD CONSTRAINT [XPKDimDigitalCityMapping] PRIMARY KEY  CLUSTERED ([DigitalCityMappingKey] ASC)
go


CREATE TABLE [dbo].[FactDigitalTouchpoint]
( 
	[DigitalTouchpointKey]		int  NOT NULL IDENTITY(1,1),
	[TouchpointDateKey]		int  NOT NULL ,
	[TouchpointTimeKey]		int  NULL,
	[DigitalTouchpointGroupKey]		int  NULL ,
	[TouchpointRowKey]		int  NULL ,
	[DigitalTouchpointMetricKey]		int  NULL ,
	[DigitalTouchpointMetadataKey]		int  NULL ,
	[MetricValue1]		nvarchar(200)  NULL ,
	[MetricValue2]		nvarchar(200)  NULL ,
	[MetricValue3]		nvarchar(200)  NULL ,
	[MetricValue4]		nvarchar(200)  NULL ,
	[MetricValue5]		nvarchar(200)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[FactDigitalTouchpoint]
       ADD CONSTRAINT [XPKFactDigitalTouchpoint] PRIMARY KEY  CLUSTERED ([DigitalTouchpointKey] ASC)
go

CREATE UNIQUE INDEX [XAK1FactDigitalTouchpoint]
ON [dbo].[FactDigitalTouchpoint]([DigitalTouchpointGroupKey], [TouchpointRowKey])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go


CREATE TABLE [dbo].[FactWebAd]
( 
	[WebAdKey]		int  NOT NULL IDENTITY(1,1),
	[AdDateKey]		int  NOT NULL ,
	[WebAdInfoKey]		int  NULL ,
	[DigitalTouchpointMetadataKey]		int  NULL ,
	[AdCost]		decimal(18,2)  NULL ,
	[AdClickCount]		bigint  NULL ,
	[AdImpressionCount]		bigint  NULL ,
	[AdSecondsOnPage]		decimal(18,2)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[FactWebAd]
       ADD CONSTRAINT [XPKFactWebAd] PRIMARY KEY  CLUSTERED ([WebAdKey] ASC)
go

CREATE UNIQUE INDEX [XAK1FactWebAd]
ON [dbo].[FactWebAd]([AdDateKey], [WebAdInfoKey], [DigitalTouchpointMetadataKey])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go



CREATE TABLE [dbo].[FactWebGoal]
( 
	[WebGoalKey]		int  NOT NULL IDENTITY(1,1),
	[WebGoalDateKey]	int  NOT NULL ,
	[WebGoalTimeKey]	int NOT NULL,
	[WebPageKey]		int  NULL ,
	[DigitalTouchpointMetadataKey]		int  NULL ,
	[GoalNumber]		int  NULL ,
	[GoalStartsValue]		bigint  NULL ,
	[GoalCompletionsValue]		bigint  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[FactWebGoal]
       ADD CONSTRAINT [XPKFactWebGoal] PRIMARY KEY  CLUSTERED ([WebGoalKey] ASC)
go

CREATE UNIQUE INDEX [XAK1FactWebGoal]
ON [dbo].[FactWebGoal]([WebGoalDateKey], [WebGoalTimeKey], [WebPageKey], [DigitalTouchpointMetadataKey], [GoalNumber])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go


CREATE TABLE [dbo].[FactWebPageEvent]
( 
	[PageEventKey]		int  NOT NULL IDENTITY(1,1),
	[PageEventDateKey]		int  NOT NULL ,
	[PageEventTimeKey]		int  NOT NULL,
	[WebPageKey]		int  NULL ,
	[DigitalTouchpointMetadataKey]		int  NULL ,
	[WebPageEventInfoKey]		int  NULL ,
	[EventCount]		bigint  NULL ,
	[EventUniqueCount]		bigint  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[FactWebPageEvent]
       ADD CONSTRAINT [XPKFactWebPageEvent] PRIMARY KEY  CLUSTERED ([PageEventKey] ASC)
go

CREATE UNIQUE INDEX [XAK1FactWebPageEvent]
ON [dbo].[FactWebPageEvent]([PageEventDateKey], [PageEventTimeKey], [WebPageKey], [DigitalTouchpointMetadataKey], [WebPageEventInfoKey])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go



CREATE TABLE [dbo].[FactWebPageView]
( 
	[WebPageViewKey]		int  NOT NULL IDENTITY(1,1),
	[PageViewDateKey]		int  NOT NULL ,
	[PageViewTimeKey]	int NOT NULL,
	[WebPageKey]		int  NULL ,
	[DigitalTouchpointMetadataKey]		int  NULL ,
	[WebPageParameterGroupKey]		int  NULL ,
	[PageViewParameters]		nvarchar(max)  NULL ,
	[PageViewEntrances]		bigint  NULL ,
	[PageViewExits]		bigint  NULL ,
	[PageViewCount]		bigint  NULL ,
	[PageViewUniqueCount]		bigint  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[FactWebPageView]
       ADD CONSTRAINT [XPKFactWebPageView] PRIMARY KEY  CLUSTERED ([WebPageViewKey] ASC)
go

CREATE UNIQUE INDEX [XAK1FactWebPageView]
ON [dbo].[FactWebPageView]([PageViewDateKey], [PageViewTimeKey], [WebPageKey], [DigitalTouchpointMetadataKey]) 
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go


CREATE TABLE [dbo].[FactWebPageVisit]
( 
	[WebPageVisitKey]		int  NOT NULL IDENTITY(1,1),
	[VisitDateKey]		int  NOT NULL ,
	[VisitTimeKey]		int  NOT NULL,
	[VisitLandingWebPageKey]		int  NULL ,
	[VisitWebPageKey]		int  NULL ,
	[DigitalTouchpointMetadataKey]		int  NULL ,
	[VisitSessionCount]		bigint  NULL ,
	[VisitSessionDurationSeconds]		decimal(18,2)  NULL ,
	[VisitBouncesCount]		bigint  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[FactWebPageVisit]
       ADD CONSTRAINT [XPKFactWebPageVisit] PRIMARY KEY  CLUSTERED ([WebPageVisitKey] ASC)
go

CREATE UNIQUE INDEX [XAK1FactWebPageVisit]
ON [dbo].[FactWebPageVisit]([VisitDateKey], [VisitTimeKey], [VisitLandingWebPageKey], [VisitWebPageKey], [DigitalTouchpointMetadataKey])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go


CREATE TABLE [dbo].[DimWebSearchInfo]
( 
	[WebSearchInfoKey]		int  NOT NULL IDENTITY(1,1),
	[WebSearchInfoHash]		binary(20) NOT NULL ,
	[SearchQuery]		nvarchar(2000)  NULL ,
	[SearchCountry]		nvarchar(200)  NULL ,
	[SearchType]		nvarchar(200)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[DimWebSearchInfo]
       ADD CONSTRAINT [XPKDimWebSearchInfo] PRIMARY KEY  CLUSTERED ([WebSearchInfoKey] ASC)
go

CREATE UNIQUE INDEX [XAK1DimWebSearchInfo]
ON [dbo].[DimWebSearchInfo]([WebSearchInfoHash]) INCLUDE ([WebSearchInfoKey])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go

CREATE TABLE [dbo].[FactWebSearch]
( 
	[WebSearchKey]		int  NOT NULL IDENTITY(1,1),
	[SearchDateKey]		int  NULL ,
	[WebPageKey]		int  NULL ,
	[DigitalTouchpointMetadataKey]		int  NULL ,
	[WebSearchInfoKey]		int  NULL ,
	[SearchClickCount]		decimal(18,2)  NULL ,
	[SearchClickthroughRate]	decimal(18,2) NULL ,
	[SearchImpressionCount]		decimal(18,2)  NULL ,
	[SearchPosition]		decimal(18,2)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[FactWebSearch]
       ADD CONSTRAINT [XPKFactWebSearch] PRIMARY KEY  CLUSTERED ([WebSearchKey] ASC)
go

CREATE UNIQUE INDEX [XAK1FactWebSearch]
ON [dbo].[FactWebSearch]([SearchDateKey], [WebPageKey], [DigitalTouchpointMetadataKey], [WebSearchInfoKey]) 
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go




CREATE TABLE [dbo].[FactDigitalMetric]
( 
	[DigitalMetricKey]		int  NOT NULL IDENTITY(1,1),
	[MetricStartDateKey]		int  NULL ,
	[MetricEndDateKey]		int  NULL ,
	[DigitalMetricGroupKey]		int  NULL ,
	[DigitalMetricInfoKey]		int  NULL ,
	[MetricRowKey]		int  NULL ,
	[MetricActualValue]		decimal(18,2)  NULL ,
	[MetricTargetValue]		decimal(18,2)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[FactDigitalMetric]
       ADD CONSTRAINT [XPKFactDigitalMetric] PRIMARY KEY  CLUSTERED ([DigitalMetricKey] ASC)
go

CREATE UNIQUE INDEX [XAK1FactDigitalMetric]
ON [dbo].[FactDigitalMetric]([MetricStartDateKey], [MetricEndDateKey], [DigitalMetricGroupKey], [DigitalMetricInfoKey], [MetricRowKey])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go



CREATE TABLE [dbo].[DimDigitalMetricGroup]
( 
	[DigitalMetricGroupKey]		int  NOT NULL IDENTITY(1,1),
	[MetricSourceTableName]		nvarchar(200)  NULL ,
	[MetricGroupName]		nvarchar(200)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[DimDigitalMetricGroup]
       ADD CONSTRAINT [XPKDimDigitalMetricGroup] PRIMARY KEY  CLUSTERED ([DigitalMetricGroupKey] ASC)
go

CREATE UNIQUE INDEX [XAK1DimDigitalMetricGroup]
ON [dbo].[DimDigitalMetricGroup]([MetricSourceTableName], [MetricGroupName]) INCLUDE ([DigitalMetricGroupKey])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go


CREATE TABLE [dbo].[DimDigitalMetricInfo]
( 
	[DigitalMetricInfoKey]		int  NOT NULL IDENTITY(1,1),
	[MetricName]		nvarchar(200)  NULL ,
	[MetricDescription]		nvarchar(200)  NULL ,
	[MetricUnit]		nvarchar(200)  NULL ,
	[MetricCriteria]		nvarchar(200)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[DimDigitalMetricInfo]
       ADD CONSTRAINT [XPKDimDigitalMetricInfo] PRIMARY KEY  CLUSTERED ([DigitalMetricInfoKey] ASC)
go

CREATE UNIQUE INDEX [XAK1DimDigitalMetricInfo]
ON [dbo].[DimDigitalMetricInfo]([MetricName], [MetricUnit], [MetricCriteria]) INCLUDE ([DigitalMetricInfoKey])
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go



CREATE TABLE [dbo].[FactDigitalForm]
( 
	[DigitalFormKey]		int  NOT NULL IDENTITY(1,1),
	[DigitalFormInfoKey]		int  NULL ,
	[FormSubmissionDateKey]		int  NULL ,
	[FormCount]			bigint  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[FactDigitalForm]
       ADD CONSTRAINT [XPKFactDigitalForm] PRIMARY KEY  CLUSTERED ([DigitalFormKey] ASC)
go

CREATE UNIQUE INDEX [XAK1FactDigitalForm]
ON [dbo].[FactDigitalForm]([DigitalFormInfoKey], [FormSubmissionDateKey]) 
WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go



CREATE TABLE [dbo].[DimDigitalFormInfo]
( 
	[DigitalFormInfoKey]		int  NOT NULL IDENTITY(1,1),
	[FormName]		nvarchar(max)  NULL ,
	[FormType]		nvarchar(max)  NULL ,
	[FormOfficialName]		nvarchar(max)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
go

ALTER TABLE [dbo].[DimDigitalFormInfo]
       ADD CONSTRAINT [XPKDimDigitalFormInfo] PRIMARY KEY  CLUSTERED ([DigitalFormInfoKey] ASC)
go


ALTER TABLE [dbo].[DimDigitalChannel]
       ADD CONSTRAINT [FK_DimDigitalChannelGroup_DimDigitalChannel_DigitalChannelGroupKey] FOREIGN KEY ([DigitalChannelGroupKey]) REFERENCES [dbo].[DimDigitalChannelGroup]([DigitalChannelGroupKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[DimDigitalTouchpointMetadata]
       ADD CONSTRAINT [FK_DimDigitalChannel_DimDigitalTouchpointMetadata_DigitalChannelKey] FOREIGN KEY ([DigitalChannelKey]) REFERENCES [dbo].[DimDigitalChannel]([DigitalChannelKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[DimDigitalTouchpointMetadata]
       ADD CONSTRAINT [FK_DimDigitalDeviceCategory_DimDigitalTouchpointMetadata_DigitalDeviceCategoryKey] FOREIGN KEY ([DigitalDeviceCategoryKey]) REFERENCES [dbo].[DimDigitalDeviceCategory]([DigitalDeviceCategoryKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[DimDigitalTouchpointMetadata]
       ADD CONSTRAINT [FK_DimDigitalCityMapping_DimDigitalTouchpointMetadata_TouchpointCityId] FOREIGN KEY ([TouchpointCityId]) REFERENCES [dbo].[DimDigitalCityMapping]([DigitalCityMappingKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[DimWebPage]
       ADD CONSTRAINT [FK_DimWebPage_DimWebPage_WebPageKey] FOREIGN KEY ([PageMappingKey]) REFERENCES [dbo].[DimWebPage]([WebPageKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactDigitalForm]
       ADD CONSTRAINT [FK_DimDigitalFormInfo_FactDigitalForm_DigitalFormInfoKey] FOREIGN KEY ([DigitalFormInfoKey]) REFERENCES [dbo].[DimDigitalFormInfo]([DigitalFormInfoKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactDigitalMetric]
       ADD CONSTRAINT [FK_DimDigitalMetricGroup_FactDigitalMetric_DigitalMetricGroupKey] FOREIGN KEY ([DigitalMetricGroupKey]) REFERENCES [dbo].[DimDigitalMetricGroup]([DigitalMetricGroupKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactDigitalMetric]
       ADD CONSTRAINT [FK_DimDigitalMetricInfo_FactDigitalMetric_DigitalMetricInfoKey] FOREIGN KEY ([DigitalMetricInfoKey]) REFERENCES [dbo].[DimDigitalMetricInfo]([DigitalMetricInfoKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactDigitalTouchpoint]
       ADD CONSTRAINT [FK_DimDigitalTouchpointGroup_FactDigitalTouchpoint_DigitalTouchpointGroupKey] FOREIGN KEY ([DigitalTouchpointGroupKey]) REFERENCES [dbo].[DimDigitalTouchpointGroup]([DigitalTouchpointGroupKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactDigitalTouchpoint]
       ADD CONSTRAINT [FK_DimDigitalTouchpointMetadata_FactDigitalTouchpoint_DigitalTouchpointMetadataKey] FOREIGN KEY ([DigitalTouchpointMetadataKey]) REFERENCES [dbo].[DimDigitalTouchpointMetadata]([DigitalTouchpointMetadataKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactDigitalTouchpoint]
       ADD CONSTRAINT [FK_DimDigitalTouchpointMetrics_FactDigitalTouchpoint_DigitalTouchpointMetricKey] FOREIGN KEY ([DigitalTouchpointMetricKey]) REFERENCES [dbo].[DimDigitalTouchpointMetrics]([DigitalTouchpointMetricKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go


ALTER TABLE [dbo].[FactWebAd]
       ADD CONSTRAINT [FK_DimDigitalTouchpointMetadata_FactWebAd_DigitalTouchpointMetadataKey] FOREIGN KEY ([DigitalTouchpointMetadataKey]) REFERENCES [dbo].[DimDigitalTouchpointMetadata]([DigitalTouchpointMetadataKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebAd]
       ADD CONSTRAINT [FK_DimWebAdInfo_FactWebAd_WebAdInfoKey] FOREIGN KEY ([WebAdInfoKey]) REFERENCES [dbo].[DimWebAdInfo]([WebAdInfoKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebGoal]
       ADD CONSTRAINT [FK_DimDate_FactWebGoal_WebGoalDateKey] FOREIGN KEY ([WebGoalDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebGoal]
       ADD CONSTRAINT [FK_DimTime_FactWebGoal_WebGoalTimeKey] FOREIGN KEY ([WebGoalTimeKey]) REFERENCES [dbo].[DimTime]([TimeKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebGoal]
       ADD CONSTRAINT [FK_DimDigitalTouchpointMetadata_FactWebGoal_DigitalTouchpointMetadataKey] FOREIGN KEY ([DigitalTouchpointMetadataKey]) REFERENCES [dbo].[DimDigitalTouchpointMetadata]([DigitalTouchpointMetadataKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebGoal]
       ADD CONSTRAINT [FK_DimWebPage_FactWebGoal_WebPageKey] FOREIGN KEY ([WebPageKey]) REFERENCES [dbo].[DimWebPage]([WebPageKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebPageEvent]
       ADD CONSTRAINT [FK_DimDate_FactWebPageEvent_PageEventDateKey] FOREIGN KEY ([PageEventDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebPageEvent]
       ADD CONSTRAINT [FK_DimTime_FactWebPageEvent_PageEventTimeKey] FOREIGN KEY ([PageEventTimeKey]) REFERENCES [dbo].[DimTime]([TimeKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebPageEvent]
       ADD CONSTRAINT [FK_DimWebPage_FactWebPageEvent_WebPageKey] FOREIGN KEY ([WebPageKey]) REFERENCES [dbo].[DimWebPage]([WebPageKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebPageEvent]
       ADD CONSTRAINT [FK_DimDigitalTouchpointMetadata_FactWebPageEvent_DigitalTouchpointMetadataKey] FOREIGN KEY ([DigitalTouchpointMetadataKey]) REFERENCES [dbo].[DimDigitalTouchpointMetadata]([DigitalTouchpointMetadataKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebPageEvent]
       ADD CONSTRAINT [FK_DimWebPageEventInfo_FactWebPageEvent_WebPageEventInfoKey] FOREIGN KEY ([WebPageEventInfoKey]) REFERENCES [dbo].[DimWebPageEventInfo]([WebPageEventInfoKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactWebPageView]
       ADD CONSTRAINT [FK_DimDate_FactWebPageView_PageViewDateKey] FOREIGN KEY ([PageViewDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebPageView]
       ADD CONSTRAINT [FK_DimTime_FactWebPageView_PageViewTimeKey] FOREIGN KEY ([PageViewTimeKey]) REFERENCES [dbo].[DimTime]([TimeKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebPageView]
       ADD CONSTRAINT [FK_DimDigitalTouchpointMetadata_FactWebPageView_DigitalTouchpointMetadataKey] FOREIGN KEY ([DigitalTouchpointMetadataKey]) REFERENCES [dbo].[DimDigitalTouchpointMetadata]([DigitalTouchpointMetadataKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebPageView]
       ADD CONSTRAINT [FK_DimWebPage_FactWebPageView_WebPageKey] FOREIGN KEY ([WebPageKey]) REFERENCES [dbo].[DimWebPage]([WebPageKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebPageView]
       ADD CONSTRAINT [FK_DimWebPageParameterGroup_FactWebPageView_WebPageParameterGroupKey] FOREIGN KEY ([WebPageParameterGroupKey]) REFERENCES [dbo].[DimWebPageParameterGroup]([WebPageParameterGroupKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebPageVisit]
       ADD CONSTRAINT [FK_DimDigitalTouchpointMetadata_FactWebPageVisit_DigitalTouchpointMetadataKey] FOREIGN KEY ([DigitalTouchpointMetadataKey]) REFERENCES [dbo].[DimDigitalTouchpointMetadata]([DigitalTouchpointMetadataKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebPageVisit]
       ADD CONSTRAINT [FK_DimWebPage_FactWebPageVisit_VisitWebPageKey] FOREIGN KEY ([VisitWebPageKey]) REFERENCES [dbo].[DimWebPage]([WebPageKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactWebSearch]
       ADD CONSTRAINT [FK_DimDigitalTouchpointMetadata_FactWebSearch_DigitalTouchpointMetadataKey] FOREIGN KEY ([DigitalTouchpointMetadataKey]) REFERENCES [dbo].[DimDigitalTouchpointMetadata]([DigitalTouchpointMetadataKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebSearch]
       ADD CONSTRAINT [FK_DimWebPage_FactWebSearch_WebPageKey] FOREIGN KEY ([WebPageKey]) REFERENCES [dbo].[DimWebPage]([WebPageKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactWebSearch]
       ADD CONSTRAINT [FK_DimWebSearchInfo_FactWebSearch_WebSearchInfoKey] FOREIGN KEY ([WebSearchInfoKey]) REFERENCES [dbo].[DimWebSearchInfo]([WebSearchInfoKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactDigitalForm]
       ADD CONSTRAINT [FK_DimDate_FactDigitalForm_FormSubmissionDateKey] FOREIGN KEY ([FormSubmissionDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactDigitalMetric]
       ADD CONSTRAINT [FK_DimDate_FactDigitalMetric_MetricStartDateKey] FOREIGN KEY ([MetricStartDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactDigitalMetric]
       ADD CONSTRAINT [FK_DimDate_FactDigitalMetric_MetricEndDateKey] FOREIGN KEY ([MetricEndDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactDigitalTouchpoint]
       ADD CONSTRAINT [FK_DimDate_FactDigitalTouchpoint_TouchpointDateKey] FOREIGN KEY ([TouchpointDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactDigitalTouchpoint]
       ADD CONSTRAINT [FK_DimTime_FactDigitalTouchpoint_TouchpointTimeKey] FOREIGN KEY ([TouchpointTimeKey]) REFERENCES [dbo].[DimTime]([TimeKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactWebPageVisit]
       ADD CONSTRAINT [FK_DimDate_FactWebPageVisit_VisitDateKey] FOREIGN KEY ([VisitDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebPageVisit]
       ADD CONSTRAINT [FK_DimTime_FactWebPageVisit_VisitTimeKey] FOREIGN KEY ([VisitTimeKey]) REFERENCES [dbo].[DimTime]([TimeKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebPageVisit]
       ADD CONSTRAINT [FK_DimWebPage_FactWebPageVisit_VisitLandingWebPageKey] FOREIGN KEY ([VisitLandingWebPageKey]) REFERENCES [dbo].[DimWebPage]([WebPageKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebAd]
       ADD CONSTRAINT [FK_DimDate_FactWebAd_AdStartDateKey] FOREIGN KEY ([AdDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[FactWebSearch]
       ADD CONSTRAINT [FK_DimDate_FactWebSearch_SearchDateKey] FOREIGN KEY ([SearchDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[DimWebContent]
       ADD CONSTRAINT [FK_DimDate_DimWebContent_ContentDateKey] FOREIGN KEY ([ContentDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
ALTER TABLE [dbo].[DimWebContent]
       ADD CONSTRAINT [FK_DimTime_DimWebContent_ContentTimeKey] FOREIGN KEY ([ContentTimeKey]) REFERENCES [dbo].[DimTime]([TimeKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
go
