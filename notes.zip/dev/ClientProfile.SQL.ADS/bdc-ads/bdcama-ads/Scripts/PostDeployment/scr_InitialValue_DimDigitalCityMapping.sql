

DECLARE @TMP_DimDigitalCityMapping TABLE
( 
	[DigitalCityMappingKey]		int  NOT NULL,
	[CityName]			nvarchar(100)  NULL ,
	[ProvinceId]		int  NULL,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)


INSERT INTO @TMP_DimDigitalCityMapping (
	[DigitalCityMappingKey]
	,[CityName]
	,[ProvinceId]
	,InsertedDate
	,InsertedBy
	,ModifiedDate
	,ModifiedBy
)
VALUES (
	-1
	,'N/A'
	,-1
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
)
BEGIN TRANSACTION
	MERGE dbo.DimDigitalCityMapping AS dst
	USING @TMP_DimDigitalCityMapping as src
		ON dst.[DigitalCityMappingKey] = src.[DigitalCityMappingKey]
	WHEN NOT MATCHED THEN
		INSERT (
			[DigitalCityMappingKey]
			,[CityName]
			,[ProvinceId]
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
			)
		VALUES (
			src.[DigitalCityMappingKey]
			,src.[CityName]
			,src.[ProvinceId]
			,src.InsertedDate
			,src.InsertedBy
			,src.ModifiedDate
			,src.ModifiedBy
		)
	OUTPUT $ACTION as ActionType, src.*;
COMMIT TRANSACTION