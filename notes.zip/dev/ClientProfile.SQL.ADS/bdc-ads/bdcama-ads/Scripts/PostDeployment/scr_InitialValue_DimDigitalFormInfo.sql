

DECLARE @TMP_DimDigitalFormInfo TABLE
( 
	[DigitalFormInfoKey]		int  NOT NULL,
	[FormName]		nvarchar(50)  NULL ,
	[FormType]		nvarchar(50)  NULL ,
	[FormOfficialName]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50) NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)


INSERT INTO @TMP_DimDigitalFormInfo (
	DigitalFormInfoKey
	,FormName
	,FormType
	,FormOfficialName
	,InsertedDate
	,InsertedBy
	,ModifiedDate
	,ModifiedBy
)
VALUES (
	-1
	,'N/A'
	,'N/A'
	,'N/A'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
)
BEGIN TRANSACTION
	SET IDENTITY_INSERT dbo.DimDigitalFormInfo ON 
	MERGE dbo.DimDigitalFormInfo AS dst
	USING @TMP_DimDigitalFormInfo as src
		ON dst.DigitalFormInfoKey = src.DigitalFormInfoKey
	WHEN NOT MATCHED THEN
		INSERT (
			DigitalFormInfoKey
			,FormName
			,FormType
			,FormOfficialName
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
			)
		VALUES (
			src.DigitalFormInfoKey
			,src.FormName
			,src.FormType
			,src.FormOfficialName
			,src.InsertedDate
			,src.InsertedBy
			,src.ModifiedDate
			,src.ModifiedBy
			
		)
	OUTPUT $ACTION as ActionType, src.*;
	SET IDENTITY_INSERT dbo.DimDigitalFormInfo OFF
COMMIT TRANSACTION