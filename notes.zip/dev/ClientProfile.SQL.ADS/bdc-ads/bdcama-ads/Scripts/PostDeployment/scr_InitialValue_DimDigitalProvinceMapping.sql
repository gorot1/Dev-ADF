

DECLARE @TMP_DimDigitalProvinceMapping TABLE
( 
	[DigitalProvinceMappingKey]		int  NOT NULL,
	[ProvinceNameEn]	nvarchar(100)  NULL ,
	[ProvinceCode]		nvarchar(10)  NULL,
	[FSAProvince]		int  NULL ,
	[RegionBDCEn]		nvarchar(100)  NULL,
	[ProvinceNameFr]	nvarchar(100)  NULL ,
	[RegionBDCFr]		nvarchar(100)  NULL,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)


INSERT INTO @TMP_DimDigitalProvinceMapping (
	[DigitalProvinceMappingKey]
	,[ProvinceNameEn]
	,[ProvinceCode]
	,[FSAProvince]
	,[RegionBDCEn]
	,[ProvinceNameFr]
	,[RegionBDCFr]
	,InsertedDate
	,InsertedBy
	,ModifiedDate
	,ModifiedBy
)
VALUES (
	-1
	,'N/A'
	,'N/A'
	,0
	,'N/A'
	,'N/A'
	,'N/A'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
)
BEGIN TRANSACTION
	SET IDENTITY_INSERT dbo.DimDigitalProvinceMapping ON 
	MERGE dbo.DimDigitalProvinceMapping AS dst
	USING @TMP_DimDigitalProvinceMapping as src
		ON dst.[DigitalProvinceMappingKey] = src.[DigitalProvinceMappingKey]
	WHEN NOT MATCHED THEN
		INSERT (
			[DigitalProvinceMappingKey]
			,[ProvinceNameEn]
			,[ProvinceCode]
			,[FSAProvince]
			,[RegionBDCEn]
			,[ProvinceNameFr]
			,[RegionBDCFr]
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
			)
		VALUES (
			src.[DigitalProvinceMappingKey]
			,src.[ProvinceNameEn]
			,src.[ProvinceCode]
			,src.[FSAProvince]
			,src.[RegionBDCEn]
			,src.[ProvinceNameFr]
			,src.[RegionBDCFr]
			,src.InsertedDate
			,src.InsertedBy
			,src.ModifiedDate
			,src.ModifiedBy
		)
	OUTPUT $ACTION as ActionType, src.*;
	SET IDENTITY_INSERT dbo.DimDigitalProvinceMapping OFF
COMMIT TRANSACTION