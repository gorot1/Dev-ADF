

DECLARE @TMP_DimWebAdInfo TABLE
( 
	[WebAdInfoKey]		int  NOT NULL,
	[WebAdInfoHash] binary(20) NOT NULL,
	[AdContent]		nvarchar(50)  NULL ,
	[AdKeyword]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50) NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)


INSERT INTO @TMP_DimWebAdInfo (
	WebAdInfoKey
	,WebAdInfoHash
	,AdContent
	,AdKeyword
	,InsertedDate
	,InsertedBy
	,ModifiedDate
	,ModifiedBy
)
VALUES (
	-1
	,HASHBYTES('SHA1', 'N/AN/A')
	,'N/A'
	,'N/A'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
)BEGIN TRANSACTION
	SET IDENTITY_INSERT dbo.DimWebAdInfo ON 
	MERGE dbo.DimWebAdInfo AS dst
	USING @TMP_DimWebAdInfo as src
		ON dst.WebAdInfoKey = src.WebAdInfoKey
	WHEN NOT MATCHED THEN
		INSERT (
			WebAdInfoKey
			,WebAdInfoHash
			,AdContent
			,AdKeyword
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
			)
		VALUES (
			src.WebAdInfoKey
			,src.WebAdInfoHash
			,src.AdContent
			,src.AdKeyword
			,src.InsertedDate
			,src.InsertedBy
			,src.ModifiedDate
			,src.ModifiedBy
			
		)
	OUTPUT $ACTION as ActionType, src.*;
	SET IDENTITY_INSERT dbo.DimWebAdInfo OFF
COMMIT TRANSACTION