DECLARE @TMP_DimWebPageEventInfo TABLE
( 
	[WebPageEventInfoKey]		int  NOT NULL,
	[WebPageEventInfoHash]	binary(20) NOT NULL,
	[EventEntityType]			varchar(20) NOT NULL,
	[EventCategory]		nvarchar(300)  NULL ,
	[EventAction]		nvarchar(3000)  NULL ,
	[EventLabel]		nvarchar(max)  NULL ,
	[EventContainer]	nvarchar(300) NULL,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50) NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL
)


INSERT INTO @TMP_DimWebPageEventInfo (
	[WebPageEventInfoKey],
	[WebPageEventInfoHash],
	[EventEntityType],
	[EventCategory],
	[EventAction],
	[EventLabel],
	[EventContainer],
	[InsertedDate],
	[InsertedBy],
	[ModifiedDate],
	[ModifiedBy]
)
VALUES (
	-1
	,HASHBYTES('SHA1', 'N/AN/AN/AN/AN/A')
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
)BEGIN TRANSACTION
	SET IDENTITY_INSERT dbo.DimWebPageEventInfo ON 
	MERGE dbo.DimWebPageEventInfo AS dst
	USING @TMP_DimWebPageEventInfo as src
		ON dst.WebPageEventInfoKey = src.WebPageEventInfoKey
	WHEN NOT MATCHED THEN
		INSERT (
			[WebPageEventInfoKey],
			[WebPageEventInfoHash],
			[EventEntityType],
			[EventCategory],
			[EventAction],
			[EventLabel],
			[EventContainer],
			[InsertedDate],
			[InsertedBy],
			[ModifiedDate],
			[ModifiedBy]
			)
		VALUES (
			src.[WebPageEventInfoKey],
			src.[WebPageEventInfoHash],
			src.[EventEntityType],
			src.[EventCategory],
			src.[EventAction],
			src.[EventLabel],
			src.[EventContainer],
			src.[InsertedDate],
			src.[InsertedBy],
			src.[ModifiedDate],
			src.[ModifiedBy]
		)
	OUTPUT $ACTION as ActionType, src.*;
	SET IDENTITY_INSERT dbo.DimWebPageEventInfo OFF
COMMIT TRANSACTION