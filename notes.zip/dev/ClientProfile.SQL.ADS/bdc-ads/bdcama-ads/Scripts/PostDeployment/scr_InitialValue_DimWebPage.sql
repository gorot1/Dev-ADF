

DECLARE @TMP_DimWebPage TABLE
( 
	[WebPageKey]		int  NOT NULL,
	[WebPageHash]		binary(20) NOT NULL,
	[PageFullPath]		nvarchar(2000)  NULL ,
	[PageDomain]		nvarchar(100)  NULL ,
	[PageRelativePathWithoutParameters]		nvarchar(2000)  NULL ,
	[PageParameters]	nvarchar(2000)  NULL ,
	[PageLevel1]		nvarchar(1000)  NULL ,
	[PageLevel2]		nvarchar(500)  NULL ,
	[PageLevel3]		nvarchar(1000)  NULL ,
	[PageLevel4]		nvarchar(500)  NULL ,
	[PageLevel5]		nvarchar(1000)  NULL ,
	[PageIsNew]			bit NULL,
	[PageMappingKey]	int NULL,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL
)


INSERT INTO @TMP_DimWebPage (
	WebPageKey
	,WebPageHash
	,PageFullPath
	,PageDomain
	,PageRelativePathWithoutParameters
	,PageParameters
	,PageLevel1
	,PageLevel2
	,PageLevel3
	,PageLevel4
	,PageLevel5
	,PageIsNew
	,PageMappingKey
	,InsertedDate
	,InsertedBy
	,ModifiedDate
	,ModifiedBy
)
VALUES (
	-1
	,HASHBYTES('SHA1', 'N/A')
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,0
	,NULL
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
)BEGIN TRANSACTION
	SET IDENTITY_INSERT dbo.DimWebPage ON 
	MERGE dbo.DimWebPage AS dst
	USING @TMP_DimWebPage as src
		ON dst.WebPageKey = src.WebPageKey
	WHEN NOT MATCHED THEN
		INSERT (
			WebPageKey
			,WebPageHash
			,PageFullPath
			,PageDomain
			,PageRelativePathWithoutParameters
			,PageParameters
			,PageLevel1
			,PageLevel2
			,PageLevel3
			,PageLevel4
			,PageLevel5
			,PageIsNew
			,PageMappingKey
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
			)
		VALUES (
			src.WebPageKey
			,src.WebPageHash
			,src.PageFullPath
			,src.PageDomain
			,src.PageRelativePathWithoutParameters
			,src.PageParameters
			,src.PageLevel1
			,src.PageLevel2
			,src.PageLevel3
			,src.PageLevel4
			,src.PageLevel5
			,src.PageIsNew
			,src.PageMappingKey
			,src.InsertedDate
			,src.InsertedBy
			,src.ModifiedDate
			,src.ModifiedBy
		)
	OUTPUT $ACTION as ActionType, src.*;
	SET IDENTITY_INSERT dbo.DimWebPage OFF
COMMIT TRANSACTION