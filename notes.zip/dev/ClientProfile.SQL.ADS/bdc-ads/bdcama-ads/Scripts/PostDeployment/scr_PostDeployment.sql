﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]	
*/			
--------------------------------------------------------------------------------------
:r .\scr_InitialValue_DimDigitalChannelGroup.sql
:r .\scr_InitialValue_DimDigitalChannel.sql
:r .\scr_InitialValue_DimDigitalDeviceCategory.sql
:r .\scr_InitialValue_DimDigitalProvinceMapping.sql
:r .\scr_InitialValue_DimDigitalCityMapping.sql
:r .\scr_InitialValue_DimDigitalTouchpointGroup.sql
:r .\scr_InitialValue_DimDigitalTouchpointMetadata.sql
:r .\scr_InitialValue_DimDigitalTouchpointMetrics.sql
:r .\scr_InitialValue_DimWebAdInfo.sql
:r .\scr_InitialValue_DimWebContent.sql
:r .\scr_InitialValue_DimWebPage.sql
:r .\scr_InitialValue_DimWebPageEventInfo.sql
:r .\scr_InitialValue_DimWebPageParameterGroup.sql
:r .\scr_InitialValue_DimDigitalMetricGroup.sql
:r .\scr_InitialValue_DimDigitalMetricInfo.sql
:r .\scr_InitialValue_DimDigitalFormInfo.sql
:r .\scr_InitialValue_AdsWatermarksBIM.sql