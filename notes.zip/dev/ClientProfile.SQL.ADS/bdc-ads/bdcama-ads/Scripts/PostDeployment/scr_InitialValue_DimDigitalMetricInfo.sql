

DECLARE @TMP_DimDigitalMetricInfo TABLE
( 
	[DigitalMetricInfoKey]		int  NOT NULL,
	[MetricName]		nvarchar(50)  NULL ,
	[MetricDescription]		nvarchar(50)  NULL ,
	[MetricUnit]		nvarchar(50)  NULL ,
	[MetricCriteria]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50) NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)


INSERT INTO @TMP_DimDigitalMetricInfo (
	DigitalMetricInfoKey
	,MetricName
	,MetricDescription
	,MetricUnit
	,MetricCriteria
	,InsertedDate
	,InsertedBy
	,ModifiedDate
	,ModifiedBy
)
VALUES (
	-1
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	1
	,'Consulting Form Goal Completions'
	,NULL
	,NULL
	,NULL
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	2
	,'Financing Form Goal Completions'
	,NULL
	,NULL
	,NULL
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	3
	,'SBL BDC Goal Completions'
	,NULL
	,NULL
	,NULL
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	4
	,'SBL Connex Goal Completions'
	,NULL
	,NULL
	,NULL
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	5
	,'Eloqua Consent Nurturing'
	,NULL
	,NULL
	,NULL
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	6
	,'Eloqua Consent Subscriber Number'
	,NULL
	,NULL
	,NULL
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	7
	,'Eloqua VBC Client Number'
	,NULL
	,NULL
	,NULL
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
)


BEGIN TRANSACTION
	SET IDENTITY_INSERT dbo.DimDigitalMetricInfo ON 
	MERGE dbo.DimDigitalMetricInfo AS dst
	USING @TMP_DimDigitalMetricInfo as src
		ON dst.DigitalMetricInfoKey = src.DigitalMetricInfoKey
	WHEN NOT MATCHED THEN
		INSERT (
			DigitalMetricInfoKey
			,MetricName
			,MetricDescription
			,MetricUnit
			,MetricCriteria
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
			)
		VALUES (
			src.DigitalMetricInfoKey
			,src.MetricName
			,src.MetricDescription
			,src.MetricUnit
			,src.MetricCriteria
			,src.InsertedDate
			,src.InsertedBy
			,src.ModifiedDate
			,src.ModifiedBy
			
		)
	OUTPUT $ACTION as ActionType, src.*;
	SET IDENTITY_INSERT dbo.DimDigitalMetricInfo OFF
COMMIT TRANSACTION