DECLARE @TMP_DimDigitalChannelGroup TABLE
( 
	[DigitalChannelGroupKey]		int  NOT NULL,
	[ChannelGroupName]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50) NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)


INSERT INTO @TMP_DimDigitalChannelGroup (
	DigitalChannelGroupKey
	,ChannelGroupName
	,InsertedDate
	,InsertedBy
	,ModifiedDate
	,ModifiedBy
)
VALUES (
	-1
	,'Other'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	1
	,'Native Ads'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	2
	,'Direct'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	3
	,'Social Media'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	4
	,'Non-Paid Search'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	5
	,'Email'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	6
	,'Paid Search'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	7
	,'Referral'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),

(
	8
	,'Display'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
)

BEGIN TRANSACTION
	SET IDENTITY_INSERT dbo.DimDigitalChannelGroup ON 
	MERGE dbo.DimDigitalChannelGroup AS dst
	USING @TMP_DimDigitalChannelGroup as src
		ON dst.DigitalChannelGroupKey = src.DigitalChannelGroupKey
	WHEN NOT MATCHED THEN
		INSERT (
			DigitalChannelGroupKey
			,ChannelGroupName
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
			)
		VALUES (
			src.DigitalChannelGroupKey
			,src.ChannelGroupName
			,src.InsertedDate
			,src.InsertedBy
			,src.ModifiedDate
			,src.ModifiedBy
			
		)
	OUTPUT $ACTION as ActionType, src.*;
	SET IDENTITY_INSERT dbo.DimDigitalChannelGroup OFF
COMMIT TRANSACTION