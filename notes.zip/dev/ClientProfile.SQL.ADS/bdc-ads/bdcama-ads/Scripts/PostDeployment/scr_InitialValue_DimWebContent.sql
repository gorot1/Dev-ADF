

DECLARE @TMP_DimWebContent TABLE
( 
	[WebContentKey]			int  NOT NULL,
	[ContentDateKey]		int  NOT NULL,
	[ContentTimeKey]		int  NULL ,
	[ContentPageKey]		int  NULL ,
	[ContentGroupName]		nvarchar(1000)  NULL ,
	[ContentTaxonomyVersionName]		nvarchar(1000)  NULL ,
	[ContentName]		nvarchar(1000)  NULL ,
	[ContentTitle]		nvarchar(1000)  NULL ,
	[ContentSEOTitle]		nvarchar(1000)  NULL ,
	[ContentTypeName]		nvarchar(1000)  NULL ,
	[ContentLevel1Name]		nvarchar(1000)  NULL ,
	[ContentLevel2Name]		nvarchar(1000)  NULL ,
	[ContentLevel3Name]		nvarchar(1000)  NULL ,
	[ContentLevel4Name]		nvarchar(1000)  NULL ,
	[ContentLevel5Name]		nvarchar(1000)  NULL ,
	[ContentIsGated]		bit  NULL ,
	[ContentIsCovid19]		bit  NULL ,
	[ContentIsSMEResearch]	bit  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50) NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL
)


INSERT INTO @TMP_DimWebContent (
	WebContentKey
	,ContentDateKey
	,ContentTimeKey
	,ContentPageKey
	,ContentGroupName
	,ContentTaxonomyVersionName
	,ContentName
	,ContentTitle
	,ContentSEOTitle
	,ContentTypeName
	,ContentLevel1Name
	,ContentLevel2Name
	,ContentLevel3Name
	,ContentLevel4Name
	,ContentLevel5Name
	,ContentIsGated
	,ContentIsCovid19
	,ContentIsSMEResearch
	,InsertedDate
	,InsertedBy
	,ModifiedDate
	,ModifiedBy
)
VALUES (
	-1
	,19000101
	,0
	,-1
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,0
	,0
	,0
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
)BEGIN TRANSACTION
	SET IDENTITY_INSERT dbo.DimWebContent ON 
	MERGE dbo.DimWebContent AS dst
	USING @TMP_DimWebContent as src
		ON dst.WebContentKey = src.WebContentKey
	WHEN NOT MATCHED THEN
		INSERT (
			WebContentKey
			,ContentDateKey
			,ContentTimeKey
			,ContentPageKey
			,ContentGroupName
			,ContentTaxonomyVersionName
			,ContentName
			,ContentTitle
			,ContentSEOTitle
			,ContentTypeName
			,ContentLevel1Name
			,ContentLevel2Name
			,ContentLevel3Name
			,ContentLevel4Name
			,ContentLevel5Name
			,ContentIsGated
			,ContentIsCovid19
			,ContentIsSMEResearch
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
			)
		VALUES (
			src.WebContentKey
			,src.ContentDateKey
			,src.ContentTimeKey
			,src.ContentPageKey
			,src.ContentGroupName
			,src.ContentTaxonomyVersionName
			,src.ContentName
			,src.ContentTitle
			,src.ContentSEOTitle
			,src.ContentTypeName
			,src.ContentLevel1Name
			,src.ContentLevel2Name
			,src.ContentLevel3Name
			,src.ContentLevel4Name
			,src.ContentLevel5Name
			,src.ContentIsGated
			,src.ContentIsCovid19
			,src.ContentIsSMEResearch
			,src.InsertedDate
			,src.InsertedBy
			,src.ModifiedDate
			,src.ModifiedBy	
		)
	OUTPUT $ACTION as ActionType, src.*;
	SET IDENTITY_INSERT dbo.DimWebContent OFF
COMMIT TRANSACTION