﻿/* dbo.DimEmailInfo */
SET IDENTITY_INSERT dbo.DimEmailInfo ON;
MERGE dbo.DimEmailInfo AS TGT
USING
(
    VALUES
    (
        -1
        ,'N/A'
        ,'N/A'
        ,'N/A'
        ,HASHBYTES('SHA2_256', 'N/A')
        ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimEmailInfoId
    ,DimEmailInfoKey
    ,EmailName
    ,EmailCampaign
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimEmailInfoId = SRC.DimEmailInfoId
WHEN MATCHED THEN
    UPDATE SET
        DimEmailInfoKey     = SRC.DimEmailInfoKey
        ,EmailName          = SRC.EmailName
        ,EmailCampaign      = SRC.EmailCampaign
        ,_KeyHash           = SRC._KeyHash
        ,_ValueHash         = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimEmailInfoId
        ,DimEmailInfoKey
        ,EmailName
        ,EmailCampaign
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimEmailInfoId
        ,SRC.DimEmailInfoKey
        ,SRC.EmailName
        ,SRC.EmailCampaign
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT dbo.DimEmailInfo OFF;
GO
