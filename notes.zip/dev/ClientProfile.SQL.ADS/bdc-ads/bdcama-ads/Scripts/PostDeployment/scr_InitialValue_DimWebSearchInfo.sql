

DECLARE @TMP_DimWebSearchInfo TABLE
( 
	[WebSearchInfoKey]		int  NOT NULL,
	[WebSearchInfoHash]		binary(20) NOT NULL ,
	[SearchQuery]		nvarchar(3000)  NULL ,
	[SearchCountry]		nvarchar(200)  NULL ,
	[SearchType]		nvarchar(200)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50)	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL
)


INSERT INTO @TMP_DimWebSearchInfo (
	WebSearchInfoKey
	,WebSearchInfoHash
	,SearchQuery
	,SearchCountry
	,SearchType
	,InsertedDate
	,InsertedBy
	,ModifiedDate
	,ModifiedBy
)
VALUES (
	-1
	,HASHBYTES('SHA1', 'N/AN/AN/A')
	,'N/A'
	,'N/A'
	,'N/A'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
)BEGIN TRANSACTION
	SET IDENTITY_INSERT dbo.DimWebSearchInfo ON 
	MERGE dbo.DimWebSearchInfo AS dst
	USING @TMP_DimWebSearchInfo as src
		ON dst.WebSearchInfoKey = src.WebSearchInfoKey
	WHEN NOT MATCHED THEN
		INSERT (
			WebSearchInfoKey
			,WebSearchInfoHash
			,SearchQuery
			,SearchCountry
			,SearchType
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
			)
		VALUES (
			src.WebSearchInfoKey
			,src.WebSearchInfoHash
			,src.SearchQuery
			,src.SearchCountry
			,src.SearchType
			,src.InsertedDate
			,src.InsertedBy
			,src.ModifiedDate
			,src.ModifiedBy
		)
	OUTPUT $ACTION as ActionType, src.*;
	SET IDENTITY_INSERT dbo.DimWebSearchInfo OFF
COMMIT TRANSACTION