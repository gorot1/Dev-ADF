

DECLARE @TMP_DimDigitalDeviceCategory TABLE
( 
	[DigitalDeviceCategoryKey]		int  NOT NULL,
	[DeviceCategoryName]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50) NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)


INSERT INTO @TMP_DimDigitalDeviceCategory (
	DigitalDeviceCategoryKey
	,DeviceCategoryName
	,InsertedDate
	,InsertedBy
	,ModifiedDate
	,ModifiedBy
)
VALUES (
	-1
	,'N/A'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
)BEGIN TRANSACTION
	SET IDENTITY_INSERT dbo.DimDigitalDeviceCategory ON 
	MERGE dbo.DimDigitalDeviceCategory AS dst
	USING @TMP_DimDigitalDeviceCategory as src
		ON dst.DigitalDeviceCategoryKey = src.DigitalDeviceCategoryKey
	WHEN NOT MATCHED THEN
		INSERT (
			DigitalDeviceCategoryKey
			,DeviceCategoryName
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
			)
		VALUES (
			src.DigitalDeviceCategoryKey
			,src.DeviceCategoryName
			,src.InsertedDate
			,src.InsertedBy
			,src.ModifiedDate
			,src.ModifiedBy
			
		)
	OUTPUT $ACTION as ActionType, src.*;
	SET IDENTITY_INSERT dbo.DimDigitalDeviceCategory OFF
COMMIT TRANSACTION