

DECLARE @TMP_DimDigitalTouchpointMetrics TABLE
( 
	[DigitalTouchpointMetricKey]		int  NOT NULL,
	[MetricName1]		nvarchar(50)  NULL ,
	[MetricName2]		nvarchar(50)  NULL ,
	[MetricName3]		nvarchar(50)  NULL ,
	[MetricName4]		nvarchar(50)  NULL ,
	[MetricName5]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50) NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)


INSERT INTO @TMP_DimDigitalTouchpointMetrics (
	DigitalTouchpointMetricKey
	,MetricName1
	,MetricName2
	,MetricName3
	,MetricName4
	,MetricName5
	,InsertedDate
	,InsertedBy
	,ModifiedDate
	,ModifiedBy
)
VALUES (
	-1
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	1
	,'GoalStartsValue'
	,'GoalCompletionsValue'
	,''
	,''
	,''
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	2
	,'EventCount'
	,'EventUniqueCount'
	,''
	,''
	,''
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	3
	,'PageViewEntrances'
	,'PageViewExits'
	,'PageViewCount'
	,'PageViewUniqueCount'
	,''
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	4
	,'VisitSessionCount'
	,'VisitSessionDurationSeconds'
	,'VisitBouncesCount'
	,''
	,''
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	5
	,'AdCost'
	,'AdClickCount'
	,'AdImpressionCount'
	,'AdSecondsOnPage'
	,''
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	6
	,'SearchClickCount'
	,'SearchImpressionCount'
	,'SearchPosition'
	,''
	,''
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	7
	,'EmailsSent'
	,'EmailsDelivered'
	,'EmailsHardBouncebackTotal'
	,'EmailsSoftBouncebackTotal'
	,'EmailsOpensTotal'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	8
	,'EmailsOpenUnique'
	,'EmailsClickthroughsTotal'
	,'EmailsClickthroughsUnique'
	,'EmailsExistingVisitorClickthroughs'
	,'EmailsNewVisitorClickthroughs'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	9
	,'EmailsPossibleForwardsTotal'
	,'EmailsPossibleForwardersTotal'
	,'EmailsUnsubscribesByEmailTotal'
	,'EmailsFormSubmissionsFromEmailTotal'
	,'EmailsFormSubmissionsFromEmailUnique'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
)


BEGIN TRANSACTION
	SET IDENTITY_INSERT dbo.DimDigitalTouchpointMetrics ON 
	MERGE dbo.DimDigitalTouchpointMetrics AS dst
	USING @TMP_DimDigitalTouchpointMetrics as src
		ON dst.DigitalTouchpointMetricKey = src.DigitalTouchpointMetricKey
	WHEN NOT MATCHED THEN
		INSERT (
			DigitalTouchpointMetricKey
			,MetricName1
			,MetricName2
			,MetricName3
			,MetricName4
			,MetricName5
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
			)
		VALUES (
			src.DigitalTouchpointMetricKey
			,src.MetricName1
			,src.MetricName2
			,src.MetricName3
			,src.MetricName4
			,src.MetricName5
			,src.InsertedDate
			,src.InsertedBy
			,src.ModifiedDate
			,src.ModifiedBy
			
		)
	OUTPUT $ACTION as ActionType, src.*;
	SET IDENTITY_INSERT dbo.DimDigitalTouchpointMetrics OFF
COMMIT TRANSACTION