DECLARE @TMP_DimDigitalChannel TABLE
( 
	[DigitalChannelKey]		int  NOT NULL,
	[DigitalChannelHash]			binary(20) NOT NULL,
	[DigitalChannelGroupKey]		int  NULL ,
	[ChannelSource]		nvarchar(50)  NULL ,
	[ChannelMedium]		nvarchar(50)  NULL ,
	[ChannelCampaign]		nvarchar(50)  NULL ,
	[ChannelIsBranded]		bit  NULL ,
	[ChannelBusinessLine]		nvarchar(50)  NULL ,
	[ChannelProductType]		nvarchar(50)  NULL ,
	[ChannelTargetAudience]		nvarchar(50)  NULL ,
	[ChannelReferringSite]		nvarchar(50)  NULL ,
	[ChannelEmailGroup]		nvarchar(50)  NULL ,
	[ChannelLeadNurturingGroup]		nvarchar(50)  NULL ,
	[ChannelLeadNurturingStage]		nvarchar(50)  NULL ,
	[ChannelMeledition]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50) NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)

INSERT INTO @TMP_DimDigitalChannel (
	DigitalChannelKey
	,DigitalChannelHash
	,DigitalChannelGroupKey
	,ChannelSource
	,ChannelMedium
	,ChannelCampaign
	,ChannelIsBranded
	,ChannelBusinessLine
	,ChannelProductType
	,ChannelTargetAudience
	,ChannelReferringSite
	,ChannelEmailGroup
	,ChannelLeadNurturingGroup
	,ChannelLeadNurturingStage
	,ChannelMeledition
	,InsertedDate
	,InsertedBy
	,ModifiedDate
	,ModifiedBy
)
VALUES (
	-1
	,HASHBYTES('SHA1', 'N/AN/AN/A')
	,-1
	,'N/A'
	,'N/A'
	,'N/A'
	,0
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()

 

)BEGIN TRANSACTION
	SET IDENTITY_INSERT dbo.DimDigitalChannel ON 
	MERGE dbo.DimDigitalChannel AS dst
	USING @TMP_DimDigitalChannel as src
		ON dst.DigitalChannelKey = src.DigitalChannelKey
	WHEN NOT MATCHED THEN
		INSERT (
			DigitalChannelKey
			,DigitalChannelHash
			,DigitalChannelGroupKey
			,ChannelSource
			,ChannelMedium
			,ChannelCampaign
			,ChannelIsBranded
			,ChannelBusinessLine
			,ChannelProductType
			,ChannelTargetAudience
			,ChannelReferringSite
			,ChannelEmailGroup
			,ChannelLeadNurturingGroup
			,ChannelLeadNurturingStage
			,ChannelMeledition
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
			)
		VALUES (
			src.DigitalChannelKey
			,src.DigitalChannelHash
			,src.DigitalChannelGroupKey
			,src.ChannelSource
			,src.ChannelMedium
			,src.ChannelCampaign
			,src.ChannelIsBranded
			,src.ChannelBusinessLine
			,src.ChannelProductType
			,src.ChannelTargetAudience
			,src.ChannelReferringSite
			,src.ChannelEmailGroup
			,src.ChannelLeadNurturingGroup
			,src.ChannelLeadNurturingStage
			,src.ChannelMeledition
			,src.InsertedDate
			,src.InsertedBy
			,src.ModifiedDate
			,src.ModifiedBy
			
		)
	OUTPUT $ACTION as ActionType, src.*;
	SET IDENTITY_INSERT dbo.DimDigitalChannel OFF
COMMIT TRANSACTION