

DECLARE @TMP_DimDigitalTouchpointMetadata TABLE
( 
	[DigitalTouchpointMetadataKey]		int  NOT NULL,
	[DigitalTouchpointMetadataHash] binary(20) NOT NULL,
	[DigitalChannelKey]		int  NULL ,
	[TouchpointAccountId]		int  NULL ,
	[TouchpointProfileId]		int  NULL ,
	[TouchpointSegment]		varchar(50)  NULL ,
	[DigitalDeviceCategoryKey]		int  NULL ,
	[TouchpointCityId]		int  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50) NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)


INSERT INTO @TMP_DimDigitalTouchpointMetadata (
	DigitalTouchpointMetadataKey
	,DigitalTouchpointMetadataHash
	,DigitalChannelKey
	,TouchpointAccountId
	,TouchpointProfileId
	,TouchpointSegment
	,DigitalDeviceCategoryKey
	,TouchpointCityId
	,InsertedDate
	,InsertedBy
	,ModifiedDate
	,ModifiedBy
)
VALUES (
	-1
	,HASHBYTES('SHA1', '-1-1-1N/A-1-1')
	,-1
	,-1
	,-1
	,'N/A'
	,-1
	,-1
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
)BEGIN TRANSACTION
	SET IDENTITY_INSERT dbo.DimDigitalTouchpointMetadata ON 
	MERGE dbo.DimDigitalTouchpointMetadata AS dst
	USING @TMP_DimDigitalTouchpointMetadata as src
		ON dst.DigitalTouchpointMetadataKey = src.DigitalTouchpointMetadataKey
	WHEN NOT MATCHED THEN
		INSERT (
			DigitalTouchpointMetadataKey
			,DigitalTouchpointMetadataHash
			,DigitalChannelKey
			,TouchpointAccountId
			,TouchpointProfileId
			,TouchpointSegment
			,DigitalDeviceCategoryKey
			,TouchpointCityId
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
			)
		VALUES (
			src.DigitalTouchpointMetadataKey
			,src.DigitalTouchpointMetadataHash
			,src.DigitalChannelKey
			,src.TouchpointAccountId
			,src.TouchpointProfileId
			,src.TouchpointSegment
			,src.DigitalDeviceCategoryKey
			,src.TouchpointCityId
			,src.InsertedDate
			,src.InsertedBy
			,src.ModifiedDate
			,src.ModifiedBy
			
		)
	OUTPUT $ACTION as ActionType, src.*;
	SET IDENTITY_INSERT dbo.DimDigitalTouchpointMetadata OFF
COMMIT TRANSACTION