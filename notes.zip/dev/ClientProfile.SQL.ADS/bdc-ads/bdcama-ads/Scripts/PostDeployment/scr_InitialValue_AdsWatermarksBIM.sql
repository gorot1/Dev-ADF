DECLARE @TMP_AdsWatermarksBIM TABLE
( 
	[LOB] [varchar](255) NULL,
	[TargetSystem] [varchar](255) NULL,
	[TargetTableName] [varchar](255) NOT NULL,
	[TargetTableType] [varchar](20) NULL,
	[SourceSystem] [varchar](255) NULL,
	[SourceTableName] [varchar](255) NULL,
	[SourceWatermarkColumn] [varchar](255) NULL,
	[SourceWatermarkValue] [varchar](30) NULL,
	[SourceColumns] [varchar](6000) NULL,  -- [SourceColumns]: columns of the source table needed to be copied (except [SourceWatermarkColumn])
	[SourceFilter] [varchar](6000) NULL,  -- Where clause
	[RawSourceSystem] [varchar](255) NULL,
	[Enabled] [bit] NULL, -- 1: enabled, 0: disabled 
	[LoadType] [varchar](20) NULL,
	[LoadSequence] [integer] NULL,
	[Status] [varchar](20) NULL,
	[Comment] [varchar](255) NULL,
	[InsertedDate]		[datetime]	NULL,
	[InsertedBy]		[varchar](50) NULL,
	[ModifiedDate]		[datetime]	NULL,
	[ModifiedBy]		[varchar](50)	NULL

)

INSERT INTO @TMP_AdsWatermarksBIM
VALUES 
-- GA
('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalChannel', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimChannelGrouping', 'entity_modified_on', NULL, 'DISTINCT source as ChannelSource, medium as ChannelMedium, campaign as ChannelCampaign', NULL, 'Google Analytics', 1, 'SCD1', 1, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalChannel', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimGoalsEntity', 'entity_event_date', NULL, 'DISTINCT source as ChannelSource, medium as ChannelMedium, campaign as ChannelCampaign', NULL, 'Google Analytics', 1, 'SCD1', 2, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalChannel', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimAdwords', 'entity_event_date', NULL, 'DISTINCT source as ChannelSource, medium as ChannelMedium, campaign as ChannelCampaign', NULL, 'Google Analytics', 1, 'SCD1', 3, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalChannel', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimEventContainer', 'entity_event_date', NULL, 'DISTINCT source as ChannelSource, medium as ChannelMedium, campaign as ChannelCampaign', NULL, 'Google Analytics', 1, 'SCD1', 4, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalChannel', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimEvents', 'entity_event_date', NULL, 'DISTINCT source as ChannelSource, medium as ChannelMedium, campaign as ChannelCampaign', NULL, 'Google Analytics', 1, 'SCD1', 5, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalChannel', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimPageViews', 'entity_event_date', NULL, 'DISTINCT source as ChannelSource, medium as ChannelMedium, campaign as ChannelCampaign', NULL, 'Google Analytics', 1, 'SCD1', 6, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalChannel', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimVisitsEntity', 'entity_event_date', NULL, 'DISTINCT source as ChannelSource, medium as ChannelMedium, campaign as ChannelCampaign', NULL, 'Google Analytics', 1, 'SCD1', 7, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalDeviceCategory', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimGoalsEntity', 'entity_event_date', NULL, 'DISTINCT deviceCategory as DeviceCategoryName', NULL, 'Google Analytics', 1, 'SCD1', 1, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalDeviceCategory', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimPageViews', 'entity_event_date', NULL, 'DISTINCT deviceCategory as DeviceCategoryName', NULL, 'Google Analytics', 1, 'SCD1', 2, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalDeviceCategory', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimVisitsEntity', 'entity_event_date', NULL, 'DISTINCT deviceCategory as DeviceCategoryName', NULL, 'Google Analytics', 1, 'SCD1', 3, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalTouchpointMetadata', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimAdwords', 'entity_event_date', NULL, 'DISTINCT source, medium, campaign, accountID as TouchpointAccountId, profileID as TouchpointProfileId, /*segment*/ NULL as TouchpointSegment, NULL as DigitalDeviceCategory,  NULL as TouchpointCityId', NULL, 'Google Analytics', 1, 'SCD1', 8, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalTouchpointMetadata', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimEventContainer', 'entity_event_date', NULL, 'DISTINCT source, medium, campaign, accountID as TouchpointAccountId, profileID as TouchpointProfileId, ''All Users'' as TouchpointSegment, '''' as DigitalDeviceCategory, NULL as TouchpointCityId', NULL, 'Google Analytics', 1, 'SCD1', 9, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalTouchpointMetadata', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimEvents', 'entity_event_date', NULL, 'DISTINCT source, medium, campaign, accountID as TouchpointAccountId, profileID as TouchpointProfileId, segment as TouchpointSegment, '''' as DigitalDeviceCategory, NULL as TouchpointCityId', NULL, 'Google Analytics', 1, 'SCD1', 10, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalTouchpointMetadata', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimGoalsEntity', 'entity_event_date', NULL, 'DISTINCT source, medium, campaign, accountID as TouchpointAccountId, profileID as TouchpointProfileId, segment as TouchpointSegment, deviceCategory as DigitalDeviceCategory,  cityid as TouchpointCityId', NULL, 'Google Analytics', 1, 'SCD1', 11, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalTouchpointMetadata', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimPageViews', 'entity_event_date', NULL, 'DISTINCT source, medium, campaign, accountID as TouchpointAccountId, profileID as TouchpointProfileId, segment as TouchpointSegment, deviceCategory as DigitalDeviceCategory,  cityid as TouchpointCityId', NULL, 'Google Analytics', 1, 'SCD1', 12, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalTouchpointMetadata', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimVisitsEntity', 'entity_event_date', NULL, 'DISTINCT source, medium, campaign, accountID as TouchpointAccountId, profileID as TouchpointProfileId, segment as TouchpointSegment, deviceCategory as DigitalDeviceCategory,  cityid as TouchpointCityId', NULL, 'Google Analytics', 1, 'SCD1', 13, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimWebAdInfo', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimAdwords', 'entity_event_date', NULL, 'DISTINCT adContent as AdContent, keyword as adKeyword', NULL, 'Google Analytics', 1, 'SCD1', 1, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimWebPage', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimPages', 'entity_modified_on', NULL, 'DISTINCT HASHBYTES(''SHA1'', ISNULL(hostname, '''') + ISNULL(pagePath, '''')) WebPageHash, hostname, pagePath', NULL, 'Google Analytics', 1, 'SCD1', 1, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimWebPage', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimGoalsEntity', 'entity_event_date', NULL, 'DISTINCT HASHBYTES(''SHA1'', ISNULL(hostname, '''') + ISNULL(landingPagePath, '''')) WebPageHash, hostname, landingPagePath as pagePath', NULL, 'Google Analytics', 1, 'SCD1', 2, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimWebPage', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimEventContainer', 'entity_event_date', NULL, 'DISTINCT HASHBYTES(''SHA1'', ISNULL(hostname, '''') + ISNULL(pagePath, '''')) WebPageHash, hostname, pagePath', NULL, 'Google Analytics', 1, 'SCD1', 3, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimWebPage', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimEvents', 'entity_event_date', NULL, 'DISTINCT HASHBYTES(''SHA1'', ISNULL(hostname, '''') + ISNULL(pagePath, '''')) WebPageHash, hostname, pagePath', NULL, 'Google Analytics', 1, 'SCD1', 4, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimWebPage', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimPageViews', 'entity_event_date', NULL, 'DISTINCT HASHBYTES(''SHA1'', ISNULL(hostname, '''') + ISNULL(pagePath, '''')) WebPageHash, hostname, pagePath', NULL, 'Google Analytics', 1, 'SCD1', 5, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimWebPage', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimVisitsEntity', 'entity_event_date', NULL, 'DISTINCT HASHBYTES(''SHA1'', ISNULL(hostname, '''') + ISNULL(pagePath, '''')) WebPageHash, hostname, pagePath', NULL, 'Google Analytics', 1, 'SCD1', 6, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimWebPage', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimVisitsEntity', 'entity_event_date', NULL, 'DISTINCT HASHBYTES(''SHA1'', ISNULL(hostname, '''') + ISNULL(landingPagePath, '''')) WebPageHash, hostname, landingPagePath as pagePath', NULL, 'Google Analytics', 1, 'SCD1', 7, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimWebPageEventInfo', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimEvents', 'entity_event_date', NULL,'DISTINCT  HASHBYTES(''SHA1'', ''events'' + ISNULL(eventCategory, '''') + ISNULL(eventAction, '''') + ISNULL(eventLabel, '''') + '''') WebPageEventInfoHash, ''events'' EventEntityType, eventCategory, eventAction, eventLabel, '''' EventContainer', NULL, 'Google Analytics', 1, 'SCD1', 1, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimWebPageEventInfo', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimEventContainer', 'entity_event_date', NULL, 'DISTINCT  HASHBYTES(''SHA1'', ''eventContainer'' + ISNULL(eventCategory, '''') + ISNULL(eventAction, '''') + ISNULL(eventLabel, '''') + dimension25) WebPageEventInfoHash, ''eventContainer'' EventEntityType, eventCategory, eventAction, eventLabel, dimension25 EventContainer', NULL, 'Google Analytics', 1, 'SCD1', 2, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())

,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalChannelGroup', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimChannelGrouping',  NULL, NULL, 'source, medium, campaign', NULL, 'Google Analytics', 0, 'Static', NULL, NULL, 'Predefined in the function fn_GetChannelGroupName', getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalMetricGroup', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimGoalsEntity, dbo.EloquaExpressConsentsEntity, dbo.EloquaVBCEntity',  NULL, NULL, 'source, medium and campain from the GA entity, all metric fields from the two Eloqua entities', NULL, 'Google Analytics', 0, 'Static', NULL, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalMetricInfo', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimGoalsEntity, dbo.EloquaExpressConsentsEntity, dbo.EloquaVBCEntity', NULL, NULL, 'goalNumber from the Ga entity, all metric fields from the two Eloqua entities',  NULL, 'Google Analytics, Eloqua', 0, 'Static', NULL, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalTouchpointGroup', 'Dimension', 'ODS Azure SQL Database', 'dbo.FactWebGoal, dbo.FactWebPageEvent, dbo.FactWebPageView, dbo.FactWebPageVisit, dbo.FactWebAd, dbo.FactWebSearch, dbo.FactEmailsSent', NULL, NULL, NULL, NULL, 'Google Analytics, Eloqua, Google Search Console, Custom files', 0, 'Static', NULL, NULL, 'All related fact tables in ADS; Predefined groups by Matthieu ROY', getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalTouchpointMetrics', 'Dimension', 'ODS Azure SQL Database', 'dbo.FactWebGoal, dbo.FactWebPageEvent, dbo.FactWebPageView, dbo.FactWebPageVisit, dbo.FactWebAd, dbo.FactWebSearch, dbo.FactEmailsSent', NULL, NULL, 'Metric columns from each source fact table', NULL, 'Google Analytics, Eloqua, Google Search Console, Custom files', 0, 'Static', NULL, NULL, 'All related fact tables in ADS', getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimWebPageParameterGroup', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimPageViews',  NULL, NULL, 'pagePath', NULL, 'Google Analytics', 0, 'Static', NULL, NULL, 'Predefined groups', getdate(), USER_NAME(), getdate(), USER_NAME())

,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalCityMapping', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaReferenceCityMapping', 'entity_modified_on', NULL, 'DISTINCT cityid DigitalCityMappingKey, city CityName, region ProvinceName', 'cityid IS NOT NULL', 'Google Analytics', 1, 'SCD1', 2, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalCityMapping', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimGoalsEntity', 'entity_event_date', NULL, 'DISTINCT cityid DigitalCityMappingKey, NULL CityName, NULL ProvinceName', 'cityid IS NOT NULL', 'Google Analytics', 1, 'SCD1', 3, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalCityMapping', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimPageViews', 'entity_event_date', NULL, 'DISTINCT cityid DigitalCityMappingKey, NULL CityName, NULL ProvinceName', 'cityid IS NOT NULL', 'Google Analytics', 1, 'SCD1', 4, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalCityMapping', 'Dimension', 'ODS Azure SQL Database', 'dbo.GaBimVisitsEntity', 'entity_event_date', NULL, 'DISTINCT cityid DigitalCityMappingKey, NULL CityName, NULL ProvinceName', 'cityid IS NOT NULL', 'Google Analytics', 1, 'SCD1', 5, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())

,('Marketing', 'ADS Azure SQL Database', 'dbo.FactWebAd', 'Fact', 'ODS Azure SQL Database', 'dbo.GaBimAdwords',  'entity_event_date', NULL, 'entity_event_date, source, medium, campaign, accountID, profileID, segment, adContent AdContent, keyword AdKeyword, ISNULL(adCost, 0) AdCost, ISNULL(adClicks, 0) AdClickCount, ISNULL(impressions, 0) AdImpressionCount, ISNULL(timeOnPage, 0) AdSecondsOnPage', NULL, 'Google Analytics', 1, 'Upsert',1, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())

,('Marketing', 'ADS Azure SQL Database', 'dbo.FactWebGoal', 'Fact', 'ODS Azure SQL Database', 'dbo.GaBimGoalsEntity',  'entity_event_date', NULL, 'entity_event_date, cast(replace(convert(varchar(5), dateHourMinute, 108), '':'', '''') as int) TimeKey, hostname, landingPagePath, source, medium, campaign, accountID, profileID, segment, deviceCategory, cityid, goalNumber, ISNULL(goalStarts, 0) as goalStarts, ISNULL(goalCompletions, 0) as goalCompletions', 'ISNULL(goalStarts, 0) > 0 OR ISNULL(goalCompletions, 0) > 0', 'Google Analytics', 1, 'Upsert', 1, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.FactWebPageView', 'Fact', 'ODS Azure SQL Database', 'dbo.GaBimPageViews',  'entity_event_date', NULL, 'entity_event_date, cast(replace(convert(varchar(5), dateHourMinute, 108), '':'', '''') as int) TimeKey, hostname, pagePath, source, medium, campaign, accountID, profileID, segment, deviceCategory, cityid, ISNULL(entrances, 0) PageViewEntrances, ISNULL(exits, 0) PageViewExits, ISNULL(pageviews, 0) PageViewCount, ISNULL(uniquePageviews, 0) PageViewUniqueCount', NULL, 'Google Analytics', 1, 'Upsert', 1, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.FactWebPageVisit', 'Fact', 'ODS Azure SQL Database', 'dbo.GaBimVisitsEntity',  'entity_event_date', NULL, 'entity_event_date, cast(replace(convert(varchar(5), dateHourMinute, 108), '':'', '''') as int) TimeKey, hostname, landingPagePath, pagePath, source, medium, campaign, accountID, profileID, segment, deviceCategory, cityid, ISNULL(sessions, 0) VisitSessionCount, ISNULL(sessionDuration, 0) VisitSessionDurationSeconds, ISNULL(bounces, 0) VisitBouncesCount', NULL, 'Google Analytics', 1, 'Upsert', 1, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.FactWebPageEvent', 'Fact', 'ODS Azure SQL Database', 'dbo.GaBimEvents',  'entity_event_date', NULL, 'entity_event_date, cast(replace(convert(varchar(5), dateHourMinute, 108), '':'', '''') as int) TimeKey, hostname, pagePath, source, medium, campaign, accountID, profileID, segment,  ''events'' EventEntityType, eventCategory, eventAction, eventLabel, '''' EventContainer, ISNULL(totalEvents, 0) EventCount, ISNULL(uniqueEvents, 0) EventUniqueCount', NULL, 'Google Analytics', 1, 'Upsert', 1, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.FactWebPageEvent', 'Fact', 'ODS Azure SQL Database', 'dbo.GaBimEventContainer',  'entity_event_date', NULL, 'entity_event_date, cast(replace(convert(varchar(5), dateHourMinute, 108), '':'', '''') as int) TimeKey, hostname, pagePath, source, medium, campaign, accountID, profileID, ''All Users'' segment,  ''eventContainer'' EventEntityType, eventCategory, eventAction, eventLabel, dimension25 EventContainer, ISNULL(totalEvents, 0) EventCount, 0 EventUniqueCount', NULL, 'Google Analytics', 1, 'Upsert', 2, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())


,('Marketing', 'ADS Azure SQL Database', 'dbo.FactDigitalTouchpoint', 'Fact', 'ADS Azure SQL Database', 'dbo.FactWebAd', 'AdDateKey', NULL, 'AdDateKey TouchpointDateKey, NULL TouchpointTimeKey, ''dbo.FactWebAd'' TouchpointSourceTableName, WebAdKey TouchpointRowKey, ''AdCost'' MetricName1, DigitalTouchpointMetadataKey, AdCost MetricValue1, AdClickCount MetricValue2, AdImpressionCount MetricValue3, AdSecondsOnPage MetricValue4, NULL MetricValue5', NULL, 'Google Analytics', 1, 'Upsert', 2, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.FactDigitalTouchpoint', 'Fact', 'ADS Azure SQL Database', 'dbo.FactWebPageEvent',  'PageEventDateKey', NULL, 'PageEventDateKey TouchpointDateKey, PageEventTimeKey TouchpointTimeKey, ''dbo.FactWebPageEvent'' TouchpointSourceTableName, PageEventKey TouchpointRowKey, ''EventCount'' MetricName1, DigitalTouchpointMetadataKey, EventCount MetricValue1, EventUniqueCount MetricValue2, NULL MetricValue3, NULL MetricValue4, NULL MetricValue5', NULL, 'Google Analytics', 1, 'Upsert', 3, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.FactDigitalTouchpoint', 'Fact', 'ADS Azure SQL Database', 'dbo.FactWebPageVisit',  'VisitDateKey', NULL, 'VisitDateKey TouchpointDateKey, VisitTimeKey TouchpointTimeKey, ''dbo.FactWebPageVisit'' TouchpointSourceTableName, WebPageVisitKey TouchpointRowKey, ''VisitSessionCount'' MetricName1, DigitalTouchpointMetadataKey, VisitSessionCount MetricValue1, VisitSessionDurationSeconds MetricValue2, VisitBouncesCount MetricValue3, NULL MetricValue4, NULL MetricValue5', NULL, 'Google Analytics', 1, 'Upsert', 4, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.FactDigitalTouchpoint', 'Fact', 'ADS Azure SQL Database', 'dbo.FactWebPageView',  'PageViewDateKey', NULL, 'PageViewDateKey TouchpointDateKey, PageViewTimeKey TouchpointTimeKey, ''dbo.FactWebPageView'' TouchpointSourceTableName, WebPageViewKey TouchpointRowKey, ''PageViewEntrances'' MetricName1, DigitalTouchpointMetadataKey, PageViewEntrances MetricValue1, PageViewExits MetricValue2, PageViewCount MetricValue3, PageViewUniqueCount MetricValue4, NULL MetricValue5', NULL, 'Google Analytics', 1, 'Upsert', 5, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.FactDigitalTouchpoint', 'Fact', 'ADS Azure SQL Database', 'dbo.FactWebGoal', 'WebGoalDateKey', NULL, 'WebGoalDateKey TouchpointDateKey, WebGoalTimeKey TouchpointTimeKey, ''dbo.FactWebGoal'' TouchpointSourceTableName, WebGoalKey TouchpointRowKey, ''GoalStartsValue'' MetricName1, DigitalTouchpointMetadataKey,  GoalStartsValue MetricValue1, GoalCompletionsValue MetricValue2, NULL MetricValue3, NULL MetricValue4, NULL MetricValue5', NULL, 'Google Analytics', 1, 'Upsert', 6, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())


,('Marketing', 'ADS Azure SQL Database', 'dbo.FactDigitalMetric', 'Fact', 'ODS Azure SQL Database', 'dbo.GaBimGoalsEntity',  'entity_event_date', NULL, 'entity_event_date MetricStartDate, entity_event_date MetricEndDate, ''dbo.GaBimGoalsEntity'' MetricSourceTableName, source, medium, campaign, CASE goalNumber WHEN 12 THEN ''Consulting Form Goal Completions'' WHEN 18 THEN ''Financing Form Goal Completions'' WHEN 16 THEN ''SBL BDC Goal Completions'' WHEN 17 THEN ''SBL Connex Goal Completions'' END MetricName, NULL MetricRowKey, ISNULL(goalCompletions, 0) MetricActualValue, NULL MetricTargetValue', 'ISNULL(goalCompletions, 0)>0 AND segment = ''All Users'' AND goalNumber in (12, 16, 17, 18)', 'Google Analytics', 1, 'Upsert',1, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())

--Eloqua
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalFormInfo', 'Dimension', 'ODS Azure SQL Database', 'dbo.EloquaBimFormEntity', 'entity_modified_on', NULL, 'DISTINCT Landing_Page_Origin as FormName, FormType, Landing_Page_Origin as FormOfficialName', 'Landing_Page_Origin IS NOT NULL', 'Eloqua', 1, 'SCD1', 1, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())

,('Marketing', 'ADS Azure SQL Database', 'dbo.FactDigitalForm', 'Fact', 'ODS Azure SQL Database', 'dbo.EloquaBimFormEntity',  'entity_modified_on', NULL, 'Landing_Page_Origin as FormName, FormType, cast(submittedAt as date) FormSubmissionDate', 'Email_Address IS NOT NULL', 'Eloqua', 1, 'Upsert',1, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.FactDigitalMetric', 'Fact', 'ODS Azure SQL Database', 'dbo.EloquaBimExpressConsentsEntity',  'entity_modified_on', NULL, 'entity_event_date MetricStartDate, entity_event_date MetricEndDate, ''dbo.EloquaBimExpressConsentsEntity'' MetricSourceTableName, ExpressConsents, InBusiness, LeadNurturing, ClientNurturing, MEL, Newsletters, Partners, Profits, UniqueEmailSubscribers, ISNULL(LeadAndClientNurturingCombined, 0)  Nurturing', NULL, 'Eloqua', 1, 'Upsert',2, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.FactDigitalMetric', 'Fact', 'ODS Azure SQL Database', 'dbo.EloquaBimVBCEntity',  'entity_modified_on', NULL, 'entity_event_date MetricStartDate, entity_event_date MetricEndDate, ''dbo.EloquaBimVBCEntity'' MetricSourceTableName, OnboardedClients, ActiveClients, ClientsRemainingToOnboardUnsupportedAms, ClientsRemainingToOnboardSupportedAms, AutomatedOnboardableClients, VBCClients', NULL, 'Eloqua', 1, 'Upsert',3, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())

--GSC
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimWebPage', 'Dimension', 'ODS Azure SQL Database', 'dbo.GscBimAllSearches', 'entity_event_date', NULL, 'DISTINCT HASHBYTES(''SHA1'', ISNULL(page, '''')) WebPageHash, LEFT(siteURL, 18) hostname, RIGHT(page, LEN(page)-18) pagePath', NULL, 'Google Search Console', 1, 'SCD1', 8, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalDeviceCategory', 'Dimension', 'ODS Azure SQL Database', 'dbo.GscBimAllSearches', 'entity_event_date', NULL, 'DISTINCT LOWER(device) as DeviceCategoryName', NULL, 'Google Search Console', 1, 'SCD1', 4, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalTouchpointMetadata', 'Dimension', 'ODS Azure SQL Database', 'dbo.GscBimAllSearches', 'entity_event_date', NULL, 'DISTINCT ''google'' source, ''organic'' medium, ''(not set)'' campaign, -1 as TouchpointAccountId, -1 as TouchpointProfileId, '''' as TouchpointSegment, LOWER(device) as DigitalDeviceCategory,  -1 as TouchpointCityId', NULL, 'Google Search Console', 1, 'SCD1', 14, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimWebSearchInfo', 'Dimension', 'ODS Azure SQL Database', 'dbo.GscBimAllSearches', 'entity_event_date', NULL, 'DISTINCT HASHBYTES(''SHA1'', ISNULL(query, '''')+ISNULL(country, '''')+ISNULL(searchType, '''')) WebSearchInfoHash, query SearchQuery, country SearchCountry, searchType SearchType', NULL, 'Google Search Console', 1, 'SCD1', 1, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())

,('Marketing', 'ADS Azure SQL Database', 'dbo.FactWebSearch', 'Fact', 'ODS Azure SQL Database', 'dbo.GscBimAllSearches', 'entity_event_date', NULL, 'entity_event_date, searchType SearchType, page as pageFullPath, LOWER(device) as DeviceCategoryName, country SearchCountry, query SearchQuery, clicks SearchClickCount, ctr SearchClickthroughRate, impressions SearchImpressionCount, position SearchPosition', NULL, 'Google Search Console', 1, 'Upsert', 1, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())


--Custom files
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimWebPage', 'Dimension', 'ODS Azure SQL Database', 'dbo.BimCustomTaxonomyWebPagesEntity', 'entity_modified_on', NULL, 'DISTINCT HASHBYTES(''SHA1'', ''bdc.ca''+ISNULL(NEW_relative_URL, '''')) WebPageHash, ''bdc.ca'' hostname, NEW_relative_URL AS pagePath', 'NEW_relative_URL IS NOT NULL', 'Custom file', 1, 'SCD1', 9, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimWebPage', 'Dimension', 'ODS Azure SQL Database', 'dbo.BimCustomTaxonomyWebPagesEntity', 'entity_modified_on', NULL, 'DISTINCT HASHBYTES(''SHA1'', ''bdc.ca''+ISNULL(Page_path, '''')) WebPageHash, ''bdc.ca'' hostname, Page_path AS pagePath, HASHBYTES(''SHA1'', ''bdc.ca''+ISNULL(NEW_relative_URL, '''')) NewWebPageHash', 'Page_path IS NOT NULL', 'Custom file', 1, 'SCD1', 10, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimWebPage', 'Dimension', 'ODS Azure SQL Database', 'dbo.BimCustomAcademyMatrixEntity', 'entity_modified_on', NULL, 'DISTINCT HASHBYTES(''SHA1'', ''bdc.ca''+ISNULL(page_en, '''')) WebPageHash, ''bdc.ca'' hostname, page_en AS pagePath', 'page_en IS NOT NULL', 'Custom file', 1, 'SCD1', 11, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimWebPage', 'Dimension', 'ODS Azure SQL Database', 'dbo.BimCustomAcademyMatrixEntity', 'entity_modified_on', NULL, 'DISTINCT HASHBYTES(''SHA1'', ''bdc.ca''+ISNULL(page_fr, '''')) WebPageHash, ''bdc.ca'' hostname, page_fr AS pagePath', 'page_fr IS NOT NULL', 'Custom file', 1, 'SCD1', 12, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimDigitalProvinceMapping', 'Dimension', 'ODS Azure SQL Database', 'dbo.BimCustomProvinceMappingEntity', 'entity_modified_on', NULL, 'DISTINCT Province ProvinceNameEn, ProvinceCode, RegionBDC RegionBDCEn, FSAProvince, ProvinceFr ProvinceNameFr, RegionBDCFr', NULL, 'Custom file', 1, 'SCD1', 1, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())




--Epi Server + TaxonomyWebPages + AcademyMatrix
,('Marketing', 'ADS Azure SQL Database', 'dbo.DimWebContent', 'Dimension', 'ODS Azure SQL Database', 'dbo.vwAMADimWebContent', NULL, NULL, 'DISTINCT *', NULL, 'Epi Server, TaxonomyWebPages, AcademyMatrix ', 1, 'Full Load', 13, NULL, NULL, getdate(), USER_NAME(), getdate(), USER_NAME())

BEGIN TRANSACTION
	MERGE dbo.AdsWatermarksBIM AS dst
	USING @TMP_AdsWatermarksBIM as src
		ON dst.[TargetTableName] = src.[TargetTableName] AND 
		((dst.[SourceTableName] = src.[SourceTableName]) OR ((dst.[SourceTableName] IS NULL) AND (src.[SourceTableName] IS NULL))) AND 
		((dst.[SourceColumns] = src.[SourceColumns]) OR ((dst.[SourceColumns] IS NULL) AND (src.[SourceColumns] IS NULL)))
	WHEN MATCHED THEN
		UPDATE SET
			[LoadSequence] = src.[LoadSequence]
			,[Enabled] = src.[Enabled]
			,[LoadType] = src.[LoadType]
			,[SourceFilter] = src.[SourceFilter]
			,[RawSourceSystem] = src.[RawSourceSystem]
			,[SourceWatermarkColumn] = src.[SourceWatermarkColumn]
			,ModifiedDate = GETDATE()
			,ModifiedBy = src.ModifiedBy
	WHEN NOT MATCHED THEN
		INSERT (
			LOB
			,TargetSystem
			,TargetTableName
			,TargetTableType
			,SourceSystem
			,SourceTableName
			,SourceWatermarkColumn
			,SourceWatermarkValue
			,SourceColumns
			,SourceFilter
			,RawSourceSystem
			,Enabled
			,LoadType
			,LoadSequence
			,Status
			,Comment
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
			)
		VALUES (
			src.LOB
			,src.TargetSystem
			,src.TargetTableName
			,src.TargetTableType
			,src.SourceSystem
			,src.SourceTableName
			,src.SourceWatermarkColumn
			,src.SourceWatermarkValue
			,src.SourceColumns
			,src.SourceFilter
			,src.RawSourceSystem
			,src.Enabled
			,src.LoadType
			,src.LoadSequence
			,src.Status
			,src.Comment
			,src.InsertedDate
			,src.InsertedBy
			,src.ModifiedDate
			,src.ModifiedBy	
		)
	OUTPUT $ACTION as ActionType, src.*;

COMMIT TRANSACTION
GO