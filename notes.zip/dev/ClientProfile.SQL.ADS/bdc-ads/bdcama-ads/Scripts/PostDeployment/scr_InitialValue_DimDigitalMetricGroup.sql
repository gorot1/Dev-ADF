

DECLARE @TMP_DimDigitalMetricGroup TABLE
( 
	[DigitalMetricGroupKey]		int  NOT NULL,
	[MetricSourceTableName]		nvarchar(50)  NULL ,
	[MetricGroupName]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50) NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)


INSERT INTO @TMP_DimDigitalMetricGroup (
	DigitalMetricGroupKey
	,MetricSourceTableName
	,MetricGroupName
	,InsertedDate
	,InsertedBy
	,ModifiedDate
	,ModifiedBy
)
VALUES (
	-1
	,'N/A'
	,'N/A'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	1
	,'dbo.GaBimGoalsEntity'
	,'Native Ads'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	2
	,'dbo.GaBimGoalsEntity'
	,'Direct'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	3
	,'dbo.GaBimGoalsEntity'
	,'Social Media'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	4
	,'dbo.GaBimGoalsEntity'
	,'Non-Paid Search'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	5
	,'dbo.GaBimGoalsEntity'
	,'Email'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	6
	,'dbo.GaBimGoalsEntity'
	,'Paid Search'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	7
	,'dbo.GaBimGoalsEntity'
	,'Referral'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	8
	,'dbo.GaBimGoalsEntity'
	,'Display'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	9
	,'dbo.EloquaBimExpressConsentsEntity'
	,'Client Nurturing'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	10
	,'dbo.EloquaBimExpressConsentsEntity'
	,'Express Consents'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),

(
	11
	,'dbo.EloquaBimExpressConsentsEntity'
	,'In Business'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	12
	,'dbo.EloquaBimExpressConsentsEntity'
	,'Lead Nurturing'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	13
	,'dbo.EloquaBimExpressConsentsEntity'
	,'MEL'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	14
	,'dbo.EloquaBimExpressConsentsEntity'
	,'Newsletters'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),

(
	15
	,'dbo.EloquaBimExpressConsentsEntity'
	,'Partners'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	16
	,'dbo.EloquaBimExpressConsentsEntity'
	,'Profits'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	17
	,'dbo.EloquaBimExpressConsentsEntity'
	,'Unique Email Subscribers'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	18
	,'dbo.EloquaBimVBCEntity'
	,'Active Clients'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),

(
	19
	,'dbo.EloquaBimVBCEntity'
	,'Automated Onboardable Clients'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	20
	,'dbo.EloquaBimVBCEntity'
	,'Clients Remaining to Onboard Supported Ams'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	21
	,'dbo.EloquaBimVBCEntity'
	,'Clients Remaining to Onboard Unsupported Ams'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	22
	,'dbo.EloquaBimVBCEntity'
	,'Onboarded Clients'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	23
	,'dbo.EloquaBimVBCEntity'
	,'VBC Clients'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
)


BEGIN TRANSACTION
	SET IDENTITY_INSERT dbo.DimDigitalMetricGroup ON 
	MERGE dbo.DimDigitalMetricGroup AS dst
	USING @TMP_DimDigitalMetricGroup as src
		ON dst.DigitalMetricGroupKey = src.DigitalMetricGroupKey
	WHEN MATCHED THEN
		UPDATE SET
			MetricSourceTableName = src.MetricSourceTableName
			,MetricGroupName = src.MetricGroupName
			,ModifiedDate = GETDATE()
			,ModifiedBy = src.ModifiedBy

	WHEN NOT MATCHED THEN
		INSERT (
			DigitalMetricGroupKey
			,MetricSourceTableName
			,MetricGroupName
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
			)
		VALUES (
			src.DigitalMetricGroupKey
			,src.MetricSourceTableName
			,src.MetricGroupName
			,src.InsertedDate
			,src.InsertedBy
			,src.ModifiedDate
			,src.ModifiedBy
			
		)
	OUTPUT $ACTION as ActionType, src.*;
	SET IDENTITY_INSERT dbo.DimDigitalMetricGroup OFF
COMMIT TRANSACTION