

DECLARE @TMP_DimDigitalTouchpointGroup TABLE
( 
	[DigitalTouchpointGroupKey]		int  NOT NULL,
	[TouchpointSourceTableName]		nvarchar(50)  NULL ,
	[TouchpointGroupName]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50) NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)


INSERT INTO @TMP_DimDigitalTouchpointGroup (
	DigitalTouchpointGroupKey
	,TouchpointSourceTableName
	,TouchpointGroupName
	,InsertedDate
	,InsertedBy
	,ModifiedDate
	,ModifiedBy
)
VALUES (
	-1
	,'N/A'
	,'N/A'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	1
	,'dbo.FactWebGoal'
	,'Goal'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	2
	,'dbo.FactWebPageEvent'
	,'Event'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	3
	,'dbo.FactWebPageView'
	,'Pageview'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	4
	,'dbo.FactWebPageVisit'
	,'Visit'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	5
	,'dbo.FactWebAd'
	,'Visit'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	6
	,'dbo.FactWebSearch'
	,'Search'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	7
	,'dbo.FactEmailsSent'
	,'Email'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
)


BEGIN TRANSACTION
	SET IDENTITY_INSERT dbo.DimDigitalTouchpointGroup ON 
	MERGE dbo.DimDigitalTouchpointGroup AS dst
	USING @TMP_DimDigitalTouchpointGroup as src
		ON dst.DigitalTouchpointGroupKey = src.DigitalTouchpointGroupKey
	WHEN NOT MATCHED THEN
		INSERT (
			DigitalTouchpointGroupKey
			,TouchpointSourceTableName
			,TouchpointGroupName
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
			)
		VALUES (
			src.DigitalTouchpointGroupKey
			,src.TouchpointSourceTableName
			,src.TouchpointGroupName
			,src.InsertedDate
			,src.InsertedBy
			,src.ModifiedDate
			,src.ModifiedBy
			
		)
	OUTPUT $ACTION as ActionType, src.*;
	SET IDENTITY_INSERT dbo.DimDigitalTouchpointGroup OFF
COMMIT TRANSACTION