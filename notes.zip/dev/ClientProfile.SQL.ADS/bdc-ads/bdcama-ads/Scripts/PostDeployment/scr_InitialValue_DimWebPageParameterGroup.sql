

DECLARE @TMP_DimWebPageParameterGroup TABLE
( 
	[WebPageParameterGroupKey]		int  NOT NULL,
	[PageParametersGroupName]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[InsertedBy]		varchar(50) NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)


INSERT INTO @TMP_DimWebPageParameterGroup (
	WebPageParameterGroupKey
	,PageParametersGroupName
	,InsertedDate
	,InsertedBy
	,ModifiedDate
	,ModifiedBy
)
VALUES (
	-1
	,'N/A'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	1
	,'financing_form_step_1_of_5'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	2
	,'financing_form_step_2_of_5'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	3
	,'financing_form_step_3_of_5'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	4
	,'financing_form_step_4_of_5'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	5
	,'financing_form_step_5_of_5'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	6
	,'financing_form_step_1_of_3'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	7
	,'financing_form_step_2_of_3'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
),
(
	8
	,'financing_form_step_3_of_3'
	,GETDATE()
	,USER_NAME()
	,GETDATE()
	,USER_NAME()
)

BEGIN TRANSACTION
	SET IDENTITY_INSERT dbo.DimWebPageParameterGroup ON 
	MERGE dbo.DimWebPageParameterGroup AS dst
	USING @TMP_DimWebPageParameterGroup as src
		ON dst.WebPageParameterGroupKey = src.WebPageParameterGroupKey
	WHEN NOT MATCHED THEN
		INSERT (
			WebPageParameterGroupKey
			,PageParametersGroupName
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
			)
		VALUES (
			src.WebPageParameterGroupKey
			,src.PageParametersGroupName
			,src.InsertedDate
			,src.InsertedBy
			,src.ModifiedDate
			,src.ModifiedBy
			
		)
	OUTPUT $ACTION as ActionType, src.*;
	SET IDENTITY_INSERT dbo.DimWebPageParameterGroup OFF
COMMIT TRANSACTION