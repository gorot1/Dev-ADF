-- =============================================
-- Author:      David Sun
-- Create Date: 2021-02-26
-- Description: Updates DimDigitalCityMapping from tmp_DimDigitalCityMapping
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_DimDigitalCityMapping
AS
BEGIN
	-- ================================================================================== 
	-- update the dim table
	-- ==================================================================================   
	WITH T AS
	(
		SELECT
			t1.DigitalCityMappingKey,
			t1.CityName,
			ISNULL(t2.DigitalProvinceMappingKey, -1) ProvinceId
		FROM 
		(
			SELECT DigitalCityMappingKey, CityName, CAST(ProvinceName AS NVARCHAR) ProvinceName, row_number() over (Partition by [DigitalCityMappingKey]  order by [ProvinceName] asc) as duplicateRecCount
			FROM dbo.tmp_DimDigitalCityMapping
		) t1
		LEFT JOIN dbo.DimDigitalProvinceMapping t2
		ON (t1.ProvinceName = t2.ProvinceNameEn) or (t1.ProvinceName = N'Yukon' AND t2.ProvinceNameEn = N'Yukon Territory')
		WHERE t1.duplicateRecCount<2
	)
	
	MERGE dbo.DimDigitalCityMapping AS dst
	USING T AS src
	ON (dst.DigitalCityMappingKey = src.DigitalCityMappingKey)

	WHEN MATCHED AND (src.CityName IS NOT NULL OR src.ProvinceId <> -1) THEN
		UPDATE SET
			CityName = src.CityName
			,ProvinceId = src.ProvinceId
			,ModifiedDate = GETDATE()
			,ModifiedBy = USER_NAME()

	WHEN NOT MATCHED THEN
		INSERT (
			DigitalCityMappingKey
			,[CityName]
			,[ProvinceId]
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
		)
		VALUES (
			src.DigitalCityMappingKey
			,src.[CityName]
			,src.[ProvinceId]
			,GETDATE()
			,USER_NAME()
			,GETDATE()
			,USER_NAME()
		);
END
GO
