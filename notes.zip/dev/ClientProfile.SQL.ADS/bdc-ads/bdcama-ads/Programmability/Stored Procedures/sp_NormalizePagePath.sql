﻿-- =============================================
-- Author:      David Sun
-- Create Date: 2021-02-05
-- Description: Handles strange unicodes of pagepaths
-- =============================================
CREATE PROCEDURE dbo.sp_NormalizePagePath
(
    @tableName VARCHAR(255),
    @pagePathField VARCHAR(255)
)
AS
BEGIN

    -- remove strange invisible unicode character
	EXEC ('UPDATE ' + @tableName + ' SET ' + @pagePathField + ' = N''/'' WHERE ' + @pagePathField + ' = N''/'';');
	-- dœuvre would cause issue when hash; therefore, replace it with doeuvre
	EXEC ('UPDATE ' + @tableName + ' SET ' + @pagePathField + ' = REPLACE(' + @pagePathField + ', ''doeuvre'', ''doeuvre'') WHERE ' + @pagePathField + ' LIKE N''%doeuvre%'';');

END
GO


