-- =============================================
-- Author:      David Sun
-- Create Date: 2021-02-03
-- Description: Updates FactWebAd from tmp_FactWebAd
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_FactWebAd
AS
BEGIN
	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================   
	EXEC dbo.sp_ResetIdentityKeySeed  @tableName = 'dbo.FactWebAd', @identityKey = 'WebAdKey';
	-- ================================================================================== 
	-- Then update the dim table
	-- ==================================================================================  

	WITH T AS
	(
	SELECT
		t2.DimDateKey AdDateKey,
		ISNULL(t3.WebAdInfoKey, -1) WebAdInfoKey,
		ISNULL(t4.DigitalTouchpointMetadataKey, -1) DigitalTouchpointMetadataKey,
		t1.AdCost,
		t1.AdClickCount,
		t1.AdImpressionCount,
		t1.AdSecondsOnPage
	FROM 
	(
		SELECT
			tmp.entity_event_date,
			HASHBYTES('SHA1', cast(ISNULL(channel.DigitalChannelKey, -1) as varchar)+cast(ISNULL(tmp.accountID, -1) as varchar)+cast(ISNULL(tmp.profileID,-1) as varchar)+/*cast(ISNULL(tmp.segment,'') as varchar)*/+cast(-1 as varchar)+cast(-1 as varchar)) TouchpointMetadataHash,
			WebAdInfoHash, 
			AdCost,
			AdClickCount,
			AdImpressionCount,
			AdSecondsOnPage
			FROM 
			(
				SELECT 
					entity_event_date,accountID, profileID, /*segment,*/
					AdCost, AdClickCount, AdImpressionCount, AdSecondsOnPage,
					HASHBYTES('SHA1', ISNULL(AdContent, '') + ISNULL(AdKeyWord, '')) WebAdInfoHash,
					HASHBYTES('SHA1', ISNULL(source, '')+ISNULL(medium, '')+ISNULL(campaign, '')) ChannelHash
				FROM 
				dbo.tmp_FactWebAd 
			) tmp
			left join dbo.DimDigitalChannel channel on  tmp.ChannelHash = channel.DigitalChannelHash 
	) t1
	LEFT JOIN dbo.DimDate t2 ON t1.entity_event_date = t2.Date
	LEFT JOIN dbo.DimWebAdInfo t3 ON t1.WebAdInfoHash = t3.WebAdInfoHash
	LEFT JOIN dbo.DimDigitalTouchpointMetadata t4 ON t1.TouchpointMetadataHash = t4.DigitalTouchpointMetadataHash
	)
	
	MERGE dbo.FactWebAd AS dst
	USING T AS src
	ON (dst.AdDateKey = src.AdDateKey)
	AND (dst.WebAdInfoKey = src.WebAdInfoKey)
	AND (dst.DigitalTouchpointMetadataKey = src.DigitalTouchpointMetadataKey)
	WHEN MATCHED THEN
		UPDATE SET
			AdCost = src.AdCost
			,AdClickCount = src.AdClickCount
			,AdImpressionCount = src.AdImpressionCount
			,AdSecondsOnPage = src.AdSecondsOnPage
			,ModifiedDate = GETDATE()
			,ModifiedBy = USER_NAME()
	WHEN NOT MATCHED THEN
		INSERT (
			AdDateKey
			,WebAdInfoKey
			,DigitalTouchpointMetadataKey
			,AdCost
			,AdClickCount
			,AdImpressionCount
			,AdSecondsOnPage
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
		)
		VALUES (
			src.AdDateKey
			,src.WebAdInfoKey
			,src.DigitalTouchpointMetadataKey
			,src.AdCost
			,src.AdClickCount
			,src.AdImpressionCount
			,src.AdSecondsOnPage
			,GETDATE()
			,USER_NAME()
			,GETDATE()
			,USER_NAME()
		);
	
END
GO