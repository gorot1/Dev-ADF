CREATE PROCEDURE [dbo].[sp_upsert_FactEmailSent]
AS
--DECLARE @tmp_FactEmailSent TABLE (
--	[FactEmailSentId] [int] IDENTITY(1, 1) NOT NULL
--	,[FactEmailSentKey] [varchar](350) NOT NULL
--	,[EmailDateId] [int] NOT NULL
--	,[EmailInfoId] [int] NOT NULL
--	,[EmailSentCount] [int] NOT NULL
--	,[EmailClickthroughCount] [int] NOT NULL
--	,[EmailUniqueClickthroughCount] [int] NOT NULL
--	,[EmailExistingVisitorClickthroughCount] [int] NOT NULL
--	,[EmailNewVisitorClickthroughCount] [int] NOT NULL
--	,[EmailOpenCount] [int] NOT NULL
--	,[EmailUniqueOpenCount] [int] NOT NULL
--	,[EmailBouncebackCount] [int] NOT NULL
--	,[EmailHardBouncebackCount] [int] NOT NULL
--	,[EmailSoftBouncebackCount] [int] NOT NULL
--	,[EmailFormSubmissionCount] [int] NOT NULL
--	,[EmailUniqueFormSubmissionCount] [int] NOT NULL
--	,[EmailUnsubscribedCount] [int] NOT NULL
--	,[EmailDeliveredCount] [int] NOT NULL
--	--,[_StartDate] [date] NOT NULL
--	--,[_EndDate] [date] NOT NULL
--	,[_KeyHash] [binary](32) NOT NULL
--	,[_ValueHash] [binary](32) NOT NULL
--	,[_InsertDate] [datetime2](7) NOT NULL
--	,[_InsertBy] [varchar](50) NOT NULL
--	,[_UpdateDate] [datetime2](7) NOT NULL
--	,[_UpdateBy] [varchar](50) NOT NULL
	--)

BEGIN
	--INSERT INTO @tmp_FactEmailSent (
	--	[FactEmailSentKey]
	--	,[EmailDateId]
	--	,[EmailInfoId]
	--	,[EmailSentCount]
	--	,[EmailClickthroughCount]
	--	,[EmailUniqueClickthroughCount]
	--	,[EmailExistingVisitorClickthroughCount]
	--	,[EmailNewVisitorClickthroughCount]
	--	,[EmailOpenCount]
	--	,[EmailUniqueOpenCount]
	--	,[EmailBouncebackCount]
	--	,[EmailHardBouncebackCount]
	--	,[EmailSoftBouncebackCount]
	--	,[EmailFormSubmissionCount]
	--	,[EmailUniqueFormSubmissionCount]
	--	,[EmailUnsubscribedCount]
	--	,[EmailDeliveredCount]
	--	--,[_StartDate]
	--	--,[_EndDate]
	--	,[_KeyHash]
	--	,[_ValueHash]
	--	,[_InsertDate]
	--	,[_InsertBy]
	--	,[_UpdateDate]
	--	,[_UpdateBy]
	--	)
	--SELECT --[FactEmailSentId]
	--	[FactEmailSentKey]
	--	,[EmailDateId]
	--	,[EmailInfoId]
	--	,[EmailSentCount]
	--	,[EmailClickthroughCount]
	--	,[EmailUniqueClickthroughCount]
	--	,[EmailExistingVisitorClickthroughCount]
	--	,[EmailNewVisitorClickthroughCount]
	--	,[EmailOpenCount]
	--	,[EmailUniqueOpenCount]
	--	,[EmailBouncebackCount]
	--	,[EmailHardBouncebackCount]
	--	,[EmailSoftBouncebackCount]
	--	,[EmailFormSubmissionCount]
	--	,[EmailUniqueFormSubmissionCount]
	--	,[EmailUnsubscribedCount]
	--	,[EmailDeliveredCount]
	--	--,SYSDATETIME()
	--	--,[_EndDate]
	--	,[_KeyHash]
	--	,[_ValueHash]
	--	,SYSDATETIME()
	--	,SUSER_SNAME()
	--	,SYSDATETIME()
	--	,SUSER_SNAME()
	--FROM (
		MERGE dbo.[FactEmailSent] AS [TARGET]
		USING (
			SELECT [EmailSentId]
				,FactEmailSentKey = [EmailSentKey]
				,CAST([EmailDate] AS INT) AS EmailDateId
				,ISNULL(ei.[DimEmailInfoId], - 1) AS EmailInfoId
				,EmailSentCount
				,[EmailClickthroughCount]
				,[EmailUniqueClickthroughCount]
				,[EmailExistingVisitorClickthroughCount]
				,[EmailNewVisitorClickthroughCount]
				,[EmailOpenCount]
				,[EmailUniqueOpenCount]
				,[EmailBouncebackCount]
				,[EmailHardBouncebackCount]
				,[EmailSoftBouncebackCount]
				,[EmailFormSubmissionCount]
				,[EmailUniqueFormSubmissionCount]
				,[EmailUnsubscribedCount]
				,[EmailDeliveredCount]
				,[_KeyHash]
				,[_ValueHash]
				,[_InsertedDate]
				,[_InsertedBy]
				,[_UpdatedDate]
				,[_UpdatedBy]
			FROM dbo.tmp_FactEmailSent es
			LEFT JOIN (
				SELECT [DimEmailInfoId]
					,[DimEmailInfoKey]
				FROM [dbo].[DimEmailInfo]
				) ei ON es.emailInfo = ei.[DimEmailInfoKey]
			) AS [SOURCE]
			ON ([TARGET].[_KeyHash] = [SOURCE].[_KeyHash])
		WHEN NOT MATCHED BY TARGET
			THEN
				INSERT (
					[FactEmailSentKey]
					,[EmailDateId]
					,[EmailInfoId]
					,[EmailSentCount]
					,[EmailClickthroughCount]
					,[EmailUniqueClickthroughCount]
					,[EmailExistingVisitorClickthroughCount]
					,[EmailNewVisitorClickthroughCount]
					,[EmailOpenCount]
					,[EmailUniqueOpenCount]
					,[EmailBouncebackCount]
					,[EmailHardBouncebackCount]
					,[EmailSoftBouncebackCount]
					,[EmailFormSubmissionCount]
					,[EmailUniqueFormSubmissionCount]
					,[EmailUnsubscribedCount]
					,[EmailDeliveredCount]
					,[_KeyHash]
					,[_ValueHash]
					,[_InsertedDate]
					,[_InsertedBy]
					,[_UpdatedDate]
					,[_UpdatedBy]
					)
				VALUES (
					[SOURCE].FactEmailSentKey
					,[SOURCE].EmailDateId
					,[SOURCE].EmailInfoId
					,[SOURCE].[EmailSentCount]
					,[SOURCE].[EmailClickthroughCount]
					,[SOURCE].[EmailUniqueClickthroughCount]
					,[SOURCE].[EmailExistingVisitorClickthroughCount]
					,[SOURCE].[EmailNewVisitorClickthroughCount]
					,[SOURCE].[EmailOpenCount]
					,[SOURCE].[EmailUniqueOpenCount]
					,[SOURCE].[EmailBouncebackCount]
					,[SOURCE].[EmailHardBouncebackCount]
					,[SOURCE].[EmailSoftBouncebackCount]
					,[SOURCE].[EmailFormSubmissionCount]
					,[SOURCE].[EmailUniqueFormSubmissionCount]
					,[SOURCE].[EmailUnsubscribedCount]
					,[SOURCE].[EmailDeliveredCount]
					,[SOURCE].[_KeyHash]
					,[SOURCE].[_ValueHash]
					,SYSDATETIME()
					,SUSER_SNAME()
					,SYSDATETIME()
					,SUSER_SNAME()
					)
		WHEN MATCHED
			AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
			--AND ([TARGET].[_EndDate] = '9999-12-31')
			THEN
				UPDATE
				SET
					--  [TARGET].[_EndDate] = SYSDATETIME(),
					[TARGET].[_InsertedBy] = [SOURCE].[_InsertedBy]
					,[TARGET].[_UpdatedDate] = SYSDATETIME()
					,[TARGET].[_UpdatedBy] = [SOURCE].[_UpdatedBy]
					,[TARGET].EmailDateId =[SOURCE].EmailDateId
					,[TARGET].EmailInfoId = [SOURCE].EmailInfoId
					,[TARGET].[EmailSentCount]= [SOURCE].[EmailSentCount]
					,[TARGET].[EmailClickthroughCount] = [SOURCE].[EmailClickthroughCount]
					,[TARGET].[EmailUniqueClickthroughCount] = [SOURCE].[EmailUniqueClickthroughCount]
					,[TARGET].[EmailExistingVisitorClickthroughCount]= [SOURCE].[EmailExistingVisitorClickthroughCount]
					,[TARGET].[EmailNewVisitorClickthroughCount]= [SOURCE].[EmailNewVisitorClickthroughCount]
					,[TARGET].[EmailOpenCount] = [SOURCE].[EmailOpenCount]
					,[TARGET].[EmailUniqueOpenCount] = [SOURCE].[EmailUniqueOpenCount]
					,[TARGET].[EmailBouncebackCount] = [SOURCE].[EmailBouncebackCount]
					,[TARGET].[EmailHardBouncebackCount] = [SOURCE].[EmailHardBouncebackCount]
					,[TARGET].[EmailSoftBouncebackCount] = [SOURCE].[EmailSoftBouncebackCount]
					,[TARGET].[EmailFormSubmissionCount] = [SOURCE].[EmailFormSubmissionCount]
					,[TARGET].[EmailUniqueFormSubmissionCount] = [SOURCE].[EmailUniqueFormSubmissionCount]
					,[TARGET].[EmailUnsubscribedCount] = [SOURCE].[EmailUnsubscribedCount]
					,[TARGET].[EmailDeliveredCount] = [SOURCE].[EmailDeliveredCount];
	--	OUTPUT $ACTION AS ACTION
	--		,[SOURCE].*
	--	) AS MERGE_OUTPUT
	--WHERE MERGE_OUTPUT.ACTION = 'UPDATE';

	--INSERT INTO dbo.[FactEmailSent] (
	--	--[FactEmailSentId]
	--	[FactEmailSentKey]
	--	,[EmailDateId]
	--	,[EmailInfoId]
	--	,[EmailSentCount]
	--	,[EmailClickthroughCount]
	--	,[EmailUniqueClickthroughCount]
	--	,[EmailExistingVisitorClickthroughCount]
	--	,[EmailNewVisitorClickthroughCount]
	--	,[EmailOpenCount]
	--	,[EmailUniqueOpenCount]
	--	,[EmailBouncebackCount]
	--	,[EmailHardBouncebackCount]
	--	,[EmailSoftBouncebackCount]
	--	,[EmailFormSubmissionCount]
	--	,[EmailUniqueFormSubmissionCount]
	--	,[EmailUnsubscribedCount]
	--	,[EmailDeliveredCount]
	--	--,[_StartDate]
	--	-- ,[_EndDate]
	--	,[_KeyHash]
	--	,[_ValueHash]
	--	,[_InsertedDate]
	--	,[_InsertedBy]
	--	,[_UpdatedDate]
	--	,[_UpdatedBy]
	--	)
	--SELECT [FactEmailSentKey]
	--	,[EmailDateId]
	--	,[EmailInfoId]
	--	,[EmailSentCount]
	--	,[EmailClickthroughCount]
	--	,[EmailUniqueClickthroughCount]
	--	,[EmailExistingVisitorClickthroughCount]
	--	,[EmailNewVisitorClickthroughCount]
	--	,[EmailOpenCount]
	--	,[EmailUniqueOpenCount]
	--	,[EmailBouncebackCount]
	--	,[EmailHardBouncebackCount]
	--	,[EmailSoftBouncebackCount]
	--	,[EmailFormSubmissionCount]
	--	,[EmailUniqueFormSubmissionCount]
	--	,[EmailUnsubscribedCount]
	--	,[EmailDeliveredCount]
	--	--,[_StartDate]
	--	--,[_EndDate]
	--	,[_KeyHash]
	--	,[_ValueHash]
	--	,[_InsertDate]
	--	,[_InsertBy]
	--	,[_UpdateDate]
	--	,[_UpdateBy]
	--FROM @tmp_FactEmailSent
END
GO
