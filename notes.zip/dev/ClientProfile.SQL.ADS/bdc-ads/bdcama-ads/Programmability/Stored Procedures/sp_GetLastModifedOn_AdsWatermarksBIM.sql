﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-05
-- Description: Gets lastModifiedOn from AdsWatermarks
-- =============================================
CREATE PROCEDURE dbo.sp_GetLastModifedOn_AdsWatermarksBIM
(
    @targetTableName VARCHAR(255),
    @sourceTableName VARCHAR(255),
    @sourceColumns VARCHAR(6000)
)
AS
BEGIN
	SELECT CONVERT(VARCHAR(30), ISNULL(MAX(SourceWatermarkValue), '1900-01-01'), 121) AS ModifiedOn FROM dbo.AdsWatermarksBIM WHERE TargetTableName = @targetTableName and SourceTableName = @sourceTableName and SourceColumns = @sourceColumns
END
GO


