-- =============================================
-- Author:      David Sun
-- Create Date: 2021-02-08
-- Description: Updates DimDigitalFormInfo from tmp_DimDigitalFormInfo
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_DimDigitalFormInfo
AS
BEGIN
	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================   
	EXEC dbo.sp_ResetIdentityKeySeed  @tableName = 'dbo.DimDigitalFormInfo', @identityKey = 'DigitalFormInfoKey';
	-- ================================================================================== 
	-- Then update the dim table
	-- ==================================================================================   
	MERGE dbo.DimDigitalFormInfo AS dst
	USING dbo.tmp_DimDigitalFormInfo AS src
	ON dst.FormName = src.FormName and dst.FormType = src.FormType

	WHEN MATCHED THEN
		UPDATE SET
			FormOfficialName = src.FormOfficialName
			,ModifiedDate = GETDATE()
			,ModifiedBy = USER_NAME()

	WHEN NOT MATCHED THEN
		INSERT (
			FormName
			,FormType
			,FormOfficialName
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
		)
		VALUES (
			src.FormName
			,src.FormType
			,src.FormOfficialName
			,GETDATE()
			,USER_NAME()
			,GETDATE()
			,USER_NAME()
		);
END
GO
