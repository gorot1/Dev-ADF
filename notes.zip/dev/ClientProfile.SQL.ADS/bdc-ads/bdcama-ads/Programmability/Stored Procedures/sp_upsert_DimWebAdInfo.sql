-- =============================================
-- Author:      David Sun
-- Create Date: 2021-01-19
-- Description: Updates DimWebAdInfo from tmp_DimWebAdInfo
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_DimWebAdInfo
AS
BEGIN
	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================   
	EXEC dbo.sp_ResetIdentityKeySeed  @tableName = 'dbo.DimWebAdInfo', @identityKey = 'WebAdInfoKey';
	-- ================================================================================== 
	-- Then update the dim table
	-- ==================================================================================   
	MERGE dbo.DimWebAdInfo AS dst
	USING (
		SELECT
			HASHBYTES('SHA1', ISNULL(AdContent, '') + ISNULL(AdKeyWord, '')) WebAdInfoHash
			,AdContent
			,AdKeyWord
			,USER_NAME() AS InsertedBy
			,USER_NAME() AS ModifiedBy
		FROM dbo.tmp_DimWebAdInfo
		) AS src
	ON dst.WebAdInfoHash = src.WebAdInfoHash

	--WHEN MATCHED THEN
	--	UPDATE SET
	--		AdContent = src.AdContent
	--		,AdKeyword = src.AdKeyword
	--		,ModifiedDate = GETDATE()
	--		,ModifiedBy = src.ModifiedBy

	WHEN NOT MATCHED THEN
		INSERT (
			WebAdInfoHash
			,AdContent
			,AdKeyword
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
		)
		VALUES (
			src.WebAdInfoHash
			,src.AdContent
			,src.AdKeyword
			,GETDATE()
			,src.InsertedBy
			,GETDATE()
			,src.ModifiedBy
		);
END
GO
