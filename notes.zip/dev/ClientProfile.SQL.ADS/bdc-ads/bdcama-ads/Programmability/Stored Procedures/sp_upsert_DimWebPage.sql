-- =============================================
-- Author:      David Sun
-- Create Date: 2021-01-14
-- Description: Updates DimWebPage from tmp_DimWebPage
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_DimWebPage
AS
BEGIN
	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================   
	EXEC dbo.sp_ResetIdentityKeySeed  @tableName = 'dbo.DimWebPage', @identityKey = 'WebPageKey';

	-- ================================================================================== 
	-- Then update the dim table
	-- ==================================================================================  
	WITH T AS
	(
		SELECT 
			WebPageHash,
			PageFullPath,
			PageDomain,
			PageRelativePathWithoutParameters,
			PageParameters,
			REPLACE(TRIM(REPLACE(pageLevel1, '/', ' ')), ' ', '/') pageLevel1,
			REPLACE(TRIM(REPLACE(pageLevel2, '/', ' ')), ' ', '/') pageLevel2,
			REPLACE(TRIM(REPLACE(pageLevel3, '/', ' ')), ' ', '/') pageLevel3,
			REPLACE(TRIM(REPLACE(pageLevel4, '/', ' ')), ' ', '/') pageLevel4,
			REPLACE(TRIM(REPLACE(pagePath4, '/', ' ')), ' ', '/') AS pageLevel5
		FROM
		(
			SELECT
				WebPageHash,
				PageFullPath,
				PageDomain,
				PageRelativePathWithoutParameters,
				PageParameters,
				pagePath1,
				pageLevel1,
				pagePath2,
				pageLevel2,
				pagePath3,
				pageLevel3,
				RIGHT(pagePath3, LEN(pagePath3)-CHARINDEX('/', pagePath3, 2)) pagePath4,
				SUBSTRING(pagePath3, 0, CHARINDEX('/', pagePath3, 2)) pageLevel4
			FROM
			(
				SELECT
					WebPageHash,
					PageFullPath,
					PageDomain,
					PageRelativePathWithoutParameters,
					PageParameters,
					pagePath1,
					pagePath2,
					pageLevel1,
					pageLevel2,
					RIGHT(pagePath2, LEN(pagePath2)-CHARINDEX('/', pagePath2, 2)) pagePath3,
					SUBSTRING(pagePath2, 0, CHARINDEX('/', pagePath2, 2)) pageLevel3
				FROM
				(
					SELECT
						WebPageHash,
						PageFullPath,
						PageDomain,
						PageRelativePathWithoutParameters,
						PageParameters,
						pagePath1,
						pageLevel1,
						RIGHT(pagePath1, LEN(pagePath1)-CHARINDEX('/', pagePath1, 2)) pagePath2,
						SUBSTRING(pagePath1, 0, CHARINDEX('/', pagePath1, 2)) pageLevel2
					FROM
					(
						SELECT  
							WebPageHash,
							ISNULL(hostname, '')+ISNULL(pagePath, '') PageFullPath,
							hostname PageDomain,
							CASE WHEN CHARINDEX('?', pagePath) > 0 THEN LEFT(pagePath, CHARINDEX('?', pagePath) - 1)
                            ELSE pagePath
							END PageRelativePathWithoutParameters,
							CASE WHEN CHARINDEX('?', pagePath) > 0 THEN RIGHT(pagePath, CHARINDEX('?', REVERSE(pagePath)) - 1)
							END PageParameters,
							RIGHT(pagePath+'/////', LEN(pagePath+'/////')-CHARINDEX('/', pagePath+'/////', 2)) pagePath1,
							SUBSTRING(pagePath+'//////', 2, CHARINDEX('/', pagePath+'/////', 2)-2) pageLevel1
						FROM dbo.tmp_DimWebPage
					) l1
				) l2
			) l3
		) l4
	)

	MERGE dbo.DimWebPage AS dst
	USING T AS src
	ON (dst.WebPageHash = src.WebPageHash)

	--WHEN MATCHED THEN
	--	UPDATE SET
	--		ModifiedDate = GETDATE()
	--		,ModifiedBy = USER_NAME()

	WHEN NOT MATCHED THEN
		INSERT (
			WebPageHash
			,PageFullPath
			,PageDomain
			,PageRelativePathWithoutParameters
			,PageParameters
			,PageLevel1
			,PageLevel2
			,PageLevel3
			,PageLevel4
			,PageLevel5
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
		)
		VALUES (
			src.WebPageHash
			,src.PageFullPath
			,src.PageDomain
			,src.PageRelativePathWithoutParameters
			,src.PageParameters
			,src.PageLevel1
			,src.PageLevel2
			,src.PageLevel3
			,src.PageLevel4
			,src.PageLevel5			
			,GETDATE()
			,USER_NAME()
			,GETDATE()
			,USER_NAME()
		);

	IF COL_LENGTH('dbo.tmp_DimWebPage', 'NewWebPageHash') IS NOT NULL
	BEGIN
		EXEC('
			WITH T2 AS
			(
				SELECT
					t2.WebPageKey,
					0 PageIsNew,
					t3.WebPageKey PageMappingKey
				FROM dbo.tmp_DimWebPage t1
				LEFT JOIN dbo.DimWebPage t2 ON t1.WebPageHash = t2.WebPageHash
				LEFT JOIN dbo.DimWebPage t3 ON t1.NewWebPageHash = t3.WebPageHash
				UNION
				SELECT
					t3.WebPageKey,
					1 PageIsNew,
					t2.WebPageKey PageMappingKey
				FROM dbo.tmp_DimWebPage t1
				LEFT JOIN dbo.DimWebPage t2 ON t1.WebPageHash = t2.WebPageHash
				LEFT JOIN dbo.DimWebPage t3 ON t1.NewWebPageHash = t3.WebPageHash
			)

			MERGE dbo.DimWebPage AS dst
			USING T2 AS src
			ON (dst.WebPageKey = src.WebPageKey)

			WHEN MATCHED THEN
				UPDATE SET
					PageIsNew = src.PageIsNew
					,PageMappingKey = src.PageMappingKey
					,ModifiedDate = GETDATE()
					,ModifiedBy = USER_NAME()
			;
		')
	END 

END
GO
