-- =============================================
-- Author:      David Sun
-- Create Date: 2021-02-06
-- Description: Updates FactWebPageVisit from tmp_FactWebPageVisit
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_FactWebPageVisit
AS
BEGIN
	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================   
	EXEC dbo.sp_ResetIdentityKeySeed  @tableName = 'dbo.FactWebPageVisit', @identityKey = 'WebPageVisitKey';
	-- ================================================================================== 
	-- Then update the dim table
	-- ==================================================================================  
	WITH T AS
	(
	SELECT
		t2.DimDateKey VisitDateKey,
		t1.TimeKey VisitTimeKey,
		ISNULL(t5.WebPageKey, -1) VisitLandingWebPageKey,
		ISNULL(t3.WebPageKey, -1) VisitWebPageKey,
		ISNULL(t4.DigitalTouchpointMetadataKey, -1) DigitalTouchpointMetadataKey,
		Sum(t1.VisitSessionCount) VisitSessionCount,
		t1.VisitSessionDurationSeconds VisitSessionDurationSeconds,
		Sum(t1.VisitBouncesCount) VisitBouncesCount
	FROM 
	(
		SELECT
			tmp.entity_event_date,
			tmp.TimeKey, 
			HASHBYTES('SHA1', cast(ISNULL(channel.DigitalChannelKey, -1) as varchar)+cast(ISNULL(tmp.accountID, -1) as varchar)+cast(ISNULL(tmp.profileID, -1) as varchar)+cast(ISNULL(tmp.segment,'') as varchar)+cast(ISNULL(device.DigitalDeviceCategoryKey,-1) as varchar)+cast(ISNULL(tmp.cityid, -1) as varchar)) TouchpointMetadataHash,
			LandingPageFullPathHash,
			PageFullPathHash,
			VisitSessionCount,
			VisitSessionDurationSeconds,
			VisitBouncesCount
			FROM 
			(
				SELECT 
					entity_event_date, TimeKey, accountID, profileID, segment, deviceCategory, cityid, 
					VisitSessionCount, VisitSessionDurationSeconds, VisitBouncesCount,
					HASHBYTES('SHA1', ISNULL(hostname, '')+ISNULL(landingPagePath, '')) LandingPageFullPathHash,
					HASHBYTES('SHA1', ISNULL(hostname, '')+ISNULL(pagePath, '')) PageFullPathHash,
					HASHBYTES('SHA1', ISNULL(source, '')+ISNULL(medium, '')+ISNULL(campaign, '')) ChannelHash
				FROM 
				dbo.tmp_FactWebPageVisit 
			) tmp
			left join dbo.DimDigitalChannel channel on  tmp.ChannelHash = channel.DigitalChannelHash 
			left join dbo.DimDigitalDeviceCategory device on tmp.deviceCategory = device.DeviceCategoryName
	) t1
	LEFT JOIN dbo.DimDate t2 ON t1.entity_event_date = t2.Date
	LEFT JOIN dbo.DimWebPage t3 ON t1.PageFullPathHash = t3.WebPageHash
	LEFT JOIN dbo.DimDigitalTouchpointMetadata t4 ON t1.TouchpointMetadataHash = t4.DigitalTouchpointMetadataHash
	LEFT JOIN dbo.DimWebPage t5 ON t1.LandingPageFullPathHash = t5.WebPageHash
	GROUP BY t2.DimDateKey,
		t1.TimeKey,
		t5.WebPageKey,
		t3.WebPageKey,
		t4.DigitalTouchpointMetadataKey,		
		t1.VisitSessionDurationSeconds 
	)
	
	MERGE dbo.FactWebPageVisit AS dst
	USING T AS src
	ON (dst.VisitDateKey = src.VisitDateKey)
	AND (dst.VisitTimeKey = src.VisitTimeKey)
	AND (dst.VisitLandingWebPageKey = src.VisitLandingWebPageKey)
	AND (dst.VisitWebPageKey = src.VisitWebPageKey)
	AND (dst.DigitalTouchpointMetadataKey = src.DigitalTouchpointMetadataKey)
	WHEN MATCHED THEN
		UPDATE SET
			VisitSessionCount = src.VisitSessionCount
			,VisitSessionDurationSeconds = src.VisitSessionDurationSeconds
			,VisitBouncesCount = src.VisitBouncesCount
			,ModifiedDate = GETDATE()
			,ModifiedBy = USER_NAME()

	WHEN NOT MATCHED THEN
		INSERT (
			VisitDateKey
			,VisitTimeKey
			,VisitLandingWebPageKey
			,VisitWebPageKey
			,DigitalTouchpointMetadataKey
			,VisitSessionCount
			,VisitSessionDurationSeconds
			,VisitBouncesCount
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
		)
		VALUES (
			src.VisitDateKey
			,src.VisitTimeKey
			,src.VisitLandingWebPageKey
			,src.VisitWebPageKey
			,src.DigitalTouchpointMetadataKey
			,src.VisitSessionCount
			,src.VisitSessionDurationSeconds
			,src.VisitBouncesCount
			,GETDATE()
			,USER_NAME()
			,GETDATE()
			,USER_NAME()
		);
	
END