-- =============================================
-- Author:      David Sun
-- Create Date: 2021-01-18
-- Description: Updates DimDigitalChannel from tmp_DimDigitalChannel
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_DimDigitalChannel
AS
BEGIN

	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================     
    EXEC dbo.sp_ResetIdentityKeySeed  @tableName = 'dbo.DimDigitalChannel', @identityKey = 'DigitalChannelKey';
	-- ================================================================================== 
	-- Then apply business rules and conduct data transformation to get one CTE T
	-- ==================================================================================  
    WITH T AS 
    (
        SELECT DigitalChannelGroupKey,
	        ChannelSource,
	        ChannelMedium,
	        ChannelCampaign,
            HASHBYTES('SHA1', ISNULL([ChannelSource], '') + ISNULL([ChannelMedium], '') + ISNULL([ChannelCampaign], '')) [DigitalChannelHash],
	        CASE
		        WHEN ChannelMedium = 'cpc'
			        AND
			        (
				        (
					        dbo.fn_ContainsAnyWord(
											        ChannelCampaign,
											        'bdc_,brand_,Search_BDC_EN,Search_BDC_FR,search_bdc_fr,search_bdc_en',
											        ','
										        ) = 1
					        OR ChannelCampaign LIKE 'brand-%'
				        )
				        AND (dbo.fn_ContainsAnyWord(ChannelCampaign, 'top-outils,toolkit', ',') = 0)
			        ) THEN
			        'branded'
		        ELSE
			        'unbranded'
	        END ChannelIsBranded,
	        CASE
		        WHEN ChannelGroupName = 'paid search'
			        AND
			        (
				        dbo.fn_ContainsAnyWord(ChannelCampaign, 'search_consulting_,rlsa_consulting', ',') = 1
				        OR ChannelCampaign LIKE '%sea_%_consulting_%'
				        OR ChannelCampaign LIKE '%rlsa_%_consulting_%'
				        OR ChannelCampaign LIKE '%search_%_consulting_%'
				        OR ChannelCampaign LIKE 'consulting-%'
			        ) THEN
			        'advisory_services'
		        WHEN ChannelGroupName = 'paid search'
			        AND
			        (
				        dbo.fn_ContainsAnyWord(
										        ChannelCampaign,
										        'search_smb,search_financing,rlsa_financing_,women-financing,smb-fin',
										        ','
									        ) = 1
				        OR ChannelCampaign LIKE '%sea_%smb-fin%'
				        OR ChannelCampaign LIKE '%search_%_financing%'
				        OR ChannelCampaign LIKE '%rsla_%_smb_%'
				        OR ChannelCampaign LIKE '%rsla_%_financing_%'
				        OR ChannelCampaign LIKE 'sbl-financing-%'
			        ) THEN
			        'financing'
		        ELSE
			        'other'
	        END ChannelBusinessLine,
	        CASE
		        WHEN ChannelGroupName = 'paid search'
			        AND dbo.fn_ContainsAnyWord(ChannelCampaign, 'smb', ',') = 1 THEN
			        'small_business_loan'
		        ELSE
			        'other'
	        END ChannelProductType, 
	        CASE
		        WHEN ChannelGroupName = 'paid search'
			        AND dbo.fn_ContainsAnyWord(ChannelCampaign, 'sea,search', ',') = 1
			        AND dbo.fn_ContainsAnyWord(ChannelCampaign, 'women', ',') = 1
			        AND dbo.fn_ContainsAnyWord(ChannelCampaign, 'financing', ',') = 1 THEN
			        'women'
		        ELSE
			        'other'
	        END ChannelTargetAudience,

            CASE
                WHEN dbo.fn_ContainsAnyWord(
                                            ChannelSource,
                                            'gc.ca,businesslink.ca,canadabusiness.ca,cbo-eco.ca,entreprisescanada.ca,novascotia.ca,servicealberta.ca,edc.ca,.canada.ca',
                                            ','
                                        ) = 1 THEN
                    'Gov. of Canada'
                WHEN dbo.fn_ContainsAnyWord(
                                            ChannelSource,
                                            'futurpreneur.ca,infoentrepreneurs.org,www1.toronto.ca,sba-bc.ca,smallbusinessbc.ca,servicealberta.gov.ab.ca,ccmm.qc.ca,marsdd.com,barriebusinesscentre.ca,clddequebec.qc.ca,albertacanada.com,sauder-ubc-csm.symplicity.com,alis.alberta.ca,ceed.ca,entrepreneuriat.poly-udem.ca,ressourcesentreprises.org,bacd.ca,ubc-csm.symplicity.com,entrepreneurship.qc.ca,benhur.teluq.uquebec.ca,novascotiabusiness.com,cdepnql.org,regionalbusiness.ca,releve.qc.ca,cldmn.qc.ca,www2.gouv.qc.ca,tvdsb.ca,riccentre.ca,chaitonsweb.chaitons.local,oce-ontario.org,portal.rotmancommerce.utoronto.ca,communityfarms.ca,smallbusiness.alberta.ca,fsa.ulaval.ca,brampton.ca,fundica.com,lancersonentreprise.com,chamber.ca,investinhamilton.ca,usherbrooke.ca,socca.qc.ca,immigration-quebec.gouv.qc.ca,sadckamouraska.com,cabe.ca,cdest.org,cteestrie.ca,innovationpei.com,magarderie.com,economy.gov.sk.ca,smallbusinesshuron.ca,boussoleentrepreneuriale.com,sbcentre.ca,ctelaurentides.ca,gov.mb.ca,entrepreneurshipmanitoba.ca,sasknetwork.gov.sk.ca',
                                            ','
                                        ) = 1 THEN
                    'Provinces/Cities/Associations'
                WHEN dbo.fn_ContainsAnyWord(ChannelSource, 'twitter,facebook,linkedin,lnkd.in,flipboard,t.co,ht.ly', ',') = 1 THEN
                    'Social Media'
                WHEN dbo.fn_ContainsAnyWord(
                                            ChannelSource,
                                            'job,emploi,career,recru,eluta,workopolis,neuvoo,grenier.qc.ca',
                                            ','
                                        ) = 1 THEN
                    'Job Sites'
                WHEN dbo.fn_ContainsAnyWord(ChannelSource, 'authoring.ext,bdc.ca,pshr.bdc.ca', ',') = 1 THEN
                    'BDC'
                ELSE
                    'Others'
            END ChannelReferringSite,
            CASE
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'ln--,lead-nurturing', ',') = 1 THEN
                    'Lead Nurturing'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'monthly economic,MEL--,lettre �conomique', ',') = 1 THEN
                    'Monthly Economic Newsletter'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'in-business', ',') = 1 THEN
                    'In Business'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'oil-market-update', ',') = 1 THEN
                    'Oil Market Update'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'client-retention,client-nurturing', ',') = 1 THEN
                    'Client-Nurturing'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'ebook', ',') = 1 THEN
                    'Ebooks'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'event-', ',') = 1 THEN
                    'Events'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'webinar', ',') = 1 THEN
                    'Webinar'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'debit-advice', ',') = 1 THEN
                    'Debit Advice'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'partner-with-bdc', ',') = 1 THEN
                    'Partner with BDC'
                ELSE
                    'Other'
            END ChannelEmailGroup,
            CASE
                WHEN dbo.fn_ContainsAnyWord(
                                            ChannelCampaign,
                                            'lead-nurturing--1-,lead-nurturing--2-,lead-nurturing--3-,lead-nurturing--4-,lead-nurturing--5-,lead-nurturing--6-,lead-nurturing--7-,lead-nurturing--8-,lead-nurturing--9-,lead-nurturing--10-',
                                            ','
                                        ) = 1 THEN
                    '1 to 10'
                WHEN dbo.fn_ContainsAnyWord(
                                            ChannelCampaign,
                                            'lead-nurturing--11-,lead-nurturing--12-,lead-nurturing--13-,lead-nurturing--14-,lead-nurturing--15-,lead-nurturing--16-,lead-nurturing--17-,lead-nurturing--18-,lead-nurturing--19-,lead-nurturing--120-',
                                            ','
                                        ) = 1 THEN
                    '11 to 20'
                WHEN dbo.fn_ContainsAnyWord(
                                            ChannelCampaign,
                                            'lead-nurturing--21-,lead-nurturing--22-,lead-nurturing--23-,lead-nurturing--24-,lead-nurturing--25-,lead-nurturing--26-,lead-nurturing--27-,lead-nurturing--28-,lead-nurturing--29-,lead-nurturing--30-',
                                            ','
                                        ) = 1 THEN
                    '21 to 30'
                WHEN dbo.fn_ContainsAnyWord(
                                            ChannelCampaign,
                                            'lead-nurturing--31-,lead-nurturing--32-,lead-nurturing--33-,lead-nurturing--34-,lead-nurturing--35-,lead-nurturing--36-,lead-nurturing--37-,lead-nurturing--38-,lead-nurturing--39-,lead-nurturing--40-',
                                            ','
                                        ) = 1 THEN
                    '31 to 40'
                WHEN dbo.fn_ContainsAnyWord(
                                            ChannelCampaign,
                                            'lead-nurturing--41-,lead-nurturing--42-,lead-nurturing--43-,lead-nurturing--44-,lead-nurturing--45-,lead-nurturing--46-,lead-nurturing--47-,lead-nurturing--48-,lead-nurturing--49-,lead-nurturing--50-',
                                            ','
                                        ) = 1 THEN
                    '41 to 50'
                WHEN dbo.fn_ContainsAnyWord(
                                            ChannelCampaign,
                                            'lead-nurturing--51-,lead-nurturing--52-,lead-nurturing--53-,lead-nurturing--54-,lead-nurturing--55-,lead-nurturing--56-,lead-nurturing--57-,lead-nurturing--58-,lead-nurturing--59-,lead-nurturing--60-',
                                            ','
                                        ) = 1 THEN
                    '51 to 60'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'lead-nurturing--cash-flow-1-', ',') = 1 THEN
                    'Cash flow 1'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'lead-nurturing--cash-flow-2-', ',') = 1 THEN
                    'Cash flow 2'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'lead-nurturing--cash-flow-3-', ',') = 1 THEN
                    'Cash flow 3'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'lead-nurturing--cash-flow-4-', ',') = 1 THEN
                    'Cash flow 4'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'lead-nurturing--cash-flow-5-', ',') = 1 THEN
                    'Cash flow 5'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'lead-nurturing--cash-flow-6-', ',') = 1 THEN
                    'Cash flow 6'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'lead-nurturing--1-export--', ',') = 1 THEN
                    'Export 1'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'lead-nurturing--2-export--', ',') = 1 THEN
                    'Export 2'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'lead-nurturing--3-export--', ',') = 1 THEN
                    'Export 3'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'lead-nurturing--5-export--', ',') = 1 THEN
                    'Export 4'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'lead-nurturing--6-export--', ',') = 1 THEN
                    'Export 5'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'lead-nurturing--operational-efficiency-1-', ',') = 1 THEN
                    'Op Efficiency 1'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'lead-nurturing--operational-efficiency-2-', ',') = 1 THEN
                    'Op Efficiency 2'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'lead-nurturing--operational-efficiency-3-', ',') = 1 THEN
                    'Op Efficiency 3'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'lead-nurturing--operational-efficiency-4-', ',') = 1 THEN
                    'Op Efficiency 4'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'lead-nurturing--operational-efficiency-5-', ',') = 1 THEN
                    'Op Efficiency 5'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'lead-nurturing--operational-efficiency-6-', ',') = 1 THEN
                    'Op Efficiency 6'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'ln--mf--', ',') = 1 THEN
                    'Managing finances'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'ln--gf--', ',') = 1 THEN
                    'Get financing'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'ln--oe--', ',') = 1 THEN
                    'Operational Efficiency'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'ln--sp--', ',') = 1 THEN
                    'Strategic planning'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'ln--re--', ',') = 1 THEN
                    'Real Estate Financing'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'ln--dm--', ',') = 1 THEN
                    'Digital Marketing'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'ln--sa--', ',') = 1 THEN
                    'Sales'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'ln--ex--', ',') = 1 THEN
                    'Export'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'ln--hr--', ',') = 1 THEN
                    'Human Resources'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'ln--te--', ',') = 1 THEN
                    'Technology'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'ln--ge--', ',') = 1 THEN
                    'General'
                ELSE
                    'Other'
            END ChannelLeadNurturingGroup,
            CASE
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'ln--', ',') = 1
                    AND dbo.fn_ContainsAnyWord(ChannelCampaign, '--a--', ',') = 1 THEN
                    'Awareness'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'ln--', ',') = 1
                    AND dbo.fn_ContainsAnyWord(ChannelCampaign, '--c--', ',') = 1 THEN
                    'Consideration'
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'ln--', ',') = 1
                    AND dbo.fn_ContainsAnyWord(ChannelCampaign, '--d--', ',') = 1 THEN
                    'Decision'
                ELSE
                    'Default'
            END ChannelLeadNurturingStage,
            CASE
                WHEN dbo.fn_ContainsAnyWord(ChannelCampaign, 'mel--monthly-economic-letter--', ',') = 1 THEN
                    'mel-'
                    + dbo.fn_GetColumnValue(
                                            REPLACE('MEL--Monthly-economic-letter--05-2016--NEWS--EN', '--', '$'),
                                            '$',
                                            3
                                        )
                ELSE
                    NULL
            END ChannelMeledition
        FROM
        (
            SELECT
			        t2.DigitalChannelGroupKey,
			        t2.ChannelGroupName,
                    t1.ChannelSource,
                    t1.ChannelMedium,
                    t1.ChannelCampaign
            FROM dbo.tmp_DimDigitalChannel t1
	        LEFT OUTER JOIN dbo.DimDigitalChannelGroup t2      
	        ON t2.ChannelGroupName = dbo.fn_GetChannelGroupName(t1.ChannelSource, t1.ChannelMedium, t1.ChannelCampaign)
        ) c
    )


	-- ================================================================================== 
	-- Finally update the dim table
	-- ==================================================================================   
	MERGE dbo.DimDigitalChannel AS dst
	USING T AS src
	ON (dst.DigitalChannelHash = src.DigitalChannelHash) 

	--WHEN MATCHED THEN
	--	UPDATE SET
	--		DigitalChannelGroupKey = src.DigitalChannelGroupKey
	--		,ChannelSource = src.ChannelSource
	--		,ChannelMedium = src.ChannelMedium
 --           ,ChannelCampaign = src.ChannelCampaign
	--		,ChannelIsBranded = src.ChannelIsBranded
	--		,ChannelBusinessLine = src.ChannelBusinessLine
	--		,ChannelProductType = src.ChannelProductType
	--		,ChannelTargetAudience = src.ChannelTargetAudience
	--		,ChannelReferringSite = src.ChannelReferringSite
	--		,ChannelEmailGroup = src.ChannelEmailGroup
	--		,ChannelLeadNurturingGroup = src.ChannelLeadNurturingGroup
	--		,ChannelLeadNurturingStage = src.ChannelLeadNurturingStage
	--		,ChannelMeledition = src.ChannelMeledition
	--		,ModifiedDate = GETDATE()
	--		,ModifiedBy = USER_NAME()

	WHEN NOT MATCHED THEN
		INSERT (
            [DigitalChannelHash]
			,[DigitalChannelGroupKey]
            ,[ChannelSource]
            ,[ChannelMedium]
            ,[ChannelCampaign]
            ,[ChannelIsBranded]
            ,[ChannelBusinessLine]
            ,[ChannelProductType]
            ,[ChannelTargetAudience]
            ,[ChannelReferringSite]
            ,[ChannelEmailGroup]
            ,[ChannelLeadNurturingGroup]
            ,[ChannelLeadNurturingStage]
            ,[ChannelMeledition]
			,InsertedDate
            ,InsertedBy
			,ModifiedDate
			,ModifiedBy
		)
		VALUES (
            src.[DigitalChannelHash]
			,src.[DigitalChannelGroupKey]
            ,src.[ChannelSource]
            ,src.[ChannelMedium]
            ,src.[ChannelCampaign]
            ,src.[ChannelIsBranded]
            ,src.[ChannelBusinessLine]
            ,src.[ChannelProductType]
            ,src.[ChannelTargetAudience]
            ,src.[ChannelReferringSite]
            ,src.[ChannelEmailGroup]
            ,src.[ChannelLeadNurturingGroup]
            ,src.[ChannelLeadNurturingStage]
            ,src.[ChannelMeledition]
			,GETDATE()
            ,USER_NAME()
			,GETDATE()
			,USER_NAME()
		);
END
GO
