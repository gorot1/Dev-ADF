-- =============================================
-- Author:      David Sun
-- Create Date: 2021-01-14
-- Description: Updates DimDigitalDeviceCategory from tmp_DimDigitalDeviceCategory
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_DimDigitalDeviceCategory
AS
BEGIN
	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================   
	EXEC dbo.sp_ResetIdentityKeySeed  @tableName = 'dbo.DimDigitalDeviceCategory', @identityKey = 'DigitalDeviceCategoryKey';
	-- ================================================================================== 
	-- Then update the dim table
	-- ==================================================================================   
	MERGE dbo.DimDigitalDeviceCategory AS dst
	USING (
		SELECT
			ISNULL(DeviceCategoryName, 'N/A') DeviceCategoryName
			,USER_NAME() AS InsertedBy
			,USER_NAME() AS ModifiedBy
		FROM dbo.tmp_DimDigitalDeviceCategory
		) AS src
	ON (dst.DeviceCategoryName = src.DeviceCategoryName)

	--WHEN MATCHED THEN
	--	UPDATE SET
	--		DeviceCategoryName = src.DeviceCategoryName
	--		,ModifiedDate = GETDATE()
	--		,ModifiedBy = src.ModifiedBy

	WHEN NOT MATCHED THEN
		INSERT (
			DeviceCategoryName
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
		)
		VALUES (
			src.DeviceCategoryName
			,GETDATE()
			,src.InsertedBy
			,GETDATE()
			,src.ModifiedBy
		);
END
GO
