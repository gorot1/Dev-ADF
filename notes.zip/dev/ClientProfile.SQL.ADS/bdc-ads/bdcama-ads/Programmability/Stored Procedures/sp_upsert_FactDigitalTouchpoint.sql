-- =============================================
-- Author:      David Sun
-- Create Date: 2021-02-01
-- Description: Updates FactDigitalTouchpoint from tmp_FactDigitalTouchpoint
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_FactDigitalTouchpoint
AS
BEGIN
	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================   
	EXEC dbo.sp_ResetIdentityKeySeed  @tableName = 'dbo.FactDigitalTouchpoint', @identityKey = 'DigitalTouchpointKey';
	-- ================================================================================== 
	-- Then update the dim table
	-- ==================================================================================  

	--DECLARE @id_control INT
	--DECLARE @batchSize INT
	--DECLARE @results INT

	--SET @results = 1
	--SET @batchSize = 1000000
	--SET @id_control = 0

	--IF OBJECT_ID('dbo.FactDigitalTouchpoint_batch', 'U') IS NOT NULL
	--	DROP TABLE dbo.[FactDigitalTouchpoint_batch];

	--CREATE TABLE [dbo].[FactDigitalTouchpoint_batch] (
	--	 [Id] [int] IDENTITY(1, 1) NOT NULL 
	--	,[TouchpointDateKey] [int] NOT NULL
	--	,[TouchpointTimeKey] [int] NULL
	--	,[DigitalTouchpointGroupKey] [int] NULL
	--	,[TouchpointRowKey] [int] NULL
	--	,[DigitalTouchpointMetricKey] [int] NULL
	--	,[DigitalTouchpointMetadataKey] [int] NULL
	--	,[MetricValue1] [nvarchar](200) NULL
	--	,[MetricValue2] [nvarchar](200) NULL
	--	,[MetricValue3] [nvarchar](200) NULL
	--	,[MetricValue4] [nvarchar](200) NULL
	--	,[MetricValue5] [nvarchar](200) NULL
	--	)

	--INSERT INTO [dbo].[FactDigitalTouchpoint_batch]
	--SELECT *
	--FROM dbo.tmp_FactDigitalTouchpoint
	--ALTER TABLE dbo.tmp_FactDigitalTouchpoint ADD [Id] [int] IDENTITY(1,1) NOT NULL,PRIMARY KEY (id);
	--CREATE UNIQUE NONCLUSTERED INDEX IX_tmp_FactDigitalTouchpoint on dbo.tmp_FactDigitalTouchpoint (Id ASC);
	--WHILE (@results > 0)
	--BEGIN
		--BEGIN TRAN;

		;WITH T
		AS (
			SELECT tmp.TouchpointDateKey
				,tmp.TouchpointTimeKey
				,ISNULL(touchpointgroup.DigitalTouchpointGroupKey, - 1) DigitalTouchpointGroupKey
				,tmp.TouchpointRowKey
				,ISNULL(touchpointmetrics.DigitalTouchpointMetricKey, - 1) DigitalTouchpointMetricKey
				,tmp.DigitalTouchpointMetadataKey
				,SUM(tmp.MetricValue1) MetricValue1
				,SUM(tmp.MetricValue2) MetricValue2
				,SUM(tmp.MetricValue3) MetricValue3
				,SUM(tmp.MetricValue4) MetricValue4
				,SUM(tmp.MetricValue5) MetricValue5
			FROM dbo.[tmp_FactDigitalTouchpoint] tmp
			LEFT JOIN dbo.DimDigitalTouchpointGroup touchpointgroup ON tmp.TouchpointSourceTableName = touchpointgroup.TouchpointSourceTableName
			LEFT JOIN dbo.DimDigitalTouchpointMetrics touchpointmetrics ON tmp.MetricName1 = touchpointmetrics.MetricName1
			--WHERE ID > @id_control
			--	AND ID <= @id_control + @batchSize
				GROUP BY tmp.TouchpointDateKey
				,tmp.TouchpointTimeKey
				,touchpointgroup.DigitalTouchpointGroupKey
				,tmp.TouchpointRowKey
				,touchpointmetrics.DigitalTouchpointMetricKey
				,tmp.DigitalTouchpointMetadataKey
			)
		MERGE dbo.FactDigitalTouchpoint AS dst
		USING T AS src
			ON (dst.DigitalTouchpointGroupKey = src.DigitalTouchpointGroupKey)
				AND (dst.TouchpointRowKey = src.TouchpointRowKey)
		WHEN MATCHED
			THEN
				UPDATE
				SET MetricValue1 = src.MetricValue1
					,MetricValue2 = src.MetricValue2
					,MetricValue3 = src.MetricValue3
					,MetricValue4 = src.MetricValue4
					,MetricValue5 = src.MetricValue5
					,ModifiedDate = GETDATE()
					,ModifiedBy = USER_NAME()
		WHEN NOT MATCHED
			THEN
				INSERT (
					TouchpointDateKey
					,TouchpointTimeKey
					,DigitalTouchpointGroupKey
					,TouchpointRowKey
					,DigitalTouchpointMetricKey
					,DigitalTouchpointMetadataKey
					,MetricValue1
					,MetricValue2
					,MetricValue3
					,MetricValue4
					,MetricValue5
					,InsertedDate
					,InsertedBy
					,ModifiedDate
					,ModifiedBy
					)
				VALUES (
					src.TouchpointDateKey
					,src.TouchpointTimeKey
					,src.DigitalTouchpointGroupKey
					,src.TouchpointRowKey
					,src.DigitalTouchpointMetricKey
					,src.DigitalTouchpointMetadataKey
					,src.MetricValue1
					,src.MetricValue2
					,src.MetricValue3
					,src.MetricValue4
					,src.MetricValue5
					,GETDATE()
					,USER_NAME()
					,GETDATE()
					,USER_NAME()
					);

		--SET @results = @@ROWCOUNT

		--COMMIT TRAN;

		--SET @id_control = @id_control + @batchSize
	--END
END
GO
