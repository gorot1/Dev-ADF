-- =============================================
-- Author:      David Sun
-- Create Date: 2021-01-19
-- Description: Updates DimWebPageEventInfo from tmp_DimWebPageEventInfo
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_DimWebPageEventInfo
AS
BEGIN
	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================   
	EXEC dbo.sp_ResetIdentityKeySeed @tableName = 'dbo.DimWebPageEventInfo', @identityKey = 'WebPageEventInfoKey';

	-- ================================================================================== 
	-- Then update the dim table
	-- ==================================================================================   
	MERGE dbo.DimWebPageEventInfo AS dst
	USING dbo.tmp_DimWebPageEventInfo AS src
	ON (dst.WebPageEventInfoHash = src.WebPageEventInfoHash)

	--WHEN MATCHED THEN
	--	UPDATE SET
	--		ModifiedDate = GETDATE()
	--		,ModifiedBy = src.ModifiedBy

	WHEN NOT MATCHED THEN
		INSERT (
			WebPageEventInfoHash
			,EventEntityType
			,EventCategory
			,EventAction
			,EventLabel
			,EventContainer
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
		)
		VALUES (
			src.WebPageEventInfoHash
			,src.EventEntityType
			,src.EventCategory
			,src.EventAction
			,src.EventLabel
			,src.EventContainer
			,GETDATE()
			,USER_NAME()
			,GETDATE()
			,USER_NAME()
		);
END
GO
