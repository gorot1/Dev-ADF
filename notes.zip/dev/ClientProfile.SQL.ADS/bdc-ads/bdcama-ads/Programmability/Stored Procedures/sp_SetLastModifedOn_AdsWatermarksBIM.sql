﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-05
-- Description: Sets lastModifiedOn to AdsWatermarks
-- =============================================
CREATE PROCEDURE dbo.sp_SetLastModifedOn_AdsWatermarksBIM
(
    @targetTableName VARCHAR(255),
    @sourceTableName VARCHAR(255),
    @sourceWatermarkColumn VARCHAR(255),
    @sourceWatermarkValue VARCHAR(30),
	@sourceColumns VARCHAR(6000)
)
AS
BEGIN

	MERGE dbo.AdsWatermarksBIM AS dst
	USING (SELECT * FROM (VALUES (@targetTableName, @sourceTableName, @sourceWatermarkColumn, @sourceWatermarkValue, @sourceColumns)) AS s (TargetTableName, SourceTableName, SourceWatermarkColumn, SourceWatermarkValue, SourceColumns)) AS src
	ON dst.TargetTableName = src.TargetTableName and dst.SourceTableName = src.SourceTableName and dst.SourceColumns = src.SourceColumns

	WHEN MATCHED THEN
		UPDATE SET SourceWatermarkValue = src.SourceWatermarkValue, ModifiedDate = getdate(), ModifiedBy = SYSTEM_USER
	;
	--WHEN NOT MATCHED THEN
	--	INSERT (TargetTableName, SourceTableName, SourceWatermarkColumn, SourceWatermarkValue, SourceColumns, InsertedDate, InsertedBy, ModifiedDate, ModifiedBy)
	--	VALUES (src.TargetTableName, src.SourceTableName, src.SourceWatermarkColumn, src.SourceWatermarkValue, src.SourceColumns, getdate(), SYSTEM_USER, getdate(), SYSTEM_USER);
END
GO
