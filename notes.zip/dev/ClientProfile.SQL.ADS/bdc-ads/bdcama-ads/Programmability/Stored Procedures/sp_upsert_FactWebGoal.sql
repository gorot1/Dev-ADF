-- =============================================
-- Author:      David Sun
-- Create Date: 2021-02-02
-- Description: Updates FactWebGoal from tmp_FactWebGoal
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_FactWebGoal
AS
BEGIN
	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================   
	EXEC dbo.sp_ResetIdentityKeySeed  @tableName = 'dbo.FactWebGoal', @identityKey = 'WebGoalKey';

	-- ================================================================================== 
	-- Then update the dim table
	-- ==================================================================================  
	WITH T AS
	(
	SELECT
		t2.DimDateKey WebGoalDateKey,
		t1.TimeKey WebGoalTimeKey,
		ISNULL(t3.WebPageKey, -1) WebPageKey,
		ISNULL(t4.DigitalTouchpointMetadataKey, -1) DigitalTouchpointMetadataKey,
		Sum(t1.goalNumber) GoalNumber, 
		Sum(t1.goalStarts) GoalStartsValue,
		Sum(t1.goalCompletions) GoalCompletionsValue
	FROM 
	(
		SELECT
			tmp.entity_event_date,
			tmp.TimeKey,
			HASHBYTES('SHA1', cast(ISNULL(channel.DigitalChannelKey, -1) as varchar)+cast(ISNULL(tmp.accountID, -1) as varchar)+cast(ISNULL(tmp.profileID,-1) as varchar)+/*cast(ISNULL(tmp.segment,'') as varchar)+*/cast(ISNULL(device.DigitalDeviceCategoryKey,-1) as varchar)+cast(ISNULL(tmp.cityid,-1) as varchar)) TouchpointMetadataHash,
			PageFullPathHash,
			goalNumber,
			goalStarts,
			goalCompletions
			FROM 
			(
				SELECT 
					entity_event_date, TimeKey, accountID, profileID,deviceCategory, cityid, goalNumber, 
					goalStarts, goalCompletions,
					HASHBYTES('SHA1', ISNULL(hostname, '')+ISNULL(landingPagePath, '')) PageFullPathHash,
					HASHBYTES('SHA1', ISNULL(source, '')+ISNULL(medium, '')+ISNULL(campaign, '')) ChannelHash
				FROM 
				dbo.tmp_FactWebGoal
			) tmp
			left join dbo.DimDigitalChannel channel on  tmp.ChannelHash = channel.DigitalChannelHash 
			left join dbo.DimDigitalDeviceCategory device on tmp.deviceCategory = device.DeviceCategoryName
	) t1
	LEFT JOIN dbo.DimDate t2 ON t1.entity_event_date = t2.Date
	LEFT JOIN dbo.DimWebPage t3 ON t1.PageFullPathHash = t3.WebPageHash
	LEFT JOIN dbo.DimDigitalTouchpointMetadata t4 ON t1.TouchpointMetadataHash = t4.DigitalTouchpointMetadataHash
	Group by t2.DimDateKey ,
		t1.TimeKey,
		t3.WebPageKey,
		t4.DigitalTouchpointMetadataKey
	)
	
	MERGE dbo.FactWebGoal AS dst
	USING T AS src
	ON (dst.WebGoalDateKey = src.WebGoalDateKey)
	AND (dst.WebGoalTimeKey = src.WebGoalTimeKey)
	AND (dst.WebPageKey = src.WebPageKey)
	AND (dst.DigitalTouchpointMetadataKey = src.DigitalTouchpointMetadataKey)
	AND ((dst.GoalNumber = src.GoalNumber) or ((dst.GoalNumber IS NULL) AND (src.GoalNumber IS NULL))) 
	WHEN MATCHED THEN
		UPDATE SET
			GoalStartsValue = src.GoalStartsValue
			,GoalCompletionsValue = src.GoalCompletionsValue
			,ModifiedDate = GETDATE()
			,ModifiedBy = USER_NAME()

	WHEN NOT MATCHED THEN
		INSERT (
			WebGoalDateKey
			,WebGoalTimeKey
			,WebPageKey
			,DigitalTouchpointMetadataKey
			,GoalNumber
			,GoalStartsValue
			,GoalCompletionsValue
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
		)
		VALUES (
			src.WebGoalDateKey
			,src.WebGoalTimeKey
			,src.WebPageKey
			,src.DigitalTouchpointMetadataKey
			,src.GoalNumber
			,src.GoalStartsValue
			,src.GoalCompletionsValue
			,GETDATE()
			,USER_NAME()
			,GETDATE()
			,USER_NAME()
		);
	
END
GO