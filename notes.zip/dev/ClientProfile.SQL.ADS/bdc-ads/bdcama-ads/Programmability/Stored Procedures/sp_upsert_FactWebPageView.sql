-- =============================================
-- Author:      David Sun
-- Create Date: 2021-02-05
-- Description: Updates FactWebPageView from tmp_FactWebPageView
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_FactWebPageView
AS
BEGIN
	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================   
	EXEC dbo.sp_ResetIdentityKeySeed  @tableName = 'dbo.FactWebPageView', @identityKey = 'WebPageViewKey';
	
	-- ================================================================================== 
	-- Then update the dim table
	-- ==================================================================================  
WITH T AS
	(
	SELECT
		t2.DimDateKey PageViewDateKey,
		t1.TimeKey PageViewTimeKey,
		ISNULL(t3.WebPageKey, -1) WebPageKey,
		ISNULL(t4.DigitalTouchpointMetadataKey, -1) DigitalTouchpointMetadataKey,
		t1.WebPageParameterGroupKey,
		t1.PageViewParameters,
		Sum(t1.PageViewEntrances) PageViewEntrances,
		Sum(t1.PageViewExits) PageViewExits,
		Sum(t1.PageViewCount) PageViewCount,
		Sum(t1.PageViewUniqueCount) PageViewUniqueCount
	FROM 
	(
		SELECT
			tmp.entity_event_date,
			tmp.TimeKey,
			HASHBYTES('SHA1', cast(ISNULL(channel.DigitalChannelKey, -1) as varchar)+cast(ISNULL(tmp.accountID, -1) as varchar)+cast(ISNULL(tmp.profileID, -1) as varchar)+cast(ISNULL(tmp.segment,'') as varchar)+cast(ISNULL(device.DigitalDeviceCategoryKey,-1) as varchar)+cast(ISNULL(tmp.cityid, -1) as varchar)) TouchpointMetadataHash,
			PageFullPathHash,
			ISNULL(paramgroup.WebPageParameterGroupKey, -1) WebPageParameterGroupKey,
			PageViewParameters,
			PageViewEntrances,
			PageViewExits,
			PageViewCount,
			PageViewUniqueCount
			FROM 
			(
				SELECT 
					entity_event_date, TimeKey, accountID, profileID, segment, deviceCategory, cityid,
					PageViewEntrances, PageViewExits, PageViewCount, PageViewUniqueCount,
					HASHBYTES('SHA1', ISNULL(hostname, '')+ISNULL(pagePath, '')) PageFullPathHash,
					HASHBYTES('SHA1', ISNULL(source, '')+ISNULL(medium, '')+ISNULL(campaign, '')) ChannelHash,
					dbo.fn_GetPagePathParameters(pagePath) PageViewParameters
				FROM 
				dbo.tmp_FactWebPageView 
			) tmp
			left join dbo.DimDigitalChannel channel on  tmp.ChannelHash = channel.DigitalChannelHash 
			left join dbo.DimDigitalDeviceCategory device on tmp.deviceCategory = device.DeviceCategoryName
			left join dbo.DimWebPageParameterGroup paramgroup on dbo.fn_GetPagePathParameterGroupName(tmp.PageViewParameters) = paramgroup.PageParametersGroupName
	) t1
	LEFT JOIN dbo.DimDate t2 ON t1.entity_event_date = t2.Date
	LEFT JOIN dbo.DimWebPage t3 ON t1.PageFullPathHash = t3.WebPageHash
	LEFT JOIN dbo.DimDigitalTouchpointMetadata t4 ON t1.TouchpointMetadataHash = t4.DigitalTouchpointMetadataHash
	GROUP BY t2.DimDateKey,
		t1.TimeKey,
		t3.WebPageKey,
		t4.DigitalTouchpointMetadataKey,
		t1.WebPageParameterGroupKey,
		t1.PageViewParameters
	)
	
	MERGE dbo.FactWebPageView AS dst
	USING T AS src
	ON (dst.PageViewDateKey = src.PageViewDateKey)
	AND (dst.PageViewTimeKey = src.PageViewTimeKey)
	AND (dst.WebPageKey = src.WebPageKey)
	AND (dst.DigitalTouchpointMetadataKey = src.DigitalTouchpointMetadataKey)
	AND (dst.WebPageParameterGroupKey = src.WebPageParameterGroupKey)
	WHEN MATCHED THEN
		UPDATE SET
			PageViewParameters = src.PageViewParameters
			,PageViewEntrances = src.PageViewEntrances
			,PageViewExits = src.PageViewExits
			,PageViewCount = src.PageViewCount
			,PageViewUniqueCount = src.PageViewUniqueCount
			,ModifiedDate = GETDATE()
			,ModifiedBy = USER_NAME()

	WHEN NOT MATCHED THEN
		INSERT (
			PageViewDateKey
			,PageViewTimeKey
			,WebPageKey
			,DigitalTouchpointMetadataKey
			,WebPageParameterGroupKey
			,PageViewParameters
			,PageViewEntrances
			,PageViewExits
			,PageViewCount
			,PageViewUniqueCount
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
		)
		VALUES (
			src.PageViewDateKey
			,src.PageViewTimeKey
			,src.WebPageKey
			,src.DigitalTouchpointMetadataKey
			,src.WebPageParameterGroupKey
			,src.PageViewParameters
			,src.PageViewEntrances
			,src.PageViewExits
			,src.PageViewCount
			,src.PageViewUniqueCount
			,GETDATE()
			,USER_NAME()
			,GETDATE()
			,USER_NAME()
		);
	
END
GO