-- =============================================
-- Author:      David Sun
-- Create Date: 2021-01-19
-- Description: Updates DimDigitalTouchpointMetadata from tmp_DimDigitalTouchpointMetadata
-- =============================================

CREATE PROCEDURE dbo.sp_upsert_DimDigitalTouchpointMetadata
AS
BEGIN

	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================   
	EXEC dbo.sp_ResetIdentityKeySeed  @tableName = 'dbo.DimDigitalTouchpointMetadata', @identityKey = 'DigitalTouchpointMetadataKey';

	-- ================================================================================== 
	-- Then update the dim table
	-- ==================================================================================   
	MERGE dbo.DimDigitalTouchpointMetadata AS dst
	USING (
		SELECT
			HASHBYTES('SHA1', cast(ISNULL(t2.DigitalChannelKey, -1) as varchar)+cast(ISNULL(t1.TouchpointAccountId, -1) as varchar)+cast(ISNULL(t1.TouchpointProfileId,-1) as varchar)+cast(ISNULL(t1.TouchpointSegment,'') as varchar)+cast(ISNULL(t3.DigitalDeviceCategoryKey,-1) as varchar)+cast(ISNULL(t1.TouchpointCityId, -1) as varchar)) as DigitalTouchpointMetadataHash
			,ISNULL(t2.DigitalChannelKey, -1) as DigitalChannelKey
			,t1.TouchpointAccountId as TouchpointAccountId
			,t1.TouchpointProfileId as TouchpointProfileId
			,t1.TouchpointSegment as TouchpointSegment
			,ISNULL(t3.DigitalDeviceCategoryKey, -1) as DigitalDeviceCategoryKey
			,t1.TouchpointCityId AS TouchpointCityId
			,USER_NAME() AS InsertedBy
			,USER_NAME() AS ModifiedBy
		FROM dbo.tmp_DimDigitalTouchpointMetadata t1
		LEFT JOIN dbo.DimDigitalChannel t2
		ON t1.source = t2.ChannelSource and t1.medium = t2.ChannelMedium and t1.campaign = t2.ChannelCampaign
		LEFT JOIN dbo.DimDigitalDeviceCategory t3
		ON t1.DigitalDeviceCategory = t3.DeviceCategoryName
		) AS src
	ON dst.DigitalTouchpointMetadataHash = src.DigitalTouchpointMetadataHash

	--WHEN MATCHED THEN
	--	UPDATE SET
	--		ModifiedDate = GETDATE()
	--		,ModifiedBy = src.ModifiedBy

	WHEN NOT MATCHED THEN
		INSERT (
			DigitalTouchpointMetadataHash
			,DigitalChannelKey
			,TouchpointAccountId
			,TouchpointProfileId
			,TouchpointSegment
			,DigitalDeviceCategoryKey
			,TouchpointCityId
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
		)
		VALUES (
			src.DigitalTouchpointMetadataHash
			,src.DigitalChannelKey
			,src.TouchpointAccountId
			,src.TouchpointProfileId
			,src.TouchpointSegment
			,src.DigitalDeviceCategoryKey
			,src.TouchpointCityId
			,GETDATE()
			,src.InsertedBy
			,GETDATE()
			,src.ModifiedBy
		);
END
GO
