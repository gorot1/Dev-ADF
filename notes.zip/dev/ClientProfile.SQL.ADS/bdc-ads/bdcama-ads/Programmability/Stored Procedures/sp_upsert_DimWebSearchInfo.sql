-- =============================================
-- Author:      David Sun
-- Create Date: 2021-02-17
-- Description: Updates DimWebSearchInfo from tmp_DimWebSearchInfo
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_DimWebSearchInfo
AS
BEGIN
	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================   
	EXEC dbo.sp_ResetIdentityKeySeed  @tableName = 'dbo.DimWebSearchInfo', @identityKey = 'WebSearchInfoKey';
	-- ================================================================================== 
	-- Then update the dim table
	-- ==================================================================================   
	MERGE dbo.DimWebSearchInfo AS dst
	USING dbo.tmp_DimWebSearchInfo AS src
	ON dst.WebSearchInfoHash = src.WebSearchInfoHash

	--WHEN MATCHED THEN
	--	UPDATE SET
	--		SearchQuery = src.SearchQuery
	--		,SearchCountry = src.SearchCountry
	--		,SearchType = src.SearchType
	--		,ModifiedDate = GETDATE()
	--		,ModifiedBy = src.ModifiedBy

	WHEN NOT MATCHED THEN
		INSERT (
			WebSearchInfoHash
			,SearchQuery
			,SearchCountry
			,SearchType
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
		)
		VALUES (
			src.WebSearchInfoHash
			,src.SearchQuery
			,src.SearchCountry
			,src.SearchType
			,GETDATE()
			,USER_NAME()
			,GETDATE()
			,USER_NAME()
		);
END
GO
