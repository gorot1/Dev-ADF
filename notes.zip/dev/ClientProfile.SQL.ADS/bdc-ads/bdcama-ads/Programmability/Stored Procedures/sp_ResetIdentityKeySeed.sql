﻿-- =============================================
-- Author:      David Sun
-- Create Date: 2021-02-05
-- Description: Resets identity key seed
-- =============================================
CREATE PROCEDURE dbo.sp_ResetIdentityKeySeed
(
    @tableName VARCHAR(255),
    @identityKey VARCHAR(255)
)
AS
BEGIN
	-- Reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	EXEC ('DECLARE @MAX INT; SELECT @MAX = ISNULL(MAX(' + @identityKey + '), 1) FROM '+ @tableName + '; IF @MAX = -1 SELECT @MAX = 1; DBCC CHECKIDENT(''' + @tableName + ''', RESEED,  @MAX);');

END
GO


