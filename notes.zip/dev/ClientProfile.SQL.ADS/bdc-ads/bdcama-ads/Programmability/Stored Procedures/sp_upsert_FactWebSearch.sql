-- =============================================
-- Author:      David Sun
-- Create Date: 2021-02-16
-- Description: Updates FactWebSearch from tmp_FactWebSearch
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_FactWebSearch
AS
BEGIN
	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================   
	EXEC dbo.sp_ResetIdentityKeySeed  @tableName = 'dbo.FactWebSearch', @identityKey = 'WebSearchKey';
	-- ================================================================================== 
	-- Then update the dim table
	-- ==================================================================================  

	WITH T
	AS (
		SELECT t2.DimDateKey SearchDateKey
			,ISNULL(t3.WebPageKey, - 1) WebPageKey
			,ISNULL(t4.DigitalTouchpointMetadataKey, - 1) DigitalTouchpointMetadataKey
			,ISNULL(t1.WebSearchInfoKey, - 1) WebSearchInfoKey
			,sum(t1.SearchClickCount) SearchClickCount
			,sum(t1.SearchClickthroughRate) SearchClickthroughRate
			,sum(t1.SearchImpressionCount) SearchImpressionCount
			,t1.SearchPosition
		FROM (
			SELECT tmp.entity_event_date
				,HASHBYTES('SHA1', cast(ISNULL(channel.DigitalChannelKey, - 1) AS VARCHAR) + cast(- 1 AS VARCHAR) + cast(- 1 AS VARCHAR) + '' + cast(ISNULL(device.DigitalDeviceCategoryKey, - 1) AS VARCHAR) + cast(- 1 AS VARCHAR)) TouchpointMetadataHash
				,PageFullPathHash
				,search.WebSearchInfoKey
				,SearchClickCount
				,SearchClickthroughRate
				,SearchImpressionCount
				,SearchPosition
			FROM (
				SELECT entity_event_date
					,DeviceCategoryName
					,SearchClickCount
					,SearchClickthroughRate
					,SearchImpressionCount
					,SearchPosition
					,HASHBYTES('SHA1', ISNULL(SearchQuery, '') + ISNULL(SearchCountry, '') + ISNULL(SearchType, '')) WebSearchInfoHash
					,HASHBYTES('SHA1', ISNULL(pageFullPath, '')) PageFullPathHash
					,HASHBYTES('SHA1', N'googleorganic(not set)') ChannelHash
				FROM dbo.tmp_FactWebSearch
				) tmp
			LEFT JOIN dbo.DimDigitalChannel channel ON tmp.ChannelHash = channel.DigitalChannelHash
			LEFT JOIN dbo.DimDigitalDeviceCategory device ON tmp.DeviceCategoryName = device.DeviceCategoryName
			LEFT JOIN dbo.DimWebSearchInfo search ON tmp.WebSearchInfoHash = search.WebSearchInfoHash
			) t1
		LEFT JOIN dbo.DimDate t2 ON t1.entity_event_date = t2.DATE
		LEFT JOIN dbo.DimWebPage t3 ON t1.PageFullPathHash = t3.WebPageHash
		LEFT JOIN dbo.DimDigitalTouchpointMetadata t4 ON t1.TouchpointMetadataHash = t4.DigitalTouchpointMetadataHash
		GROUP BY t2.DimDateKey
			,t3.WebPageKey
			,t4.DigitalTouchpointMetadataKey
			,t1.WebSearchInfoKey
			,t1.SearchPosition
		)
	MERGE dbo.FactWebSearch AS dst
	USING T AS src
		ON (dst.SearchDateKey = src.SearchDateKey)
			AND (dst.WebPageKey = src.WebPageKey)
			AND (dst.DigitalTouchpointMetadataKey = src.DigitalTouchpointMetadataKey)
			AND (dst.WebSearchInfoKey = src.WebSearchInfoKey)
	WHEN MATCHED
		THEN
			UPDATE
			SET SearchClickCount = src.SearchClickCount
				,SearchClickthroughRate = src.SearchClickthroughRate
				,SearchImpressionCount = src.SearchImpressionCount
				,SearchPosition = src.SearchPosition
				,ModifiedDate = GETDATE()
				,ModifiedBy = USER_NAME()
	WHEN NOT MATCHED
		THEN
			INSERT (
				SearchDateKey
				,WebPageKey
				,DigitalTouchpointMetadataKey
				,WebSearchInfoKey
				,SearchClickCount
				,SearchClickthroughRate
				,SearchImpressionCount
				,SearchPosition
				,InsertedDate
				,InsertedBy
				,ModifiedDate
				,ModifiedBy
				)
			VALUES (
				src.SearchDateKey
				,src.WebPageKey
				,src.DigitalTouchpointMetadataKey
				,src.WebSearchInfoKey
				,src.SearchClickCount
				,src.SearchClickthroughRate
				,src.SearchImpressionCount
				,src.SearchPosition
				,GETDATE()
				,USER_NAME()
				,GETDATE()
				,USER_NAME()
				);
END
GO