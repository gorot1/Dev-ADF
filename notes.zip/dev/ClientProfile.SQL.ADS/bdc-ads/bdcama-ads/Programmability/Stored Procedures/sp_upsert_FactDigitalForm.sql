-- =============================================
-- Author:      David Sun
-- Create Date: 2021-02-09
-- Description: Updates FactDigitalForm from tmp_FactDigitalForm
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_FactDigitalForm
AS
BEGIN
	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================   
	EXEC dbo.sp_ResetIdentityKeySeed  @tableName = 'dbo.FactDigitalForm', @identityKey = 'DigitalFormKey';
	-- ================================================================================== 
	-- Then update the dim table
	-- ==================================================================================  

	WITH T AS
	(
		SELECT
			ISNULL(forminfo.DigitalFormInfoKey, -1) DigitalFormInfoKey,
			dimdate.DimDateKey FormSubmissionDateKey,
			tmp.FormCount
		FROM
			(
			SELECT 
			FormSubmissionDate, FormName, FormType, COUNT(1) FormCount
			FROM 
				dbo.tmp_FactDigitalForm
			group by FormSubmissionDate, FormName, FormType
		) tmp
		left join dbo.DimDigitalFormInfo forminfo on  tmp.FormName = forminfo.FormName and tmp.FormType = forminfo.FormType
		LEFT JOIN dbo.DimDate dimdate ON tmp.FormSubmissionDate = dimdate.Date
			
	)

	MERGE dbo.FactDigitalForm AS dst
	USING T AS src
	ON (dst.DigitalFormInfoKey = src.DigitalFormInfoKey)
	AND (dst.FormSubmissionDateKey = src.FormSubmissionDateKey)

	WHEN MATCHED THEN
		UPDATE SET
			FormCount = src.FormCount
			,ModifiedDate = GETDATE()
			,ModifiedBy = USER_NAME()
	WHEN NOT MATCHED THEN
		INSERT (
			DigitalFormInfoKey
			,FormSubmissionDateKey
			,FormCount
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
		)
		VALUES (
			src.DigitalFormInfoKey
			,src.FormSubmissionDateKey
			,src.FormCount
			,GETDATE()
			,USER_NAME()
			,GETDATE()
			,USER_NAME()
		);
END
GO
