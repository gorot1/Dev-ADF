-- =============================================
-- Author:      David Sun
-- Create Date: 2021-02-10
-- Description: Updates FactDigitalMetric from tmp_FactDigitalMetric
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_FactDigitalMetric
AS
BEGIN
	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================   
	EXEC dbo.sp_ResetIdentityKeySeed  @tableName = 'dbo.FactDigitalMetric', @identityKey = 'DigitalMetricKey';
	-- ================================================================================== 
	-- Then update the dim table
	-- ==================================================================================  
	CREATE TABLE #T
	( 
		[MetricStartDateKey]		int  NULL ,
		[MetricEndDateKey]		int  NULL ,
		[DigitalMetricGroupKey]		int  NULL ,
		[DigitalMetricInfoKey]		int  NULL ,
		[MetricRowKey]		int  NULL ,
		[MetricActualValue]		decimal(18,2)  NULL ,
		[MetricTargetValue]		decimal(18,2)  NULL 
	)
	
	IF COL_LENGTH('dbo.tmp_FactDigitalMetric', 'source') IS NOT NULL
	BEGIN
		EXEC('
		INSERT INTO #T
		SELECT
			t2.DimDateKey MetricStartDateKey,
			t3.DimDateKey MetricEndDateKey,
			ISNULL(t4.DigitalMetricGroupKey, -1) DigitalMetricGroupKey,
			ISNULL(t5.DigitalMetricInfoKey, -1) DigitalMetricInfoKey,
			ISNULL(t1.MetricRowKey, -1) MetricRowKey
			,SUM(t1.MetricActualValue) MetricActualValue,
			SUM(t1.MetricTargetValue) MetricTargetValue
		FROM 
			(
				SELECT MetricStartDate
				,MetricEndDate
				,MetricSourceTableName
				,dbo.fn_GetChannelGroupName(source, medium, campaign) MetricGroupName
				,MetricName
				,MetricRowKey
				,MetricActualValue
				,metricTargetValue 

				FROM 
				dbo.tmp_FactDigitalMetric
			
			) t1
			LEFT JOIN dbo.DimDate t2 ON t1.MetricStartDate = t2.Date
			LEFT JOIN dbo.DimDate t3 ON t1.MetricEndDate = t3.Date
			LEFT JOIN dbo.DimDigitalMetricGroup t4 ON t1.MetricSourceTableName = t4.MetricSourceTableName AND t1.MetricGroupName = t4.MetricGroupName
			LEFT JOIN dbo.DimDigitalMetricInfo t5 ON t1.MetricName = t5.MetricName
			GROUP BY t2.DimDateKey ,
			t3.DimDateKey ,
			t4.DigitalMetricGroupKey,
			t5.DigitalMetricInfoKey,
			t1.MetricRowKey
		')
	END 
		
	IF COL_LENGTH('dbo.tmp_FactDigitalMetric', 'ExpressConsents') IS NOT NULL
	BEGIN
		EXEC('
		SELECT 
			q.MetricStartDate,
			q.MetricEndDate,
			q.MetricSourceTableName,
			q.TrackName MetricGroupName,
			q.MetricRowKey,
			q.Nurturing,
			q.SubscriberNumber
		INTO #eloqua
		FROM
		(
			SELECT DISTINCT
					e.MetricStartDate,
					e.MetricEndDate,
					e.MetricSourceTableName,
					NULL MetricRowKey,
					e.Nurturing,
					tr.TrackName,
					SUM(ISNULL(   CASE
										WHEN tr.TrackName = ''Express Consents'' THEN
											nb.[ExpressConsents]
										WHEN tr.TrackName = ''In Business'' THEN
											nb.[InBusiness]
										WHEN tr.TrackName = ''Lead Nurturing'' THEN
											nb.[LeadNurturing]
										WHEN tr.TrackName = ''Client Nurturing'' THEN
											nb.[ClientNurturing]
										WHEN tr.TrackName = ''MEL'' THEN
											nb.[MEL]
										WHEN tr.TrackName = ''Newsletters'' THEN
											nb.[Newsletters]
										WHEN tr.TrackName = ''Partners'' THEN
											nb.[Partners]
										WHEN tr.TrackName = ''Profits'' THEN
											nb.[Profits]
										WHEN tr.TrackName = ''Unique Email Subscribers'' THEN
											nb.[UniqueEmailSubscribers]
									END,
									0
								)
						) SubscriberNumber
			FROM dbo.tmp_FactDigitalMetric e
				CROSS JOIN
				(
					SELECT *
					FROM
					(
						VALUES
							(''Express Consents''),
							(''In Business''),
							(''Lead Nurturing''),
							(''Client Nurturing''),
							(''MEL''),
							(''Newsletters''),
							(''Partners''),
							(''Profits''),
							(''Unique Email Subscribers'')
					) t (TrackName)
				) tr
				LEFT JOIN dbo.tmp_FactDigitalMetric nb
					ON nb.MetricStartDate = e.MetricStartDate
						AND e.Nurturing = nb.Nurturing
			GROUP BY e.MetricStartDate,
						e.MetricEndDate,
						e.MetricSourceTableName,
						e.Nurturing,
						tr.TrackName
		) q
		WHERE SubscriberNumber > 0;

		INSERT INTO #T
		SELECT *  
		FROM (
			SELECT
				t2.DimDateKey MetricStartDateKey,
				t3.DimDateKey MetricEndDateKey,
				ISNULL(t4.DigitalMetricGroupKey, -1) DigitalMetricGroupKey,
				ISNULL(t5.DigitalMetricInfoKey, -1) DigitalMetricInfoKey,
				ISNULL(t1.MetricRowKey, -1) MetricRowKey,
				t1.Nurturing,
				NULL MetricTargetValue
			FROM #eloqua t1
			LEFT JOIN dbo.DimDate t2 ON t1.MetricStartDate = t2.Date
			LEFT JOIN dbo.DimDate t3 ON t1.MetricEndDate = t3.Date
			LEFT JOIN dbo.DimDigitalMetricGroup t4 ON t1.MetricSourceTableName = t4.MetricSourceTableName AND t1.MetricGroupName = t4.MetricGroupName
			LEFT JOIN dbo.DimDigitalMetricInfo t5 ON t5.MetricName = ''Eloqua Consent Nurturing''
	
			UNION ALL

			SELECT
				t2.DimDateKey MetricStartDateKey,
				t3.DimDateKey MetricEndDateKey,
				ISNULL(t4.DigitalMetricGroupKey, -1) DigitalMetricGroupKey,
				ISNULL(t5.DigitalMetricInfoKey, -1) DigitalMetricInfoKey,
				ISNULL(t1.MetricRowKey, -1) MetricRowKey,
				t1.SubscriberNumber,
				NULL MetricTargetValue
			FROM #eloqua t1
			LEFT JOIN dbo.DimDate t2 ON t1.MetricStartDate = t2.Date
			LEFT JOIN dbo.DimDate t3 ON t1.MetricEndDate = t3.Date
			LEFT JOIN dbo.DimDigitalMetricGroup t4 ON t1.MetricSourceTableName = t4.MetricSourceTableName AND t1.MetricGroupName = t4.MetricGroupName
			LEFT JOIN dbo.DimDigitalMetricInfo t5 ON t5.MetricName = ''Eloqua Consent Subscriber Number''
		) Eloqua
	')
	END
	
	IF COL_LENGTH('dbo.tmp_FactDigitalMetric', 'OnboardedClients') IS NOT NULL
	BEGIN
		EXEC('
			SELECT 
				q.MetricStartDate,
				q.MetricEndDate,
				q.MetricSourceTableName,
				q.clientCategory MetricGroupName,
				q.MetricRowKey,
				q.[number of clients]
			INTO #eloqua
			FROM
			(
				SELECT DISTINCT
						e.MetricStartDate,
						e.MetricEndDate,
						e.MetricSourceTableName,
						NULL MetricRowKey,
						tr.clientCategory,
						SUM(ISNULL(   CASE
											WHEN tr.clientCategory = ''Onboarded clients'' THEN
												nb.[OnboardedClients]
											WHEN tr.clientCategory = ''Active clients'' THEN
												nb.[ActiveClients]
											WHEN tr.clientCategory = ''Clients remaining to onboard unsupported Ams'' THEN
												nb.[ClientsRemainingToOnboardUnsupportedAms]
											WHEN tr.clientCategory = ''Clients remaining to onboard supported Ams'' THEN
												nb.[ClientsRemainingToOnboardSupportedAms]
											WHEN tr.clientCategory = ''VBC Clients'' THEN
												nb.[VBCClients]
											WHEN tr.clientCategory = ''Automated onboardable clients'' THEN
												nb.[AutomatedOnboardableClients]
										END,
										0
									)
							) [number of clients]
				FROM dbo.tmp_FactDigitalMetric e
					CROSS JOIN
					(
						SELECT *
						FROM
						(
							VALUES
								(''Onboarded clients''),
								(''Active clients''),
								(''Clients remaining to onboard unsupported Ams''),
								(''Clients remaining to onboard supported Ams''),
								(''VBC Clients''),
								(''Automated onboardable clients'')
						) t (clientCategory)
					) tr
					LEFT JOIN dbo.tmp_FactDigitalMetric nb
						ON nb.MetricStartDate = e.MetricStartDate
				GROUP BY  e.MetricStartDate,
						e.MetricEndDate,
						e.MetricSourceTableName,
						tr.clientCategory
			) q
			WHERE [number of clients] > 0;

			INSERT INTO #T
			SELECT
				t2.DimDateKey MetricStartDateKey,
				t3.DimDateKey MetricEndDateKey,
				ISNULL(t4.DigitalMetricGroupKey, -1) DigitalMetricGroupKey,
				ISNULL(t5.DigitalMetricInfoKey, -1) DigitalMetricInfoKey,
				ISNULL(t1.MetricRowKey, -1) MetricRowKey,
				t1.[number of clients],
				NULL MetricTargetValue
			FROM #eloqua t1
			LEFT JOIN dbo.DimDate t2 ON t1.MetricStartDate = t2.Date
			LEFT JOIN dbo.DimDate t3 ON t1.MetricEndDate = t3.Date
			LEFT JOIN dbo.DimDigitalMetricGroup t4 ON t1.MetricSourceTableName = t4.MetricSourceTableName AND t1.MetricGroupName = t4.MetricGroupName
			LEFT JOIN dbo.DimDigitalMetricInfo t5 ON t5.MetricName = ''Eloqua VBC Client Number''
		')
	END


	MERGE dbo.FactDigitalMetric AS dst
	USING  #T AS src
	ON (dst.MetricStartDateKey = src.MetricStartDateKey)
	AND (dst.MetricEndDateKey = src.MetricEndDateKey)
	AND (dst.DigitalMetricGroupKey = src.DigitalMetricGroupKey)
	AND (dst.DigitalMetricInfoKey = src.DigitalMetricInfoKey)
	AND (dst.MetricRowKey = src.MetricRowKey)
	WHEN MATCHED THEN
		UPDATE SET
			MetricActualValue = src.MetricActualValue
			,MetricTargetValue = src.MetricTargetValue
			,ModifiedDate = GETDATE()
			,ModifiedBy = USER_NAME()
	WHEN NOT MATCHED THEN
		INSERT (
			MetricStartDateKey
			,MetricEndDateKey
			,DigitalMetricGroupKey
			,DigitalMetricInfoKey
			,MetricRowKey
			,MetricActualValue
			,MetricTargetValue
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
		)
		VALUES (
			src.MetricStartDateKey
			,src.MetricEndDateKey
			,src.DigitalMetricGroupKey
			,src.DigitalMetricInfoKey
			,src.MetricRowKey
			,src.MetricActualValue
			,src.MetricTargetValue
			,GETDATE()
			,USER_NAME()
			,GETDATE()
			,USER_NAME()
		);
	
END
GO