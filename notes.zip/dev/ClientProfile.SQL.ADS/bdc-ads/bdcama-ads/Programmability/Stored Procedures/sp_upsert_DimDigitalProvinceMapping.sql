-- =============================================
-- Author:      David Sun
-- Create Date: 2021-02-26
-- Description: Updates DimDigitalProvinceMapping from tmp_DimDigitalProvinceMapping
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_DimDigitalProvinceMapping
AS
BEGIN
	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================   
	EXEC dbo.sp_ResetIdentityKeySeed  @tableName = 'dbo.DimDigitalProvinceMapping', @identityKey = 'DigitalProvinceMappingKey';
	-- ================================================================================== 
	-- Then update the dim table
	-- ==================================================================================   
	MERGE dbo.DimDigitalProvinceMapping AS dst
	USING dbo.tmp_DimDigitalProvinceMapping AS src
	ON (dst.ProvinceNameEn = src.ProvinceNameEn)

	WHEN MATCHED THEN
		UPDATE SET
			ProvinceCode = src.ProvinceCode
			,FSAProvince = src.FSAProvince
			,RegionBDCEn = src.RegionBDCEn
			,ProvinceNameFr = src.ProvinceNameFr
			,RegionBDCFr = src.RegionBDCFr
			,ModifiedDate = GETDATE()
			,ModifiedBy = USER_NAME()

	WHEN NOT MATCHED THEN
		INSERT (
			[ProvinceNameEn]
			,[ProvinceCode]
			,[FSAProvince]
			,[RegionBDCEn]
			,[ProvinceNameFr]
			,[RegionBDCFr]
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
		)
		VALUES (
			src.[ProvinceNameEn]
			,src.[ProvinceCode]
			,src.[FSAProvince]
			,src.[RegionBDCEn]
			,src.[ProvinceNameFr]
			,src.[RegionBDCFr]
			,GETDATE()
			,USER_NAME()
			,GETDATE()
			,USER_NAME()
		);
END
GO
