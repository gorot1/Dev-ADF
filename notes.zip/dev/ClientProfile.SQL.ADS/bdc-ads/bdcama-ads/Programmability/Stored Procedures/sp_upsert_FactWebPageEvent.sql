-- =============================================
-- Author:      David Sun
-- Create Date: 2021-02-04
-- Description: Updates FactWebPageEvent from tmp_FactWebPageEvent
-- =============================================
CREATE PROCEDURE [dbo].[sp_upsert_FactWebPageEvent]
AS
BEGIN
	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================   

	EXEC dbo.sp_ResetIdentityKeySeed @tableName = 'dbo.FactWebPageEvent', @identityKey = 'PageEventKey';
	-- ================================================================================== 
	-- Then update the dim table
	-- ==================================================================================  
	WITH T AS
	(
	SELECT
		t2.DimDateKey PageEventDateKey,
		t1.TimeKey PageEventTimeKey,
		ISNULL(t3.WebPageKey, -1) WebPageKey,
		ISNULL(t4.DigitalTouchpointMetadataKey, -1) DigitalTouchpointMetadataKey,
		ISNULL(t5.WebPageEventInfoKey, -1) WebPageEventInfoKey,
		SUM(t1.EventCount) EventCount,
		SUM(t1.EventUniqueCount) EventUniqueCount
	FROM 
	(
		SELECT
			tmp.entity_event_date,
			tmp.TimeKey,
			HASHBYTES('SHA1', cast(ISNULL(channel.DigitalChannelKey, -1) as varchar)+cast(ISNULL(tmp.accountID, -1) as varchar)+cast(ISNULL(tmp.profileID,-1) as varchar)+cast(ISNULL(tmp.segment,'') as varchar)+cast(-1 as varchar)+cast(-1 as varchar)) TouchpointMetadataHash,
			PageFullPathHash,
			WebPageEventInfoHash,
			EventCount,
			EventUniqueCount
			FROM 
			(
				SELECT 
					entity_event_date, TimeKey, accountID, profileID, segment,
					EventCount, EventUniqueCount,
					HASHBYTES('SHA1', ISNULL(hostname, '')+ISNULL(pagePath, '')) PageFullPathHash,
					HASHBYTES('SHA1', ISNULL(source, '')+ISNULL(medium, '')+ISNULL(campaign, '')) ChannelHash,
					HASHBYTES('SHA1', EventEntityType + ISNULL(eventCategory, '') + ISNULL(eventAction, '') + ISNULL(eventLabel, '') + EventContainer) WebPageEventInfoHash
				FROM 
				dbo.tmp_FactWebPageEvent 
			) tmp
			left join dbo.DimDigitalChannel channel on  tmp.ChannelHash = channel.DigitalChannelHash 
	) t1
	LEFT JOIN dbo.DimDate t2 ON t1.entity_event_date = t2.Date
	LEFT JOIN dbo.DimWebPage t3 ON t1.PageFullPathHash = t3.WebPageHash
	LEFT JOIN dbo.DimDigitalTouchpointMetadata t4 ON t1.TouchpointMetadataHash = t4.DigitalTouchpointMetadataHash
	LEFT JOIN dbo.DimWebPageEventInfo t5 ON t1.WebPageEventInfoHash = t5.WebPageEventInfoHash
	GROUP BY t2.DimDateKey,
		t1.TimeKey,
		t3.WebPageKey,
		t4.DigitalTouchpointMetadataKey,
		t5.WebPageEventInfoKey
	)
	
	MERGE dbo.FactWebPageEvent AS dst
	USING T AS src
	ON (dst.PageEventDateKey = src.PageEventDateKey)
	AND (dst.PageEventTimeKey = src.PageEventTimeKey)
	AND (dst.WebPageKey = src.WebPageKey)
	AND (dst.DigitalTouchpointMetadataKey = src.DigitalTouchpointMetadataKey)
	AND (dst.WebPageEventInfoKey = src.WebPageEventInfoKey)
	WHEN MATCHED THEN
		UPDATE SET
			EventCount = src.EventCount
			,EventUniqueCount = src.EventUniqueCount
			,ModifiedDate = GETDATE()
			,ModifiedBy = USER_NAME()

	WHEN NOT MATCHED THEN
		INSERT (
			PageEventDateKey
			,PageEventTimeKey
			,WebPageKey
			,DigitalTouchpointMetadataKey
			,WebPageEventInfoKey
			,EventCount
			,EventUniqueCount
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
		)
		VALUES (
			src.PageEventDateKey
			,src.PageEventTimeKey
			,src.WebPageKey
			,src.DigitalTouchpointMetadataKey
			,src.WebPageEventInfoKey
			,src.EventCount
			,src.EventUniqueCount
			,GETDATE()
			,USER_NAME()
			,GETDATE()
			,USER_NAME()
		);
	
END