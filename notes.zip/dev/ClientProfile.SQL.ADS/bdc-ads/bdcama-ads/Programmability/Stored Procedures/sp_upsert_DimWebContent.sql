-- =============================================
-- Author:      David Sun
-- Create Date: 2021-02-24
-- Description: Updates DimWebContent from tmp_DimWebContent
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_DimWebContent
AS
BEGIN
	-- ==================================================================================  
	-- Firstly reseed the identity field:
	--		every autoincrement is based on the max value of the current identity field 
	--		gaps can be avoided in case some rows are deleted
	-- ==================================================================================   
	DELETE FROM dbo.DimWebContent WHERE WebContentKey > -1;
	EXEC dbo.sp_ResetIdentityKeySeed  @tableName = 'dbo.DimWebContent', @identityKey = 'WebContentKey';
	-- ================================================================================== 
	-- Then update the dim table
	-- ==================================================================================  

	WITH Transform_URLFullPath_HISTORY AS
    (
		SELECT 
				    WebPageKey UrlKey,
					PageDomain HostName,
					PageRelativePathWithoutParameters SubPagePathWithoutParameters,
					GETDATE() TimeStamp
		FROM dbo.DimWebPage ct
		WHERE ct.PageDomain LIKE '%bdc.ca'
				AND
				(
					ct.PageRelativePathWithoutParameters NOT LIKE '/fr/accounts/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/en/accounts/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/accounts/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/fr/cpm/accounts/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/en/cpm/accounts/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/fr/progress/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/en/progress/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/es_%/progress/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/fr/profile/request/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/en/profile/request/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/fr_%/progress/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/en_%/progress/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/es_%/progress/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/fr_%/summary/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/en_%/summary/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/es_%/summary/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/fr_%/detail/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/en_%/detail/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/fr%/reports/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/en%/reports/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/es_%/reports/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/fr_%/reports/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/fr/financingrequests/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/en/financingrequests/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/fr/search/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/en/search/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/undefined/search/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/d2l/home/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '%/_layouts/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/docproxy/fetch/%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/boomerang/iframekey-%'
					AND ct.PageRelativePathWithoutParameters NOT LIKE '/mx/productivitybenchmarking/%'
				)
	),

	T AS
	(
		SELECT 
		   t2.DimDateKey ContentDateKey,
		   cast(replace(convert(varchar(5), url.TimeStamp, 108), ':', '') as int) ContentTimeKey,
		   url.UrlKey ContentPageKey,
		   CAST('Web Page' AS NVARCHAR(1000)) ContentGroupName,
		   CAST(CASE
					WHEN epi.urlshortpath IS NOT NULL THEN
						'Episerver'
					WHEN tx.urlshortpath IS NOT NULL THEN
						'TaxonomyWebPages'
					WHEN am.urlshortpath IS NOT NULL THEN
						'AcademyMatrix'
					ELSE
						'[Undefined-WebPages]'
				END AS NVARCHAR(1000)) ContentTaxonomyVersionName,
		   CAST(COALESCE(epi.name, tx.name) AS NVARCHAR(1000)) ContentName,
		   CAST(COALESCE(epi.[title value], tx.[title value], am.[title value]) AS NVARCHAR(1000)) ContentTitle,
		   CAST(COALESCE(epi.[titleSEO value], tx.[titleSEO value], am.[titleSEO value]) AS NVARCHAR(1000)) ContentSEOTitle,
		   CAST(COALESCE(epi.contentType, tx.contentType, am.contentType) AS NVARCHAR(1000)) ContentTypeName,
		   CAST(COALESCE(epi.category_level1, tx.category_level1, am.category_level1) AS NVARCHAR(1000)) ContentLevel1Name,
		   CAST(COALESCE(epi.category_level2, tx.category_level2, am.category_level2) AS NVARCHAR(1000)) ContentLevel2Name,
		   CAST(COALESCE(epi.category_level3, tx.category_level3, am.category_level3) AS NVARCHAR(1000)) ContentLevel3Name,
		   CAST(COALESCE(epi.category_level4, tx.category_level4, am.category_level4) AS NVARCHAR(1000)) ContentLevel4Name,
		   CAST(COALESCE(epi.category_level5, tx.category_level5, am.category_level5) AS NVARCHAR(1000)) ContentLevel5Name,
		   CAST(COALESCE(tx.is_gated, am.is_gated) AS BIT) ContentIsGated,
		   CAST(ISNULL(tx.is_covid19, 0) AS BIT) ContentIsCovid19,
		   CAST(CASE
					WHEN dbo.fn_ContainsAnyWord(
											   url.SubPagePathWithoutParameters,
											   '/sme_research/,/recherche_pme/,/analysis-research/,/analyses-recherche/',
											   ','
										   ) = 1
						 AND dbo.fn_ContainsAnyWord(
												   url.SubPagePathWithoutParameters,
												   '/sme_research/our_team/,/recherche_pme/notre_equipe/',
												   ','
											   ) = 0
					THEN 1
					ELSE 0
				END AS BIT) ContentIsSMEResearch
		FROM Transform_URLFullPath_HISTORY url
			LEFT JOIN (SELECT * from dbo.tmp_DimWebContent where contentVersion = 'EpiServer') epi
				ON epi.urlshortpath = url.SubPagePathWithoutParameters AND url.HostName = 'bdc.ca' --Episerver
			LEFT JOIN (SELECT * from dbo.tmp_DimWebContent where contentVersion = 'TaxonomyWebPages') tx
				ON tx.urlshortpath = url.SubPagePathWithoutParameters AND url.HostName = 'bdc.ca' --Taxonomy
			LEFT JOIN (SELECT * from dbo.tmp_DimWebContent where contentVersion = 'AcademyMatrix') am
				ON am.urlshortpath = url.SubPagePathWithoutParameters AND url.HostName = 'bdc.ca' --Academy
			LEFT JOIN dbo.DimDate t2 ON CAST(url.TimeStamp AS DATE) = t2.Date
	)

	MERGE dbo.DimWebContent AS dst
	USING T AS src
	ON dst.ContentPageKey = src.ContentPageKey

	WHEN MATCHED THEN
		UPDATE SET
			ContentGroupName = src.ContentGroupName
			,ContentTaxonomyVersionName = src.ContentTaxonomyVersionName
			,ContentName = src.ContentName
			,ContentTitle = src.ContentTitle
			,ContentSEOTitle = src.ContentSEOTitle
			,ContentTypeName = src.ContentTypeName
			,ContentLevel1Name = src.ContentLevel1Name
			,ContentLevel2Name = src.ContentLevel2Name
			,ContentLevel3Name = src.ContentLevel3Name
			,ContentLevel4Name = src.ContentLevel4Name
			,ContentLevel5Name = src.ContentLevel5Name
			,ContentIsGated = src.ContentIsGated
			,ContentIsCovid19 = src.ContentIsCovid19
			,ContentIsSMEResearch = src.ContentIsSMEResearch
			,ModifiedDate = GETDATE()
			,ModifiedBy = USER_NAME()

	WHEN NOT MATCHED THEN
		INSERT (
			ContentDateKey
			,ContentTimeKey
			,ContentPageKey
			,ContentGroupName
			,ContentTaxonomyVersionName
			,ContentName
			,ContentTitle
			,ContentSEOTitle
			,ContentTypeName
			,ContentLevel1Name
			,ContentLevel2Name
			,ContentLevel3Name
			,ContentLevel4Name
			,ContentLevel5Name
			,ContentIsGated
			,ContentIsCovid19
			,ContentIsSMEResearch
			,InsertedDate
			,InsertedBy
			,ModifiedDate
			,ModifiedBy
		)
		VALUES (
			src.ContentDateKey
			,src.ContentTimeKey
			,src.ContentPageKey
			,src.ContentGroupName
			,src.ContentTaxonomyVersionName
			,src.ContentName
			,src.ContentTitle
			,src.ContentSEOTitle
			,src.ContentTypeName
			,src.ContentLevel1Name
			,src.ContentLevel2Name
			,src.ContentLevel3Name
			,src.ContentLevel4Name
			,src.ContentLevel5Name
			,src.ContentIsGated
			,src.ContentIsCovid19
			,src.ContentIsSMEResearch
			,GETDATE()
			,USER_NAME()
			,GETDATE()
			,USER_NAME()
		);
END
GO