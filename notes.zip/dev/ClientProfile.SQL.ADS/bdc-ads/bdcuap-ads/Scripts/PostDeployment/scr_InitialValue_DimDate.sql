﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-16
-- Description: Inserts initial values to DimDate
-- =============================================
SET NOCOUNT ON
DECLARE 
  @CalPeriodBeginDate DATE,
  @CalPeriodEndDate DATE,
  @FiscalYearMonthOffset int
DECLARE 
  @CYDate DATE,
  @FYDate DATE,
  @FY_StartDate DATE,
  @FY_EndDate DATE 
SELECT
   @CalPeriodBeginDate = 'Jan 1, 1900' -- Format 'MMM d, YYYY'
  ,@CalPeriodEndDate =  'Jan 1, 2099'
  ,@FiscalYearMonthOffset = 9 -- 9 = start in April

SET DATEFIRST  7 -- 1 = Monday, 7 = Sunday

SET @CYDate = @CalPeriodBeginDate
SET @FYDate = DATEADD(m, @FiscalYearMonthOffset, @CYDate)

DROP TABLE IF EXISTS #stgdate

BEGIN TRANSACTION

CREATE TABLE #StgDate(
	[DateKey] [int] NOT NULL,
	[FullDate] [date] NULL,
	[FullDateDesc] [varchar](12) NULL,
	[DayOfYear] [smallint] NULL,
	[DayOfMonth] [smallint] NULL,
	[DayOfWeekNum] [smallint] NULL,
	[DayOfWeekNameEN] [varchar](20) NULL,
	[DayOfWeekNameFR] [varchar](20) NULL,
	[WeekdayWeekendEN] [varchar](20)  NULL ,
	[WeekdayWeekendFR] [varchar](20)  NULL ,
	[WeekOfYear] [smallint] NULL,
	[MonthKey] [int] NULL,
	[MonthName] [varchar](7) NULL,
	[MonthFullNameEN] [varchar](9) NULL,
	[MonthFullNameFR] [varchar](9) NULL,
	[MonthNumInQuarter] [smallint] NULL,
	[MonthNumInYear] [smallint] NULL,
	[MonthNumOfDays] [int] NULL,
	[MonthStartDate] [int] NULL,
	[MonthEndDate] [int] NULL,
	[LastDayOfMonthFlag] [bit] NULL,
	[PriorMonth] [int] NULL,
	[NextMonth] [int] NULL,
	[MonthNextYear] [int] NULL,
	[MonthPriorYear] [int] NULL,
	[QuarterKey] [int] NULL,
	[QuarterName] [varchar](8) NULL,
	[QuarterCode] [varchar](6) NULL,
	[QuarterNumInYear] [smallint] NULL,
	[QuarterNumOfDays] [int] NULL,
	[QuarterStartDate] [int] NULL,
	[QuarterEndDate] [int] NULL,
	[QuarterStartMonth] [int] NULL,
	[QuarterEndMonth] [int] NULL,
	[PriorQuarter] [varchar](6) NULL,
	[NextQuarter] [varchar](6) NULL,
	[QuarterNextYear] [varchar](6) NULL,
	[QuarterPriorYear] [varchar](6) NULL,
	[YearKey] [int] NULL,
	[YearName] [varchar](7) NULL,
	[YearNumOfDays] [int] NULL,
	[YearStartDate] [int] NULL,
	[YearEndDate] [int] NULL,
	[YearStartMonth] [int] NULL,
	[YearEndMonth] [int] NULL,
	[PriorYear] [int] NULL,
	[NextYear] [int] NULL,
	[FiscalMonthKey] [int] NULL,
	[FiscalMonthName] [varchar](7) NULL,
	[FiscalMonthNumInQuarter] [smallint] NULL,
	[FiscalMonthNumInYear] [smallint] NULL,
	[FiscalMonthNumOfDays] [int] NULL,
	[FiscalMonthStartDate] [int] NULL,
	[FiscalMonthEndDate] [int] NULL,
	[FiscalPriorMonth] [int] NULL,
	[FiscalNextMonth] [int] NULL,
	[FiscalMonthNextYear] [int] NULL,
	[FiscalMonthPriorYear] [int] NULL,
	[FiscalQuarterKey] [int] NULL,
	[FiscalQuarterName] [varchar](8) NULL,
	[FiscalQuarterCode] [varchar](8) NULL,
	[FiscalQuarterNumInYear] [smallint] NULL,
	[FiscalQuarterNumOfDays] [int] NULL,
	[FiscalQuarterStartDate] [int] NULL,
	[FiscalQuarterEndDate] [int] NULL,
	[FiscalQuarterStartMonth] [int] NULL,
	[FiscalQuarterEndMonth] [int] NULL,
	[FiscalPriorQuarter] [varchar](6) NULL,
	[FiscalNextQuarter] [varchar](6) NULL,
	[FiscalQuarterNextYear] [varchar](6) NULL,
	[FiscalQuarterPriorYear] [varchar](6) NULL,
	[FiscalYearKey] [int] NULL,
	[FiscalYearName] [varchar](7) NULL,
	[FiscalYearNumOfDays] [int] NULL,
	[FiscalYearStartDate] [int] NULL,
	[FiscalYearEndDate] [int] NULL,
	[FiscalYearStartMonth] [int] NULL,
	[FiscalYearEndMonth] [int] NULL,
	[FiscalPriorYear] [int] NULL,
	[FiscalNextYear] [int] NULL
)
ALTER TABLE #StgDate ADD  CONSTRAINT [temp_PK_StgDate] PRIMARY KEY CLUSTERED 
(
	[DateKey] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

WHILE @CYDate <= DATEADD(YY, 1, @CalPeriodEndDate)
BEGIN  
	INSERT #StgDate
	(
		[DateKey]
		,[FullDate]
		,[FullDateDesc]
		,[DayOfYear]
		,[DayOfMonth]
		,[DayOfWeekNum]
		,[DayOfWeekNameEN]
		,[DayOfWeekNameFR]
		,[WeekdayWeekendEN]
		,[WeekdayWeekendFR]
		,[WeekOfYear]
		,[MonthKey]
		,[MonthName]
		,[MonthFullNameEN]
		,[MonthFullNameFR]
		,[MonthNumInYear]
		,[PriorMonth]
		,[NextMonth]
		,[MonthNextYear]
		,[MonthPriorYear]
		,[QuarterKey]
		,[QuarterName]
		,[QuarterCode]
		,[QuarterNumInYear]
		,[PriorQuarter]
		,[NextQuarter]
		,[QuarterNextYear]
		,[QuarterPriorYear]
		,[YearKey]
		,[YearName]
		,[YearStartDate]
		,[YearEndDate]
		,[YearStartMonth]
		,[YearEndMonth]
		,[PriorYear]
		,[NextYear]
		,[FiscalMonthKey]
		,[FiscalMonthName]
		,[FiscalMonthNumInYear]
		,[FiscalPriorMonth]
		,[FiscalNextMonth]
		,[FiscalMonthNextYear]
		,[FiscalMonthPriorYear]
		,[FiscalQuarterKey]
		,[FiscalQuarterName]
		,[FiscalQuarterCode]
		,[FiscalQuarterNumInYear]
		,[FiscalPriorQuarter]
		,[FiscalNextQuarter]
		,[FiscalQuarterNextYear]
		,[FiscalQuarterPriorYear]
		,[FiscalYearKey]
		,[FiscalYearName]
		,[FiscalPriorYear]
		,[FiscalNextYear]
	)
	SELECT
		[DateKey] = YEAR(@CYDate) * 10000  + LEFT(MONTH(@CYDate), 3) * 100 + DAY(@CYDate)
		,[FullDate] = @CYDate
		,[FullDateDesc] = LEFT(DATEname(mm, @CYDate), 3)  + ' ' + CAST(DATEPART(dd, @CYDate) AS CHAR(2)) + ', ' + CAST(YEAR(@CYDate) AS CHAR(4))
		,[DayOfYear] = DATEPART(DAYOFYEAR, @CYDate)
		,[DayOfMonth] = DATENAME(dd, @CYDate)
		,[DayOfWeekNum] = DATEPART(dw, @CYDate)
		--,[DayOfWeekNameEN] = LEFT(DATENAME(DW, @CYDate), 3)
		,[DayOfWeekNameEN] = ' ' -- added later
		,[DayOfWeekNameFR] = ' ' -- added later
		,[WeekdayWeekendEN] = ' ' -- added later
		,[WeekdayWeekendFR] = ' ' -- added later
		,[WeekOfYear] = DATEPART(ISO_WEEK, @CYDate)
		,[MonthKey] = YEAR(@CYDate)*100 + MONTH(@CYDate)
		,[MonthName] = LEFT(DATENAME(mm, @CYDate), 3) + '-' + RIGHT(CAST(YEAR(@CYDate) AS CHAR(4)), 2)
		,[MonthFullNameEN] = ' ' -- added later
		,[MonthFullNameFR] = ' ' -- added later
		,[MonthNumInYear] = MONTH(@CYDate) 
		,[PriorMonth] = YEAR(DATEADD(MM, -1, @CYDate))*100 + MONTH(DATEADD(MM, -1, @CYDate))
		,[NextMonth] =  YEAR(DATEADD(MM, 1, @CYDate))*100 + MONTH(DATEADD(MM, 1, @CYDate))
		,[MonthNextYear] = (YEAR(@CYDate) + 1)*100 + MONTH(@CYDate)
		,[MonthPriorYear] =(YEAR(@CYDate) - 1)*100 + MONTH(@CYDate)
		,[QuarterKey] = YEAR(@CYDate)*100 + DATENAME(qq, @CYDate) 
		,[QuarterName] = 'CY-' + RIGHT(CAST(YEAR(@CYDate) AS CHAR(4)), 2) + ' Q' + CAST(DATENAME(qq, @CYDate) AS CHAR(1))
		,[QuarterCode] =  CONCAT(CAST(YEAR(@CYDate) AS CHAR(4)),'Q',CAST(DATENAME(qq, @CYDate) AS CHAR(1)))
		,[QuarterNumInYear] = CAST(DATENAME(qq, @CYDate) AS SMALLINT)
		,[PriorQuarter] = CONCAT(YEAR(DATEADD(QQ, -1, @CYDate)),'Q',DATENAME(qq, (DATEADD(QQ, -1, @CYDate))))
		,[NextQuarter] = CONCAT(YEAR(DATEADD(QQ, 1, @CYDate)),'Q',DATENAME(qq, (DATEADD(QQ, 1, @CYDate))))
		,[QuarterNextYear] = CONCAT((YEAR(@CYDate) + 1),'Q',DATENAME(qq, @CYDate))
		,[QuarterPriorYear] =CONCAT((YEAR(@CYDate) - 1),'Q',DATENAME(qq, @CYDate))
		,[YearKey] = YEAR(@CYDate)
		,[YearName] = 'CY-' + RIGHT(CAST(YEAR(@CYDate) AS CHAR(4)), 2)
		,[YearStartDate] = YEAR(@CYDate)*10000 + 0101
		,[YearEndDate]= YEAR(@CYDate)*10000 + 1231
		,[YearStartMonth] = YEAR(@CYDate)*100 + 1
		,[YearEndMonth] = YEAR(@CYDate)*100 + 12
		,[PriorYear] = YEAR(@CYDate) - 1
		,[NextYear] = YEAR(@CYDate) + 1
		,[FiscalMonthKey] = YEAR(@FYDate)*100 + MONTH(@FYDate)
		,[FiscalMonthName] = LEFT(DATENAME(mm, @CYDate), 3) + '-' + RIGHT(CAST(YEAR(@CYDate) AS CHAR(4)), 2)
		,[FiscalMonthNumInYear] = MONTH(@FYDate) 
		,[FiscalPriorMonth] = YEAR(DATEADD(MM, -1, @FYDate))*100 + MONTH(DATEADD(MM, -1, @FYDate))
		,[FiscalNextMonth] = YEAR(DATEADD(MM, 1, @FYDate))*100 + MONTH(DATEADD(MM, 1, @FYDate))
		,[FiscalMonthNextYear] = (YEAR(@FYDate) + 1)*100 + MONTH(@FYDate)
		,[FiscalMonthPriorYear] = (YEAR(@FYDate) - 1)*100 + MONTH(@FYDate)
		,[FiscalQuarterKey] = YEAR(@FYDate)*100+DATENAME(qq, @FYDate)
		,[FiscalQuarterName] = 'FY-' + RIGHT(CAST(YEAR(@FYDate) AS CHAR(4)), 2) + ' Q' + CAST(DATENAME(qq, @FYDate) AS CHAR(1))
		,[FiscalQuarterCode] = CONCAT(CAST(YEAR(@FYDate) AS CHAR(4)),'Q',CAST(DATENAME(qq, @FYDate) AS CHAR(1)))
		,[FiscalQuarterNumInYear] = CAST(DATENAME(qq, @FYDate) AS SMALLINT)
		,[FiscalPriorQuarter] = CONCAT(YEAR(DATEADD(QQ, -1, @FYDate)),'Q',DATENAME(qq, (DATEADD(QQ, -1, @FYDate))))
		,[FiscalNextQuarter] = CONCAT(YEAR(DATEADD(QQ, 1, @FYDate)),'Q',DATENAME(qq, (DATEADD(QQ, 1, @FYDate))))
		,[FiscalQuarterNextYear] = CONCAT((YEAR(@FYDate) + 1),'Q',DATENAME(qq, @FYDate))
		,[FiscalQuarterPriorYear] = CONCAT((YEAR(@FYDate) - 1),'Q',DATENAME(qq, @FYDate))
		,[FiscalYearKey] = YEAR(@FYDate)
		,[FiscalYearName] = 'FY-' + RIGHT(CAST(YEAR(@FYDate) AS CHAR(4)), 2)
		,[FiscalPriorYear] = YEAR(@FYDate) - 1
		,[FiscalNextYear] = YEAR(@FYDate) + 1

	SET @CYDate = DATEADD(d, 1, @CYDate)    
	SET @FYDate = DATEADD(m, @FiscalYearMonthOffset, @CYDate)
END

;WITH result AS
(
	SELECT MonthKey, QuarterKey, ROW_NUMBER() OVER(PARTITION BY QuarterKey ORDER BY MonthKey) AS MonthNum
	FROM
	(
		SELECT DISTINCT MonthKey, QuarterKey
		FROM #StgDate
	) t
)
UPDATE stg
SET
	MonthNumInQuarter = r.MonthNum
FROM #StgDate stg
INNER JOIN result r ON r.MonthKey = stg.MonthKey

;WITH result AS
(
	SELECT MonthKey, COUNT(*) AS NumDays, MIN(DateKey) AS StartDateKey, MAX(DateKey) AS EndDateKey
	FROM #StgDate GROUP BY MonthKey
)
UPDATE stg
SET
	MonthNumOfDays = r.NumDays
	,MonthStartDate = r.StartDateKey
	,MonthEndDate = r.EndDateKey
FROM #StgDate stg
INNER JOIN result r ON r.MonthKey = stg.MonthKey

;WITH result AS
(
	SELECT QuarterKey, COUNT(*) AS NumDays, MIN(DateKey) AS StartDateKey, MAX(DateKey) AS EndDateKey, MIN(MonthKey) AS StartMonthKey, MAX(MonthKey) AS EndMonthKey
	FROM #StgDate GROUP BY QuarterKey
)
UPDATE stg
SET
	QuarterNumOfDays = r.NumDays
	,QuarterStartDate = r.StartDateKey
	,QuarterEndDate = r.EndDateKey
	,QuarterStartMonth = r.StartMonthKey
	,QuarterEndMonth = r.EndMonthKey
FROM #StgDate stg
INNER JOIN result r ON r.QuarterKey = stg.QuarterKey

UPDATE stg
SET
	YearNumOfDays = DATEDIFF(DAY, CAST(YearKey AS CHAR(4)) + '-01-01', CAST(YearKey AS CHAR(4)) + '-12-31') + 1
FROM #StgDate stg 

;WITH result AS
(
	SELECT FiscalMonthKey, FiscalQuarterKey, ROW_NUMBER() OVER(PARTITION BY FiscalQuarterKey ORDER BY FiscalMonthKey ) AS MonthNum
	FROM
	(
		SELECT DISTINCT FiscalMonthKey, FiscalQuarterKey
		FROM #StgDate
	) t
)
UPDATE stg
SET
	FiscalMonthNumInQuarter = r.MonthNum
FROM #StgDate stg
INNER JOIN result r ON r.FiscalMonthKey = stg.FiscalMonthKey

;WITH result AS
(
	SELECT MonthKey, COUNT(*) AS NumDays, MIN(DateKey) AS StartDateKey, MAX(DateKey) AS EndDateKey
	FROM #StgDate GROUP BY MonthKey
)
UPDATE stg
SET
	FiscalMonthNumOfDays = r.NumDays
	,FiscalMonthStartDate = r.StartDateKey
	,FiscalMonthEndDate = r.EndDateKey
FROM #StgDate stg
INNER JOIN result r ON r.MonthKey = stg.MonthKey

;WITH result AS
(
	SELECT FiscalQuarterKey, COUNT(*) AS NumDays, MIN(DateKey) AS StartDateKey, MAX(DateKey) AS EndDateKey, MIN(MonthKey) AS StartMonthKey, MAX(MonthKey) AS EndMonthKey
	FROM #StgDate GROUP BY FiscalQuarterKey
)
UPDATE stg
SET
	FiscalQuarterNumOfDays = r.NumDays
	,FiscalQuarterStartDate = r.StartDateKey
	,FiscalQuarterEndDate = r.EndDateKey
	,FiscalQuarterStartMonth = r.StartMonthKey
	,FiscalQuarterEndMonth = r.EndMonthKey
FROM #StgDate stg
INNER JOIN result r ON r.FiscalQuarterKey = stg.FiscalQuarterKey

;WITH result AS
(
	SELECT YearKey AS Yr, DATEADD(MM, -9, CAST(YearKey AS CHAR(4)) + '-01-01') AS StDate, DATEADD(MM, -9, CAST(YearKey AS CHAR(4)) + '-12-31') AS EndDate
	FROM #StgDate GROUP BY YearKey
)
UPDATE stg
SET
	FiscalYearStartDate = YEAR(StDate)*10000 + MONTH(StDate) * 100 + DAY(StDate)
	,FiscalYearEndDate = YEAR(EndDate)*10000 + MONTH(EndDate) * 100 + DAY(EndDate)
	,FiscalYearStartMonth = YEAR(StDate)*100 + MONTH(StDate) 
	,FiscalYearEndMonth = YEAR(EndDate)*100 + MONTH(EndDate)
	,FiscalYearNumOfDays = DATEDIFF(dd, StDate, EndDate) + 1
FROM #StgDate stg
INNER JOIN result r ON stg.FiscalYearKey = r.Yr;

UPDATE #StgDate 
SET
	MonthFullNameEN = CASE MonthNumInYear 
		WHEN 1 THEN 'January' 
		WHEN 2 THEN 'February' 
		WHEN 3 THEN 'March'
		WHEN 4 THEN 'April' 
		WHEN 5 THEN 'May' 
		WHEN 6 THEN 'Jun'
		WHEN 7 THEN 'July' 
		WHEN 8 THEN 'August' 
		WHEN 9 THEN 'September'
		WHEN 10 THEN 'October' 
		WHEN 11 THEN 'November' 
		WHEN 12 THEN 'December'
	END
	,MonthFullNameFR = CASE MonthNumInYear 
		WHEN 1 THEN 'Janvier' 
		WHEN 2 THEN 'Février' 
		WHEN 3 THEN 'Mars'
		WHEN 4 THEN 'Avril' 
		WHEN 5 THEN 'Mai' 
		WHEN 6 THEN 'Juin'
		WHEN 7 THEN 'Juillet' 
		WHEN 8 THEN 'Août' 
		WHEN 9 THEN 'Septembre'
		WHEN 10 THEN 'Octobre' 
		WHEN 11 THEN 'Novembre' 
		WHEN 12 THEN 'Décembre'
	END
	,DayOfWeekNameEN = CASE DayOfWeekNum
		WHEN 1 THEN 'Sunday'
		WHEN 2 THEN 'Monday' 
		WHEN 3 THEN 'Tuesday'
		WHEN 4 THEN 'Wednesday' 
		WHEN 5 THEN 'Thursday' 
		WHEN 6 THEN 'Friday'
		WHEN 7 THEN 'Saturday'
	END
	,[DayOfWeekNameFR] = CASE DayOfWeekNum
		WHEN 1 THEN 'Dimanche'
		WHEN 2 THEN 'Lundi' 
		WHEN 3 THEN 'Mardi'
		WHEN 4 THEN 'Mercredi' 
		WHEN 5 THEN 'Jeudi' 
		WHEN 6 THEN 'Vendredi'
		WHEN 7 THEN 'Samedi'
	END
	,[WeekdayWeekendEN] = CASE DayOfWeekNum
		WHEN 1 THEN 'Weekend'
		WHEN 7 THEN 'Weekend'
		ELSE 'Weekday'
	END
	,[WeekdayWeekendFR] = CASE DayOfWeekNum
		WHEN 1 THEN 'FinDeSemaine'
		WHEN 7 THEN 'FinDeSemaine'
		ELSE 'JourDeSemaine'
	END
	,[LastDayOfMonthFlag] = CASE
		WHEN MonthEndDate = DateKey THEN 1
		ELSE 0
	END

	INSERT INTO #StgDate (
		[DateKey]
		,[FullDate]
		,[DayOfWeekNameEN]
		,[DayOfWeekNameFR]
		,[DayOfWeekNum]
		,[DayOfMonth]
		,[DayOfYear]
		,[WeekdayWeekendEN]
		,[WeekdayWeekendFR]
		,[WeekOfYear]
		,[MonthFullNameEN]
		,[MonthFullNameFR]
		,[MonthNumInYear]
		,[LastDayOfMonthFlag]
		,[QuarterNumInYear]
		,[YearKey]
		,[MonthKey]
		,[QuarterKey]
		,[FiscalMonthNumInYear]
		,[FiscalQuarterNumInYear]
		,[FiscalYearKey]
		,[FiscalMonthKey]
		,[FiscalQuarterKey]
	)
	VALUES (
		99991231
		,'9999-12-31'
		,'Friday'
		,'Vendredi'
		,6
		,31
		,365
		,'Weekday'
		,'JourDeSemaine'
		,53
		,'December'
		,'Décembre'
		,12
		,1
		,4
		,9999
		,999912
		,999904
		,9
		,3
		,10000
		,1000012
		,1000004
	)

SET NOCOUNT OFF

;WITH
	actual_month_rank AS 
	(
		SELECT month_rank
		FROM
		(
			SELECT fulldate, Monthkey, DENSE_RANK() OVER (ORDER BY monthkey) AS month_rank
			FROM #StgDate
		) a
		WHERE fulldate = CONVERT(DATE, GETDATE())
	),
	actual_year_rank AS 
	(
		SELECT year_rank
		FROM
		(
			SELECT fulldate, Monthkey, fiscalyearkey ,DENSE_RANK() OVER (ORDER BY fiscalyearkey) AS year_rank
			FROM #StgDate
		) b
		WHERE fulldate = CONVERT(DATE, GETDATE()) 
	), 
	total_ranking AS
	(
		SELECT
			DateKey as datekeyrank
			,DENSE_RANK() over (order by monthkey) - (select month_rank from actual_month_rank) as CAL_MONTH_SEQ
			,DENSE_RANK() over (order by fiscalyearkey) - (select year_rank from actual_year_rank) as FISC_YEAR_SEQ
		FROM #StgDate
	)
    --SET IDENTITY_INSERT dbo.DimDate ON
    MERGE dbo.DimDate AS dst
    USING (
		SELECT
			[DateKey] AS [DimDateKey]
			,[FullDate] AS [Date]
			,[DayOfWeekNameEN]
			,[DayOfWeekNameFR]
			,([DayOfWeekNum] + 5) % 7 + 1 AS [DayOfWeek]
			,[DayOfMonth]
			,[DayOfYear]
			,[WeekdayWeekendEN]
			,[WeekdayWeekendFR]
			,[WeekOfYear]
			,[MonthFullNameEN] AS [MonthNameEN]
			,[MonthFullNameFR] AS [MonthNameFR]
			,[MonthNumInYear] AS [MonthOfYear]
			,[LastDayOfMonthFlag]
			,[QuarterNumInYear] AS [CalendarQuarter]
			,[YearKey] AS [CalendarYear]
			,[MonthKey] AS [CalendarYearMonth]
			,[QuarterKey] AS [CalendarYearQuarter]
			,[FiscalMonthNumInYear] AS [FiscalMonthOfYear]
			,[FiscalQuarterNumInYear] AS [FiscalQuarter]
			,[FiscalYearKey] AS [FiscalYear]
			,[FiscalMonthKey] AS [FiscalYearMonth]
			,[FiscalQuarterKey] AS [FiscalYearQuarter]
			,GETDATE() AS [InsertedDate]
			,GETDATE() AS [ModifiedDate]
		FROM #StgDate
		INNER JOIN total_ranking ON datekeyrank = datekey
	) AS src
        ON dst.[DimDateKey] = src.[DimDateKey]
    WHEN MATCHED AND (dst.[DayOfWeek] <> src.[DayOfWeek]) THEN
        UPDATE SET
			[Date] = src.[Date]
			,[DayOfWeekNameEN] = src.[DayOfWeekNameEN]
			,[DayOfWeekNameFR] = src.[DayOfWeekNameFR]
			,[DayOfWeek] = src.[DayOfWeek]
			,[DayOfMonth] = src.[DayOfMonth]
			,[DayOfYear] = src.[DayOfYear]
			,[WeekdayWeekendEN] = src.[WeekdayWeekendEN]
			,[WeekdayWeekendFR] = src.[WeekdayWeekendFR]
			,[WeekofYear] = src.[WeekofYear]
			,[MonthNameEN] = src.[MonthNameEN]
			,[MonthNameFR] = src.[MonthNameFR]
			,[MonthOfYear] = src.[MonthOfYear]
			,[LastDayOfMonthFlag] = src.[LastDayOfMonthFlag]
			,[CalendarQuarter] = src.[CalendarQuarter]
			,[CalendarYear] = src.[CalendarYear]
			,[CalendarYearMonth] = src.[CalendarYearMonth]
			,[CalendarYearQuarter] = src.[CalendarYearQuarter]
			,[FiscalMonthOfYear] = src.[FiscalMonthOfYear]
			,[FiscalQuarter] = src.[FiscalQuarter]
			,[FiscalYear] = src.[FiscalYear]
			,[FiscalYearMonth] = src.[FiscalYearMonth]
			,[FiscalYearQuarter] = src.[FiscalYearQuarter]
			,[ModifiedDate] = src.[ModifiedDate]
    WHEN NOT MATCHED THEN
		INSERT (
			[DimDateKey]
			,[Date]
			,[DayOfWeekNameEN]
			,[DayOfWeekNameFR]
			,[DayOfWeek]
			,[DayOfMonth]
			,[DayOfYear]
			,[WeekdayWeekendEN]
			,[WeekdayWeekendFR]
			,[WeekofYear]
			,[MonthNameEN]
			,[MonthNameFR]
			,[MonthOfYear]
			,[LastDayOfMonthFlag]
			,[CalendarQuarter]
			,[CalendarYear]
			,[CalendarYearMonth]
			,[CalendarYearQuarter]
			,[FiscalMonthOfYear]
			,[FiscalQuarter]
			,[FiscalYear]
			,[FiscalYearMonth]
			,[FiscalYearQuarter]
			,[InsertedDate]
			,[ModifiedDate]
		)
		VALUES (
			src.[DimDateKey]
			,src.[Date]
			,src.[DayOfWeekNameEN]
			,src.[DayOfWeekNameFR]
			,src.[DayOfWeek]
			,src.[DayOfMonth]
			,src.[DayOfYear]
			,src.[WeekdayWeekendEN]
			,src.[WeekdayWeekendFR]
			,src.[WeekofYear]
			,src.[MonthNameEN]
			,src.[MonthNameFR]
			,src.[MonthOfYear]
			,src.[LastDayOfMonthFlag]
			,src.[CalendarQuarter]
			,src.[CalendarYear]
			,src.[CalendarYearMonth]
			,src.[CalendarYearQuarter]
			,src.[FiscalMonthOfYear]
			,src.[FiscalQuarter]
			,src.[FiscalYear]
			,src.[FiscalYearMonth]
			,src.[FiscalYearQuarter]
			,src.[InsertedDate]
			,src.[ModifiedDate]
		)
    OUTPUT $ACTION as ActionType, src.*;
    --SET IDENTITY_INSERT dbo.DimDate OFF

	ALTER TABLE #StgDate DROP CONSTRAINT [temp_PK_StgDate] 
	DROP TABLE IF EXISTS #stgdate

COMMIT TRANSACTION
