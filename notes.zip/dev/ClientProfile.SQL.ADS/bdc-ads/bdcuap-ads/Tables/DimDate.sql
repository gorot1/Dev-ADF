﻿CREATE TABLE [dbo].[DimDate]
( 
	[Date]               date  NOT NULL ,
	[DayOfWeekNameEN]    varchar(20)  NULL ,
	[DayOfWeekNameFR]    varchar(20)  NULL ,
	[DayOfMonth]         [Integer] ,
	[DayOfYear]          [Integer] ,
	[WeekdayWeekendEN]   varchar(20)  NULL ,
	[WeekdayWeekendFR]   varchar(20)  NULL ,
	[WeekofYear]         [Integer] ,
	[MonthNameEN]        varchar(20)  NULL ,
	[MonthNameFR]        varchar(20)  NULL ,
	[MonthOfYear]        [Integer] ,
	[LastDayOfMonthFlag] bit  NULL ,
	[CalendarQuarter]    [Integer] ,
	[CalendarYear]       [Integer] ,
	[CalendarYearMonth]  [Integer] ,
	[CalendarYearQuarter] [Integer] ,
	[FiscalMonthOfYear]  [Integer] ,
	[FiscalQuarter]      [Integer] ,
	[FiscalYear]         [Integer] ,
	[FiscalYearMonth]    [Integer] ,
	[FiscalYearQuarter]  [Integer] ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[DimDateKey]         [Integer]  NOT NULL ,
	[DayOfWeek]          [Integer] 
)
go

ALTER TABLE [dbo].[DimDate]
	ADD CONSTRAINT [XPKDimDate] PRIMARY KEY  CLUSTERED ([DimDateKey] ASC)
go

ALTER TABLE [dbo].[DimDate]
	ADD CONSTRAINT [XAK1DimDate] UNIQUE ([Date]  ASC)
go