﻿CREATE TABLE [dbo].[DimTime]
( 
	[TimeKey]		            int				NOT NULL,
	[FullTime]                  time(7)			NOT NULL,
	[Hour24]		            tinyint			NOT NULL,
	[Hour12]		            tinyint			NOT NULL,
	[Minute]		            tinyint			NOT NULL,
	[AMPM]		                char(2)			NOT NULL,
	[InsertedDate]		        datetime		NOT NULL	CONSTRAINT DF_DimTime_InsertedDate	DEFAULT SYSDATETIME(),
	[ModifiedDate]		        datetime		NOT NULL    CONSTRAINT DF_DimTime_ModifiedDate	DEFAULT SYSDATETIME(),
	[ModifiedBy]		        varchar(128)	NOT NULL    CONSTRAINT DF_DimTime_ModifiedBy	DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_DimTime] PRIMARY KEY CLUSTERED ([TimeKey] ASC),
	CONSTRAINT [UX_DimTime] UNIQUE ([FullTime] ASC)
)
GO