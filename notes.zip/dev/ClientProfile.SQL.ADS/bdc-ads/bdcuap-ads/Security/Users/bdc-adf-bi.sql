﻿CREATE USER [bdc-adf-d-bi-construction] FROM EXTERNAL PROVIDER;
GO

GRANT CONNECT TO [bdc-adf-d-bi-construction];
GO
