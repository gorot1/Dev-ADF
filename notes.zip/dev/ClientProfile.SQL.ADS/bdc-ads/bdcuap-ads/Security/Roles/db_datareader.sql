﻿ALTER ROLE [db_datareader] ADD MEMBER [bdc-adf-d-bi-construction];
GO
