﻿ALTER ROLE [db_datawriter] ADD MEMBER [bdc-adf-d-bi-construction];
GO
