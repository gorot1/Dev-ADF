﻿CREATE ROLE [db_executor]
    AUTHORIZATION [dbo];
GO

ALTER ROLE [db_executor] ADD MEMBER [bdc-adf-d-bi-construction];
GO
