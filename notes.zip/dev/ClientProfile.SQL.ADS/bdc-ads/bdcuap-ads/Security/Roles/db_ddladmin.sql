﻿ALTER ROLE [db_ddladmin] ADD MEMBER [bdc-adf-d-bi-construction];
GO
