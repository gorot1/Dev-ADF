CREATE VIEW [AAS].[vwDate] AS
SELECT
    DD.Date AS DateShort
    ,DD.DayOfWeekNameEN AS WeekDayName
    ,DD.DayOfMonth
    ,DD.LastDayOfMonthFlag AS IsLastDayOfMonth
    ,DD.FiscalYearMonth AS FiscalPeriod
    ,DD.FiscalMonthOfYear AS FiscalMonth
    ,DD.FiscalQuarter
    ,CONCAT('Q', DD.FiscalQuarter) AS FiscalQuarterAbbr
    ,DD.FiscalYear
    ,DD.MonthNameEN AS MonthName
    ,LEFT(DD.MonthNameEN, 3) AS MonthNameAbbr
    ,DD.MonthOfYear AS CalendarMonth
    ,DD.CalendarQuarter
    ,DD.CalendarYear
FROM
    dbo.DimDate DD
    INNER JOIN (SELECT FiscalYear
        FROM dbo.DimDate
        WHERE DimDateKey = CAST(FORMAT(SYSDATETIME(), 'yyyyMMdd') AS INT)) CUR ON DD.FiscalYear BETWEEN (CUR.FiscalYear - 2) AND (CUR.FiscalYear + 2)
GO