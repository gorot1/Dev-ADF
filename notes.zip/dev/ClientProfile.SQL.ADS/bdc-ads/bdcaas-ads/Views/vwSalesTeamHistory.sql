CREATE VIEW [AAS].[vwSalesTeamHistory] AS
SELECT
    DRB.BranchCode
    ,DRB.BranchName
    ,DRB.RegionName
    ,DECP.EmployeePIN       AS ClientPartnerPIN
    ,DECP.EmployeeFullName  AS ClientPartnerName
    ,DED.EmployeePIN        AS DirectorPIN
    ,DED.EmployeeFullName   AS DirectorName
    ,DEVP.EmployeePIN       AS VicePresidentPIN
    ,DEVP.EmployeeFullName  AS VicePresidentName
    ,FST._StartDate
    ,FST._EndDate
FROM
    AAS.FactSalesTeam FST
    INNER JOIN AAS.DimRegionBranch DRB ON FST.RegionBranchId = DRB.DimRegionBranchId
    INNER JOIN AAS.DimEmployee DECP ON FST.ClientPartnerEmployeeId = DECP.DimEmployeeId
    INNER JOIN AAS.DimEmployee DED ON FST.DirectorEmployeeId = DED.DimEmployeeId
    INNER JOIN AAS.DimEmployee DEVP ON FST.VicePresidentEmployeeId = DEVP.DimEmployeeId
GO