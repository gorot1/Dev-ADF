﻿CREATE VIEW [AAS].[vwProjectStatus] AS
SELECT
    DP.ProjectCode
    ,DP.ProjectName
    ,DPS.ProjectStatusCode
    ,DPS.ProjectStatusName
    ,DDF.Date AS ProjectStatusFirstDate
    ,DDL.Date AS ProjectStatusLastDate
    ,FPS.ProjectStatusSeq
    ,DATEDIFF(DAY, DDF.Date, DDL.Date) AS ProjectStatusDays
FROM
    AAS.FactProjectStatus FPS
    INNER JOIN AAS.DimProject DP ON FPS.ProjectId = DP.DimProjectId
    INNER JOIN AAS.DimProjectStatus DPS ON FPS.ProjectStatusId = DPS.DimProjectStatusId
    LEFT OUTER JOIN dbo.DimDate DDF ON FPS.ProjectStatusFirstDateId = DDF.DimDateKey
    LEFT OUTER JOIN dbo.DimDate DDL ON FPS.ProjectStatusLastDateId = DDL.DimDateKey

WHERE
    FPS._StartDate <= SYSDATETIME()
    AND FPS._EndDate > SYSDATETIME()
GO