CREATE VIEW [AAS].[vwProjectHistory] AS
SELECT
    DP.ProjectCode
    ,DP.ProjectName
    ,DO.OpportunityCode
    ,DPT.ProjectTypeNo
    ,DPT.ProjectTypeName
    ,DC.CustomerCode
    ,DC.CustomerName
    ,DPE.ProjectStateCode
    ,DPE.ProjectStateName
    ,DPU.ProjectStatusCode
    ,DPU.ProjectStatusName
    ,DDS.Date AS ProjectStatusDate
    ,DE.EmployeePIN
    ,DE.EmployeeFullName
    ,DRB.BranchCode
    ,DRB.BranchName
    ,DRB.RegionName
    ,DSS.SolutionName
    ,DPJF.ProjectJobFamilyCode
    ,DPJF.ProjectJobFamilyName
    ,DDPS.Date AS ProjectStartDate
    ,DDPE.Date AS ProjectEndDate
    ,DDFA.Date AS FirstActivityDate
    ,DDLA.Date AS LastActivityDate
    ,FP.ClientNbrYTD
    ,FP.MandateNbrYTD
    ,FP.SalesAmtYTD
    ,FP.RevenueAmtYTD
    ,FP.GrossMarginYTD
    ,FP.BadDebtsYTD
    ,FP.NetMarginYTD
    ,FP.UnearnedAmt
    ,FP.ProjectAmt
    ,FP.NumberOfMandates
    ,FP.NetSalesAmt
    ,FP.RevenueAmt
    ,FP.ExternalConsultingFeeAmt
    ,FP.InternalConsultingFeeAmt
    ,FP.GrossMarginAmt
    ,FP.ResourceNonRevAmt
    ,FP.ResourceNonRevAmt AS SalesCancellationAmt
    ,CASE WHEN UPPER(DPE.ProjectStateCode) LIKE 'ON HOLD%' AND FP.RefEmployeeId < 1 THEN 1 ELSE 0 END AS IsDelayed
    ,CASE
		WHEN DATEDIFF(MONTH, DPP.ProjectStartDate, COALESCE(DP.FirstActivityDate, DP.ProjectStartDate)) < 18 THEN 'Repeat'
        WHEN UPPER(DPJF.ProjectJobFamilyCode) IN ('CG', 'MC', 'RC', 'N/A') THEN 'Acquisition'
        ELSE 'Referral/Portfolio'
    END AS ProjectChannel
    ,FP._StartDate
    ,FP._EndDate
FROM
    AAS.FactProject FP
    INNER JOIN AAS.DimProject DP ON FP.ProjectId = DP.DimProjectId
    INNER JOIN AAS.DimOpportunity DO ON FP.OpportunityId = DO.DimOpportunityId
    INNER JOIN AAS.DimProjectType DPT ON FP.ProjectTypeId = DPT.DimProjectTypeId
    INNER JOIN AAS.DimCustomer DC ON FP.CustomerId = DC.DimCustomerId
    INNER JOIN AAS.DimProjectState DPE ON FP.ProjectStateId = DPE.DimProjectStateId
    INNER JOIN AAS.DimProjectStatus DPU ON FP.ProjectStatusId = DPU.DimProjectStatusId
    INNER JOIN AAS.DimEmployee DE ON FP.RefEmployeeId = DE.DimEmployeeId
    INNER JOIN AAS.DimRegionBranch DRB ON FP.RefRegionBranchId = DRB.DimRegionBranchId
    INNER JOIN AAS.DimSegmentSolution DSS ON FP.SegmentSolutionId = DSS.DimSegmentSolutionId
    INNER JOIN AAS.DimProjectJobFamily DPJF ON FP.ProjectJobFamilyId = DPJF.DimProjectJobFamilyId
    INNER JOIN AAS.DimProject DPP ON FP.CustomerPrevProjectId = DPP.DimProjectId
    LEFT OUTER JOIN dbo.DimDate DDS ON FP.ProjectStatusDateId = DDS.DimDateKey
    LEFT OUTER JOIN dbo.DimDate DDPS ON FP.ProjectStartDateId = DDPS.DimDateKey
    LEFT OUTER JOIN dbo.DimDate DDPE ON FP.ProjectEndDateId = DDPE.DimDateKey
    LEFT OUTER JOIN dbo.DimDate DDFA ON FP.FirstActivityDateId = DDFA.DimDateKey
    LEFT OUTER JOIN dbo.DimDate DDLA ON FP.LastActivityDateId = DDLA.DimDateKey
GO
