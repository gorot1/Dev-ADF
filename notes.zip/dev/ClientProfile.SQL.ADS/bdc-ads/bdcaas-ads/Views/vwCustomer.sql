CREATE VIEW [AAS].[vwCustomer] AS
SELECT
    DC.CustomerCode
    ,DC.CustomerName
FROM
    AAS.DimCustomer DC
GO