CREATE VIEW AAS.vwMandateHistory AS
SELECT
   DDJ.Date AS JournalLineDate
    ,DDJ.FiscalYear
    ,DDJ.FiscalYearMonth AS FiscalPeriod
    ,DP.ProjectCode
    ,DP.ProjectName
    ,DEPM.EmployeePIN AS ProjectManagerPIN
    ,DEPM.EmployeeFullName AS ProjectManagerName
    ,DRB.BranchCode
    ,DRB.BranchName
    ,DRB.RegionName
    ,FPM.ContributionPct AS ProjectContributionPct
    ,FPM.ClientNbrYTD
    ,FPM.MandateNbrYTD
    ,FPM.SalesAmtYTD
    ,FPM.RevenueAmtYTD
    ,FPM.GrossMarginYTD
    ,FPM.BadDebtsYTD
    ,FPM.NetMarginYTD
    ,FPM.UnearnedAmt
    ,FPM.ProjectAmt
    ,FPM.NumberOfMandates
    ,FPM.NetSalesAmt
    ,FPM.RevenueAmt
    ,FPM.ExternalConsultingFeeAmt
    ,FPM.InternalConsultingFeeAmt
    ,FPM.GrossMarginAmt
    ,FPM.ResourceNonRevAmt
    ,FPM.ResourceRevAmt
    ,FPM.ResourceNonRevAmt AS SalesCancellationAmt
    ,CASE
        WHEN DDJ.Date = DP.FirstActivityDate THEN 'Initial Sales'
        WHEN (FPM.ResourceNonRevAmt + FPM.ResourceRevAmt) > 0 THEN 'Scope Increase'
        WHEN (SUM(FPM.ResourceNonRevAmt + FPM.ResourceRevAmt) OVER (PARTITION BY FPM.ProjectId)) < 0 THEN 'Full Cancellations'
        ELSE 'Partial Cancellations'
    END AS SaleCancellationState
    ,FPM._StartDate
    ,FPM._EndDate
FROM
    AAS.FactMandate FPM
    INNER JOIN AAS.DimProject DP ON FPM.ProjectId = DP.DimProjectId
    INNER JOIN AAS.DimEmployee DEPM ON FPM.ProjectManagerEmployeeId = DEPM.DimEmployeeId
    INNER JOIN AAS.DimRegionBranch DRB ON FPM.RegionBranchId = DRB.DimRegionBranchId
    LEFT OUTER JOIN dbo.DimDate DDJ ON FPM.JournalLineDateId = DDJ.DimDateKey
GO
