--CREATE MATERIALIZED VIEW AAS.vwOpportunityHistory WITH (DISTRIBUTION = HASH(OpportunityCode)) AS
CREATE VIEW [AAS].[vwOpportunityHistory] AS
SELECT
    DO.OpportunityCode
    ,DDC.Date AS OpportunityCreatedDate
    ,CASE WHEN FA.CustomerId < 1 THEN NULL ELSE DCU.CustomerCode END AS CustomerCode
    ,CASE WHEN FA.CustomerId < 1 THEN NULL ELSE DCU.CustomerName END AS CustomerName
    ,CASE WHEN FA.RegionBranchId < 1 THEN NULL ELSE DRB.BranchCode END AS BranchCode
    ,CASE WHEN FA.RegionBranchId < 1 THEN NULL ELSE DRB.BranchName END AS BranchName
    ,CASE WHEN FA.RegionBranchId < 1 THEN NULL ELSE DRB.RegionName END AS RegionName
    ,CASE WHEN FA.SegmentSolutionId < 1 THEN NULL ELSE DSS.SolutionName END AS SolutionName
    ,CASE WHEN FA.OpportunityRatingId < 1 THEN NULL ELSE DOR.OpportunityRatingName END AS OpportunityRatingName
    ,CASE WHEN FA.OpportunityStageId < 1 THEN NULL ELSE DOSG.OpportunityStageName END AS OpportunityStageName
    ,CASE WHEN FA.OpportunityStageId < 1 THEN NULL ELSE DOSG.OpportunityStageSeq END AS OpportunityStageSeq
    ,DOSG.IsQualifiedStage
    ,DOSG.IsProposedStage
    ,DOSG.IsSalesStage
    ,CASE WHEN DDSG.DimDateKey < 1 THEN NULL ELSE DDSG.Date END AS OpportunityStageDate
    ,DATEDIFF(DAY, DDSG.Date, SYSDATETIME()) AS OpportunityStageDays
    ,CASE WHEN FA.OpportunityStateId < 1 THEN NULL ELSE DOST.OpportunityStateName END AS StatusName
    ,CASE WHEN DDST.DimDateKey < 1 THEN NULL ELSE DDST.Date END AS ConsultingStateDate
    ,DATEDIFF(DAY, DDST.Date, SYSDATETIME()) AS ConsultingStateDays
    ,CASE WHEN FA.OpportunityStatusId < 1 THEN NULL ELSE DOSU.OpportunityStatusName END AS StatusReasonName
    ,CASE WHEN FA.ClientPartnerEmployeeId < 1 THEN NULL ELSE DECP.EmployeePIN END AS ClientPartnerPIN
    ,CASE WHEN FA.ClientPartnerEmployeeId < 1 THEN NULL ELSE DECP.EmployeeFullName END AS ClientPartnerName
    ,CASE WHEN FA.ReferrerEmployeeId < 1 THEN NULL ELSE DER.EmployeePIN END AS ReferrerPIN
    ,CASE WHEN FA.ReferrerEmployeeId < 1 THEN NULL ELSE DER.EmployeeFullName END AS ReferrerName
    ,CASE WHEN FA.CampaignId < 1 THEN NULL ELSE DC.CampaignName END AS CampaignName
    ,CASE WHEN FA.OpportunitySourceId < 1 THEN NULL ELSE DOS.OpportunitySourceName END AS OpportunitySourceName
    ,CASE WHEN DDEC.DimDateKey < 1 THEN NULL ELSE DDEC.Date END AS EstimatedCloseDate
    ,CASE WHEN FA.ReferrerLineOfBusinessId < 1 THEN NULL ELSE DLOBR.LineOfBusinessName END AS ReferrerLineOfBusinessName
    ,FA.OpportunityEstimatedAmt
    ,CASE WHEN UPPER(DOS.OpportunitySourceName) IN ('CLIENT INITIATED', 'PERSONAL INITIATIVE', 'PERSONAL REFERRALS', 'BDL REFERRALS', 'ROUND TABLES')
        AND DOST.IsLostState = 1
        AND UPPER(DOSU.OpportunityStatusName) NOT IN ('OPPORTUNITY CANCELLED', 'OPPORTUNITY CREATED IN ERROR')
        THEN 1 ELSE 0 END IsProgramDelivered
    ,DO.IsAccess1On1
    ,CASE WHEN DO.IsAccess1On1 = 1 AND DDC.Date BETWEEN '2020-10-01' AND '2021-02-28' THEN 1 ELSE 0 END AS IsAccess1On1Initiated
    ,CASE WHEN DO.IsAccess1On1 = 1 AND DDC.Date BETWEEN '2020-10-01' AND '2021-02-28'
        AND DOST.IsLostState = 1 AND UPPER(DOSU.OpportunityStatusName) NOT IN ('OPPORTUNITY CANCELLED', 'OPPORTUNITY CREATED IN ERROR') THEN 1
        ELSE 0 END AS IsAccess1On1Delivered
    ,FA.IsBusinessDevelopment
    ,FA._StartDate
    ,FA._EndDate
FROM
    AAS.FactOpportunity FA
    INNER JOIN AAS.DimOpportunity DO ON FA.OpportunityId = DO.DimOpportunityId
    INNER JOIN AAS.DimCustomer DCU ON FA.CustomerId = DCU.DimCustomerId
    INNER JOIN AAS.DimRegionBranch DRB ON FA.RegionBranchId = DRB.DimRegionBranchId
    INNER JOIN AAS.DimSegmentSolution DSS ON FA.SegmentSolutionId = DSS.DimSegmentSolutionId
    INNER JOIN AAS.DimOpportunityRating DOR ON FA.OpportunityRatingId = DOR.DimOpportunityRatingId
    INNER JOIN AAS.DimOpportunityStage DOSG ON FA.OpportunityStageId = DOSG.DimOpportunityStageId
    INNER JOIN AAS.DimOpportunityState DOST ON FA.OpportunityStateId = DOST.DimOpportunityStateId
    INNER JOIN AAS.DimOpportunityStatus DOSU ON FA.OpportunityStatusId = DOSU.DimOpportunityStatusId
    INNER JOIN AAS.DimEmployee DECP ON FA.ClientPartnerEmployeeId = DECP.DimEmployeeId
    INNER JOIN AAS.DimEmployee DER ON FA.ReferrerEmployeeId = DER.DimEmployeeId
    INNER JOIN AAS.DimCampaign DC ON FA.CampaignId = DC.DimCampaignId
    INNER JOIN AAS.DimLineOfBusiness DLOB ON FA.LineOfBusinessId = DLOB.DimLineOfBusinessId
    INNER JOIN AAS.DimOpportunitySource DOS ON FA.OpportunitySourceId = DOS.DimOpportunitySourceId
    INNER JOIN AAS.DimLineOfBusiness DLOBR ON FA.ReferrerLineOfBusinessId = DLOBR.DimLineOfBusinessId
    LEFT OUTER JOIN dbo.DimDate DDC ON FA.OpportunityCreatedDateId = DDC.DimDateKey
    LEFT OUTER JOIN dbo.DimDate DDSG ON FA.OpportunityStageDateId = DDSG.DimDateKey
    LEFT OUTER JOIN dbo.DimDate DDST ON FA.OpportunityStateDateId = DDST.DimDateKey
    LEFT OUTER JOIN dbo.DimDate DDEC ON FA.EstimatedCloseDateId = DDEC.DimDateKey
WHERE
    --DLOB.IsConsulting = 1
    DOSU.OpportunityStatusCode <> '803750012'
GO