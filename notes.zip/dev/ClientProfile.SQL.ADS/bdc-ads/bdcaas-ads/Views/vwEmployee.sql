CREATE VIEW [AAS].[vwEmployee] AS
SELECT
    EmployeePIN
    ,EmployeeFullName
    ,EmployeeLastName
    ,EmployeeFirstName
FROM
    AAS.DimEmployee
GO