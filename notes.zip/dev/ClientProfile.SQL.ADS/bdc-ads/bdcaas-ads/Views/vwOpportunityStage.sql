CREATE VIEW [AAS].[vwOpportunityStage] AS
SELECT
    DO.OpportunityCode
    ,FOS.OpportunityStageSeq AS OpportunityHistoryStageSeq
    ,DOS.OpportunityStageSeq
    ,DOS.OpportunityStageName
    ,DOS.IsQualifiedStage
    ,DOS.IsProposedStage
    ,DOS.IsSalesStage
	,DOSE.IsWonState
	,DOSE.IsLostState
    ,CASE WHEN FOS.OpportunityStageFirstDateId < 1 THEN NULL ELSE DDF.Date END AS OpportunityStageFirstDate
    ,CASE
        WHEN (FOS.OpportunityStageLastDateId < 1 AND FO.OpportunityStageDateId < 1) THEN CAST(SYSDATETIME() AS DATE)
        WHEN (FOS.OpportunityStageLastDateId < 1) AND (DDF.Date < DDS.Date) THEN DDS.Date
        WHEN (FOS.OpportunityStageLastDateId < 1) THEN DDF.Date
		WHEN (DDL.Date > SYSDATETIME() AND (DOSE.IsWonState = 1 OR DOSE.IsLostState = 1)) THEN DDF.Date
		WHEN (DDL.Date > SYSDATETIME()) THEN CAST(SYSDATETIME() AS DATE)
        ELSE DDL.Date END AS OpportunityStageLastDate
    ,CASE
        WHEN (FOS.OpportunityStageLastDateId < 1 AND FO.OpportunityStageDateId < 1) THEN DATEDIFF(DAY, DDF.Date, SYSDATETIME())
        WHEN (FOS.OpportunityStageLastDateId < 1) AND (DDF.Date < DDS.Date) THEN DATEDIFF(DAY, DDF.Date, DDS.Date)
        WHEN (FOS.OpportunityStageLastDateId < 1) THEN DATEDIFF(DAY, DDF.Date, DDF.Date)
		WHEN (DDL.Date > SYSDATETIME() AND (DOSE.IsWonState = 1 OR DOSE.IsLostState = 1)) THEN DATEDIFF(DAY, DDF.Date, DDF.Date)
		WHEN (DDL.Date > SYSDATETIME()) THEN DATEDIFF(DAY, DDF.Date, SYSDATETIME())
        ELSE DATEDIFF(DAY, DDF.Date, DDL.Date) END AS OpportunityStageDays
FROM
    AAS.FactOpportunityStage FOS
    INNER JOIN AAS.DimOpportunity DO ON FOS.OpportunityId = DO.DimOpportunityId
    INNER JOIN AAS.DimOpportunityStage DOS ON FOS.OpportunityStageId = DOS.DimOpportunityStageId
    INNER JOIN AAS.FactOpportunity FO ON FOS.OpportunityId = FO.OpportunityId
        AND FO._StartDate <= SYSDATETIME()
        AND FO._EndDate > SYSDATETIME()
        AND FOS.OpportunityId > 0
    INNER JOIN AAS.DimOpportunityStatus DOSU ON FO.OpportunityStatusId = DOSU.DimOpportunityStatusId
    INNER JOIN AAS.DimOpportunityState DOSE ON FO.OpportunityStateId = DOSE.DimOpportunityStateId
    LEFT OUTER JOIN dbo.DimDate DDF ON FOS.OpportunityStageFirstDateId = DDF.DimDateKey
    LEFT OUTER JOIN dbo.DimDate DDL ON FOS.OpportunityStageLastDateId = DDL.DimDateKey
    LEFT OUTER JOIN dbo.DimDate DDS ON FO.OpportunityStageDateId = DDS.DimDateKey
WHERE
    FOS._StartDate <= SYSDATETIME()
    AND FOS._EndDate > SYSDATETIME()
    AND DOSU.OpportunityStatusCode <> '803750012'
GO