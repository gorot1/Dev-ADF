﻿CREATE VIEW [AAS].[vwProjectWorkflow] AS
SELECT
    DP.ProjectCode
    ,DP.ProjectName
    ,DD.Date AS ProjectWorkflowDate
    ,DPW.ProjectWorkflowSource
    ,DPW.ProjectWorkflowDestination
    ,DPW.ProjectWorkflowAction
    ,FPW.ProjectWorkflowSeq
FROM
    AAS.FactProjectWorkflow FPW
    INNER JOIN AAS.DimProject DP ON FPW.ProjectId = DP.DimProjectId
    LEFT OUTER JOIN dbo.DimDate DD ON FPW.ProjectWorkflowDateId = DD.DimDateKey
    INNER JOIN AAS.DimProjectWorkflow DPW ON FPW.ProjectWorkflowId = DPW.DimProjectWorkflowId
WHERE
    FPW._StartDate <= SYSDATETIME()
    AND FPW._EndDate > SYSDATETIME()
GO