CREATE VIEW [AAS].[vwCustomerActivity] AS
SELECT
    FCA.FactCustomerActivityKey AS ActivityCode
    ,CASE WHEN FCA.CustomerId < 1 THEN NULL ELSE DC.CustomerCode END AS CustomerCode
    ,CASE WHEN FCA.CustomerId < 1 THEN NULL ELSE DC.CustomerName END AS CustomerName
    ,CASE WHEN FCA.ActivityTypeId < 1 THEN NULL ELSE DAT.ActivityTypeCode END AS ActivityTypeCode
    ,CASE WHEN FCA.ActivityTypeId < 1 THEN NULL ELSE DAT.ActivityTypeName END AS ActivityTypeName
    ,CASE WHEN FCA.OwnerEmployeeId < 1 THEN NULL ELSE DEO.EmployeePIN END AS OwnerEmployeePIN
    ,CASE WHEN FCA.OwnerEmployeeId < 1 THEN NULL ELSE DEO.EmployeeFullName END AS OwnerName
    ,CASE WHEN FCA.RegionBranchId < 1 THEN NULL ELSE DRB.BranchCode END AS BranchCode
    ,CASE WHEN FCA.RegionBranchId < 1 THEN NULL ELSE DRB.BranchName END AS BranchName
    ,CASE WHEN FCA.RegionBranchId < 1 THEN NULL ELSE DRB.RegionName END AS RegionName
    ,CASE WHEN DDSF.DimDateKey < 1 THEN NULL ELSE DDSF.Date END AS ScheduledStartDate
    ,CASE WHEN DDSL.DimDateKey < 1 THEN NULL ELSE DDSL.Date END AS ScheduledEndDate
    ,CASE WHEN DDSL.Date IS NULL OR DDSL.Date > SYSDATETIME() THEN DATEDIFF(DAY, DDSF.Date, SYSDATETIME()) ELSE DATEDIFF(DAY, DDSF.Date, DDSL.Date) END AS ScheduledDays
    ,CASE WHEN DDAF.DimDateKey < 1 THEN NULL ELSE DDAF.Date END AS ActualStartDate
    ,CASE WHEN DDAL.DimDateKey < 1 THEN NULL ELSE DDAL.Date END AS ActualEndDate
    ,CASE WHEN DDAL.Date IS NULL OR DDAL.Date > SYSDATETIME() THEN DATEDIFF(DAY, DDAF.Date, SYSDATETIME()) ELSE DATEDIFF(DAY, DDAF.Date, DDAL.Date) END AS ActualDays
    ,CASE WHEN DDAL.Date IS NULL OR DDAL.Date >= DATEADD(WEEK, -2, SYSDATETIME()) THEN 1 ELSE 0 END AS IsLast2Weeks
    --,COUNT(1)   AS CustomerActivityCount
FROM
    AAS.FactCustomerActivity FCA
    INNER JOIN AAS.DimCustomer DC ON FCA.CustomerId = DC.DimCustomerId
    INNER JOIN AAS.DimActivityType DAT ON FCA.ActivityTypeId = DAT.DimActivityTypeId
    INNER JOIN AAS.DimEmployee DEO ON FCA.OwnerEmployeeId = DEO.DimEmployeeId
    INNER JOIN AAS.DimRegionBranch DRB ON FCA.RegionBranchId = DRB.DimRegionBranchId
    LEFT OUTER JOIN dbo.DimDate DDSF ON FCA.ScheduledStartDateId = DDSF.DimDateKey
    LEFT OUTER JOIN dbo.DimDate DDSL ON FCA.ScheduledEndDateId = DDSL.DimDateKey
    LEFT OUTER JOIN dbo.DimDate DDAF ON FCA.ActualStartDateId = DDAF.DimDateKey
    LEFT OUTER JOIN dbo.DimDate DDAL ON FCA.ActualEndDateId = DDAL.DimDateKey
WHERE
    FCA._StartDate <= SYSDATETIME()
    AND FCA._EndDate > SYSDATETIME()
GO