﻿CREATE TABLE [AAS].[FactProjectStatus]
( 
	[FactProjectStatusId] int  IDENTITY ( 1,1 )  NOT NULL ,
	[FactProjectStatusKey] varchar(100)  NOT NULL ,
	[ProjectId]          int  NULL ,
	[ProjectStatusId]    int  NULL ,
	[ProjectStatusFirstDateId] int  NULL ,
	[ProjectStatusLastDateId] int  NULL ,
	[ProjectStatusSeq]   integer  NOT NULL ,
	[_StartDate]         date  NOT NULL ,
	[_EndDate]           date  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_FactProjectStatus_InsertDate		DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_FactProjectStatus_InsertBy		DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_FactProjectStatus_UpdateDate		DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_FactProjectStatus_UpdateBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_FactProjectStatus] PRIMARY KEY  CLUSTERED ([FactProjectStatusId] ASC),
	CONSTRAINT [UX_FactProjectStatus_Key] UNIQUE ([FactProjectStatusKey]  ASC,[_StartDate]  ASC),
	CONSTRAINT [FK_FactProjectStatus_DimProject] FOREIGN KEY ([ProjectId]) REFERENCES [AAS].[DimProject]([DimProjectId]),
	CONSTRAINT [FK_FactProjectStatus_DimProjectStatus] FOREIGN KEY ([ProjectStatusId]) REFERENCES [AAS].[DimProjectStatus]([DimProjectStatusId]),
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
go

CREATE NONCLUSTERED INDEX [IX_FactProjectStatus_Hash] ON [AAS].[FactProjectStatus]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash],[_StartDate],[_EndDate] )
go

CREATE NONCLUSTERED INDEX [IX_FactProjectStatus_StartEndDate] ON [AAS].[FactProjectStatus]
( 
	[_StartDate]          ASC,
	[_EndDate]            ASC
)
INCLUDE( [FactProjectStatusId],[FactProjectStatusKey],[_KeyHash] )
go