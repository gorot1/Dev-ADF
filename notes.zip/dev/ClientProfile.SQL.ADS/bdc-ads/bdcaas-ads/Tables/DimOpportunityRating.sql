﻿CREATE TABLE [AAS].[DimOpportunityRating]
( 
	[DimOpportunityRatingId] int  IDENTITY ( 1,1 )  NOT NULL ,
	[OpportunityRatingCode] varchar(10)  NOT NULL ,
	[OpportunityRatingName] varchar(50)  NOT NULL ,
	[OpportunityRatingSeq] int  NOT NULL ,
	[IsHotRating]        bit  NOT NULL ,
	[_CurrentFlag]       bit  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_DimOpportunityRating_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimOpportunityRating_InsertBy	DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_DimOpportunityRating_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimOpportunityRating_UpdateBy	DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_DimOpportunityRating] PRIMARY KEY  CLUSTERED ([DimOpportunityRatingId] ASC),
	CONSTRAINT [UX_DimOpportunityRating_Code] UNIQUE ([OpportunityRatingCode]  ASC)
)
WITH 
(
	DATA_COMPRESSION = ROW
)
go

CREATE NONCLUSTERED INDEX [IX_DimOpportunityRating_Hash] ON [AAS].[DimOpportunityRating]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash] )
go