﻿CREATE TABLE [AAS].[FactProject]
( 
	[FactProjectId]			int IDENTITY ( 1,1 )  NOT NULL ,
	[FactProjectKey]		varchar(100)  NOT NULL ,
	[ProjectId]				int NOT NULL ,
	[OpportunityId]			int NOT NULL ,
	[ProjectTypeId]			int NOT NULL ,
	[CustomerId]			int NOT NULL ,
	[ProjectStateId]		int NOT NULL ,
	[ProjectStatusId]		int NOT NULL ,
	[ProjectStatusDateId]	int NOT NULL ,
	[RefEmployeeId]			int NOT NULL ,
	[RefRegionBranchId]		int NOT NULL ,
	[SegmentSolutionId]		int NOT NULL ,
	[ProjectJobFamilyId]	int NOT NULL ,
	[CustomerPrevProjectId] int NOT NULL ,
	[ProjectStartDateId]	int NOT NULL ,
	[ProjectEndDateId]		int NOT NULL ,
	[FirstActivityDateId]	int NOT NULL ,
	[LastActivityDateId]	int NOT NULL ,
	[ClientNbrYTD]				decimal(13,5)  NOT NULL ,
	[MandateNbrYTD]				decimal(13,5)  NOT NULL ,
	[SalesAmtYTD]				decimal(18,5)  NOT NULL ,
	[RevenueAmtYTD]				decimal(18,5)  NOT NULL ,
	[GrossMarginYTD]			decimal(18,5)  NOT NULL ,
	[BadDebtsYTD]				decimal(18,5)  NOT NULL ,
	[NetMarginYTD]				decimal(18,5)  NOT NULL ,
	[UnearnedAmt]				decimal(18,5)  NOT NULL ,
	[ProjectAmt]				decimal(18,5)  NOT NULL ,
	[NumberOfMandates]			decimal(13,5)  NOT NULL ,
	[NetSalesAmt]				decimal(18,5)  NOT NULL ,
	[RevenueAmt]				decimal(18,5)  NOT NULL ,
	[ExternalConsultingFeeAmt]	decimal(18,5)  NOT NULL ,
	[InternalConsultingFeeAmt]	decimal(18,5)  NOT NULL ,
	[GrossMarginAmt]			decimal(18,5)  NOT NULL ,
	[ResourceNonRevAmt]			decimal(18,5)  NOT NULL ,
	[ResourceRevAmt]			decimal(18,5)  NOT NULL ,
	[_StartDate]			date  NOT NULL ,
	[_EndDate]				date  NOT NULL ,
	[_KeyHash]				binary(32)  NOT NULL ,
	[_ValueHash]			binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_FactProject_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_FactProject_InsertBy		DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_FactProject_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_FactProject_UpdateBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_FactProject] PRIMARY KEY  CLUSTERED ([FactProjectId] ASC),
	CONSTRAINT [UX_FactProject_Key] UNIQUE ([FactProjectKey]  ASC,[_StartDate]  ASC),
	CONSTRAINT [FK_FactProject_DimOpportunity] FOREIGN KEY ([OpportunityId]) REFERENCES [AAS].[DimOpportunity]([DimOpportunityId]),
	CONSTRAINT [FK_FactProject_DimRegionBranch] FOREIGN KEY ([RefRegionBranchId]) REFERENCES [AAS].[DimRegionBranch]([DimRegionBranchId]),
	CONSTRAINT [FK_FactProject_DimProjectType] FOREIGN KEY ([ProjectTypeId]) REFERENCES [AAS].[DimProjectType]([DimProjectTypeId]),
	CONSTRAINT [FK_FactProject_DimSegmentSolution] FOREIGN KEY ([SegmentSolutionId]) REFERENCES [AAS].[DimSegmentSolution]([DimSegmentSolutionId]),
	CONSTRAINT [FK_FactProject_DimCustomer] FOREIGN KEY ([CustomerId]) REFERENCES [AAS].[DimCustomer]([DimCustomerId]),
	CONSTRAINT [FK_FactProject_DimProjectStatus] FOREIGN KEY ([ProjectStatusId]) REFERENCES [AAS].[DimProjectStatus]([DimProjectStatusId]),
	CONSTRAINT [FK_FactProject_DimEmployee_ProjectManager] FOREIGN KEY ([RefEmployeeId]) REFERENCES [AAS].[DimEmployee]([DimEmployeeId]),
	CONSTRAINT [FK_FactProject_DimProject] FOREIGN KEY ([ProjectId]) REFERENCES [AAS].[DimProject]([DimProjectId]),
	CONSTRAINT [FK_FactProject_DimProject_Prev] FOREIGN KEY ([CustomerPrevProjectId]) REFERENCES [AAS].[DimProject]([DimProjectId]),
	CONSTRAINT [FK_FactProject_DimProjectState] FOREIGN KEY ([ProjectStateId]) REFERENCES [AAS].[DimProjectState]([DimProjectStateId]),
	CONSTRAINT [FK_FactProject_DimProjectJobFamily] FOREIGN KEY ([ProjectJobFamilyId]) REFERENCES [AAS].[DimProjectJobFamily]([DimProjectJobFamilyId])
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
go

CREATE NONCLUSTERED INDEX [IX_FactProject_Hash] ON [AAS].[FactProject]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash], [_StartDate], [_EndDate] )
go

CREATE NONCLUSTERED INDEX [IX_FactProject_StartEndDate] ON [AAS].[FactProject]
( 
	[_StartDate]          ASC,
	[_EndDate]            ASC
)
INCLUDE( [FactProjectId], [FactProjectKey], [_KeyHash] )
go

CREATE NONCLUSTERED INDEX [IX_FactProject_Key] ON [AAS].[FactProject]
( 
	[ProjectId]			ASC
)
go
