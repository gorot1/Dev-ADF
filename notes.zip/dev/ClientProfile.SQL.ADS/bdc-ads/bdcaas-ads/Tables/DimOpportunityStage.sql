﻿CREATE TABLE [AAS].[DimOpportunityStage]
( 
	[DimOpportunityStageId] int  IDENTITY ( 1,1 )  NOT NULL ,
	[OpportunityStageCode] varchar(50)  NOT NULL ,
	[OpportunityStageName] varchar(50)  NOT NULL ,
	[OpportunityStageSeq] int  NOT NULL ,
	[IsQualifiedStage]   bit  NOT NULL ,
	[IsProposedStage]    bit  NOT NULL ,
	[IsSalesStage]       bit  NOT NULL ,
	[_CurrentFlag]       bit  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_DimOpportunityStage_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimOpportunityStage_InsertBy		DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_DimOpportunityStage_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimOpportunityStage_UpdateBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_DimOpportunityStage] PRIMARY KEY  CLUSTERED ([DimOpportunityStageId] ASC),
	CONSTRAINT [UX_DimOpportunityStage_Code] UNIQUE ([OpportunityStageCode]  ASC)
)
WITH 
(
	DATA_COMPRESSION = ROW
)
go

CREATE NONCLUSTERED INDEX [IX_DimOpportunityStage_Hash] ON [AAS].[DimOpportunityStage]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash] )
go