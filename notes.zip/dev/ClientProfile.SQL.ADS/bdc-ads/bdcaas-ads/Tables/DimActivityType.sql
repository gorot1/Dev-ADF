﻿CREATE TABLE [AAS].[DimActivityType]
( 
	[DimActivityTypeId]  int  IDENTITY ( 1,1 )  NOT NULL ,
	[ActivityTypeCode]   varchar(10)  NOT NULL ,
	[ActivityTypeName]   varchar(50)  NOT NULL ,
	[IsConsulting]       bit  NOT NULL ,
	[_CurrentFlag]       bit  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_DimActivityType_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimActivityType_InsertBy		DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_DimActivityType_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimActivityType_UpdateBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_DimActivityType] PRIMARY KEY  CLUSTERED ([DimActivityTypeId] ASC),
	CONSTRAINT [UX_DimActivityType_Code] UNIQUE ([ActivityTypeCode]  ASC)
)
WITH 
(
	DATA_COMPRESSION = ROW
)
go

CREATE NONCLUSTERED INDEX [IX_DimActivityType_Hash] ON [AAS].[DimActivityType]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash] )
go