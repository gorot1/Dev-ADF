﻿CREATE TABLE [AAS].[DimProject]
( 
	[DimProjectId]       int  IDENTITY ( 1,1 )  NOT NULL ,
	[ProjectCode]        varchar(20)  NOT NULL ,
	[ProjectName]        varchar(100)  NOT NULL ,
	[ProjectStartDate]	date  NULL ,
	[ProjectEndDate]	date  NULL ,
	[FirstActivityDate]	date  NULL ,
	[LastActivityDate]	date  NULL ,
	[_CurrentFlag]       bit  NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_DimProject_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimProject_InsertBy		DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_DimProject_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimProject_UpdateBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_DimProject] PRIMARY KEY  CLUSTERED ([DimProjectId] ASC),
	CONSTRAINT [UX_DimProject_Code] UNIQUE ([ProjectCode]  ASC)
)
WITH 
(
	DATA_COMPRESSION = ROW
)
go

CREATE NONCLUSTERED INDEX [IX_DimProject_Hash] ON [AAS].[DimProject]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash] )
go