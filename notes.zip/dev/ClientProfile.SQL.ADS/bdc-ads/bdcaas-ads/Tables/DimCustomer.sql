﻿CREATE TABLE [AAS].[DimCustomer]
( 
	[DimCustomerId]      int  IDENTITY ( 1,1 )  NOT NULL ,
	[CustomerCode]       varchar(10)  NOT NULL ,
	[CustomerName]       varchar(300)  NOT NULL ,
	[_CurrentFlag]       bit  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_DimCustomer_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimCustomer_InsertBy		DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_DimCustomer_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimCustomer_UpdateBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_DimCustomer] PRIMARY KEY  CLUSTERED ([DimCustomerId] ASC),
	CONSTRAINT [UX_DimCustomer_Code] UNIQUE ([CustomerCode]  ASC)
)
WITH 
(
	DATA_COMPRESSION = ROW
)
go

CREATE NONCLUSTERED INDEX [IX_DimCustomer_Hash] ON [AAS].[DimCustomer]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash] )
go