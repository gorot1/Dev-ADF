﻿CREATE TABLE [AAS].[DimSegmentSolution]
( 
	[DimSegmentSolutionId] int  IDENTITY ( 1,1 )  NOT NULL ,
	[SolutionCode]       varchar(300)  NOT NULL ,
	[SolutionName]       varchar(300)  NOT NULL ,
	[PracticeAbbr]       varchar(10)  NOT NULL ,
	[PracticeName]       varchar(50)  NOT NULL ,
	[SubSegmentAbbr]     varchar(10)  NOT NULL ,
	[SubSegmentName]     varchar(50)  NOT NULL ,
	[SegmentAbbr]        varchar(10)  NOT NULL ,
	[SegmentName]        varchar(50)  NOT NULL ,
	[_CurrentFlag]       bit  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_DimSegmentSolution_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimSegmentSolution_InsertBy		DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_DimSegmentSolution_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimSegmentSolution_UpdateBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_DimSegmentSolution] PRIMARY KEY  CLUSTERED ([DimSegmentSolutionId] ASC),
	CONSTRAINT [UX_DimSegmentSolution_Code] UNIQUE ([SolutionCode]  ASC)
)
WITH 
(
	DATA_COMPRESSION = ROW
)
go

CREATE NONCLUSTERED INDEX [IX_DimSegmentSolution_Hash] ON [AAS].[DimSegmentSolution]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash] )
go