﻿CREATE TABLE [AAS].[FactOpportunityStage]
( 
	[FactOpportunityStageId] int  IDENTITY ( 1,1 )  NOT NULL ,
	[FactOpportunityStageKey] varchar(100)  NOT NULL ,
	[OpportunityId]      int  NULL ,
	[OpportunityStageId] int  NULL ,
	[OpportunityStageFirstDateId] int  NULL ,
	[OpportunityStageLastDateId] int  NULL ,
	[OpportunityStageSeq] integer  NOT NULL ,
	[OpportunityStageDays] int  NULL ,
	[_StartDate]         date  NOT NULL ,
	[_EndDate]           date  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_FactOpportunityStage_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_FactOpportunityStage_InsertBy	DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_FactOpportunityStage_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_FactOpportunityStage_UpdateBy	DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_FactOpportunityStage] PRIMARY KEY  CLUSTERED ([FactOpportunityStageId] ASC),
	CONSTRAINT [UX_FactOpportunityStage_Key] UNIQUE ([FactOpportunityStageKey]  ASC,[_StartDate]  ASC),
	CONSTRAINT [FK_FactOpportunityStage_DimOpportunity] FOREIGN KEY ([OpportunityId]) REFERENCES [AAS].[DimOpportunity]([DimOpportunityId]),
	--CONSTRAINT [FK_FactOpportunityStage_DimDate_FirstDate] FOREIGN KEY ([OpportunityStageFirstDateId]) REFERENCES [AAS].[DimDate]([DimDateId]),
	CONSTRAINT [FK_FactOpportunityStage_DimOpportunityStage] FOREIGN KEY ([OpportunityStageId]) REFERENCES [AAS].[DimOpportunityStage]([DimOpportunityStageId]),
	--CONSTRAINT [FK_FactOpportunityStage_DimDate_LastDate] FOREIGN KEY ([OpportunityStageLastDateId]) REFERENCES [AAS].[DimDate]([DimDateId])
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
go

CREATE NONCLUSTERED INDEX [IX_FactOpportunityStage_Hash] ON [AAS].[FactOpportunityStage]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash],[_StartDate],[_EndDate] )
go

CREATE NONCLUSTERED INDEX [IX_FactOpportunityStage_StartEndDate] ON [AAS].[FactOpportunityStage]
( 
	[_StartDate]          ASC,
	[_EndDate]            ASC
)
INCLUDE( [FactOpportunityStageId],[FactOpportunityStageKey],[_KeyHash] )
go

CREATE NONCLUSTERED INDEX [IX_FactOpportunityStage_OpportunityId] ON [AAS].[FactOpportunityStage]
( 
	[OpportunityId]		ASC,
	[_StartDate]        ASC,
	[_EndDate]          ASC
)
INCLUDE( [OpportunityStageId] )
go