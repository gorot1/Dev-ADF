﻿CREATE TABLE [AAS].[DimProjectType]
( 
	[DimProjectTypeId]   int  IDENTITY ( 1,1 )  NOT NULL ,
	[ProjectTypeCode]    varchar(50)  NOT NULL ,
	[ProjectTypeNo]		 varchar(10)  NULL ,
	[ProjectTypeName]    varchar(50)  NOT NULL ,
	[_CurrentFlag]       bit  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_DimProjectType_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimProjectType_InsertBy		DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_DimProjectType_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimProjectType_UpdateBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_DimProjectType] PRIMARY KEY  CLUSTERED ([DimProjectTypeId] ASC),
	CONSTRAINT [UX_DimProjectType_Code] UNIQUE ([ProjectTypeCode]  ASC)
)
WITH 
(
	DATA_COMPRESSION = ROW
)
go

CREATE NONCLUSTERED INDEX [IX_DimProjectType_Hash] ON [AAS].[DimProjectType]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash] )
go