﻿CREATE TABLE [AAS].[FactMandate]
( 
	[FactMandateId]				int IDENTITY ( 1,1 )  NOT NULL ,
	[FactMandateKey]			varchar(100)  NOT NULL ,
	[JournalLineDateId]			int  NOT NULL ,
	[ProjectId]					int  NOT NULL ,
	[ProjectManagerEmployeeId]	int NOT NULL ,
	[RegionBranchId]			int  NOT NULL ,
	[ContributionPct]			decimal(5,2)  NOT NULL ,
	[ClientNbrYTD]				decimal(13,5)  NOT NULL ,
	[MandateNbrYTD]				decimal(13,5)  NOT NULL ,
	[SalesAmtYTD]				decimal(18,5)  NOT NULL ,
	[RevenueAmtYTD]				decimal(18,5)  NOT NULL ,
	[GrossMarginYTD]			decimal(18,5)  NOT NULL ,
	[BadDebtsYTD]				decimal(18,5)  NOT NULL ,
	[NetMarginYTD]				decimal(18,5)  NOT NULL ,
	[UnearnedAmt]				decimal(18,5)  NOT NULL ,
	[ProjectAmt]				decimal(18,5)  NOT NULL ,
	[NumberOfMandates]			decimal(13,5)  NOT NULL ,
	[NetSalesAmt]				decimal(18,5)  NOT NULL ,
	[RevenueAmt]				decimal(18,5)  NOT NULL ,
	[ExternalConsultingFeeAmt]	decimal(18,5)  NOT NULL ,
	[InternalConsultingFeeAmt]	decimal(18,5)  NOT NULL ,
	[GrossMarginAmt]			decimal(18,5)  NOT NULL ,
	[ResourceNonRevAmt]			decimal(18,5)  NOT NULL ,
	[ResourceRevAmt]			decimal(18,5)  NOT NULL ,
	[_StartDate]				date  NOT NULL ,
	[_EndDate]					date  NOT NULL ,
	[_KeyHash]					binary(32)  NOT NULL ,
	[_ValueHash]				binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_FactMandate_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_FactMandate_InsertBy		DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_FactMandate_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_FactMandate_UpdateBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_FactMandate] PRIMARY KEY  CLUSTERED ([FactMandateId] ASC),
	CONSTRAINT [UX_FactMandate_Key] UNIQUE ([FactMandateKey]  ASC,[_StartDate]  ASC),
	CONSTRAINT [FK_FactMandate_DimProject] FOREIGN KEY ([ProjectId]) REFERENCES [AAS].[DimProject]([DimProjectId]),
	CONSTRAINT [FK_FactMandate_DimEmployee_ProjectManager] FOREIGN KEY ([ProjectManagerEmployeeId]) REFERENCES [AAS].[DimEmployee]([DimEmployeeId]),
	CONSTRAINT [FK_FactMandate_DimRegionBranch] FOREIGN KEY ([RegionBranchId]) REFERENCES [AAS].[DimRegionBranch]([DimRegionBranchId])
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
go
CREATE NONCLUSTERED INDEX [IX_FactMandate_Hash] ON [AAS].[FactMandate]
( 
	[_KeyHash]            ASC,
	[_StartDate]          ASC
)
INCLUDE( [_EndDate] )
go

CREATE NONCLUSTERED INDEX [IX_FactMandate_StartEndDate] ON [AAS].[FactMandate]
( 
	[_StartDate]          ASC,
	[_EndDate]            ASC
)
INCLUDE( [FactMandateId], [FactMandateKey], [_KeyHash] )
go

CREATE NONCLUSTERED INDEX [IX_FactMandate_Key] ON [AAS].[FactMandate]
( 
	[JournalLineDateId]			ASC,
	[ProjectId]					ASC,
	[ProjectManagerEmployeeId]	ASC
)
go
