﻿CREATE TABLE [AAS].[FactProjectWorkflow]
( 
	[FactProjectWorkflowId] int  IDENTITY ( 1,1 )  NOT NULL ,
	[FactProjectWorkflowKey] varchar(200)  NOT NULL ,
	[ProjectId]          int  NULL ,
	[ProjectWorkflowDateId] int  NULL ,
	[ProjectWorkflowId]  int  NULL ,
	[ProjectWorkflowSeq] int  NOT NULL ,
	[_StartDate]         date  NOT NULL ,
	[_EndDate]           date  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_FactProjectWorkflow_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_FactProjectWorkflow_InsertBy		DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_FactProjectWorkflow_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_FactProjectWorkflow_UpdateBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_FactProjectWorkflow] PRIMARY KEY  CLUSTERED ([FactProjectWorkflowId] ASC),
	CONSTRAINT [UX_FactProjectWorkflow_Key] UNIQUE ([FactProjectWorkflowKey]  ASC,[_StartDate]  ASC),
	CONSTRAINT [FK_FactProjectWorkflow_DimProject] FOREIGN KEY ([ProjectId]) REFERENCES [AAS].[DimProject]([DimProjectId]),
	CONSTRAINT [FK_FactProjectWorkflow_DimProjectWorkflow] FOREIGN KEY ([ProjectWorkflowId]) REFERENCES [AAS].[DimProjectWorkflow]([DimProjectWorkflowId])
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
go

CREATE NONCLUSTERED INDEX [IX_FactProjectWorkflow_Hash] ON [AAS].[FactProjectWorkflow]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash],[_StartDate],[_EndDate] )
go

CREATE NONCLUSTERED INDEX [IX_FactProjectWorkflow_StartEndDate] ON [AAS].[FactProjectWorkflow]
( 
	[_StartDate]          ASC,
	[_EndDate]            ASC
)
INCLUDE( [FactProjectWorkflowId],[FactProjectWorkflowKey],[_KeyHash] )
go