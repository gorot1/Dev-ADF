﻿CREATE TABLE [AAS].[DimOpportunityState]
( 
	[DimOpportunityStateId] int  IDENTITY ( 1,1 )  NOT NULL ,
	[OpportunityStateCode] varchar(10)  NOT NULL ,
	[OpportunityStateName] varchar(50)  NOT NULL ,
	[OpportunityStateSeq] int  NOT NULL ,
	[IsOpenState]        bit  NOT NULL ,
	[IsWonState]         bit  NOT NULL ,
	[IsLostState]        bit  NOT NULL ,
	[_CurrentFlag]       bit  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_DimOpportunityState_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimOpportunityState_InsertBy		DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_DimOpportunityState_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimOpportunityState_UpdateBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_DimOpportunityState] PRIMARY KEY  CLUSTERED ([DimOpportunityStateId] ASC),
	CONSTRAINT [UX_DimOpportunityState_Code] UNIQUE ([OpportunityStateCode]  ASC)
)
WITH 
(
	DATA_COMPRESSION = ROW
)
go

CREATE NONCLUSTERED INDEX [IX_DimOpportunityState_Hash] ON [AAS].[DimOpportunityState]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash] )
go