﻿CREATE TABLE [AAS].[FactOpportunity]
( 
	[FactOpportunityId]  int  IDENTITY ( 1,1 )  NOT NULL ,
	[FactOpportunityKey] varchar(100)  NOT NULL ,
	[OpportunityId]      int  NULL ,
	[OpportunityCreatedDateId] int  NULL ,
	[CustomerId]         int  NULL ,
	[RegionBranchId]     int  NULL ,
	[SegmentSolutionId]  int  NULL ,
	[OpportunityRatingId] int  NULL ,
	[OpportunityStageId] int  NULL ,
	[OpportunityStageDateId] int  NULL ,
	[OpportunityStateId] int  NULL ,
	[OpportunityStateDateId] int  NULL ,
	[OpportunityStatusId] int  NULL ,
	[ClientPartnerEmployeeId] int  NULL ,
	[ReferrerEmployeeId] int  NULL ,
	[LineOfBusinessId]   int  NULL ,
	[CampaignId]         int  NULL ,
	[OpportunitySourceId] int  NULL ,
	[EstimatedCloseDateId] int  NULL ,
	[ReferrerLineOfBusinessId] int  NULL ,
	[OpportunityEstimatedAmt] money  NOT NULL ,
	[IsBusinessDevelopment]	bit  NOT NULL ,
	[_StartDate]         date  NOT NULL ,
	[_EndDate]           date  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_FactOpportunity_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_FactOpportunity_InsertBy		DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_FactOpportunity_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_FactOpportunity_UpdateBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_FactOpportunity] PRIMARY KEY  CLUSTERED ([FactOpportunityId] ASC),
	CONSTRAINT [UX_FactOpportunity_Key] UNIQUE ([FactOpportunityKey]  ASC,[_StartDate]  ASC),
	CONSTRAINT [FK_FactOpportunity_DimCustomer] FOREIGN KEY ([CustomerId]) REFERENCES [AAS].[DimCustomer]([DimCustomerId]),
	CONSTRAINT [FK_FactOpportunity_DimRegionBranch] FOREIGN KEY ([RegionBranchId]) REFERENCES [AAS].[DimRegionBranch]([DimRegionBranchId]),
	CONSTRAINT [FK_FactOpportunity_DimSegmentSolution] FOREIGN KEY ([SegmentSolutionId]) REFERENCES [AAS].[DimSegmentSolution]([DimSegmentSolutionId]),
	CONSTRAINT [FK_FactOpportunity_DimOpportunityRating] FOREIGN KEY ([OpportunityRatingId]) REFERENCES [AAS].[DimOpportunityRating]([DimOpportunityRatingId]),
	CONSTRAINT [FK_FactOpportunity_DimOpportunityState] FOREIGN KEY ([OpportunityStateId]) REFERENCES [AAS].[DimOpportunityState]([DimOpportunityStateId]),
	CONSTRAINT [FK_FactOpportunity_DimOpportunityStatus] FOREIGN KEY ([OpportunityStatusId]) REFERENCES [AAS].[DimOpportunityStatus]([DimOpportunityStatusId]),
	CONSTRAINT [FK_FactOpportunity_DimOpportunity] FOREIGN KEY ([OpportunityId]) REFERENCES [AAS].[DimOpportunity]([DimOpportunityId]),
	CONSTRAINT [FK_FactOpportunity_DimEmployee_ClientPartner] FOREIGN KEY ([ClientPartnerEmployeeId]) REFERENCES [AAS].[DimEmployee]([DimEmployeeId]),
	CONSTRAINT [FK_FactOpportunity_DimEmployee_Referrer] FOREIGN KEY ([ReferrerEmployeeId]) REFERENCES [AAS].[DimEmployee]([DimEmployeeId]),
	CONSTRAINT [FK_FactOpportunity_DimOpportunityStage] FOREIGN KEY ([OpportunityStageId]) REFERENCES [AAS].[DimOpportunityStage]([DimOpportunityStageId]),
	CONSTRAINT [FK_FactOpportunity_DimLineOfBusiness] FOREIGN KEY ([LineOfBusinessId]) REFERENCES [AAS].[DimLineOfBusiness]([DimLineOfBusinessId]),
	CONSTRAINT [FK_FactOpportunity_DimCampaign] FOREIGN KEY ([CampaignId]) REFERENCES [AAS].[DimCampaign]([DimCampaignId]),
	CONSTRAINT [FK_FactOpportunity_DimOpportunitySource] FOREIGN KEY ([OpportunitySourceId]) REFERENCES [AAS].[DimOpportunitySource]([DimOpportunitySourceId]),
	CONSTRAINT [FK_FactOpportunity_DimLineOfBusiness_Referrer] FOREIGN KEY ([ReferrerLineOfBusinessId]) REFERENCES [AAS].[DimLineOfBusiness]([DimLineOfBusinessId])
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
go

CREATE NONCLUSTERED INDEX [IX_FactOpportunity_Hash] ON [AAS].[FactOpportunity]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash],[_StartDate],[_EndDate] )
go

CREATE NONCLUSTERED INDEX [IX_FactOpportunity_StartEndDate] ON [AAS].[FactOpportunity]
( 
	[_StartDate]          ASC,
	[_EndDate]            ASC
)
INCLUDE( [FactOpportunityId],[FactOpportunityKey],[_KeyHash] )
go

CREATE NONCLUSTERED INDEX [IX_FactOpportunity_OpportunityId] ON [AAS].[FactOpportunity]
( 
	[OpportunityId]		ASC,
	[_StartDate]        ASC,
	[_EndDate]			ASC
)
INCLUDE( [OpportunityStageId] )
go