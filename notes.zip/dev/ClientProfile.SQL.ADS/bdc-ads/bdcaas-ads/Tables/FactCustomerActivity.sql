﻿CREATE TABLE [AAS].[FactCustomerActivity]
( 
	[FactCustomerActivityId] int  IDENTITY ( 1,1 )  NOT NULL ,
	[FactCustomerActivityKey] varchar(100)  NOT NULL ,
	[CustomerId]         int  NULL ,
	[ActivityTypeId]     int  NULL ,
	[OwnerEmployeeId]    int  NULL ,
	[RegionBranchId]     int  NULL ,
	[ScheduledStartDateId] int  NULL ,
	[ScheduledEndDateId] int  NULL ,
	[ActualStartDateId]  int  NULL ,
	[ActualEndDateId]    int  NULL ,
	[_StartDate]         date  NOT NULL ,
	[_EndDate]           date  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_FactCustomerActivity_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_FactCustomerActivity_InsertBy	DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_FactCustomerActivity_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_FactCustomerActivity_UpdateBy	DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_FactCustomerActivity] PRIMARY KEY  CLUSTERED ([FactCustomerActivityId] ASC),
	CONSTRAINT [UX_FactCustomerActivity_Key] UNIQUE ([FactCustomerActivityKey]  ASC,[_StartDate]  ASC),
	CONSTRAINT [FK_FactCustomerActivity_DimCustomer] FOREIGN KEY ([CustomerId]) REFERENCES [AAS].[DimCustomer]([DimCustomerId]),
	CONSTRAINT [FK_FactCustomerActivity_DimActivityType] FOREIGN KEY ([ActivityTypeId]) REFERENCES [AAS].[DimActivityType]([DimActivityTypeId]),
	CONSTRAINT [FK_FactCustomerActivity_DimRegionBranch] FOREIGN KEY ([RegionBranchId]) REFERENCES [AAS].[DimRegionBranch]([DimRegionBranchId]),
	CONSTRAINT [FK_FactCustomerActivity_DimEmployee_Owner] FOREIGN KEY ([OwnerEmployeeId]) REFERENCES [AAS].[DimEmployee]([DimEmployeeId])
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
go

CREATE NONCLUSTERED INDEX [IX_FactCustomerActivity_Hash] ON [AAS].[FactCustomerActivity]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash],[_StartDate],[_EndDate] )
go

CREATE NONCLUSTERED INDEX [IX_FactCustomerActivity_StartEndDate] ON [AAS].[FactCustomerActivity]
( 
	[_StartDate]          ASC,
	[_EndDate]            ASC
)
INCLUDE( [FactCustomerActivityId],[FactCustomerActivityKey],[_KeyHash] )
go