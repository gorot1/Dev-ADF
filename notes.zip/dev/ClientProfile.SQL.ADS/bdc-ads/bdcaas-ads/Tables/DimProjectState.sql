﻿CREATE TABLE [AAS].[DimProjectState]
( 
	[DimProjectStateId]  int  IDENTITY ( 1,1 )  NOT NULL ,
	[ProjectStateCode]   varchar(50)  NOT NULL ,
	[ProjectStateName]   varchar(50)  NOT NULL ,
	[_CurrentFlag]       bit  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_DimProjectState_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimProjectState_InsertBy		DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_DimProjectState_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimProjectState_UpdateBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_DimProjectState] PRIMARY KEY  CLUSTERED ([DimProjectStateId] ASC),
	CONSTRAINT [UX_DimProjectState_Code] UNIQUE ([ProjectStateCode]  ASC)
)
WITH 
(
	DATA_COMPRESSION = ROW
)
go

CREATE NONCLUSTERED INDEX [IX_DimProjectState_Hash] ON [AAS].[DimProjectState]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash] )
go