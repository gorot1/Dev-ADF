﻿CREATE TABLE [AAS].[DimProjectStatus]
( 
	[DimProjectStatusId] int  IDENTITY ( 1,1 )  NOT NULL ,
	[ProjectStatusCode]  varchar(10)  NOT NULL ,
	[ProjectStatusName]  varchar(50)  NOT NULL ,
	[_CurrentFlag]       bit  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_DimProjectStatus_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimProjectStatus_InsertBy	DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_DimProjectStatus_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimProjectStatus_UpdateBy	DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_DimProjectStatus] PRIMARY KEY  CLUSTERED ([DimProjectStatusId] ASC),
	CONSTRAINT [UX_DimProjectStatus_Code] UNIQUE ([ProjectStatusCode]  ASC)
)
WITH 
(
	DATA_COMPRESSION = ROW
)
go

CREATE NONCLUSTERED INDEX [IX_DimProjectStatus_Hash] ON [AAS].[DimProjectStatus]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash] )
go