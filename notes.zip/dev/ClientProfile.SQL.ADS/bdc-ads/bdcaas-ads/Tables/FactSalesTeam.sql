﻿CREATE TABLE [AAS].[FactSalesTeam]
( 
	[FactSalesTeamId]    int  IDENTITY ( 1,1 )  NOT NULL ,
	[FactSalesTeamKey]   varchar(100)  NOT NULL ,
	[RegionBranchId]     int  NULL ,
	[ClientPartnerEmployeeId] int  NULL ,
	[DirectorEmployeeId] int  NULL ,
	[VicePresidentEmployeeId] int  NULL ,
	[_StartDate]         date  NOT NULL ,
	[_EndDate]           date  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_FactSalesTeam_InsertDate		DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_FactSalesTeam_InsertBy		DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_FactSalesTeam_UpdateDate		DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_FactSalesTeam_UpdateBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_FactSalesTeam] PRIMARY KEY  CLUSTERED ([FactSalesTeamId] ASC),
	CONSTRAINT [UX_FactSalesTeam_Key] UNIQUE ([FactSalesTeamKey]  ASC,[_StartDate]  ASC),
	CONSTRAINT [FK_FactSalesTeam_DimRegionBranch] FOREIGN KEY ([RegionBranchId]) REFERENCES [AAS].[DimRegionBranch]([DimRegionBranchId]),
	CONSTRAINT [FK_FactSalesTeam_DimEmployee_ClientPartner] FOREIGN KEY ([ClientPartnerEmployeeId]) REFERENCES [AAS].[DimEmployee]([DimEmployeeId]),
	CONSTRAINT [FK_FactSalesTeam_DimEmployee_Director] FOREIGN KEY ([DirectorEmployeeId]) REFERENCES [AAS].[DimEmployee]([DimEmployeeId]),
	CONSTRAINT [FK_FactSalesTeam_DimEmployee_VicePresident] FOREIGN KEY ([VicePresidentEmployeeId]) REFERENCES [AAS].[DimEmployee]([DimEmployeeId])
)
WITH 
(
	DATA_COMPRESSION = PAGE
)
go

CREATE NONCLUSTERED INDEX [IX_FactSalesTeam_Hash] ON [AAS].[FactSalesTeam]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash],[_StartDate],[_EndDate] )
go

CREATE NONCLUSTERED INDEX [IX_FactSalesTeam_StartEndDate] ON [AAS].[FactSalesTeam]
( 
	[_StartDate]          ASC,
	[_EndDate]            ASC
)
INCLUDE( [FactSalesTeamId],[FactSalesTeamKey],[_KeyHash] )
go