﻿CREATE TABLE [AAS].[DimProjectWorkflow]
( 
	[DimProjectWorkflowId] int  IDENTITY ( 1,1 )  NOT NULL ,
	[ProjectWorkflowCode] varchar(200)  NOT NULL ,
	[ProjectWorkflowSource] varchar(50)  NOT NULL ,
	[ProjectWorkflowDestination] varchar(50)  NOT NULL ,
	[ProjectWorkflowAction] varchar(50)  NOT NULL ,
	[_CurrentFlag]       bit  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_DimProjectWorkflow_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimProjectWorkflow_InsertBy		DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_DimProjectWorkflow_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimProjectWorkflow_UpdateBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_DimProjectWorkflow] PRIMARY KEY  CLUSTERED ([DimProjectWorkflowId] ASC),
	CONSTRAINT [UX_DimProjectWorkflow_Code] UNIQUE ([ProjectWorkflowCode]  ASC)
)
WITH 
(
	DATA_COMPRESSION = ROW
)
go

CREATE NONCLUSTERED INDEX [IX_DimProjectWorkflow_Hash] ON [AAS].[DimProjectWorkflow]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash] )
go