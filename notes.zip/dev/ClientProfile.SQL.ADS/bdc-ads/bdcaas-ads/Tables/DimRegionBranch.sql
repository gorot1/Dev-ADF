﻿CREATE TABLE [AAS].[DimRegionBranch]
( 
	[DimRegionBranchId]  int  IDENTITY ( 1,1 )  NOT NULL ,
	[BranchCode]         varchar(10)  NOT NULL ,
	[BranchName]         varchar(50)  NOT NULL ,
	[AreaCode]           varchar(10)  NOT NULL ,
	[AreaName]           varchar(50)  NOT NULL ,
	[SubRegionName]      varchar(50)  NOT NULL ,
	[RegionCode]         varchar(10)  NOT NULL ,
	[RegionAbbr]         varchar(10)  NOT NULL ,
	[RegionName]         varchar(50)  NOT NULL ,
	[VPRegionAbbr]       varchar(10)  NOT NULL ,
	[VPRegionName]       varchar(50)  NOT NULL ,
	[_CurrentFlag]       bit  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_DimRegionBranch_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimRegionBranch_InsertBy		DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_DimRegionBranch_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimRegionBranch_UpdateBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_DimRegionBranch] PRIMARY KEY  CLUSTERED ([DimRegionBranchId] ASC),
	CONSTRAINT [UX_DimRegionBranch_Code] UNIQUE ([BranchCode]  ASC)
)
WITH 
(
	DATA_COMPRESSION = ROW
)
go

CREATE NONCLUSTERED INDEX [IX_DimRegionBranch_Hash] ON [AAS].[DimRegionBranch]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash] )
go