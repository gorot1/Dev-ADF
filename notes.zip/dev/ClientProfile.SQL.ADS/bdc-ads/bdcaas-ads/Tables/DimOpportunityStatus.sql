﻿CREATE TABLE [AAS].[DimOpportunityStatus]
( 
	[DimOpportunityStatusId] int  IDENTITY ( 1,1 )  NOT NULL ,
	[OpportunityStatusCode] varchar(10)  NOT NULL ,
	[OpportunityStatusName] varchar(100)  NOT NULL ,
	[OpportunityStatusSeq] int  NOT NULL ,
	[_CurrentFlag]       bit  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_DimOpportunityStatus_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimOpportunityStatus_InsertBy	DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_DimOpportunityStatus_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimOpportunityStatus_UpdateBy	DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_DimOpportunityStatus] PRIMARY KEY  CLUSTERED ([DimOpportunityStatusId] ASC),
	CONSTRAINT [UX_DimOpportunityStatus_Code] UNIQUE ([OpportunityStatusCode]  ASC)
)
WITH 
(
	DATA_COMPRESSION = ROW
)
go

CREATE NONCLUSTERED INDEX [IX_DimOpportunityStatus_Hash] ON [AAS].[DimOpportunityStatus]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash] )
go