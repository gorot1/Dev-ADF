﻿CREATE TABLE [AAS].[DimOpportunity]
( 
	[DimOpportunityId]   int  IDENTITY ( 1,1 )  NOT NULL ,
	[OpportunityCode]    varchar(10)  NOT NULL ,
	[OpportunityName]    varchar(1000)  NOT NULL ,
	[IsAccess1On1]		 AS (CASE WHEN UPPER(OpportunityName) LIKE '%ADVISORY%ACCESS%' THEN 1 ELSE 0 END) PERSISTED NOT NULL,
	[_CurrentFlag]       bit  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_DimOpportunity_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimOpportunity_InsertBy		DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_DimOpportunity_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimOpportunity_UpdateBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_DimOpportunity] PRIMARY KEY  CLUSTERED ([DimOpportunityId] ASC),
	CONSTRAINT [UX_DimOpportunity_Code] UNIQUE ([OpportunityCode]  ASC)
)
WITH 
(
	DATA_COMPRESSION = ROW
)
go

CREATE NONCLUSTERED INDEX [IX_DimOpportunity_Hash] ON [AAS].[DimOpportunity]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash] )
go