﻿CREATE TABLE [AAS].[DimCampaign]
( 
	[DimCampaignId]      int  IDENTITY ( 1,1 )  NOT NULL ,
	[CampaignCode]       varchar(50)  NOT NULL ,
	[CampaignName]       varchar(300)  NOT NULL ,
	[_CurrentFlag]       bit  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_DimCampaign_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimCampaign_InsertBy		DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_DimCampaign_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimCampaign_UpdateBy		DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_DimCampaign] PRIMARY KEY  CLUSTERED ([DimCampaignId] ASC),
	CONSTRAINT [UX_DimCampaign_Code] UNIQUE ([CampaignCode]  ASC)

)
WITH 
(
	DATA_COMPRESSION = ROW
)
go

CREATE NONCLUSTERED INDEX [IX_DimCampaign_Hash] ON [AAS].[DimCampaign]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash] )
go