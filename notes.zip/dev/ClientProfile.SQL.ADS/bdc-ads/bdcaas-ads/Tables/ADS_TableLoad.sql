﻿CREATE TABLE [AAS].[ADS_TableLoad]
( 
	[TableLoadId]   int IDENTITY    NOT NULL,
	[TableName]     varchar(50)     NOT NULL,
	[LastLoadDate]  datetime2       NOT NULL,
	[IsActive]      bit             NOT NULL CONSTRAINT DF_ADS_TableLoad_IsActive	DEFAULT (1),
	[_InsertDate]	datetime2		NOT NULL CONSTRAINT DF_ADS_TableLoad_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]		varchar(128)	NOT NULL CONSTRAINT DF_ADS_TableLoad_InsertBy	DEFAULT SUSER_SNAME(),
	[_UpdateDate]	datetime2		NOT NULL CONSTRAINT DF_ADS_TableLoad_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]		varchar(128)	NOT NULL CONSTRAINT DF_ADS_TableLoad_UpdateBy	DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_ADS_TableLoad] PRIMARY KEY  CLUSTERED ([TableLoadId] ASC),
	CONSTRAINT [UX_ADS_TableLoad_Name] UNIQUE ([TableName]  ASC)
)
go