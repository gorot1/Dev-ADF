﻿CREATE TABLE [AAS].[DimOpportunitySource]
( 
	[DimOpportunitySourceId] int  IDENTITY ( 1,1 )  NOT NULL ,
	[OpportunitySourceCode] varchar(10)  NOT NULL ,
	[OpportunitySourceName] varchar(100)  NOT NULL ,
	[_CurrentFlag]       bit  NOT NULL ,
	[_KeyHash]           binary(32)  NOT NULL ,
	[_ValueHash]         binary(32)  NOT NULL ,
	[_InsertDate]		datetime2		NOT NULL CONSTRAINT DF_DimOpportunitySource_InsertDate	DEFAULT SYSDATETIME(),
	[_InsertBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimOpportunitySource_InsertBy	DEFAULT SUSER_SNAME(),
	[_UpdateDate]		datetime2		NOT NULL CONSTRAINT DF_DimOpportunitySource_UpdateDate	DEFAULT SYSDATETIME(),
	[_UpdateBy]			varchar(128)	NOT NULL CONSTRAINT DF_DimOpportunitySource_UpdateBy	DEFAULT SUSER_SNAME(),
	CONSTRAINT [PK_DimOpportunitySource] PRIMARY KEY  CLUSTERED ([DimOpportunitySourceId] ASC),
	CONSTRAINT [UX_DimOpportunitySource_Code] UNIQUE ([OpportunitySourceCode]  ASC)
)
WITH 
(
	DATA_COMPRESSION = ROW
)
go

CREATE NONCLUSTERED INDEX [IX_DimOpportunitySource_Hash] ON [AAS].[DimOpportunitySource]
( 
	[_KeyHash]            ASC
)
INCLUDE( [_ValueHash] )
go