﻿CREATE PROCEDURE [AAS].[sp_upsert_FactProjectStatus]
AS
DECLARE @tmp_FactProjectStatus TABLE (
	[FactProjectStatusId] [int] IDENTITY(1, 1) NOT NULL
	,[FactProjectStatusKey] [varchar](100) NULL
	,[ProjectId] [int] NULL
	,[ProjectStatusId] [int] NULL
	,[ProjectStatusFirstDateId] [int] NULL
	,[ProjectStatusLastDateId] [int] NULL
	,[ProjectStatusSeq] [int] NULL
	,[_StartDate] [date] NULL
	,[_EndDate] [date] NULL
	,[_KeyHash] [binary](32) NULL
	,[_ValueHash] [binary](32) NULL
	,[_InsertDate] [datetime2](7) NULL
	,[_InsertBy] [varchar](50) NULL
	,[_UpdateDate] [datetime2](7) NOT NULL
	,[_UpdateBy] [varchar](50) NULL
	)

BEGIN
	INSERT INTO @tmp_FactProjectStatus (
		[FactProjectStatusKey]
		,[ProjectId]
		,[ProjectStatusId]
		,[ProjectStatusFirstDateId]
		,[ProjectStatusLastDateId]
		,[ProjectStatusSeq]
		,[_StartDate]
		,[_EndDate]
		,[_KeyHash]
		,[_ValueHash]
		,[_InsertDate]
		,[_InsertBy]
		,[_UpdateDate]
		,[_UpdateBy]
		)
	SELECT [FactProjectStatusKey]
		,[ProjectId]
		,[ProjectStatusId]
		,[ProjectStatusFirstDateId]
		,[ProjectStatusLastDateId]
		,[ProjectStatusSeq]
		,SYSDATETIME()
		,[_EndDate]
		,[_KeyHash]
		,[_ValueHash]
		,SYSDATETIME()
		,SYSTEM_USER
		,SYSDATETIME()
		,SYSTEM_USER
	FROM (
		MERGE [AAS].[FactProjectStatus] AS [TARGET]
		USING (
			SELECT ps.[FactProjectStatusKey]
				,pt.DimprojectID AS [ProjectId]
				,ISNULL(psk.DimprojectStatusID, - 1) AS [ProjectStatusId]
				--,ISNULL(da.DimDateID, - 1) AS [ProjectStatusFirstDateId]
				,ps.ProjectStatusLastDateId AS [ProjectStatusFirstDateId]
				--,ISNULL(da.DimDateID, - 1) AS ProjectStatusLastDateId
				,ps.ProjectStatusLastDateId AS ProjectStatusLastDateId
				,ISNULL(ps.[ProjectStatusSeq], - 1) AS [ProjectStatusSeq]
				,[_StartDate]
				,[_EndDate]
				,ps.[_KeyHash]
				,ps.[_ValueHash]
				,ps.[_InsertDate]
				,ps.[_InsertBy]
				,ps.[_UpdateDate]
				,ps.[_UpdateBy]
			FROM [AAS].[tmp_FactProjectStatus] ps
			LEFT JOIN (
				SELECT po.DimprojectStatusID
					,projectStatusCode
				FROM AAS.DimProjectStatus po
				) psk ON ps.projectStatusID = psk.projectStatusCode
			LEFT JOIN (
				SELECT DimprojectID
					,ProjectCode
				FROM AAS.DimProject
				) pt ON pt.ProjectCode = ps.[ProjectId]
				--LEFT JOIN (
				--	SELECT DimDateID
				--		,DateShort
				--	FROM [AAS].[DimDate]
				--	) dt ON Replace(ps.ProjectStatusLastDateId, '-1', '') = dt.DateShort
				--LEFT JOIN (
				--	SELECT DimDateID
				--		,DateShort
				--	FROM [AAS].[DimDate]
				--	) da ON Replace(ps.ProjectStatusLastDateId, '-1', '') = da.DateShort
			) AS [SOURCE]
			ON ([TARGET].[_KeyHash] = [SOURCE].[_KeyHash])
		WHEN NOT MATCHED BY TARGET
			THEN
				INSERT (
					[FactProjectStatusKey]
					,[ProjectId]
					,[ProjectStatusId]
					,[ProjectStatusFirstDateId]
					,[ProjectStatusLastDateId]
					,[ProjectStatusSeq]
					,[_StartDate]
					,[_EndDate]
					,[_KeyHash]
					,[_ValueHash]
					,[_InsertDate]
					,[_InsertBy]
					,[_UpdateDate]
					,[_UpdateBy]
					)
				VALUES (
					[SOURCE].[FactProjectStatusKey]
					,[SOURCE].[ProjectId]
					,[SOURCE].[ProjectStatusId]
					,[SOURCE].[ProjectStatusFirstDateId]
					,[SOURCE].[ProjectStatusLastDateId]
					,[SOURCE].[ProjectStatusSeq]
					,SYSDATETIME()
					,[SOURCE].[_EndDate]
					,[SOURCE].[_KeyHash]
					,[SOURCE].[_ValueHash]
					,SYSDATETIME()
					,SYSTEM_USER
					,SYSDATETIME()
					,SYSTEM_USER
					)
		WHEN MATCHED
			AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
			AND ([TARGET].[_EndDate] = '9999-12-31')
			THEN
				UPDATE
				SET [TARGET].[_EndDate] = SYSDATETIME()
					,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
					,[TARGET].[_UpdateDate] = SYSDATETIME()
					,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy]
		OUTPUT $ACTION AS ACTION
			,[SOURCE].*
		) AS MERGE_OUTPUT
	WHERE MERGE_OUTPUT.ACTION = 'UPDATE';

	INSERT INTO [AAS].FactProjectStatus (
		[FactProjectStatusKey]
		,[ProjectId]
		,[ProjectStatusId]
		,[ProjectStatusFirstDateId]
		,[ProjectStatusLastDateId]
		,[ProjectStatusSeq]
		,[_StartDate]
		,[_EndDate]
		,[_KeyHash]
		,[_ValueHash]
		,[_InsertDate]
		,[_InsertBy]
		,[_UpdateDate]
		,[_UpdateBy]
		)
	SELECT [FactProjectStatusKey]
		,[ProjectId]
		,[ProjectStatusId]
		,[ProjectStatusFirstDateId]
		,[ProjectStatusLastDateId]
		,[ProjectStatusSeq]
		,[_StartDate]
		,[_EndDate]
		,[_KeyHash]
		,[_ValueHash]
		,[_InsertDate]
		,[_InsertBy]
		,[_UpdateDate]
		,[_UpdateBy]
	FROM @tmp_FactProjectStatus
END