﻿CREATE PROCEDURE [AAS].[sp_upsert_FactOpportunityStage]
AS
DECLARE @tmp_FactOpportunityStage TABLE (
	[FactOpportunityStageId] [int] IDENTITY(1, 1) NOT NULL
	,[FactOpportunityStageKey] [varchar](100) NOT NULL
	,[OpportunityId] [int] NULL
	,[OpportunityStageId] [int] NULL
	,[OpportunityStageFirstDateId] [int] NULL
	,[OpportunityStageLastDateId] [int] NULL
	,[OpportunityStageSeq] [int] NOT NULL
	,[OpportunityStageDays] [int] NOT NULL
	,[_StartDate] [date] NOT NULL
	,[_EndDate] [date] NOT NULL
	,[_KeyHash] [binary](32) NOT NULL
	,[_ValueHash] [binary](32) NOT NULL
	,[_InsertDate] [datetime2](7) NOT NULL
	,[_InsertBy] [varchar](128) NOT NULL
	,[_UpdateDate] [datetime2](7) NOT NULL
	,[_UpdateBy] [varchar](128) NOT NULL
	)

BEGIN
	INSERT INTO @tmp_FactOpportunityStage (
		[FactOpportunityStageKey]
		,[OpportunityId]
		,[OpportunityStageId]
		,[OpportunityStageFirstDateId]
		,[OpportunityStageLastDateId]
		,[OpportunityStageSeq]
		,[OpportunityStageDays]
		,[_StartDate]
		,[_EndDate]
		,[_KeyHash]
		,[_ValueHash]
		,[_InsertDate]
		,[_InsertBy]
		,[_UpdateDate]
		,[_UpdateBy]
		)
	SELECT [FactOpportunityStageKey]
		,[OpportunityId]
		,[OpportunityStageId]
		,[OpportunityStageFirstDateId]
		,[OpportunityStageLastDateId]
		,[OpportunityStageSeq]
		,[OpportunityStageDays]
		,SYSDATETIME()
		,[_EndDate]
		,[_KeyHash]
		,[_ValueHash]
		,SYSDATETIME()
		,SYSTEM_USER
		,SYSDATETIME()
		,SYSTEM_USER
	FROM (
		MERGE [AAS].[FactOpportunityStage] AS [TARGET]
		USING (
			SELECT --os.[FactOpportunityStageId],
				ISNULL(os.[FactOpportunityStageKey], - 1) AS [FactOpportunityStageKey]
				,ISNULL(do.DimOpportunityId, - 1) AS [OpportunityId]
				,ISNULL(og.DimOpportunityStageId, - 1) AS [OpportunityStageId]
				--,ISNULL(da.DimDateID, - 1) AS [OpportunityStageFirstDateId]
				,os.OpportunityStageFirstDateId AS [OpportunityStageFirstDateId]
				--,ISNULL(dt.DimDateID, - 1) AS [OpportunityStageLastDateId]		
				,os.OpportunityStageLastDateId AS [OpportunityStageLastDateId]
				,ISNULL(ss.[OpportunityStageSeq], - 1) AS [OpportunityStageSeq]
				,ISNULL(os.[OpportunityStageDays], - 1) AS [OpportunityStageDays]
				,[_StartDate]
				,[_EndDate]
				,[_KeyHash]
				,[_ValueHash]
				,[_InsertDate]
				,[_InsertBy]
				,[_UpdateDate]
				,[_UpdateBy]
			FROM [AAS].[tmp_FactOpportunityStage] os
			LEFT JOIN (
				SELECT DISTINCT DimOpportunityStageId
					,OpportunityStageCode
				FROM [AAS].DimOpportunityStage
				) og ON CAST(os.OpportunityStageId AS VARCHAR) = og.OpportunityStageCode
			--LEFT JOIN (
			--SELECT DimDateID
			--	,DateShort
			--FROM [AAS].[DimDate]
			--) da ON os.OpportunityStageFirstDateId = REPLACE(da.DateShort, '-', '')
			--	LEFT JOIN (
			--SELECT DimDateID
			--	,DateShort
			--FROM [AAS].[DimDate]
			--) dt ON os.OpportunityStageLastDateId = REPLACE(dt.DateShort, '-', '')
			LEFT JOIN (
				SELECT DISTINCT DimOpportunityStageId
					,OpportunityStageCode
					,[OpportunityStageSeq]
				FROM [AAS].DimOpportunityStage
				) ss ON CAST(os.[OpportunityStageSeq] AS VARCHAR) = ss.[OpportunityStageSeq]
			LEFT JOIN (
				SELECT dimOpportunityID
					,OpportunityCode
				FROM [AAS].[DimOpportunity]
				) do ON CAST(os.OpportunityID AS VARCHAR) = do.OpportunityCode
			) AS [SOURCE]
			ON ([TARGET].[_KeyHash] = [SOURCE].[_KeyHash])
		WHEN NOT MATCHED BY TARGET
			THEN
				INSERT (
					[FactOpportunityStageKey]
					,[OpportunityId]
					,[OpportunityStageId]
					,[OpportunityStageFirstDateId]
					,[OpportunityStageLastDateId]
					,[OpportunityStageSeq]
					,[OpportunityStageDays]
					,[_StartDate]
					,[_EndDate]
					,[_KeyHash]
					,[_ValueHash]
					,[_InsertDate]
					,[_InsertBy]
					,[_UpdateDate]
					,[_UpdateBy]
					)
				VALUES (
					[SOURCE].[FactOpportunityStageKey]
					,[SOURCE].[OpportunityId]
					,[SOURCE].[OpportunityStageId]
					,[SOURCE].[OpportunityStageFirstDateId]
					,[SOURCE].[OpportunityStageLastDateId]
					,[SOURCE].[OpportunityStageSeq]
					,[SOURCE].[OpportunityStageDays]
					,SYSDATETIME()
					,[SOURCE].[_EndDate]
					,[SOURCE].[_KeyHash]
					,[SOURCE].[_ValueHash]
					,SYSDATETIME()
					,SYSTEM_USER
					,SYSDATETIME()
					,SYSTEM_USER
					)
		WHEN MATCHED
			AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
			AND ([TARGET].[_EndDate] = '9999-12-31')
			THEN
				UPDATE
				SET [TARGET].[_EndDate] = SYSDATETIME()
					,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
					,[TARGET].[_UpdateDate] = SYSDATETIME()
					,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy]
		OUTPUT $ACTION AS ACTION
			,[SOURCE].*
		) AS MERGE_OUTPUT
	WHERE MERGE_OUTPUT.ACTION = 'UPDATE';

	INSERT INTO [AAS].FactOpportunityStage (
		[FactOpportunityStageKey]
		,[OpportunityId]
		,[OpportunityStageId]
		,[OpportunityStageFirstDateId]
		,[OpportunityStageLastDateId]
		,[OpportunityStageSeq]
		,[OpportunityStageDays]
		,[_StartDate]
		,[_EndDate]
		,[_KeyHash]
		,[_ValueHash]
		,[_InsertDate]
		,[_InsertBy]
		,[_UpdateDate]
		,[_UpdateBy]
		)
	SELECT [FactOpportunityStageKey]
		,[OpportunityId]
		,[OpportunityStageId]
		,[OpportunityStageFirstDateId]
		,[OpportunityStageLastDateId]
		,[OpportunityStageSeq]
		,[OpportunityStageDays]
		,[_StartDate]
		,[_EndDate]
		,[_KeyHash]
		,[_ValueHash]
		,[_InsertDate]
		,[_InsertBy]
		,[_UpdateDate]
		,[_UpdateBy]
	FROM @tmp_FactOpportunityStage
END
GO


