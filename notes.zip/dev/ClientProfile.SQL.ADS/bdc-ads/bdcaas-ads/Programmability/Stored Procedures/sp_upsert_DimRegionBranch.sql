﻿CREATE PROCEDURE [AAS].[sp_upsert_DimRegionBranch]
AS
BEGIN
	MERGE [AAS].[DimRegionBranch] AS [TARGET]
	USING (
		SELECT [BranchCode]
			,[BranchName]
			,[AreaCode]
			,[AreaName]
			,[SubRegionName]
			,[RegionCode]
			,[RegionAbbr]
			,[RegionName]
			,[VPRegionAbbr]
			,[VPRegionName]
			,[_CurrentFlag]
			,[_KeyHash]
			,[_ValueHash]
			,[_InsertDate]
			,[_InsertBy]
			,[_UpdateDate]
			,[_UpdateBy]
		FROM [AAS].[tmp_DimRegionBranch]
		) AS [SOURCE]
		ON ([TARGET].[_KeyHash] = [SOURCE].[_KeyHash])
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				[BranchCode]
				,[BranchName]
				,[AreaCode]
				,[AreaName]
				,[SubRegionName]
				,[RegionCode]
				,[RegionAbbr]
				,[RegionName]
				,[VPRegionAbbr]
				,[VPRegionName]
				,[_CurrentFlag]
				,[_KeyHash]
				,[_ValueHash]
				,[_InsertDate]
				,[_InsertBy]
				,[_UpdateDate]
				,[_UpdateBy]
				)
			VALUES (
				[SOURCE].[BranchCode]
				,[SOURCE].[BranchName]
				,[SOURCE].[AreaCode]
				,[SOURCE].[AreaName]
				,[SOURCE].[SubRegionName]
				,[SOURCE].[RegionCode]
				,[SOURCE].[RegionAbbr]
				,[SOURCE].[RegionName]
				,[SOURCE].[VPRegionAbbr]
				,[SOURCE].[VPRegionName]
				,[SOURCE].[_CurrentFlag]
				,[SOURCE].[_KeyHash]
				,[SOURCE].[_ValueHash]
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSDATETIME()
				,SYSTEM_USER
				)
	WHEN MATCHED
		AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
		THEN
			UPDATE
			SET [TARGET].[BranchName] = [SOURCE].[BranchName]
				,[TARGET].[AreaCode] = [SOURCE].[AreaCode]
				,[TARGET].[AreaName] = [SOURCE].[AreaName]
				,[TARGET].[SubRegionName] = [SOURCE].[SubRegionName]
				,[TARGET].[RegionCode] = [SOURCE].[RegionCode]
				,[TARGET].[RegionAbbr] = [SOURCE].[RegionAbbr]
				,[TARGET].[RegionName] = [SOURCE].[RegionName]
				,[TARGET].[VPRegionAbbr] = [SOURCE].[VPRegionAbbr]
				,[TARGET].[VPRegionName] = [SOURCE].[VPRegionName]
				,[TARGET].[_ValueHash] = [SOURCE].[_ValueHash]
				,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				,[TARGET].[_UpdateDate] = SYSDATETIME()
				,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy];
END