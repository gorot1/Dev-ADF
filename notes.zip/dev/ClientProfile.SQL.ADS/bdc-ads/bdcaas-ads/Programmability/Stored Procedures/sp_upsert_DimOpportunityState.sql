﻿CREATE PROCEDURE [AAS].[sp_upsert_DimOpportunityState]
AS
BEGIN
	MERGE [AAS].[DimOpportunityState] AS [TARGET]
	USING (
		SELECT   
			[OpportunityStateCode]
			,[OpportunityStateName]
			,[OpportunityStateSeq]
			,[IsOpenState]
			,[IsWonState]
			,[IsLostState]
			,[_CurrentFlag]
			,[_KeyHash]
			,[_ValueHash]
			,[_InsertDate]
			,[_InsertBy]
			,[_UpdateDate]
			,[_UpdateBy]
		
		FROM [AAS].[tmp_DimOpportunityState]
		
		) AS [SOURCE]
		
		ON ([TARGET]._KeyHash = [SOURCE]._KeyHash)
	
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				 
                 [OpportunityStateCode]
			    ,[OpportunityStateName]
			    ,[OpportunityStateSeq]
			    ,[IsOpenState]
			    ,[IsWonState]
			    ,[IsLostState]
				,[_CurrentFlag]
				,[_KeyHash]
				,[_ValueHash]
				,[_InsertDate]
				,[_InsertBy]
				,[_UpdateDate]
				,[_UpdateBy]
				)
			VALUES (
				
				[SOURCE].[OpportunityStateCode]
				,[SOURCE].[OpportunityStateName]
				,[SOURCE].[OpportunityStateSeq]
                ,[SOURCE].[IsOpenState]
				,[SOURCE].[IsWonState]
				,[SOURCE].[IsLostState]
				,[SOURCE].[_CurrentFlag]
				,[SOURCE].[_KeyHash]
				,[SOURCE].[_ValueHash]
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSDATETIME()
				,SYSTEM_USER
				)
	WHEN MATCHED
		AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
		THEN
			UPDATE
			SET [TARGET].[OpportunityStateCode] = [SOURCE].[OpportunityStateCode]
				,[TARGET].[OpportunityStateName] = [SOURCE].[OpportunityStateName]
				,[TARGET].[OpportunityStateSeq] = [SOURCE].[OpportunityStateSeq]
				,[TARGET].[IsOpenState]= [SOURCE].[IsOpenState]
				,[TARGET].[IsWonState]= [SOURCE].[IsWonState]
				,[TARGET].[IsLostState]= [SOURCE].[IsLostState]
				,[TARGET].[_CurrentFlag] = [SOURCE].[_CurrentFlag]
				,[TARGET].[_ValueHash] = [SOURCE].[_ValueHash]
				,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				,[TARGET].[_UpdateDate] = SYSDATETIME()
				,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy];
END
GO