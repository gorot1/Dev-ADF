﻿CREATE PROCEDURE [AAS].[sp_upsert_DimProjectWorkflow]
AS
BEGIN
	MERGE [AAS].[DimProjectWorkflow] AS [TARGET]
	USING (
		SELECT [DimProjectWorkflowId]
			,[ProjectWorkflowCode]
			,[ProjectWorkflowSource]
			,[ProjectWorkflowDestination]
			,[ProjectWorkflowAction]
			,[_CurrentFlag]
			,[_KeyHash]
			,[_ValueHash]
			,[_InsertDate]
			,[_InsertBy]
			,[_UpdateDate]
			,[_UpdateBy]
		FROM [AAS].[tmp_DimProjectWorkflow]
		) AS [SOURCE]
		ON ([TARGET].[_KeyHash] = [SOURCE].[_KeyHash])
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				[ProjectWorkflowCode]
				,[ProjectWorkflowSource]
				,[ProjectWorkflowDestination]
				,[ProjectWorkflowAction]
				,[_CurrentFlag]
				,[_KeyHash]
				,[_ValueHash]
				,[_InsertDate]
				,[_InsertBy]
				,[_UpdateDate]
				,[_UpdateBy]
				)
			VALUES (
				[SOURCE].[ProjectWorkflowCode]
				,[SOURCE].[ProjectWorkflowSource]
				,[SOURCE].[ProjectWorkflowDestination]
				,[SOURCE].[ProjectWorkflowAction]
				,[SOURCE].[_CurrentFlag]
				,[SOURCE].[_KeyHash]
				,[SOURCE].[_ValueHash]
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSDATETIME()
				,SYSTEM_USER
				)
	WHEN MATCHED
		AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
		THEN
			UPDATE
			SET [TARGET].[ProjectWorkflowCode] = [SOURCE].[ProjectWorkflowCode]
				,[TARGET].[ProjectWorkflowSource] = [SOURCE].[ProjectWorkflowSource]
				,[TARGET].[ProjectWorkflowDestination] = [SOURCE].[ProjectWorkflowDestination]
				,[TARGET].[ProjectWorkflowAction] = [SOURCE].[ProjectWorkflowAction]
				,[TARGET].[_ValueHash] = [SOURCE].[_ValueHash]
				,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				,[TARGET].[_UpdateDate] = SYSDATETIME()
				,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy];
END