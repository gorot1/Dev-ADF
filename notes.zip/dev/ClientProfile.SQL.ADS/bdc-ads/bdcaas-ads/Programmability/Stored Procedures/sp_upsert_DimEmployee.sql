﻿
CREATE PROCEDURE [AAS].[sp_upsert_DimEmployee]
AS
BEGIN
	MERGE [AAS].[DimEmployee] AS [TARGET]
	USING (
		SELECT [DimEmployeeId]
			,[EmployeeCode]
			,[EmployeePIN]
			,[EmployeeLastName]
			,[EmployeeFirstName]
			,[EmployeeFullName]
			,[_CurrentFlag]
			,[_KeyHash]
			,[_ValueHash]
			,[_InsertBy]
			,[_UpdateBy]
		FROM [AAS].[tmp_DimEmployee] 
		) AS [SOURCE]
		ON ([TARGET].[_KeyHash] = [SOURCE].[_KeyHash])
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				[EmployeeCode]
				,[EmployeePIN]
				,[EmployeeLastName]
				,[EmployeeFirstName]
				,[EmployeeFullName]
				,[_CurrentFlag]
				,[_KeyHash]
				,[_ValueHash]
				,[_InsertDate]
				,[_InsertBy]
				,[_UpdateDate]
				,[_UpdateBy]
				)
			VALUES (
				[SOURCE].[EmployeeCode]
				,[SOURCE].[EmployeePIN]
				,[SOURCE].[EmployeeLastName]
				,[SOURCE].[EmployeeFirstName]
				,[SOURCE].[EmployeeFullName]
				,[SOURCE].[_CurrentFlag]
				,[SOURCE].[_KeyHash]
				,[SOURCE].[_ValueHash]
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSDATETIME()
				,SYSTEM_USER
				)
	WHEN MATCHED
		AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
		THEN
			UPDATE
			SET	 --[TARGET].[EmployeeCode]=[SOURCE].[EmployeeCode],
				[TARGET].[EmployeePIN] = [SOURCE].[EmployeePIN]
				,[TARGET].[EmployeeLastName] = [SOURCE].[EmployeeLastName]
				,[TARGET].[EmployeeFirstName] = [SOURCE].[EmployeeFirstName]
				,[TARGET].[EmployeeFullName] = [SOURCE].[EmployeeFullName]
				,[TARGET].[_ValueHash] = [SOURCE].[_ValueHash]
				,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				,[TARGET].[_UpdateDate] = SYSDATETIME()
				,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy];
END
GO


