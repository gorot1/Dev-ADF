﻿CREATE PROCEDURE [AAS].[sp_upsert_DimCampaign]
AS
BEGIN
	MERGE [AAS].[DimCampaign] AS [TARGET]
	USING (
		SELECT [DimCampaignId]
			,[CampaignCode]
			,[CampaignName]
			,[_CurrentFlag]
			,[_KeyHash]
			,[_ValueHash]
			,[_InsertDate]
			,[_InsertBy]
			,[_UpdateDate]
			,[_UpdateBy]
		FROM [AAS].[tmp_DimCampaign]
		) AS [SOURCE]
		ON ([TARGET].[_KeyHash] = [SOURCE].[_KeyHash])
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				[CampaignCode]
				,[CampaignName]
				,[_CurrentFlag]
				,[_KeyHash]
				,[_ValueHash]
				,[_InsertDate]
				,[_InsertBy]
				,[_UpdateDate]
				,[_UpdateBy]
				)
			VALUES (
				 [SOURCE].[CampaignCode]
				,[SOURCE].[CampaignName]
				,[SOURCE].[_CurrentFlag]
				,[SOURCE].[_KeyHash]
				,[SOURCE].[_ValueHash]
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSDATETIME()
				,SYSTEM_USER
				)
	WHEN MATCHED
		AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
		THEN
			UPDATE
			SET [TARGET].[CampaignName] = [SOURCE].[CampaignName]
				,[TARGET].[_ValueHash] = [SOURCE].[_ValueHash]
				,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				,[TARGET].[_UpdateDate] = SYSDATETIME()
				,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy];
END