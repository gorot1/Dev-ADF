﻿CREATE PROCEDURE [AAS].[sp_upsert_FactProjectManager]
AS
/*
DECLARE @tamper_FactProjectManager TABLE ( 
   	 [FactProjectManagerId] int  IDENTITY  NOT NULL 
	,[FactProjectManagerKey] varchar(100)  NOT NULL 
	,[ProjectId]          int  NULL 
	,[ProjectManagerEmployeeId] int  NULL 
	,[ContributionPct]    decimal(5,2) NULL 
	,[ClientNbrYTD] decimal(5,2) NULL 
	,[MandateNbrYTD] decimal(5,2) NULL 
	,[SalesAmtYTD] money NULL 
	,[RevenueAmtYTD] money NULL 
	,[GrossMarginYTD] money NULL 
	,[BadDebtsYTD] money NULL 
	,[NetMarginYTD] money NULL 
	,[UnearnedAmt] money NULL 
	,[ClientNbrMTD] decimal(5,2) NULL 
	,[MandateNbrMTD] money NULL 
	,[SalesAmtMTD] money NULL 
	,[RevenueAmtMTD] money NULL 
	,[GrossMarginMTD] money NULL 
	,[BadDebtsMTD] money NULL 
	,[ResourceNonRevAmt] money NULL 
	,[ResourceRevAmt] money NULL 
	,[_StartDate]         date  NOT NULL 
	,[_EndDate]           date  NOT NULL 
	,[_KeyHash]           binary(32)  NOT NULL 
	,[_ValueHash]         binary(32)  NOT NULL 
	,[_InsertDate]        Datetime2  NOT NULL 
	,[_InsertBy]          varchar(50)  NOT NULL 
	,[_UpdateDate]        Datetime2  NOT NULL 
	,[_UpdateBy]          varchar(50)  NOT NULL 
	)
BEGIN
	INSERT INTO @tamper_FactProjectManager (
	 [FactProjectManagerKey] 
	,[ProjectId]      
	,[ProjectManagerEmployeeId] 
	 ,[ContributionPct]
	,[ClientNbrYTD]
	,[MandateNbrYTD]
	,[SalesAmtYTD]
	,[RevenueAmtYTD]
	,[GrossMarginYTD]
	,[BadDebtsYTD]
	,[NetMarginYTD]
	,[UnearnedAmt]
	,[ClientNbrMTD]
	,[MandateNbrMTD]
	,[SalesAmtMTD]
	,[RevenueAmtMTD]
	,[GrossMarginMTD]
	,[BadDebtsMTD]
	,[ResourceNonRevAmt]
	,[ResourceRevAmt]
	,[_StartDate]         
	,[_EndDate]           
	,[_KeyHash]           
	,[_ValueHash]        
	,[_InsertDate]       
	,[_InsertBy]          
	,[_UpdateDate]       
	,[_UpdateBy] 
	)

   SELECT 
    
		 [FactProjectManagerKey] 
	     ,[ProjectId]      
	     ,[ProjectManagerEmployeeId] 
	    ,[ContributionPct]
		,[ClientNbrYTD]
		,[MandateNbrYTD]
		,[SalesAmtYTD]
		,[RevenueAmtYTD]
		,[GrossMarginYTD]
		,[BadDebtsYTD]
		,[NetMarginYTD]
		,[UnearnedAmt]
		,[ClientNbrMTD]
		,[MandateNbrMTD]
		,[SalesAmtMTD]
		,[RevenueAmtMTD]
		,[GrossMarginMTD]
		,[BadDebtsMTD]
		,[ResourceNonRevAmt]
		,[ResourceRevAmt]
		,SYSDATETIME()        
		,[_EndDate]           
		,[_KeyHash]           
		,[_ValueHash]        	
		,SYSDATETIME()
		,SYSTEM_USER
		,SYSDATETIME()
		,SYSTEM_USER
	FROM(
		MERGE [AAS].FactProjectManager AS [TARGET]
		USING (
		SELECT 		
		[FactProjectManagerKey]
		,ISNULL(DimPr.DimProjectId,-1)   as ProjectId
        ,ISNULL(DimEmp.DimEmployeeId,-1) as ProjectManagerEmployeeId
		,[ContributionPct]
		,[ClientNbrYTD]
		,[MandateNbrYTD]
		,[SalesAmtYTD]
		,[RevenueAmtYTD]
		,[GrossMarginYTD]
		,[BadDebtsYTD]
		,[NetMarginYTD]
		,[UnearnedAmt]
		,[ClientNbrMTD]
		,[MandateNbrMTD]
		,[SalesAmtMTD]
		,[RevenueAmtMTD]
		,[GrossMarginMTD]
		,[BadDebtsMTD]
		,[ResourceNonRevAmt]
		,[ResourceRevAmt]
		,tmp._StartDate
		,tmp._EndDate
		,tmp._KeyHash
		,tmp._ValueHash
		,tmp._InsertDate
		,tmp._InsertBy
		,tmp._UpdateBy
        
		FROM [AAS].[tmp_FactProjectManager] as tmp
        
		left join AAS.DimProject as DimPr ON DimPr.ProjectCode =tmp.ProjectCode
		left join AAS.DimEmployee  as DimEmp ON DimEmp.EmployeePIN = tmp.ProjectManagerPIN
		
		) AS [SOURCE]
        ON ([TARGET]._KeyHash = [SOURCE]._KeyHash)
	    
		WHEN NOT MATCHED BY TARGET 
		  THEN
			INSERT(
				 
				[FactProjectManagerKey] 
	            ,[ProjectId]      
	            ,[ProjectManagerEmployeeId] 
				,[ContributionPct]
				,[ClientNbrYTD]
				,[MandateNbrYTD]
				,[SalesAmtYTD]
				,[RevenueAmtYTD]
				,[GrossMarginYTD]
				,[BadDebtsYTD]
				,[NetMarginYTD]
				,[UnearnedAmt]
				,[ClientNbrMTD]
				,[MandateNbrMTD]
				,[SalesAmtMTD]
				,[RevenueAmtMTD]
				,[GrossMarginMTD]
				,[BadDebtsMTD]
				,[ResourceNonRevAmt]
				,[ResourceRevAmt]
				,[_StartDate]         
				,[_EndDate]           
				,[_KeyHash]           
				,[_ValueHash]        
				,[_InsertDate]       
				,[_InsertBy]          
				,[_UpdateDate]       
				,[_UpdateBy]          
				)
			VALUES (
                
				[FactProjectManagerKey] 
	            ,[ProjectId]      
	            ,[ProjectManagerEmployeeId] 
                ,[ContributionPct]
				,[ClientNbrYTD]
				,[MandateNbrYTD]
				,[SalesAmtYTD]
				,[RevenueAmtYTD]
				,[GrossMarginYTD]
				,[BadDebtsYTD]
				,[NetMarginYTD]
				,[UnearnedAmt]
				,[ClientNbrMTD]
				,[MandateNbrMTD]
				,[SalesAmtMTD]
				,[RevenueAmtMTD]
				,[GrossMarginMTD]
				,[BadDebtsMTD]
				,[ResourceNonRevAmt]
				,[ResourceRevAmt]
				,SYSDATETIME()        
				,[_EndDate]           
				,[_KeyHash]           
				,[_ValueHash]        	
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSDATETIME()
				,SYSTEM_USER
				)

	  WHEN MATCHED  AND [TARGET].[_ValueHash] <> [SOURCE].[_ValueHash]
	  AND ([TARGET].[_EndDate] = '9999-12-31')
	   		
		 THEN
			UPDATE
			SET  [TARGET].[_EndDate] = SYSDATETIME()
			     ,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				 ,[TARGET].[_UpdateDate] = SYSDATETIME()
				 ,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy]
			OUTPUT $ACTION as ACTION
			     , [SOURCE].*
		    ) AS MERGE_OUTPUT
		 WHERE MERGE_OUTPUT.ACTION = 'UPDATE';
			
			INSERT INTO [AAS].FactProjectManager (
			 [FactProjectManagerKey] 
	         ,[ProjectId]      
	        ,[ProjectManagerEmployeeId] 
	        ,[ContributionPct]
			,[ClientNbrYTD]
			,[MandateNbrYTD]
			,[SalesAmtYTD]
			,[RevenueAmtYTD]
			,[GrossMarginYTD]
			,[BadDebtsYTD]
			,[NetMarginYTD]
			,[UnearnedAmt]
			,[ClientNbrMTD]
			,[MandateNbrMTD]
			,[SalesAmtMTD]
			,[RevenueAmtMTD]
			,[GrossMarginMTD]
			,[BadDebtsMTD]
			,[ResourceNonRevAmt]
			,[ResourceRevAmt]
			,[_StartDate]         
			,[_EndDate]           
			,[_KeyHash]           
			,[_ValueHash]        
			,[_InsertDate]       
			,[_InsertBy]          
			,[_UpdateDate]       
			,[_UpdateBy] 
			)
	
			SELECT
		    [FactProjectManagerKey] 
	        ,[ProjectId]      
	        ,[ProjectManagerEmployeeId] 
            ,[ContributionPct]
			,[ClientNbrYTD]
			,[MandateNbrYTD]
			,[SalesAmtYTD]
			,[RevenueAmtYTD]
			,[GrossMarginYTD]
			,[BadDebtsYTD]
			,[NetMarginYTD]
			,[UnearnedAmt]
			,[ClientNbrMTD]
			,[MandateNbrMTD]
			,[SalesAmtMTD]
			,[RevenueAmtMTD]
			,[GrossMarginMTD]
			,[BadDebtsMTD]
			,[ResourceNonRevAmt]
			,[ResourceRevAmt]
			,[_StartDate]         
			,[_EndDate]           
			,[_KeyHash]           
			,[_ValueHash]        
			,[_InsertDate]       
			,[_InsertBy]          
			,[_UpdateDate]       
			,[_UpdateBy] 
      FROM @tamper_FactProjectManager
END
*/