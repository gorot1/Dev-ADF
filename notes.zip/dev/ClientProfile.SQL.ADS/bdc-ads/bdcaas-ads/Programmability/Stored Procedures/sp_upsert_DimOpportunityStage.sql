﻿CREATE PROCEDURE [AAS].[sp_upsert_DimOpportunityStage]
AS
BEGIN
	MERGE [AAS].[DimOpportunityStage] AS [TARGET]
	USING (
		SELECT [OpportunityStageCode]
			,[OpportunityStageName]
			,[OpportunityStageSeq]
			,[IsQualifiedStage]
			,[IsProposedStage]
			,[IsSalesStage]
			,[_CurrentFlag]
			,[_KeyHash]
			,[_ValueHash]
			,[_InsertDate]
			,[_InsertBy]
			,[_UpdateDate]
			,[_UpdateBy]
		FROM [AAS].[tmp_DimOpportunityStage]
		) AS [SOURCE]
		ON ([TARGET].[_KeyHash] = [SOURCE].[_KeyHash])
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				[OpportunityStageCode]
				,[OpportunityStageName]
				,[OpportunityStageSeq]
				,[IsQualifiedStage]
				,[IsProposedStage]
				,[IsSalesStage]
				,[_CurrentFlag]
				,[_KeyHash]
				,[_ValueHash]
				,[_InsertDate]
				,[_InsertBy]
				,[_UpdateDate]
				,[_UpdateBy]
				)
			VALUES (
				[SOURCE].[OpportunityStageCode]
				,[SOURCE].[OpportunityStageName]
				,[SOURCE].[OpportunityStageSeq]
				,[SOURCE].[IsQualifiedStage]
				,[SOURCE].[IsProposedStage]
				,[SOURCE].[IsSalesStage]
				,[SOURCE].[_CurrentFlag]
				,[SOURCE].[_KeyHash]
				,[SOURCE].[_ValueHash]
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSDATETIME()
				,SYSTEM_USER
				)
	WHEN MATCHED
		AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
		THEN
			UPDATE
			SET [TARGET].[OpportunityStageName] = [SOURCE].[OpportunityStageName]
				,[TARGET].[OpportunityStageSeq] = [SOURCE].[OpportunityStageSeq]
				,[TARGET].[IsQualifiedStage] = [SOURCE].[IsQualifiedStage]
				,[TARGET].[IsProposedStage] = [SOURCE].[IsProposedStage]
				,[TARGET].[IsSalesStage] = [SOURCE].[IsSalesStage]
				,[TARGET].[_CurrentFlag] = [SOURCE].[_CurrentFlag]
				,[TARGET].[_ValueHash] = [SOURCE].[_ValueHash]
				,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				,[TARGET].[_UpdateDate] = SYSDATETIME()
				,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy];
END
