﻿CREATE PROCEDURE [AAS].[sp_upsert_FactProjectWorkflow]
AS
DECLARE @tamper_FactProjectWorkflow TABLE (
	[FactProjectWorkflowId] INT IDENTITY NOT NULL
	,[FactProjectWorkflowKey] VARCHAR(200) NOT NULL
	,[ProjectId] INT NULL
	,[ProjectWorkflowDateId] INT NULL
	,[ProjectWorkflowId] INT NULL
	,[ProjectWorkflowSeq] INT NOT NULL
	,[_StartDate] DATE NOT NULL
	,[_EndDate] DATE NOT NULL
	,[_KeyHash] BINARY (32) NOT NULL
	,[_ValueHash] BINARY (32) NOT NULL
	,[_InsertDate] DATETIME2 NOT NULL
	,[_InsertBy] VARCHAR(50) NOT NULL
	,[_UpdateDate] DATETIME2 NOT NULL
	,[_UpdateBy] VARCHAR(50) NOT NULL
	)

BEGIN
INSERT INTO @tamper_FactProjectWorkflow (
	[FactProjectWorkflowKey]
	,[ProjectId]
	,[ProjectWorkflowDateId]
	,[ProjectWorkflowId]
	,[ProjectWorkflowSeq]
	,[_StartDate]
	,[_EndDate]
	,[_KeyHash]
	,[_ValueHash]
	,[_InsertDate]
	,[_InsertBy]
	,[_UpdateDate]
	,[_UpdateBy]
	)
SELECT [FactProjectWorkflowKey]
	,[ProjectId]
	,[ProjectWorkflowDateId]
	,[ProjectWorkflowId]
	,[ProjectWorkflowSeq]
	,SYSDATETIME()
	,[_EndDate]
	,[_KeyHash]
	,[_ValueHash]
	,SYSDATETIME()
	,SYSTEM_USER
	,SYSDATETIME()
	,SYSTEM_USER
FROM (
	MERGE [AAS].FactProjectWorkflow AS [TARGET]
	USING (
		SELECT tmp.FactProjectWorkflowKey
			,ISNULL(DimPr.DimProjectId, - 1) AS ProjectId
			,ISNULL(dm.DimDateKey, - 1) AS ProjectWorkflowDateId
			,ISNULL(DimPrWf.DimProjectWorkflowId, - 1) AS ProjectWorkflowId
			,ProjectWorkflowSeq
			,tmp._StartDate
			,tmp._EndDate
			,tmp._KeyHash
			,tmp._ValueHash
			,tmp._InsertDate
			,tmp._InsertBy
			,tmp._UpdateBy
		FROM [AAS].[tmp_FactProjectWorkflow] AS tmp
		LEFT JOIN AAS.DimProject AS DimPr ON DimPr.ProjectCode = Cast(tmp.ProjectId AS VARCHAR)
		LEFT JOIN AAS.DimProjectWorkflow AS DimPrWf ON DimPrWf.ProjectWorkflowCode = tmp.ProjectWorkflowCode
		LEFT JOIN (
			SELECT DATE
				,DimDateKey
			FROM dbo.DimDate
			) dm ON CAST(tmp.Project_Workflow_History_Date_Modified AS DATE) = dm.DATE
		) AS [SOURCE]
		ON ([TARGET]._KeyHash = [SOURCE]._KeyHash)
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				[FactProjectWorkflowKey]
				,[ProjectId]
				,[ProjectWorkflowDateId]
				,[ProjectWorkflowId]
				,[ProjectWorkflowSeq]
				,[_StartDate]
				,[_EndDate]
				,[_KeyHash]
				,[_ValueHash]
				,[_InsertDate]
				,[_InsertBy]
				,[_UpdateDate]
				,[_UpdateBy]
				)
			VALUES (
				[FactProjectWorkflowKey]
				,[ProjectId]
				,[ProjectWorkflowDateId]
				,[ProjectWorkflowId]
				,[ProjectWorkflowSeq]
				,SYSDATETIME()
				,[_EndDate]
				,[_KeyHash]
				,[_ValueHash]
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSDATETIME()
				,SYSTEM_USER
				)
	WHEN MATCHED
		AND [TARGET].[_ValueHash] <> [SOURCE].[_ValueHash]
		AND ([TARGET].[_EndDate] = '9999-12-31')
		THEN
			UPDATE
			SET [TARGET].[_EndDate] = SYSDATETIME()
				,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				,[TARGET].[_UpdateDate] = SYSDATETIME()
				,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy]
	OUTPUT $ACTION AS ACTION
		,[SOURCE].*
	) AS MERGE_OUTPUT
WHERE MERGE_OUTPUT.ACTION = 'UPDATE';

INSERT INTO [AAS].FactProjectWorkflow (
	[FactProjectWorkflowKey]
	,[ProjectId]
	,[ProjectWorkflowDateId]
	,[ProjectWorkflowId]
	,[ProjectWorkflowSeq]
	,[_StartDate]
	,[_EndDate]
	,[_KeyHash]
	,[_ValueHash]
	,[_InsertDate]
	,[_InsertBy]
	,[_UpdateDate]
	,[_UpdateBy]
	)
SELECT [FactProjectWorkflowKey]
	,[ProjectId]
	,[ProjectWorkflowDateId]
	,[ProjectWorkflowId]
	,[ProjectWorkflowSeq]
	,[_StartDate]
	,[_EndDate]
	,[_KeyHash]
	,[_ValueHash]
	,[_InsertDate]
	,[_InsertBy]
	,[_UpdateDate]
	,[_UpdateBy]
FROM @tamper_FactProjectWorkflow
	END