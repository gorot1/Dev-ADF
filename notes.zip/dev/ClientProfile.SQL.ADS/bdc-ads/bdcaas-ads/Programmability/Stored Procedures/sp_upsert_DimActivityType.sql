﻿CREATE PROCEDURE [AAS].[sp_upsert_DimActivityType]
AS
BEGIN
	MERGE [AAS].[DimActivityType] AS [TARGET]
	USING (
		SELECT   
			 [ActivityTypeCode]  
			,[ActivityTypeName]  
			,[IsConsulting]      
			,[_CurrentFlag]
			,[_KeyHash]
			,[_ValueHash]
			,[_InsertDate]
			,[_InsertBy]
			,[_UpdateDate]
			,[_UpdateBy]
		
		FROM [AAS].[tmp_DimActivityType]
		) AS [SOURCE]
		ON ([TARGET]._KeyHash = [SOURCE]._KeyHash)
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (           
                 [ActivityTypeCode]   
                ,[ActivityTypeName]   
                ,[IsConsulting]       
				,[_CurrentFlag]
				,[_KeyHash]
				,[_ValueHash]
				,[_InsertDate]
				,[_InsertBy]
				,[_UpdateDate]
				,[_UpdateBy]
				)
			VALUES (
				
				 [SOURCE].[ActivityTypeCode]
				,[SOURCE].[ActivityTypeName]   
				,[SOURCE].[IsConsulting]   
				,[SOURCE].[_CurrentFlag]
				,[SOURCE].[_KeyHash]
				,[SOURCE].[_ValueHash]
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSDATETIME()
				,SYSTEM_USER
				)
	WHEN MATCHED
		AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
		THEN
			UPDATE
			SET [TARGET].[ActivityTypeCode] = [SOURCE].[ActivityTypeCode]
				,[TARGET].[ActivityTypeName] = [SOURCE].[ActivityTypeName]
				,[TARGET].[IsConsulting] = [SOURCE].[IsConsulting]
				,[TARGET].[_CurrentFlag] = [SOURCE].[_CurrentFlag]
				,[TARGET].[_ValueHash] = [SOURCE].[_ValueHash]
				,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				,[TARGET].[_UpdateDate] = SYSDATETIME()
				,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy];
END