﻿CREATE PROCEDURE [AAS].[sp_upsert_DimLineOfBusiness]
AS
BEGIN
	MERGE [AAS].[DimLineOfBusiness] AS [TARGET]
	USING (
		SELECT [DimLineOfBusinessId]
			,[LineOfBusinessCode]
			,[LineOfBusinessName]
			,[IsConsulting]
			,[_CurrentFlag]
			,[_KeyHash]
			,[_ValueHash]
			,[_InsertDate]
			,[_UpdateDate]
			,[_InsertBy]
			,[_UpdateBy]
		FROM [AAS].[tmp_DimLineOfBusiness]
		) AS [SOURCE]
		ON ([TARGET].[_KeyHash] = [SOURCE].[_KeyHash])
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				[LineOfBusinessCode]
				,[LineOfBusinessName]
				,[IsConsulting]
				,[_CurrentFlag]
				,[_KeyHash]
				,[_ValueHash]
				,[_InsertDate]
				,[_UpdateDate]
				,[_InsertBy]
				,[_UpdateBy]
				)
			VALUES (
				[SOURCE].[LineOfBusinessCode]
				,[SOURCE].[LineOfBusinessName]
				,[SOURCE].[IsConsulting]
				,[SOURCE].[_CurrentFlag]
				,[SOURCE].[_KeyHash]
				,[SOURCE].[_ValueHash]
				,SYSDATETIME()
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSTEM_USER
				)
	WHEN MATCHED
		AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
		THEN
			UPDATE
			SET [TARGET].[LineOfBusinessCode] = [SOURCE].[LineOfBusinessCode]
				,[TARGET].[LineOfBusinessName] = [SOURCE].[LineOfBusinessName]
				,[TARGET].[IsConsulting] = [SOURCE].[IsConsulting]
				,[TARGET].[_ValueHash] = [SOURCE].[_ValueHash]
				,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				,[TARGET].[_UpdateDate] = SYSDATETIME()
				,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy];
END