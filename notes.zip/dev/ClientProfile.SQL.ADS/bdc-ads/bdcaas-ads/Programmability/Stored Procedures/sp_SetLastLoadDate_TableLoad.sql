﻿/****** Object:  StoredProcedure [AAS].[sp_SetLastLoadDate_TableLoad]    Script Date: 28/01/2021 3:44:15 PM ******/

CREATE PROCEDURE [AAS].[sp_setLastLoadDate_TableLoad] (
	@tableName VARCHAR(255)
	,@newLastLoadDate DATETIME
	)
AS
BEGIN
	MERGE [AAS].[ADS_TableLoad] AS [TARGET]
	USING (
		SELECT 	
				@tableName AS [TableName]
				,@newLastLoadDate AS [LastLoadDate]
				
		) AS [SOURCE]
		ON [TARGET].TableName = [SOURCE].TableName
	WHEN MATCHED
		THEN
			UPDATE
			SET [TARGET].[LastLoadDate] = [SOURCE].[LastLoadDate]
	WHEN NOT MATCHED
		THEN
			INSERT (
				[TableName]
				,[LastLoadDate]
				)
			VALUES (
				 [SOURCE].[TableName]
				,[SOURCE].[LastLoadDate]
				);
END
GO
