﻿CREATE PROCEDURE [AAS].[sp_upsert_FactMandate]
AS
DECLARE @tmp_FactMandate TABLE (
	 [FactMandateId] [int] IDENTITY(1, 1) NOT NULL
	,[FactMandateKey] [varchar](100) NOT NULL
	,[JournalLineDateId] [int] NOT NULL
	,[ProjectId] [int] NOT NULL
	,[ProjectManagerEmployeeId] [int] NOT NULL
	,[RegionBranchId]			[int]   NOT NULL 
	,[ContributionPct] [decimal](5, 2) NOT NULL
	,[ClientNbrYTD] [decimal](18, 5)  NULL
    ,[MandateNbrYTD] [decimal](18, 5)  NULL
    ,[SalesAmtYTD] [decimal](18, 5)  NULL
    ,[RevenueAmtYTD] [decimal](18, 5)  NULL
    ,[GrossMarginYTD] [decimal](18, 5)  NULL
    ,[BadDebtsYTD] [decimal](18, 5)  NULL
    ,[NetMarginYTD] [decimal](18, 5)  NULL	
	,[UnearnedAmt] [decimal](18, 5) NOT NULL
	,[ProjectAmt] [decimal](18, 5) NOT NULL
	,[NumberOfMandates] [decimal](13, 5) NOT NULL
	,[NetSalesAmt] [decimal](18, 5) NOT NULL
	,[RevenueAmt] [decimal](18, 5) NOT NULL
	,[ExternalConsultingFeeAmt] [decimal](18, 5) NOT NULL
	,[InternalConsultingFeeAmt] [decimal](18, 5) NOT NULL
	,[GrossMarginAmt] [decimal](18, 5) NOT NULL
	,[ResourceNonRevAmt] [decimal](18, 5) NOT NULL
	,[ResourceRevAmt] [decimal](18, 5) NOT NULL
	,[_StartDate] [date] NOT NULL
	,[_EndDate] [date] NOT NULL
	,[_KeyHash] [binary](32) NOT NULL
	,[_ValueHash] [binary](32) NOT NULL
	,[_InsertDate] [datetime2](7) NOT NULL
	,[_InsertBy] [varchar](128) NOT NULL
	,[_UpdateDate] [datetime2](7) NOT NULL
	,[_UpdateBy] [varchar](128) NOT NULL
	)

BEGIN
	INSERT INTO @tmp_FactMandate (
		[FactMandateKey]
		,[JournalLineDateId]
		,[ProjectId]
		,[ProjectManagerEmployeeId]
		,[RegionBranchId]
		,[ContributionPct]
		,[ClientNbrYTD]
        ,[MandateNbrYTD]
        ,[SalesAmtYTD]
        ,[RevenueAmtYTD]
        ,[GrossMarginYTD]
        ,[BadDebtsYTD]
        ,[NetMarginYTD]
		,[UnearnedAmt]
		,[ProjectAmt]
		,[NumberOfMandates]
		,[NetSalesAmt]
		,[RevenueAmt]
		,[ExternalConsultingFeeAmt]
		,[InternalConsultingFeeAmt]
		,[GrossMarginAmt]
		,[ResourceNonRevAmt]
		,[ResourceRevAmt]
		,[_StartDate]
		,[_EndDate]
		,[_KeyHash]
		,[_ValueHash]
		,[_InsertDate]
		,[_InsertBy]
		,[_UpdateDate]
		,[_UpdateBy]
		)
	SELECT [FactMandateKey]
		,[JournalLineDateId]
		,[ProjectId]
		,[ProjectManagerEmployeeId]
		,[RegionBranchId]
		,[ContributionPct]
	    ,[ClientNbrYTD]
        ,[MandateNbrYTD]
        ,[SalesAmtYTD]
        ,[RevenueAmtYTD]
        ,[GrossMarginYTD]
        ,[BadDebtsYTD]
        ,[NetMarginYTD]
		,[UnearnedAmt]
		,[ProjectAmt]
		,[NumberOfMandates]
		,[NetSalesAmt]
		,[RevenueAmt]
		,[ExternalConsultingFeeAmt]
		,[InternalConsultingFeeAmt]
		,[GrossMarginAmt]
		,[ResourceNonRevAmt]
		,[ResourceRevAmt]
		,SYSDATETIME()
		,[_EndDate]
		,[_KeyHash]
		,[_ValueHash]
		,SYSDATETIME()
		,SYSTEM_USER
		,SYSDATETIME()
		,SYSTEM_USER
	FROM (
		MERGE [AAS].[FactMandate] AS [TARGET]
		USING (
			SELECT [FactMandateKey]
				,[JournalLineDateId]
				,ISNULL(po.DimProjectID, - 1) AS [ProjectId]
				,ISNULL(em.DimEmployeeId, - 1) AS [ProjectManagerEmployeeId]
				,ISNULL(rb.DimRegionBranchId, - 1) AS [RegionBranchId]
				,ISNULL([ContributionPct], - 1) AS [ContributionPct]
				,ISNULL([ClientNbrYTD], - 1) AS [ClientNbrYTD]
                ,ISNULL([MandateNbrYTD], - 1) AS [MandateNbrYTD]
                ,ISNULL([SalesAmtYTD], - 1) AS [SalesAmtYTD]
                ,ISNULL([RevenueAmtYTD], - 1) AS [RevenueAmtYTD]
                ,ISNULL([GrossMarginYTD], - 1) AS [GrossMarginYTD]
                ,ISNULL([BadDebtsYTD], - 1) AS [BadDebtsYTD]
                ,ISNULL([NetMarginYTD], - 1) AS	[NetMarginYTD]
				,ISNULL([UnearnedAmt], - 1) AS [UnearnedAmt]
				,ISNULL([ProjectAmt], - 1) AS [ProjectAmt]
				,ISNULL([NumberOfMandates], - 1) [NumberOfMandates]
				,ISNULL([NetSalesAmt], - 1) [NetSalesAmt]
				,ISNULL([RevenueAmt], - 1) [RevenueAmt]
				,ISNULL([ExternalConsultingFeeAmt], - 1) AS [ExternalConsultingFeeAmt]
				,ISNULL([InternalConsultingFeeAmt], - 1) AS [InternalConsultingFeeAmt]
				,ISNULL([GrossMarginAmt], - 1) AS [GrossMarginAmt]
				,ISNULL([ResourceNonRevAmt], - 1) AS [ResourceNonRevAmt]
				,ISNULL([ResourceRevAmt], - 1) AS [ResourceRevAmt]
				,[_StartDate]
				,[_EndDate]
				,[_KeyHash]
				,[_ValueHash]
				,[_InsertDate]
				,[_InsertBy]
				,[_UpdateDate]
				,[_UpdateBy]
			FROM [AAS].[tmp_FactMandate] mm
			LEFT JOIN (
				SELECT DimProjectID
					,ProjectCode
				FROM [AAS].DimProject
				) po ON po.ProjectCode = mm.[ProjectCode]
			LEFT JOIN (
				SELECT EmployeePIN
					,DimEmployeeId
				FROM [AAS].DimEmployee
				) em ON mm.[ProjectManagerPIN] =CAST( em.EmployeePIN AS VARCHAR)
			LEFT JOIN (
				SELECT DimRegionBranchId
				,BranchCode
			    FROM [AAS].DimRegionBranch
				) rb ON mm.[BranchCode]= rb.[BranchCode] 					
			) AS [SOURCE]
			ON ([TARGET].[_KeyHash] = [SOURCE].[_KeyHash])
		WHEN NOT MATCHED BY TARGET
			THEN
				INSERT (
					[FactMandateKey]
					,[JournalLineDateId]
					,[ProjectId]
					,[ProjectManagerEmployeeId]
					,[RegionBranchId]
					,[ContributionPct]
					,[ClientNbrYTD]
					,[MandateNbrYTD]
					,[SalesAmtYTD]
					,[RevenueAmtYTD]
					,[GrossMarginYTD]
					,[BadDebtsYTD]
					,[NetMarginYTD]
					,[UnearnedAmt]
					,[ProjectAmt]
					,[NumberOfMandates]
					,[NetSalesAmt]
					,[RevenueAmt]
					,[ExternalConsultingFeeAmt]
					,[InternalConsultingFeeAmt]
					,[GrossMarginAmt]
					,[ResourceNonRevAmt]
					,[ResourceRevAmt]
					,[_StartDate]
					,[_EndDate]
					,[_KeyHash]
					,[_ValueHash]
					,[_InsertDate]
					,[_InsertBy]
					,[_UpdateDate]
					,[_UpdateBy]
					)
				VALUES (
					[SOURCE].[FactMandateKey]
					,[SOURCE].[JournalLineDateId]
					,[SOURCE].[ProjectId]
					,[SOURCE].[ProjectManagerEmployeeId]
					,[SOURCE].[RegionBranchId]
					,[SOURCE].[ContributionPct]
					,[SOURCE].[ClientNbrYTD]
                    ,[SOURCE].[MandateNbrYTD]
                    ,[SOURCE].[SalesAmtYTD]
                    ,[SOURCE].[RevenueAmtYTD]
                    ,[SOURCE].[GrossMarginYTD]
                    ,[SOURCE].[BadDebtsYTD]
                    ,[SOURCE].[NetMarginYTD]
					,[SOURCE].[UnearnedAmt]
					,[SOURCE].[ProjectAmt]
					,[SOURCE].[NumberOfMandates]
					,[SOURCE].[NetSalesAmt]
					,[SOURCE].[RevenueAmt]
					,[SOURCE].[ExternalConsultingFeeAmt]
					,[SOURCE].[InternalConsultingFeeAmt]
					,[SOURCE].[GrossMarginAmt]
					,[SOURCE].[ResourceNonRevAmt]
					,[SOURCE].[ResourceRevAmt]
					,SYSDATETIME()
					,[SOURCE].[_EndDate]
					,[SOURCE].[_KeyHash]
					,[SOURCE].[_ValueHash]
					,SYSDATETIME()
					,SYSTEM_USER
					,SYSDATETIME()
					,SYSTEM_USER
					)
		WHEN MATCHED
			AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
			AND ([TARGET].[_EndDate] = '9999-12-31')
			THEN
				UPDATE
				SET [TARGET].[_EndDate] = SYSDATETIME()
					,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
					,[TARGET].[_UpdateDate] = SYSDATETIME()
					,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy]
		OUTPUT $ACTION AS ACTION
			,[SOURCE].*
		) AS MERGE_OUTPUT
	WHERE MERGE_OUTPUT.ACTION = 'UPDATE';

	INSERT INTO [AAS].FactMandate (
		 [FactMandateKey]
		,[JournalLineDateId]
		,[ProjectId]
		,[ProjectManagerEmployeeId]
		,[RegionBranchId]
		,[ContributionPct]
	    ,[ClientNbrYTD]
		,[MandateNbrYTD]
		,[SalesAmtYTD]
		,[RevenueAmtYTD]
		,[GrossMarginYTD]
		,[BadDebtsYTD]
		,[NetMarginYTD]
		,[UnearnedAmt]
		,[ProjectAmt]
		,[NumberOfMandates]
		,[NetSalesAmt]
		,[RevenueAmt]
		,[ExternalConsultingFeeAmt]
		,[InternalConsultingFeeAmt]
		,[GrossMarginAmt]
		,[ResourceNonRevAmt]
		,[ResourceRevAmt]
		,[_StartDate]
		,[_EndDate]
		,[_KeyHash]
		,[_ValueHash]
		,[_InsertDate]
		,[_InsertBy]
		,[_UpdateDate]
		,[_UpdateBy]
		)
	SELECT [FactMandateKey]
		,[JournalLineDateId]
		,[ProjectId]
		,[ProjectManagerEmployeeId]
		,[RegionBranchId]
		,[ContributionPct]
		,[ClientNbrYTD]
		,[MandateNbrYTD]
		,[SalesAmtYTD]
		,[RevenueAmtYTD]
		,[GrossMarginYTD]
		,[BadDebtsYTD]
		,[NetMarginYTD]
		,[UnearnedAmt]
		,[ProjectAmt]
		,[NumberOfMandates]
		,[NetSalesAmt]
		,[RevenueAmt]
		,[ExternalConsultingFeeAmt]
		,[InternalConsultingFeeAmt]
		,[GrossMarginAmt]
		,[ResourceNonRevAmt]
		,[ResourceRevAmt]
		,[_StartDate]
		,[_EndDate]
		,[_KeyHash]
		,[_ValueHash]
		,[_InsertDate]
		,[_InsertBy]
		,[_UpdateDate]
		,[_UpdateBy]
	FROM @tmp_FactMandate
END
GO


