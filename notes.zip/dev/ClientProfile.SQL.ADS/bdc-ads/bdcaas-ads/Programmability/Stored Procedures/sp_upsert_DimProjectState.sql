﻿CREATE PROCEDURE [AAS].[sp_upsert_DimProjectState]
AS
BEGIN
	MERGE [AAS].[DimProjectState] AS [TARGET]
	USING (
		SELECT   
			[ProjectStateCode]   
            ,[ProjectStateName]    
			,[_CurrentFlag]
			,[_KeyHash]
			,[_ValueHash]
			,[_InsertDate]
			,[_InsertBy]
			,[_UpdateDate]
			,[_UpdateBy]
		FROM [AAS].[tmp_DimProjectState]
		) AS [SOURCE]
		
		ON ([TARGET].[ProjectStateCode]= [SOURCE].[ProjectStateCode])
	
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				 
				 [ProjectStateCode]   
                 ,[ProjectStateName]  
				,[_CurrentFlag]
				,[_KeyHash]
				,[_ValueHash]
				,[_InsertDate]
				,[_InsertBy]
				,[_UpdateDate]
				,[_UpdateBy]
				)
			VALUES (
				
				[SOURCE].[ProjectStateCode]  
				,[SOURCE].[ProjectStateName]  
				,[SOURCE].[_CurrentFlag]
				,[SOURCE].[_KeyHash]
				,[SOURCE].[_ValueHash]
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSDATETIME()
				,SYSTEM_USER
				)
	WHEN MATCHED
		AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
		THEN
			UPDATE
			SET 
				[TARGET].[ProjectStateName] = [SOURCE].[ProjectStateName]
				,[TARGET].[_CurrentFlag] = [SOURCE].[_CurrentFlag]
				,[TARGET].[_ValueHash] = [SOURCE].[_ValueHash]
				,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				,[TARGET].[_UpdateDate] = SYSDATETIME()
				,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy];
END
GO


