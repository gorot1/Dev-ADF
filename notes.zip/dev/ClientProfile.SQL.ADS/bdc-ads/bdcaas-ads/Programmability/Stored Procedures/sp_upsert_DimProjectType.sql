﻿CREATE PROCEDURE [AAS].[sp_upsert_DimProjectType]
AS
BEGIN
	MERGE [AAS].[DimProjectType] AS [TARGET]
	USING (
		SELECT   
			 [ProjectTypeCode]
            ,[ProjectTypeNo]
            ,[ProjectTypeName]  
			,[_CurrentFlag]
			,[_KeyHash]
			,[_ValueHash]
			,[_InsertDate]
			,[_InsertBy]
			,[_UpdateDate]
			,[_UpdateBy]
		FROM [AAS].[tmp_DimProjectType]
		) AS [SOURCE]
		
		ON ([TARGET].[_KeyHash]= [SOURCE].[_KeyHash])
	
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				 
				 [ProjectTypeCode]
                ,[ProjectTypeNo]
                ,[ProjectTypeName]
				,[_CurrentFlag]
				,[_KeyHash]
				,[_ValueHash]
				,[_InsertDate]
				,[_InsertBy]
				,[_UpdateDate]
				,[_UpdateBy]
				)
			VALUES (
				
				[SOURCE].[ProjectTypeCode] 
				,[SOURCE].[ProjectTypeNo]
				,[SOURCE].[ProjectTypeName]  
				,[SOURCE].[_CurrentFlag]
				,[SOURCE].[_KeyHash]
				,[SOURCE].[_ValueHash]
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSDATETIME()
				,SYSTEM_USER
				)
	WHEN MATCHED
		AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
		THEN
			UPDATE
			SET [TARGET].[ProjectTypeCode] = [SOURCE].[ProjectTypeCode]
			    ,[TARGET].[ProjectTypeNo] = [SOURCE].[ProjectTypeNo]
				,[TARGET].[ProjectTypeName] = [SOURCE].[ProjectTypeName]
				,[TARGET].[_CurrentFlag] = [SOURCE].[_CurrentFlag]
				,[TARGET].[_ValueHash] = [SOURCE].[_ValueHash]
				,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				,[TARGET].[_UpdateDate] = SYSDATETIME()
				,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy];
END