﻿
CREATE PROCEDURE [AAS].[sp_upsert_FactProject]
AS

DECLARE @tamper_FactProject TABLE ( 
    [FactProjectId]      int  IDENTITY  NOT NULL 
	,[FactProjectKey]     varchar(100)  NOT NULL 
	,[ProjectId]          int  NULL 
	,[OpportunityId]      int  NULL
	,[ProjectTypeId]      int  NULL 
	,[CustomerId]         int  NULL 
	,[ProjectStateId]     int  NULL 
	,[ProjectStatusId]    int  NULL 
	,[ProjectStatusDateId] int  NULL 
	,[RefEmployeeId]      int  NULL 
	,[RefRegionBranchId]  int  NULL 
	,[SegmentSolutionId]  int  NULL 
	,[ProjectJobFamilyId] int  NULL 
	,[CustomerPrevProjectId] int  NULL 
    ,[ProjectStartDateId] int  NULL 
 	,[ProjectEndDateId] int  NULL 
    ,[FirstActivityDateId] int  NULL 
    ,[LastActivityDateId] int  NULL 
 	,[ClientNbrYTD] decimal(13,5)  NULL 
    ,[MandateNbrYTD] decimal(13,5)  NULL 
    ,[SalesAmtYTD] money  NULL 
    ,[RevenueAmtYTD] money  NULL 
    ,[GrossMarginYTD] money  NULL 
    ,[BadDebtsYTD] money  NULL 
    ,[NetMarginYTD] money  NULL 
	,[UnearnedAmt] money   NULL   
	,[ProjectAmt]         money   NULL 
	,[NumberOfMandates]   decimal(13,5)  NULL 
	,[NetSalesAmt]        money  NULL 
	,[RevenueAmt]         money  NULL 
	,[ExternalConsultingFeeAmt] money  NULL 
	,[InternalConsultingFeeAmt] money   NULL 
	,[GrossMarginAmt]     money  NULL 
	,[ResourceNonRevAmt] money   NULL 
	,[ResourceRevAmt] 	money  NULL 
	,[_StartDate]         date  NOT NULL 
	,[_EndDate]           date  NOT NULL 
	,[_KeyHash]           binary(32)  NOT NULL 
	,[_ValueHash]         binary(32)  NOT NULL 
	,[_InsertDate]        Datetime2  NOT NULL 
	,[_InsertBy]          varchar(128)  NOT NULL 
	,[_UpdateDate]        Datetime2  NOT NULL 
	,[_UpdateBy]          varchar(128)  NOT NULL 
	)
BEGIN
	INSERT INTO @tamper_FactProject (
	[FactProjectKey]     
	,[ProjectId]          
	,[OpportunityId]      
	,[ProjectTypeId]    
	,[CustomerId]        
	,[ProjectStateId]     
	,[ProjectStatusId]   
	,[ProjectStatusDateId] 
	,[RefEmployeeId]      
	,[RefRegionBranchId]  
	,[SegmentSolutionId]  
	,[ProjectJobFamilyId] 
	,[CustomerPrevProjectId]
    ,[ProjectStartDateId]
  	,[ProjectEndDateId]
    ,[FirstActivityDateId] 
	,[LastActivityDateId] 
    ,[ClientNbrYTD]
    ,[MandateNbrYTD]
    ,[SalesAmtYTD]
    ,[RevenueAmtYTD]
    ,[GrossMarginYTD]
    ,[BadDebtsYTD]
    ,[NetMarginYTD]
    ,[UnearnedAmt]
	,[ProjectAmt]        
	,[NumberOfMandates]   
	,[NetSalesAmt]        
	,[RevenueAmt]         
	,[ExternalConsultingFeeAmt]
	,[InternalConsultingFeeAmt] 
	,[GrossMarginAmt]     
	,[ResourceNonRevAmt] 
	,[ResourceRevAmt] 	
	,[_StartDate]         
	,[_EndDate]           
	,[_KeyHash]           
	,[_ValueHash]        
	,[_InsertDate]       
	,[_InsertBy]          
	,[_UpdateDate]       
	,[_UpdateBy] 
	)

   SELECT 
   
		 [FactProjectKey]     
		,[ProjectId]          
		,[OpportunityId]      
		,[ProjectTypeId]    
		,[CustomerId]        
		,[ProjectStateId]     
		,[ProjectStatusId]   
		,[ProjectStatusDateId] 
		,[RefEmployeeId]      
		,[RefRegionBranchId]  
		,[SegmentSolutionId]  
		,[ProjectJobFamilyId] 
		,[CustomerPrevProjectId]
        ,[ProjectStartDateId]
		,[ProjectEndDateId]
	    ,[FirstActivityDateId] 
     	,[LastActivityDateId] 
  	    ,[ClientNbrYTD]
        ,[MandateNbrYTD]
        ,[SalesAmtYTD]
        ,[RevenueAmtYTD]
        ,[GrossMarginYTD]
        ,[BadDebtsYTD]
        ,[NetMarginYTD]
        ,[UnearnedAmt]
 	    ,[ProjectAmt]        
		,[NumberOfMandates]   
		,[NetSalesAmt]        
		,[RevenueAmt]         
		,[ExternalConsultingFeeAmt]
		,[InternalConsultingFeeAmt] 
		,[GrossMarginAmt]      
		,[ResourceNonRevAmt] 
     	,[ResourceRevAmt] 	
		,SYSDATETIME()        
		,[_EndDate]           
		,[_KeyHash]           
		,[_ValueHash]        	
		,SYSDATETIME()
		,SYSTEM_USER
		,SYSDATETIME()
		,SYSTEM_USER
	FROM(
		MERGE [AAS].FactProject AS [TARGET]
		USING (
		SELECT 		
		  tmp.FactProjectKey
		 ,ISNULL(DimPr.DimProjectId,-1)   as ProjectId
         ,ISNULL(DimOp.DimOpportunityId,-1) as OpportunityId
		 ,ISNULL(DimPrT.DimProjectTypeId,-1) as ProjectTypeId		
		 ,ISNULL(DimCus.DimCustomerId,-1) as CustomerId
		 ,ISNULL(DimPrSta.DimProjectStateId,-1) as ProjectStateId
		 ,ISNULL(DimPrStu.DimProjectStatusId,-1) as ProjectStatusId
		 ,ISNULL(tmp.ProjectStatusDateId,-1) as ProjectStatusDateId	 
		 ,ISNULL(DimEmp.DimEmployeeId,-1) as RefEmployeeId
		 ,ISNULL(DimRegBr.DimRegionBranchId,-1) as RefRegionBranchId
		 ,ISNULL(DimSegSol.DimSegmentSolutionId,-1) as SegmentSolutionId
		 ,ISNULL(DimPrJFa.DimProjectJobFamilyId,-1) as ProjectJobFamilyId
		 ,ISNULL(DimCuspr.DimProjectId,-1) as CustomerPrevProjectId
		 ,ISNULL(tmp.ProjectStartDateId,-1) as ProjectStartDateId
		 ,ISNULL(tmp.ProjectEndDateId,-1) as ProjectEndDateId
	     ,ISNULL(tmp.FirstActivityDateId,-1) as FirstActivityDateId
     	 ,ISNULL(tmp.LastActivityDateId,-1) as LastActivityDateId
		 ,tmp.ClientNbrYTD
         ,tmp.MandateNbrYTD
         ,tmp.SalesAmtYTD
         ,tmp.RevenueAmtYTD
         ,tmp.GrossMarginYTD
         ,tmp.BadDebtsYTD
         ,tmp.NetMarginYTD
      	 ,tmp.UnearnedAmt
	  	 ,tmp.ProjectAmt      
		 ,tmp.NumberOfMandates
		 ,tmp.NetSalesAmt
		 ,tmp.RevenueAmt
		 ,tmp.ExternalConsultingFeeAmt
		 ,tmp.InternalConsultingFeeAmt
		 ,tmp.GrossMarginAmt
     	 ,tmp.ResourceNonRevAmt 
    	 ,tmp.ResourceRevAmt 	
		 ,tmp._StartDate
		 ,tmp._EndDate
		 ,tmp._KeyHash
		 ,tmp._ValueHash
		 ,tmp._InsertDate
		 ,tmp._InsertBy
		 ,tmp._UpdateBy
        
		FROM [AAS].[tmp_FactProject] as tmp
        
	 	left join AAS.DimProject as DimPr ON DimPr.ProjectCode =tmp.ProjectCode
		left join AAS.DimProject as DimCuspr ON DimCuspr.ProjectCode =tmp.CustomerPrevProjectCode	
	    left join AAS.DimOpportunity  as DimOp ON DimOp.OpportunityCode = tmp.OpportunityCode
		left join AAS.DimProjectType as DimPrT ON  DimPrT.ProjectTypeCode = tmp.ProjectTypeCode
		left join AAS.DimCustomer as DimCus ON  DimCus.CustomerCode = tmp.CustomerCode
		left join AAS.DimProjectState as DimPrSta ON  DimPrSta.ProjectStateName = tmp.ProjectStateName
		left join AAS.DimProjectStatus as DimPrStu ON  DimPrStu.ProjectStatusCode = tmp.ProjectStatusCode
		left join AAS.DimEmployee as DimEmp ON cast(DimEmp.EmployeePIN as nvarchar)= tmp.RefEmployeePIN
		left join AAS.DimRegionBranch as DimRegBr ON  DimRegBr.BranchCode = tmp.BranchCode
		left join AAS.DimSegmentSolution as DimSegSol ON  DimSegSol.SolutionName = tmp.SolutionName
		left join AAS.DimProjectJobFamily as DimPrJFa ON  DimPrJFa.ProjectJobFamilyCode = tmp.ProjectJobFamilyCode
		                                                                                
		
		) AS [SOURCE]
      
	  ON ([TARGET]._KeyHash = [SOURCE]._KeyHash)
	    
		WHEN NOT MATCHED BY TARGET 
		  THEN
			INSERT(
				 
				 [FactProjectKey]     
				,[ProjectId]          
				,[OpportunityId]      
				,[ProjectTypeId]    
				,[CustomerId]        
				,[ProjectStateId]     
				,[ProjectStatusId]   
				,[ProjectStatusDateId] 
				,[RefEmployeeId]      
				,[RefRegionBranchId]  
				,[SegmentSolutionId]  
				,[ProjectJobFamilyId] 
			    ,[CustomerPrevProjectId]
                ,[ProjectStartDateId]
             	,[ProjectEndDateId]
		        ,[FirstActivityDateId] 
             	,[LastActivityDateId] 
            	,[ClientNbrYTD]
				,[MandateNbrYTD]
				,[SalesAmtYTD]
				,[RevenueAmtYTD]
				,[GrossMarginYTD]
				,[BadDebtsYTD]
			    ,[NetMarginYTD]
				,[UnearnedAmt]     
				,[ProjectAmt]        
				,[NumberOfMandates]   
				,[NetSalesAmt]        
				,[RevenueAmt]         
				,[ExternalConsultingFeeAmt]
				,[InternalConsultingFeeAmt] 
				,[GrossMarginAmt]     
				,[ResourceNonRevAmt] 
             	,[ResourceRevAmt] 				
				,[_StartDate]         
				,[_EndDate]           
				,[_KeyHash]           
				,[_ValueHash]        
				,[_InsertDate]       
				,[_InsertBy]          
				,[_UpdateDate]       
				,[_UpdateBy]          
				)
			VALUES (
                
				[FactProjectKey]     
				,[ProjectId]          
				,[OpportunityId]      
				,[ProjectTypeId]    
				,[CustomerId]        
				,[ProjectStateId]     
				,[ProjectStatusId]   
				,[ProjectStatusDateId] 
				,[RefEmployeeId]      
				,[RefRegionBranchId]  
				,[SegmentSolutionId]  
				,[ProjectJobFamilyId] 
				,[CustomerPrevProjectId]
                ,[ProjectStartDateId]
          	    ,[ProjectEndDateId]
		        ,[FirstActivityDateId] 
             	,[LastActivityDateId] 
				,[ClientNbrYTD]
				,[MandateNbrYTD]
				,[SalesAmtYTD]
				,[RevenueAmtYTD]
				,[GrossMarginYTD]
				,[BadDebtsYTD]
				,[NetMarginYTD]
             	,[UnearnedAmt]
				,[ProjectAmt]        
				,[NumberOfMandates]   
				,[NetSalesAmt]        
				,[RevenueAmt]         
				,[ExternalConsultingFeeAmt]
				,[InternalConsultingFeeAmt] 
				,[GrossMarginAmt]     
				,[ResourceNonRevAmt] 
              	,[ResourceRevAmt] 			
			    ,SYSDATETIME()        
				,[_EndDate]           
				,[_KeyHash]           
				,[_ValueHash]        	
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSDATETIME()
				,SYSTEM_USER
				)

	  WHEN MATCHED  AND [TARGET].[_ValueHash] <> [SOURCE].[_ValueHash]
	  AND ([TARGET].[_EndDate] = '9999-12-31')
	   		
		 THEN
			UPDATE
			SET  [TARGET].[_EndDate] = SYSDATETIME()
			     ,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				 ,[TARGET].[_UpdateDate] = SYSDATETIME()
				 ,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy]
			OUTPUT $ACTION as ACTION
			     , [SOURCE].*
		    ) AS MERGE_OUTPUT
		 WHERE MERGE_OUTPUT.ACTION = 'UPDATE';
			
			INSERT INTO [AAS].FactProject (
			 
	       	[FactProjectKey]     
			,[ProjectId]          
		 	,[OpportunityId]      
			,[ProjectTypeId]    
			,[CustomerId]        
			,[ProjectStateId]     
			,[ProjectStatusId]   
			,[ProjectStatusDateId] 
			,[RefEmployeeId]      
			,[RefRegionBranchId]  
			,[SegmentSolutionId]  
			,[ProjectJobFamilyId] 		
		 	,[CustomerPrevProjectId]
            ,[ProjectStartDateId]
          	,[ProjectEndDateId]
         	,[FirstActivityDateId] 
         	,[LastActivityDateId] 
			,[ClientNbrYTD]
			,[MandateNbrYTD]
			,[SalesAmtYTD]
			,[RevenueAmtYTD]
			,[GrossMarginYTD]
			,[BadDebtsYTD]
			,[NetMarginYTD]
			,[UnearnedAmt]          
			,[ProjectAmt]        
			,[NumberOfMandates]   
			,[NetSalesAmt]        
			,[RevenueAmt]         
			,[ExternalConsultingFeeAmt]
			,[InternalConsultingFeeAmt] 
			,[GrossMarginAmt]   
			,[ResourceNonRevAmt] 
         	,[ResourceRevAmt] 	
			,[_StartDate]         
			,[_EndDate]           
			,[_KeyHash]           
			,[_ValueHash]        
			,[_InsertDate]       
			,[_InsertBy]          
			,[_UpdateDate]       
			,[_UpdateBy] 
			)
	
			SELECT
		     [FactProjectKey]     
			,[ProjectId]          
			,[OpportunityId]      
			,[ProjectTypeId]    
			,[CustomerId]        
			,[ProjectStateId]     
			,[ProjectStatusId]   
			,[ProjectStatusDateId] 
			,[RefEmployeeId]      
			,[RefRegionBranchId]  
			,[SegmentSolutionId]  
			,[ProjectJobFamilyId] 
		 	,[CustomerPrevProjectId]
            ,[ProjectStartDateId]
            ,[ProjectEndDateId]
            ,[FirstActivityDateId] 
            ,[LastActivityDateId] 	
			,[ClientNbrYTD]
			,[MandateNbrYTD]
			,[SalesAmtYTD]
			,[RevenueAmtYTD]
			,[GrossMarginYTD]
			,[BadDebtsYTD]
			,[NetMarginYTD]
			,[UnearnedAmt]          	
			,[ProjectAmt]        
			,[NumberOfMandates]   
			,[NetSalesAmt]        
			,[RevenueAmt]         
			,[ExternalConsultingFeeAmt]
			,[InternalConsultingFeeAmt] 
			,[GrossMarginAmt]   
		  	,[ResourceNonRevAmt] 
         	,[ResourceRevAmt] 
			,[_StartDate]         
			,[_EndDate]           
			,[_KeyHash]           
			,[_ValueHash]        
			,[_InsertDate]       
			,[_InsertBy]          
			,[_UpdateDate]       
			,[_UpdateBy] 
      FROM @tamper_FactProject
END
GO


