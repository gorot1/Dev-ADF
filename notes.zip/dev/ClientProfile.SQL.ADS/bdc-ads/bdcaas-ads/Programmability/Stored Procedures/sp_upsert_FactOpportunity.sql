﻿CREATE PROCEDURE [AAS].[sp_upsert_FactOpportunity]
AS
DECLARE @tmp_FactOpportunity TABLE (
	[FactOpportunityId] [int] IDENTITY(1, 1)
	,[FactOpportunityKey] [varchar](100) NULL
	,[OpportunityId] [int] NULL
	,[CustomerId] [int] NULL
	,[OpportunityCreatedDateId] [int] NULL
	,[RegionBranchId] [int] NULL
	,[SolutionName] [varchar](100) NULL
	,[SegmentSolutionId] [int] NULL
	,[OpportunityRatingId] [int] NULL
	,[OpportunityStageId] [int] NULL
	,[OpportunityStageDateId] [int] NULL
	,[OpportunityStateId] [int] NULL
	,[OpportunityStateDateId] [int] NULL
	,[OpportunityStatusId] [int] NULL
	,[ClientPartnerEmployeeId] [int] NULL
	,[ReferrerEmployeeId] [int] NULL
	,[LineOfBusinessId] [int] NULL
	,[CampaignId] [int] NULL
	,[OpportunityEstimatedAmt] [money] NULL
	,[IsBusinessDevelopment] [int] NOT NULL
	,[_StartDate] [date] NOT NULL
	,[_EndDate] [date] NOT NULL
	,[_KeyHash] [binary](32) NOT NULL
	,[_ValueHash] [binary](32) NOT NULL
	,[_InsertDate] [datetime2](7) NOT NULL
	,[_InsertBy] [varchar](128) NOT NULL
	,[_UpdateDate] [datetime2](7) NOT NULL
	,[_UpdateBy] [varchar](128) NOT NULL
	,[OpportunitySourceId] [int] NULL
	,[EstimatedCloseDateId] [int] NULL
	,[ReferrerLineOfBusinessId] [int] NULL
	)

BEGIN
	INSERT INTO @tmp_FactOpportunity (
		[FactOpportunityKey]
		,[OpportunityId]
		,[RegionBranchId]
		,[OpportunityCreatedDateId]
		,[CustomerId]
		,[SegmentSolutionId]
		,[OpportunityRatingId]
		,[OpportunityStageId]
		,[OpportunityStateId]
		,[OpportunityStateDateId]
		,[OpportunityStatusId]
		,[ClientPartnerEmployeeId]
		,[ReferrerEmployeeId]
		,[LineOfBusinessId]
		,[CampaignId]
		,[OpportunityEstimatedAmt]
		,[IsBusinessDevelopment]
		,[OpportunitySourceId]
		,[OpportunityStageDateId]
		,[EstimatedCloseDateId]
		,[ReferrerLineOfBusinessId]
		,[_StartDate]
		,[_EndDate]
		,[_KeyHash]
		,[_ValueHash]
		,[_InsertDate]
		,[_InsertBy]
		,[_UpdateDate]
		,[_UpdateBy]
		)
	SELECT [FactOpportunityKey]
		,[OpportunityId]
		,[RegionBranchId]
		,[OpportunityCreatedDateId]
		,[CustomerId]
		,[SegmentSolutionId]
		,[OpportunityRatingId]
		,[OpportunityStageId]
		,[OpportunityStateId]
		,[OpportunityStateDateId]
		,[OpportunityStatusId]
		,[ClientPartnerEmployeeId]
		,[ReferrerEmployeeId]
		,[LineOfBusinessId]
		,[CampaignId]
		,[OpportunityEstimatedAmt]
		,[IsBusinessDevelopment]
		,[OpportunitySourceId]
		,[OpportunityStageDateId]
		,[EstimatedCloseDateId]
		,[ReferrerLineOfBusinessId]
		,SYSDATETIME()
		,[_EndDate]
		,[_KeyHash]
		,[_ValueHash]
		,SYSDATETIME()
		,SYSTEM_USER
		,SYSDATETIME()
		,SYSTEM_USER
	FROM (
		MERGE [AAS].[FactOpportunity] AS [TARGET]
		USING (
			SELECT [FactOpportunityKey]
				,ISNULL(do.dimOpportunityID, - 1) AS [OpportunityId]
				,ISNULL(rb.DimRegionBranchId, - 1) AS RegionBranchId
				,[OpportunityCreatedDateId]
				,ISNULL(cm.DimcustomerID, - 1) AS [CustomerId]
				,ISNULL(ss.DimSegmentSolutionId, - 1) AS [SegmentSolutionId]
				,ISNULL(pr.DimOpportunityRatingId, - 1) AS [OpportunityRatingId]
				,ISNULL(og.DimOpportunityStageId, - 1) AS [OpportunityStageId]
				,ISNULL(ot.DimOpportunityStateId, - 1) AS [OpportunityStateId]
				,op.OpportunityStateDateId AS [OpportunityStateDateId] --ISNULL(dm.DimDateID, - 1) AS [OpportunityStateDateId]
				,ISNULL(os.DimOpportunityStatusId, - 1) AS [OpportunityStatusId]
				,ISNULL(ep.DimEmployeeID, - 1) AS [ClientPartnerEmployeeId]
				,ISNULL(ep.DimEmployeeID, - 1) AS [ReferrerEmployeeId]
				,lb.DimLineOfBusinessId AS [LineOfBusinessId]
				,ISNULL(cp.DimCampaignID, - 1) AS [CampaignId]
				,ISNULL(OpportunityEstimatedAmt, - 1) AS [OpportunityEstimatedAmt]
				,ISNULL(ps.DimOpportunitySourceId, - 1) AS [OpportunitySourceId]
				--,ISNULL(da.DimDateID, - 1) AS [OpportunityStageDateId]
				,op.OpportunityStageDateId AS [OpportunityStageDateId]
				--,ISNULL(dt.DimDateID, - 1) AS EstimatedCloseDateId
				,CAST(FORMAT(EstimatedCloseDate, 'yyyyMMdd') AS INT) AS EstimatedCloseDateId
				,ISNULL(lo.DimLineOfBusinessID, - 1) AS [ReferrerLineOfBusinessId]
				,[IsBusinessDevelopment]
				,[_StartDate]
				,[_EndDate]
				,op.[_KeyHash]
				,op.[_ValueHash]
				,op.[_InsertDate]
				,op.[_InsertBy]
				,op.[_UpdateDate]
				,op.[_UpdateBy]
			FROM [AAS].[tmp_FactOpportunity] op
			LEFT JOIN (
				SELECT DimRegionBranchId
					,BranchCode
				FROM AAS.DimRegionBranch
				) rb ON right(CONCAT (
						'0000'
						,op.RegionBranchId
						), 4) = rb.BranchCode
			LEFT JOIN (
				SELECT DISTINCT DimOpportunityStatusId
					,OpportunityStatusCode
				FROM [AAS].DimOpportunityStatus
				) os ON CAST(op.OpportunityStatusID AS VARCHAR) = os.OpportunityStatusCode
			LEFT JOIN (
				SELECT DimEmployeeId
					,EmployeePin
				FROM [AAS].DimEmployee
				) ep ON op.ClientPartnerEmployeeId = ep.EmployeePin
			LEFT JOIN (
				SELECT DISTINCT DimOpportunityStageId
					,OpportunityStageCode
				FROM [AAS].DimOpportunityStage
				) og ON CAST(op.OpportunityStageID AS VARCHAR) = og.OpportunityStageCode
			LEFT JOIN (
				SELECT LineOfBusinessCode
					,DimLineOfBusinessId
				FROM [AAS].DimLineOfBusiness
				) lb ON CAST(op.LineOfBusinessCode AS VARCHAR) = lb.LineOfBusinessCode
			LEFT JOIN (
				SELECT DimSegmentSolutionId
					,SolutionName
				FROM [AAS].DimSegmentSolution
				) ss ON op.SolutionName = ss.SolutionName
			LEFT JOIN (
				SELECT DimCampaignID
					,CampaignCode
				FROM [AAS].[DimCampaign]
				) cp ON op.[CampaignCode] = cp.[CampaignCode]
			LEFT JOIN (
				SELECT dimOpportunityID
					,OpportunityCode
				FROM [AAS].[DimOpportunity]
				) do ON CAST(op.[OpportunityID] AS VARCHAR) = do.OpportunityCode
			LEFT JOIN (
				SELECT DimcustomerID
					,CustomerCode
				FROM [AAS].DimCustomer
				) cm ON CAST(op.CustomerID AS VARCHAR) = cm.CustomerCode
			LEFT JOIN (
				SELECT DimOpportunityRatingId
					,OpportunityRatingCode
				FROM [AAS].DimOpportunityRating
				) pr ON CAST(op.[OpportunityRatingId] AS VARCHAR) = pr.OpportunityRatingCode
			LEFT JOIN (
				SELECT DimOpportunityStateId
					,OpportunityStateCode
				FROM [AAS].DimOpportunityState
				) ot ON cast(op.OpportunityStateID AS VARCHAR) = ot.OpportunityStateCode
			LEFT JOIN (
				SELECT DimOpportunitySourceId
					,OpportunitySourceCode
				FROM [AAS].DimOpportunitySource
				) ps ON cast(op.[OpportunitySourceId] AS VARCHAR) = ps.OpportunitySourceCode
			LEFT JOIN (
				SELECT DimLineOfBusinessID
					,LineOfBusinessName
				FROM [AAS].[DimLineOfBusiness]
				) lo ON cast(op.[ReferrerLineOfBusinessName] AS VARCHAR) = lo.LineOfBusinessName
			--LEFT JOIN (
			--	SELECT DimDateID
			--		,DateShort
			--	FROM [AAS].[DimDate]
			--	) da ON op.OpportunityStageDateId = REPLACE(da.DateShort, '-', '')
			--LEFT JOIN (
			--	SELECT DimDateID
			--		,DateShort
			--	FROM [AAS].[DimDate]
			--	) dt ON Cast(op.EstimatedCloseDate AS DATE) = dt.DateShort
			--LEFT JOIN (
			--	SELECT DimDateID
			--		,DateShort
			--	FROM [AAS].[DimDate]
			--	) dd ON op.OpportunityStateDateId = REPLACE(dd.DateShort, '-', '')
				--LEFT JOIN (
				--SELECT DimDateID
				--	,DateShort
				--FROM [AAS].[DimDate]
				--) dm ON op.OpportunityStateDateId = REPLACE(dd.DateShort, '-', '')
			) AS [SOURCE]
			ON ([TARGET].[_KeyHash] = [SOURCE].[_KeyHash])
		WHEN NOT MATCHED BY TARGET
			THEN
				INSERT (
					[FactOpportunityKey]
					,[OpportunityId]
					,[RegionBranchId]
					,[OpportunityCreatedDateId]
					,[CustomerId]
					,[SegmentSolutionId]
					,[OpportunityRatingId]
					,[OpportunityStageId]
					,[OpportunityStateId]
					,[OpportunityStateDateId]
					,[OpportunityStatusId]
					,[ClientPartnerEmployeeId]
					,[ReferrerEmployeeId]
					,[LineOfBusinessId]
					,[CampaignId]
					,[OpportunityEstimatedAmt]
					,[IsBusinessDevelopment]
					,[OpportunitySourceId]
					,[OpportunityStageDateId]
					,[EstimatedCloseDateId]
					,[ReferrerLineOfBusinessId]
					,[_StartDate]
					,[_EndDate]
					,[_KeyHash]
					,[_ValueHash]
					,[_InsertDate]
					,[_InsertBy]
					,[_UpdateDate]
					,[_UpdateBy]
					)
				VALUES (
					[SOURCE].[FactOpportunityKey]
					,[SOURCE].[OpportunityId]
					,[SOURCE].[RegionBranchId]
					,[SOURCE].[OpportunityCreatedDateId]
					,[SOURCE].[CustomerId]
					,[SOURCE].[SegmentSolutionId]
					,[SOURCE].[OpportunityRatingId]
					,[SOURCE].[OpportunityStageId]
					,[SOURCE].[OpportunityStateId]
					,[SOURCE].[OpportunityStateDateId]
					,[SOURCE].[OpportunityStatusId]
					,[SOURCE].[ClientPartnerEmployeeId]
					,[SOURCE].[ReferrerEmployeeId]
					,[SOURCE].[LineOfBusinessId]
					,[SOURCE].[CampaignId]
					,[SOURCE].[OpportunityEstimatedAmt]
					,[SOURCE].[IsBusinessDevelopment]
					,[SOURCE].[OpportunitySourceId]
					,[SOURCE].[OpportunityStageDateId]
					,[SOURCE].[EstimatedCloseDateId]
					,[SOURCE].[ReferrerLineOfBusinessId]
					,SYSDATETIME()
					,[SOURCE].[_EndDate]
					,[SOURCE].[_KeyHash]
					,[SOURCE].[_ValueHash]
					,SYSDATETIME()
					,SYSTEM_USER
					,SYSDATETIME()
					,SYSTEM_USER
					)
		WHEN MATCHED
			AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
			AND ([TARGET].[_EndDate] = '9999-12-31')
			THEN
				UPDATE
				SET [TARGET].[_EndDate] = SYSDATETIME()
					,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
					,[TARGET].[_UpdateDate] = SYSDATETIME()
					,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy]
		OUTPUT $ACTION AS ACTION
			,[SOURCE].*
		) AS MERGE_OUTPUT
	WHERE MERGE_OUTPUT.ACTION = 'UPDATE';

	INSERT INTO [AAS].FactOpportunity (
		[FactOpportunityKey]
		,[OpportunityId]
		,[RegionBranchId]
		,[OpportunityCreatedDateId]
		,[CustomerId]
		,[SegmentSolutionId]
		,[OpportunityRatingId]
		,[OpportunityStageId]
		,[OpportunityStateId]
		,[OpportunityStateDateId]
		,[OpportunityStatusId]
		,[ClientPartnerEmployeeId]
		,[ReferrerEmployeeId]
		,[LineOfBusinessId]
		,[CampaignId]
		,[OpportunityEstimatedAmt]
		,[IsBusinessDevelopment]
		,[OpportunitySourceId]
		,[OpportunityStageDateId]
		,[EstimatedCloseDateId]
		,[ReferrerLineOfBusinessId]
		,[_StartDate]
		,[_EndDate]
		,[_KeyHash]
		,[_ValueHash]
		,[_InsertDate]
		,[_InsertBy]
		,[_UpdateDate]
		,[_UpdateBy]
		)
	SELECT [FactOpportunityKey]
		,[OpportunityId]
		,[RegionBranchId]
		,[OpportunityCreatedDateId]
		,[CustomerId]
		,[SegmentSolutionId]
		,[OpportunityRatingId]
		,[OpportunityStageId]
		,[OpportunityStateId]
		,[OpportunityStateDateId]
		,[OpportunityStatusId]
		,[ClientPartnerEmployeeId]
		,[ReferrerEmployeeId]
		,[LineOfBusinessId]
		,[CampaignId]
		,[OpportunityEstimatedAmt]
		,[IsBusinessDevelopment]
		,[OpportunitySourceId]
		,[OpportunityStageDateId]
		,[EstimatedCloseDateId]
		,[ReferrerLineOfBusinessId]
		,[_StartDate]
		,[_EndDate]
		,[_KeyHash]
		,[_ValueHash]
		,[_InsertDate]
		,[_InsertBy]
		,[_UpdateDate]
		,[_UpdateBy]
	FROM @tmp_FactOpportunity
END
GO


