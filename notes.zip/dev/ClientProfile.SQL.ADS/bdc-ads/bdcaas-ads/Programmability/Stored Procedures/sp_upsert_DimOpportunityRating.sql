﻿CREATE PROCEDURE [AAS].[sp_upsert_DimOpportunityRating]
AS
BEGIN
	MERGE [AAS].[DimOpportunityRating] AS [TARGET]
	USING (
		SELECT   
			[OpportunityRatingCode]
			,[OpportunityRatingName]
			,[OpportunityRatingSeq]
			,[IsHotRating]
			,[_CurrentFlag]
			,[_KeyHash]
			,[_ValueHash]
			,[_InsertDate]
			,[_InsertBy]
			,[_UpdateDate]
			,[_UpdateBy]
		FROM [AAS].[tmp_DimOpportunityRating]
		) AS [SOURCE]
		
		ON ([TARGET].[_KeyHash]= [SOURCE].[_KeyHash])
	
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				 
				[OpportunityRatingCode]
				,[OpportunityRatingName]
				,[OpportunityRatingSeq]
                ,[IsHotRating]
				,[_CurrentFlag]
				,[_KeyHash]
				,[_ValueHash]
				,[_InsertDate]
				,[_InsertBy]
				,[_UpdateDate]
				,[_UpdateBy]
				)
			VALUES (
				
				[SOURCE].[OpportunityRatingCode]
				,[SOURCE].[OpportunityRatingName]
				,[SOURCE].[OpportunityRatingSeq]
                ,[SOURCE].[IsHotRating] 
				,[SOURCE].[_CurrentFlag]
				,[SOURCE].[_KeyHash]
				,[SOURCE].[_ValueHash]
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSDATETIME()
				,SYSTEM_USER
				)
	WHEN MATCHED
		AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
		THEN
			UPDATE
			SET [TARGET].[OpportunityRatingCode] = [SOURCE].[OpportunityRatingCode]
				,[TARGET].[OpportunityRatingName] = [SOURCE].[OpportunityRatingName]
				,[TARGET].[OpportunityRatingSeq] = [SOURCE].[OpportunityRatingSeq]
				,[TARGET].[IsHotRating] = [SOURCE].[IsHotRating]
				,[TARGET].[_CurrentFlag] = [SOURCE].[_CurrentFlag]
				,[TARGET].[_ValueHash] = [SOURCE].[_ValueHash]
				,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				,[TARGET].[_UpdateDate] = SYSDATETIME()
				,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy];
END