﻿CREATE PROCEDURE [AAS].[sp_upsert_FactCustomerActivity]
AS
DECLARE @tamper_FactCustomerActivity TABLE ( 
    	[FactCustomerActivityId] int  IDENTITY  NOT NULL 
		,[FactCustomerActivityKey] varchar(100)  NOT NULL 
		,[CustomerId]         int  NULL 
		,[ActivityTypeId]     int  NULL 
		,[OwnerEmployeeId]    int  NULL 
		,[RegionBranchId]     int  NULL 
		,[ScheduledStartDateId] int  NULL 
		,[ScheduledEndDateId] int  NULL 
		,[ActualStartDateId]  int  NULL 
		,[ActualEndDateId]    int  NULL 
		,[_StartDate]         date  NOT NULL 
		,[_EndDate]           date  NOT NULL 
		,[_KeyHash]           binary(32)  NOT NULL 
		,[_ValueHash]         binary(32)  NOT NULL 
		,[_InsertDate]        Datetime2  NOT NULL 
		,[_InsertBy]          varchar(128)  NOT NULL 
		,[_UpdateDate]        Datetime2  NOT NULL 
		,[_UpdateBy]          varchar(128)  NOT NULL 
		)
BEGIN
   INSERT INTO @tamper_FactCustomerActivity (

         [FactCustomerActivityKey] 
		,[CustomerId]         
		,[ActivityTypeId]    
		,[OwnerEmployeeId]   
		,[RegionBranchId]    
		,[ScheduledStartDateId] 
		,[ScheduledEndDateId] 
		,[ActualStartDateId]  
		,[ActualEndDateId]    
		,[_StartDate]         
		,[_EndDate]           
		,[_KeyHash]           
		,[_ValueHash]        
		,[_InsertDate]       
		,[_InsertBy]          
		,[_UpdateDate]       
		,[_UpdateBy]          
		)
	SELECT 
	    [FactCustomerActivityKey] 
		,[CustomerId]        
		,[ActivityTypeId]     
		,[OwnerEmployeeId]    
		,[RegionBranchId]    
		,[ScheduledStartDateId] 
		,[ScheduledEndDateId] 
		,[ActualStartDateId]  
		,[ActualEndDateId]    
		,SYSDATETIME()     
		,[_EndDate]           
		,[_KeyHash]           
		,[_ValueHash]        	
		,SYSDATETIME()
		,SYSTEM_USER
		,SYSDATETIME()
		,SYSTEM_USER
     FROM (
		MERGE [AAS].[FactCustomerActivity] AS [TARGET]
		USING (	
		SELECT   		
		 tmp.FactCustomerActivityKey 
		 ,ISNULL(DimCustomer.DimCustomerId,-1)   as CustomerId 
         ,ISNULL(DimActivityType.DimActivityTypeId,-1) as ActivityTypeId  
         ,ISNULL(DimEmployee.DimEmployeeId,-1) as OwnerEmployeeId  
	     ,ISNULL(DimRegionBranch.DimRegionBranchId,-1)   as RegionBranchId    
	     ,ISNULL(tmp.ScheduledStartDateId,-1) as ScheduledStartDateId  
         ,ISNULL(tmp.ScheduledEndDateId ,-1) as ScheduledEndDateId  
	     ,ISNULL(tmp.ActualStartDateId ,-1)   as ActualStartDateId 
         ,ISNULL(tmp.ActualEndDateId,-1) as ActualEndDateId 
		 ,tmp._StartDate
		 ,tmp._EndDate
		 ,tmp._KeyHash
		 ,tmp._ValueHash
		 ,tmp._InsertDate
		 ,tmp._InsertBy
		 ,tmp._UpdateBy
        
		FROM [AAS].[tmp_FactCustomerActivity] as tmp
        
		left join AAS.DimCustomer as DimCustomer ON DimCustomer.CustomerCode = tmp.CustomerCode 
        left join AAS.DimActivityType as DimActivityType ON DimActivityType.ActivityTypeCode=tmp.ActivityTypeCode    
        left join AAS.DimEmployee  as DimEmployee ON cast(DimEmployee.EmployeePIN as varchar)= cast(tmp.OwnerEmployeePIN as varchar) 
        left join AAS.DimRegionBranch as DimRegionBranch ON DimRegionBranch.BranchCode =tmp.BranchCode 
        
		) AS [SOURCE]
		ON ([TARGET]._KeyHash = [SOURCE]._KeyHash)
	
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				 
                [FactCustomerActivityKey] 
				,[CustomerId]         
				,[ActivityTypeId]    
				,[OwnerEmployeeId]   
				,[RegionBranchId]    
				,[ScheduledStartDateId] 
				,[ScheduledEndDateId] 
				,[ActualStartDateId]  
				,[ActualEndDateId]    
				,[_StartDate]         
				,[_EndDate]           
				,[_KeyHash]           
				,[_ValueHash]        
				,[_InsertDate]       
				,[_InsertBy]          
				,[_UpdateDate]       
				,[_UpdateBy]          
				)
			VALUES (
				
				 [FactCustomerActivityKey] 
				,[CustomerId]        
				,[ActivityTypeId]     
				,[OwnerEmployeeId]    
				,[RegionBranchId]    
				,[ScheduledStartDateId] 
				,[ScheduledEndDateId] 
				,[ActualStartDateId]  
				,[ActualEndDateId]    
				,SYSDATETIME()        
				,[_EndDate]           
				,[_KeyHash]           
				,[_ValueHash]        	
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSDATETIME()
				,SYSTEM_USER
				)
	 WHEN MATCHED  AND [TARGET].[_ValueHash] <> [SOURCE].[_ValueHash]
	  AND ([TARGET].[_EndDate] = '9999-12-31')
	   		
		 THEN
			UPDATE
			SET  [TARGET].[_EndDate] = SYSDATETIME()
			     ,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				 ,[TARGET].[_UpdateDate] = SYSDATETIME()
				 ,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy]
			OUTPUT $ACTION as ACTION
			     , [SOURCE].*
		    ) AS MERGE_OUTPUT
		 WHERE MERGE_OUTPUT.ACTION = 'UPDATE';
	
	 INSERT INTO [AAS].FactCustomerActivity (
	
	            [FactCustomerActivityKey] 
				,[CustomerId]         
				,[ActivityTypeId]    
				,[OwnerEmployeeId]   
				,[RegionBranchId]    
				,[ScheduledStartDateId] 
				,[ScheduledEndDateId] 
				,[ActualStartDateId]  
				,[ActualEndDateId]    
				,[_StartDate]         
				,[_EndDate]           
				,[_KeyHash]           
				,[_ValueHash]        
				,[_InsertDate]       
				,[_InsertBy]          
				,[_UpdateDate]       
				,[_UpdateBy] 
				)
	  SELECT 
	            [FactCustomerActivityKey] 
				,[CustomerId]         
				,[ActivityTypeId]    
				,[OwnerEmployeeId]   
				,[RegionBranchId]    
				,[ScheduledStartDateId] 
				,[ScheduledEndDateId] 
				,[ActualStartDateId]  
				,[ActualEndDateId]    
				,[_StartDate]         
				,[_EndDate]           
				,[_KeyHash]           
				,[_ValueHash]        
				,[_InsertDate]       
				,[_InsertBy]          
				,[_UpdateDate]       
				,[_UpdateBy] 
			
			FROM @tamper_FactCustomerActivity
END
GO


