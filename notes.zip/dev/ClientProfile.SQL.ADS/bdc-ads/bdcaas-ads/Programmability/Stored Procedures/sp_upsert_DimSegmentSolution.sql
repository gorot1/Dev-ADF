﻿CREATE PROCEDURE [AAS].[sp_upsert_DimSegmentSolution]
AS
BEGIN
	MERGE [AAS].[DimSegmentSolution] AS [TARGET]
	USING (
		SELECT [SolutionCode]
			,[SolutionName]
			,[PracticeAbbr]
			,[PracticeName]
			,[SubSegmentAbbr]
			,[SubSegmentName]
			,[SegmentAbbr]
			,[SegmentName]
			,[_CurrentFlag]
			,[_KeyHash]
			,[_ValueHash]
			,[_InsertDate]
			,[_InsertBy]
			,[_UpdateDate]
			,[_UpdateBy]
		FROM [AAS].[tmp_DimSegmentSolution]
		) AS [SOURCE]
		ON ([TARGET].[_KeyHash] = [SOURCE].[_KeyHash])
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				[SolutionCode]
				,[SolutionName]
				,[PracticeAbbr]
				,[PracticeName]
				,[SubSegmentAbbr]
				,[SubSegmentName]
				,[SegmentAbbr]
				,[SegmentName]
				,[_CurrentFlag]
				,[_KeyHash]
				,[_ValueHash]
				,[_InsertDate]
				,[_InsertBy]
				,[_UpdateDate]
				,[_UpdateBy]
				)
			VALUES (
				[SOURCE].[SolutionCode]
				,[SOURCE].[SolutionName]
				,[SOURCE].[PracticeAbbr]
				,[SOURCE].[PracticeName]
				,[SOURCE].[SubSegmentAbbr]
				,[SOURCE].[SubSegmentName]
				,[SOURCE].[SegmentAbbr]
				,[SOURCE].[SegmentName]
				,[SOURCE].[_CurrentFlag]
				,[SOURCE].[_KeyHash]
				,[SOURCE].[_ValueHash]
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSDATETIME()
				,SYSTEM_USER
				)
	WHEN MATCHED
		AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
		THEN
			UPDATE
			SET [TARGET].[SolutionName] = [SOURCE].[SolutionName]
				,[TARGET].[PracticeAbbr] = [SOURCE].[PracticeAbbr]
				,[TARGET].[PracticeName] = [SOURCE].[PracticeName]
				,[TARGET].[SubSegmentAbbr] = [SOURCE].[SubSegmentAbbr]
				,[TARGET].[SubSegmentName] = [SOURCE].[SubSegmentName]
				,[TARGET].[SegmentAbbr] = [SOURCE].[SegmentAbbr]
				,[TARGET].[SegmentName] = [SOURCE].[SegmentName]
				,[TARGET].[_ValueHash] = [SOURCE].[_ValueHash]
				,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				,[TARGET].[_UpdateDate] = SYSDATETIME()
				,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy];
END