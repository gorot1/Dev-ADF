﻿CREATE PROCEDURE [AAS].[sp_upsert_FactSalesTeam]
AS

DECLARE @tamper_FactSalesTeam TABLE ( 
      [FactSalesTeamId]    int  IDENTITY  NOT NULL 
	,[FactSalesTeamKey]   varchar(100)  NOT NULL 
	,[RegionBranchId]     int  NULL 
	,[ClientPartnerEmployeeId] int  NULL 
	,[DirectorEmployeeId] int  NULL 
	,[VicePresidentEmployeeId] int  NULL 
	,[_StartDate]         date  NOT NULL 
	,[_EndDate]           date  NOT NULL 
	,[_KeyHash]           binary(32)  NOT NULL 
	,[_ValueHash]         binary(32)  NOT NULL 
	,[_InsertDate]        Datetime2  NOT NULL 
	,[_InsertBy]          varchar(50)  NOT NULL 
	,[_UpdateDate]        Datetime2  NOT NULL 
	,[_UpdateBy]          varchar(50)  NOT NULL 
	)
BEGIN
	INSERT INTO @tamper_FactSalesTeam (
	 [FactSalesTeamKey]   
	,[RegionBranchId]     
	,[ClientPartnerEmployeeId] 
	,[DirectorEmployeeId] 
	,[VicePresidentEmployeeId] 
	,[_StartDate]         
	,[_EndDate]           
	,[_KeyHash]           
	,[_ValueHash]        
	,[_InsertDate]       
	,[_InsertBy]          
	,[_UpdateDate]       
	,[_UpdateBy] 
	)
	
    SELECT
	 [FactSalesTeamKey]   
	,[RegionBranchId]     
	,[ClientPartnerEmployeeId] 
	,[DirectorEmployeeId] 
	,[VicePresidentEmployeeId] 
	,SYSDATETIME()         
	,[_EndDate]           
	,[_KeyHash]           
	,[_ValueHash]        	
	,SYSDATETIME()
	,SYSTEM_USER
	,SYSDATETIME()
	,SYSTEM_USER
	FROM(
		MERGE [AAS].[FactSalesTeam] AS [TARGET]
		USING (
		SELECT 		
		 tmp.FactSalesTeamKey
		 ,ISNULL(DimRegionBranch.DimRegionBranchId,-1)   as RegionBranchId
         ,ISNULL(DimEmployeeCP.DimEmployeeId,-1) as ClientPartnerEmployeeId
         ,ISNULL(DimEmployeeDI.DimEmployeeId,-1) as DirectorEmployeeId
	     ,ISNULL(DimEmployeeVP.DimEmployeeId,-1) as VicePresidentEmployeeId
	     ,tmp._StartDate
		 ,tmp._EndDate
		 ,tmp._KeyHash
		 ,tmp._ValueHash
		 ,tmp._InsertDate
		 ,tmp._InsertBy
		 ,tmp._UpdateBy
        
		FROM [AAS].[tmp_FactSalesTeam] as tmp
        
		left join AAS.DimRegionBranch as DimRegionBranch ON DimRegionBranch.BranchCode =tmp.BranchCode
		left join AAS.DimEmployee  as DimEmployeeCP ON DimEmployeeCP.EmployeePIN = tmp.ClientPartnerPIN 
		left join AAS.DimEmployee  as DimEmployeeDI ON DimEmployeeDI.EmployeePIN = tmp.DirectorPIN
		left join AAS.DimEmployee  as DimEmployeeVP ON DimEmployeeVP.EmployeePIN = tmp.VicePresidentPIN

		) AS [SOURCE]
        ON ([TARGET]._KeyHash = [SOURCE]._KeyHash)
	    
		WHEN NOT MATCHED BY TARGET 
		  THEN
			INSERT(
				 
				 [FactSalesTeamKey]   
			    ,[RegionBranchId]     
			    ,[ClientPartnerEmployeeId] 
				,[DirectorEmployeeId] 
				,[VicePresidentEmployeeId] 
				,[_StartDate]         
				,[_EndDate]           
				,[_KeyHash]           
				,[_ValueHash]        
				,[_InsertDate]       
				,[_InsertBy]          
				,[_UpdateDate]       
				,[_UpdateBy]          
				)
			VALUES (
                 [FactSalesTeamKey]   
			    ,[RegionBranchId]     
			    ,[ClientPartnerEmployeeId] 
				,[DirectorEmployeeId] 
				,[VicePresidentEmployeeId] 
				,SYSDATETIME()        
				,[_EndDate]           
				,[_KeyHash]           
				,[_ValueHash]        	
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSDATETIME()
				,SYSTEM_USER
				)

	  WHEN MATCHED  AND [TARGET].[_ValueHash] <> [SOURCE].[_ValueHash]
	  AND ([TARGET].[_EndDate] = '9999-12-31')
	   		
		 THEN
			UPDATE
			SET  [TARGET].[_EndDate] = SYSDATETIME()
			     ,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				 ,[TARGET].[_UpdateDate] = SYSDATETIME()
				 ,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy]
			OUTPUT $ACTION as ACTION
			     , [SOURCE].*
		    ) AS MERGE_OUTPUT
		 WHERE MERGE_OUTPUT.ACTION = 'UPDATE';
			
			INSERT INTO [AAS].FactSalesTeam (
			 [FactSalesTeamKey]   
			,[RegionBranchId]     
			,[ClientPartnerEmployeeId] 
			,[DirectorEmployeeId] 
			,[VicePresidentEmployeeId] 
			,[_StartDate]         
			,[_EndDate]           
			,[_KeyHash]           
			,[_ValueHash]        
			,[_InsertDate]       
			,[_InsertBy]          
			,[_UpdateDate]       
			,[_UpdateBy] 
			)
	
			SELECT
			 [FactSalesTeamKey]   
			,[RegionBranchId]     
			,[ClientPartnerEmployeeId] 
			,[DirectorEmployeeId] 
			,[VicePresidentEmployeeId] 
			,[_StartDate]         
			,[_EndDate]           
			,[_KeyHash]           
			,[_ValueHash]        
			,[_InsertDate]       
			,[_InsertBy]          
			,[_UpdateDate]       
			,[_UpdateBy] 
      FROM @tamper_FactSalesTeam
END