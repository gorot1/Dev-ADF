﻿CREATE PROCEDURE [AAS].[sp_upsert_DimProjectJobFamily]
AS
BEGIN
	MERGE [AAS].[DimProjectJobFamily] AS [TARGET]
	USING (
		SELECT [DimProjectJobFamilyId]
			,[ProjectJobFamilyCode]
			,[ProjectJobFamilyName]
			,[_CurrentFlag]
			,[_KeyHash]
			,[_ValueHash]
			,[_InsertBy]
			,[_UpdateBy]
		FROM [AAS].[tmp_DimProjectJobFamily]
		) AS [SOURCE]
		ON ([TARGET].[_KeyHash] = [SOURCE].[_KeyHash])
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				[ProjectJobFamilyCode]
				,[ProjectJobFamilyName]
				,[_CurrentFlag]
				,[_KeyHash]
				,[_ValueHash]
				,[_InsertDate]
				,[_InsertBy]
				,[_UpdateDate]
				,[_UpdateBy]
				)
			VALUES (
				[SOURCE].[ProjectJobFamilyCode]
				,[SOURCE].[ProjectJobFamilyName]
				,[SOURCE].[_CurrentFlag]
				,[SOURCE].[_KeyHash]
				,[SOURCE].[_ValueHash]
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSDATETIME()
				,SYSTEM_USER
				)
	WHEN MATCHED
		AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
		THEN
			UPDATE
			SET [TARGET].[ProjectJobFamilyName] = [SOURCE].[ProjectJobFamilyName]
				,[TARGET].[_ValueHash] = [SOURCE].[_ValueHash]
				,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				,[TARGET].[_UpdateDate] = SYSDATETIME()
				,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy];
END