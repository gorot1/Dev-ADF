﻿CREATE PROCEDURE [AAS].[sp_upsert_OpportunityStatus]
AS
BEGIN

MERGE [AAS].[DimOpportunityStatus] AS [TARGET]
USING (
	SELECT [OpportunityStatusCode]
		,[OpportunityStatusName]
		,[OpportunityStatusSeq]
		,[_CurrentFlag]
		,[_KeyHash]
		,[_ValueHash]
		,[_InsertDate]
		,[_InsertBy]
		,[_UpdateDate]
		,[_UpdateBy]
	FROM [AAS].[tmp_DimOpportunityStatus]
	) AS [SOURCE]
	ON ([TARGET].[_KeyHash] = [SOURCE].[_KeyHash])
WHEN NOT MATCHED BY TARGET
	THEN
		INSERT (
			[OpportunityStatusCode]
			,[OpportunityStatusName]
			,[OpportunityStatusSeq]
			,[_CurrentFlag]
			,[_KeyHash]
			,[_ValueHash]
			,[_InsertDate]
			,[_InsertBy]
			,[_UpdateDate]
			,[_UpdateBy]
			)
		VALUES (
			[SOURCE].[OpportunityStatusCode]
			,CAST([SOURCE].[OpportunityStatusName] AS VARCHAR (300)) 
			,[SOURCE].[OpportunityStatusSeq]
			,[SOURCE].[_CurrentFlag]
			,[SOURCE].[_KeyHash]
			,[SOURCE].[_ValueHash]
			,SYSDATETIME()
			,SYSTEM_USER
			,SYSDATETIME()
			,SYSTEM_USER
			)
WHEN MATCHED
	AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
	THEN
		UPDATE
		SET [TARGET].[OpportunityStatusCode] = [SOURCE].[OpportunityStatusCode]
			,[TARGET].[OpportunityStatusName] = [SOURCE].[OpportunityStatusName]
			,[TARGET].[OpportunityStatusSeq] = [SOURCE].[OpportunityStatusSeq]
			,[TARGET].[_CurrentFlag] = [SOURCE].[_CurrentFlag]
			,[TARGET].[_ValueHash] = [SOURCE].[_ValueHash]
			,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
			,[TARGET].[_UpdateDate] = SYSDATETIME()
			,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy];
END