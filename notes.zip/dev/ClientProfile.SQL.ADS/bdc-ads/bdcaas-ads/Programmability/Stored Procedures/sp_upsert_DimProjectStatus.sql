﻿CREATE PROCEDURE [AAS].[sp_upsert_DimProjectStatus]
AS
BEGIN
	MERGE [AAS].[DimProjectStatus] AS [TARGET]
	USING (
		SELECT [ProjectStatusCode]
			,[ProjectStatusName]
			,[_CurrentFlag]
			,[_KeyHash]
			,[_ValueHash]
			,[_InsertDate]
			,[_InsertBy]
			,[_UpdateDate]
			,[_UpdateBy]
		FROM [AAS].[tmp_DimProjectStatus]
		) AS [SOURCE]
		ON ([TARGET].[_KeyHash] = [SOURCE].[_KeyHash])
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				[ProjectStatusCode]
				,[ProjectStatusName]
				,[_CurrentFlag]
				,[_KeyHash]
				,[_ValueHash]
				,[_InsertDate]
				,[_InsertBy]
				,[_UpdateDate]
				,[_UpdateBy]
				)
			VALUES (
				[SOURCE].[ProjectStatusCode]
				,[SOURCE].[ProjectStatusName]
				,[SOURCE].[_CurrentFlag]
				,[SOURCE].[_KeyHash]
				,[SOURCE].[_ValueHash]
				,SYSDATETIME()
				,SYSTEM_USER
				,SYSDATETIME()
				,SYSTEM_USER
				)
	WHEN MATCHED
		AND ([TARGET].[_ValueHash] <> [SOURCE].[_ValueHash])
		THEN
			UPDATE
			SET [TARGET].[ProjectStatusCode] = [SOURCE].[ProjectStatusCode]
				,[TARGET].[ProjectStatusName] = [SOURCE].[ProjectStatusName]
				,[TARGET].[_ValueHash] = [SOURCE].[_ValueHash]
				,[TARGET].[_InsertBy] = [SOURCE].[_InsertBy]
				,[TARGET].[_UpdateDate] = SYSDATETIME()
				,[TARGET].[_UpdateBy] = [SOURCE].[_UpdateBy];
END
GO


