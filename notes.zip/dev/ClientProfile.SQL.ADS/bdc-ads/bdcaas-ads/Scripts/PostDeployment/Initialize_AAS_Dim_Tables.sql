﻿/* AAS.DimActivityType */
SET IDENTITY_INSERT AAS.DimActivityType ON;
MERGE AAS.DimActivityType AS TGT
USING
(
    VALUES
    (
        -1
        ,'N/A'
        ,'N/A'
        ,0
        ,0
        ,HASHBYTES('SHA2_256', 'N/A')
        ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimActivityTypeId
    ,ActivityTypeCode
    ,ActivityTypeName
    ,IsConsulting
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimActivityTypeId = SRC.DimActivityTypeId
WHEN MATCHED THEN
    UPDATE SET
        ActivityTypeCode    = SRC.ActivityTypeCode
        ,ActivityTypeName   = SRC.ActivityTypeName
        ,IsConsulting       = SRC.IsConsulting
        ,_CurrentFlag       = SRC._CurrentFlag
        ,_KeyHash           = SRC._KeyHash
        ,_ValueHash         = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimActivityTypeId
        ,ActivityTypeCode
        ,ActivityTypeName
        ,IsConsulting
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimActivityTypeId
        ,SRC.ActivityTypeCode
        ,SRC.ActivityTypeName
        ,SRC.IsConsulting
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimActivityType OFF;
GO

/* AAS.DimCustomer */
SET IDENTITY_INSERT AAS.DimCustomer ON;
MERGE AAS.DimCustomer AS TGT
USING
(
    VALUES
    (
    -1
    ,'N/A'
    ,'N/A'
    ,0
    ,HASHBYTES('SHA2_256', 'N/A')
    ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimCustomerId
    ,CustomerCode
    ,CustomerName
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimCustomerId = SRC.DimCustomerId
WHEN MATCHED THEN
    UPDATE SET
        CustomerCode    = SRC.CustomerCode
        ,CustomerName   = SRC.CustomerName
        ,_CurrentFlag   = SRC._CurrentFlag
        ,_KeyHash       = SRC._KeyHash
        ,_ValueHash     = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimCustomerId
        ,CustomerCode
        ,CustomerName
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimCustomerId
        ,SRC.CustomerCode
        ,SRC.CustomerName
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimCustomer OFF;
GO

/* AAS.DimCampaign */
SET IDENTITY_INSERT AAS.DimCampaign ON;
MERGE AAS.DimCampaign AS TGT
USING
(
    VALUES
    (
    -1
    ,'N/A'
    ,'N/A'
    ,0
    ,HASHBYTES('SHA2_256', 'N/A')
    ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimCampaignId
    ,CampaignCode
    ,CampaignName
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimCampaignId = SRC.DimCampaignId
WHEN MATCHED THEN
    UPDATE SET
        CampaignCode    = SRC.CampaignCode
        ,CampaignName   = SRC.CampaignName
        ,_CurrentFlag   = SRC._CurrentFlag
        ,_KeyHash       = SRC._KeyHash
        ,_ValueHash     = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimCampaignId
        ,CampaignCode
        ,CampaignName
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimCampaignId
        ,SRC.CampaignCode
        ,SRC.CampaignName
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimCampaign OFF;
GO

/* AAS.DimEmployee */
SET IDENTITY_INSERT AAS.DimEmployee ON;
MERGE AAS.DimEmployee AS TGT
USING
(
    VALUES
    (
        -1
        ,'N/A'
        ,NULL
        ,'N/A'
        ,'N/A'
        ,'N/A'
        ,0
        ,HASHBYTES('SHA2_256', 'N/A')
        ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimEmployeeId
    ,EmployeeCode
    ,EmployeePIN
    ,EmployeeLastName
    ,EmployeeFirstName
    ,EmployeeFullName
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimEmployeeId = SRC.DimEmployeeId
WHEN MATCHED THEN
    UPDATE SET
        EmployeeCode        = SRC.EmployeeCode
        ,EmployeePIN        = SRC.EmployeePIN
        ,EmployeeLastName   = SRC.EmployeeLastName
        ,EmployeeFirstName  = SRC.EmployeeFirstName
        ,EmployeeFullName   = SRC.EmployeeFullName
        ,_CurrentFlag       = SRC._CurrentFlag
        ,_KeyHash           = SRC._KeyHash
        ,_ValueHash         = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimEmployeeId
        ,EmployeeCode
        ,EmployeePIN
        ,EmployeeLastName
        ,EmployeeFirstName
        ,EmployeeFullName
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimEmployeeId
        ,SRC.EmployeeCode
        ,SRC.EmployeePIN
        ,SRC.EmployeeLastName
        ,SRC.EmployeeFirstName
        ,SRC.EmployeeFullName
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimEmployee OFF;
GO

/* AAS.DimLineOfBusiness */
SET IDENTITY_INSERT AAS.DimLineOfBusiness ON;
MERGE AAS.DimLineOfBusiness AS TGT
USING
(
    VALUES
    (
        -1
        ,'N/A'
        ,'N/A'
        ,0
        ,0
        ,HASHBYTES('SHA2_256', 'N/A')
        ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimLineOfBusinessId
    ,LineOfBusinessCode
    ,LineOfBusinessName
    ,IsConsulting
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimLineOfBusinessId = SRC.DimLineOfBusinessId
WHEN MATCHED THEN
    UPDATE SET
        LineOfBusinessCode      = SRC.LineOfBusinessCode
        ,LineOfBusinessName     = SRC.LineOfBusinessName
        ,IsConsulting           = SRC.IsConsulting
        ,_CurrentFlag           = SRC._CurrentFlag
        ,_KeyHash               = SRC._KeyHash
        ,_ValueHash             = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimLineOfBusinessId
        ,LineOfBusinessCode
        ,LineOfBusinessName
        ,IsConsulting
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimLineOfBusinessId
        ,SRC.LineOfBusinessCode
        ,SRC.LineOfBusinessName
        ,SRC.IsConsulting
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimLineOfBusiness OFF;
GO

/* AAS.DimOpportunity */
SET IDENTITY_INSERT AAS.DimOpportunity ON;
MERGE AAS.DimOpportunity AS TGT
USING
(
    VALUES
    (
        -1
        ,'N/A'
        ,'N/A'
        ,0
        ,HASHBYTES('SHA2_256', 'N/A')
        ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimOpportunityId
    ,OpportunityCode
    ,OpportunityName
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimOpportunityId = SRC.DimOpportunityId
WHEN MATCHED THEN
    UPDATE SET
        OpportunityCode      = SRC.OpportunityCode
        ,OpportunityName     = SRC.OpportunityName
        ,_CurrentFlag           = SRC._CurrentFlag
        ,_KeyHash               = SRC._KeyHash
        ,_ValueHash             = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimOpportunityId
        ,OpportunityCode
        ,OpportunityName
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimOpportunityId
        ,SRC.OpportunityCode
        ,SRC.OpportunityName
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimOpportunity OFF;
GO

/* AAS.DimOpportunityRating */
SET IDENTITY_INSERT AAS.DimOpportunityRating ON;
MERGE AAS.DimOpportunityRating AS TGT
USING
(
    VALUES
    (
        -1
        ,'N/A'
        ,'N/A'
        ,0
        ,0
        ,0
        ,HASHBYTES('SHA2_256', 'N/A')
        ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimOpportunityRatingId
    ,OpportunityRatingCode
    ,OpportunityRatingName
    ,OpportunityRatingSeq
    ,IsHotRating
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimOpportunityRatingId = SRC.DimOpportunityRatingId
WHEN MATCHED THEN
    UPDATE SET
        OpportunityRatingCode       = SRC.OpportunityRatingCode
        ,OpportunityRatingName      = SRC.OpportunityRatingName
        ,OpportunityRatingSeq       = SRC.OpportunityRatingSeq
        ,IsHotRating                = SRC.IsHotRating
        ,_CurrentFlag               = SRC._CurrentFlag
        ,_KeyHash                   = SRC._KeyHash
        ,_ValueHash                 = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimOpportunityRatingId
        ,OpportunityRatingCode
        ,OpportunityRatingName
        ,OpportunityRatingSeq
        ,IsHotRating
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimOpportunityRatingId
        ,SRC.OpportunityRatingCode
        ,SRC.OpportunityRatingName
        ,SRC.OpportunityRatingSeq
        ,SRC.IsHotRating
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimOpportunityRating OFF;
GO

/* AAS.DimOpportunitySource */
SET IDENTITY_INSERT AAS.DimOpportunitySource ON;
MERGE AAS.DimOpportunitySource AS TGT
USING
(
    VALUES
    (
        -1
        ,'N/A'
        ,'N/A'
        ,0
        ,HASHBYTES('SHA2_256', 'N/A')
        ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimOpportunitySourceId
    ,OpportunitySourceCode
    ,OpportunitySourceName
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimOpportunitySourceId = SRC.DimOpportunitySourceId
WHEN MATCHED THEN
    UPDATE SET
        OpportunitySourceCode       = SRC.OpportunitySourceCode
        ,OpportunitySourceName      = SRC.OpportunitySourceName
        ,_CurrentFlag               = SRC._CurrentFlag
        ,_KeyHash                   = SRC._KeyHash
        ,_ValueHash                 = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimOpportunitySourceId
        ,OpportunitySourceCode
        ,OpportunitySourceName
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimOpportunitySourceId
        ,SRC.OpportunitySourceCode
        ,SRC.OpportunitySourceName
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimOpportunitySource OFF;
GO

/* AAS.DimOpportunityStage */
SET IDENTITY_INSERT AAS.DimOpportunityStage ON;
MERGE AAS.DimOpportunityStage AS TGT
USING
(
    VALUES
    (
        -1
        ,'N/A'
        ,'N/A'
        ,0
        ,0
        ,0
        ,0
        ,0
        ,HASHBYTES('SHA2_256', 'N/A')
        ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimOpportunityStageId
    ,OpportunityStageCode
    ,OpportunityStageName
    ,OpportunityStageSeq
    ,IsQualifiedStage
    ,IsProposedStage
    ,IsSalesStage
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimOpportunityStageId = SRC.DimOpportunityStageId
WHEN MATCHED THEN
    UPDATE SET
        OpportunityStageCode    = SRC.OpportunityStageCode
        ,OpportunityStageName   = SRC.OpportunityStageName
        ,OpportunityStageSeq    = SRC.OpportunityStageSeq
        ,IsQualifiedStage       = SRC.IsQualifiedStage
        ,IsProposedStage        = SRC.IsProposedStage
        ,IsSalesStage           = SRC.IsSalesStage
        ,_CurrentFlag           = SRC._CurrentFlag
        ,_KeyHash               = SRC._KeyHash
        ,_ValueHash             = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimOpportunityStageId
        ,OpportunityStageCode
        ,OpportunityStageName
        ,OpportunityStageSeq
        ,IsQualifiedStage
        ,IsProposedStage
        ,IsSalesStage
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimOpportunityStageId
        ,SRC.OpportunityStageCode
        ,SRC.OpportunityStageName
        ,SRC.OpportunityStageSeq
        ,SRC.IsQualifiedStage
        ,SRC.IsProposedStage
        ,SRC.IsSalesStage
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimOpportunityStage OFF;
GO

/* AAS.DimOpportunityState */
SET IDENTITY_INSERT AAS.DimOpportunityState ON;
MERGE AAS.DimOpportunityState AS TGT
USING
(
    VALUES
    (
        -1
        ,'N/A'
        ,'N/A'
        ,0
        ,0
        ,0
        ,0
        ,0
        ,HASHBYTES('SHA2_256', 'N/A')
        ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimOpportunityStateId
    ,OpportunityStateCode
    ,OpportunityStateName
    ,OpportunityStateSeq
    ,IsOpenState
    ,IsWonState
    ,IsLostState
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimOpportunityStateId = SRC.DimOpportunityStateId
WHEN MATCHED THEN
    UPDATE SET
        OpportunityStateCode    = SRC.OpportunityStateCode
        ,OpportunityStateName   = SRC.OpportunityStateName
        ,OpportunityStateSeq    = SRC.OpportunityStateSeq
        ,IsOpenState            = SRC.IsOpenState
        ,IsWonState             = SRC.IsWonState
        ,IsLostState            = SRC.IsLostState
        ,_CurrentFlag           = SRC._CurrentFlag
        ,_KeyHash               = SRC._KeyHash
        ,_ValueHash             = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimOpportunityStateId
        ,OpportunityStateCode
        ,OpportunityStateName
        ,OpportunityStateSeq
        ,IsOpenState
        ,IsWonState
        ,IsLostState
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimOpportunityStateId
        ,SRC.OpportunityStateCode
        ,SRC.OpportunityStateName
        ,SRC.OpportunityStateSeq
        ,SRC.IsOpenState
        ,SRC.IsWonState
        ,SRC.IsLostState
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimOpportunityState OFF;
GO

/* AAS.DimOpportunityStatus */
SET IDENTITY_INSERT AAS.DimOpportunityStatus ON;
MERGE AAS.DimOpportunityStatus AS TGT
USING
(
    VALUES
    (
        -1
        ,'N/A'
        ,'N/A'
        ,0
        ,0
        ,HASHBYTES('SHA2_256', 'N/A')
        ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimOpportunityStatusId
    ,OpportunityStatusCode
    ,OpportunityStatusName
    ,OpportunityStatusSeq
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimOpportunityStatusId = SRC.DimOpportunityStatusId
WHEN MATCHED THEN
    UPDATE SET
        OpportunityStatusCode   = SRC.OpportunityStatusCode
        ,OpportunityStatusName  = SRC.OpportunityStatusName
        ,OpportunityStatusSeq   = SRC.OpportunityStatusSeq
        ,_CurrentFlag           = SRC._CurrentFlag
        ,_KeyHash               = SRC._KeyHash
        ,_ValueHash             = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimOpportunityStatusId
        ,OpportunityStatusCode
        ,OpportunityStatusName
        ,OpportunityStatusSeq
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimOpportunityStatusId
        ,SRC.OpportunityStatusCode
        ,SRC.OpportunityStatusName
        ,SRC.OpportunityStatusSeq
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimOpportunityStatus OFF;
GO

/* AAS.DimRegionBranch */
SET IDENTITY_INSERT AAS.DimRegionBranch ON;
MERGE AAS.DimRegionBranch AS TGT
USING
(
    VALUES
    (
        -1
        ,'N/A'
        ,'N/A'
        ,'N/A'
        ,'N/A'
        ,'N/A'
        ,'N/A'
        ,'N/A'
        ,'N/A'
        ,'N/A'
        ,'N/A'
        ,0
        ,HASHBYTES('SHA2_256', 'N/A')
        ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimRegionBranchId
    ,BranchCode
    ,BranchName
    ,AreaCode
    ,AreaName
    ,SubRegionName
    ,RegionCode
    ,RegionAbbr
    ,RegionName
    ,VPRegionAbbr
    ,VPRegionName
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimRegionBranchId = SRC.DimRegionBranchId
WHEN MATCHED THEN
    UPDATE SET
        BranchCode          = SRC.BranchCode
        ,BranchName         = SRC.BranchName
        ,AreaCode           = SRC.AreaCode
        ,AreaName           = SRC.AreaName
        ,SubRegionName      = SRC.SubRegionName
        ,RegionCode         = SRC.RegionCode
        ,RegionAbbr         = SRC.RegionAbbr
        ,RegionName         = SRC.RegionName
        ,VPRegionAbbr       = SRC.VPRegionAbbr
        ,VPRegionName       = SRC.VPRegionName
        ,_CurrentFlag       = SRC._CurrentFlag
        ,_KeyHash           = SRC._KeyHash
        ,_ValueHash         = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimRegionBranchId
        ,BranchCode
        ,BranchName
        ,AreaCode
        ,AreaName
        ,SubRegionName
        ,RegionCode
        ,RegionAbbr
        ,RegionName
        ,VPRegionAbbr
        ,VPRegionName
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimRegionBranchId
        ,SRC.BranchCode
        ,SRC.BranchName
        ,SRC.AreaCode
        ,SRC.AreaName
        ,SRC.SubRegionName
        ,SRC.RegionCode
        ,SRC.RegionAbbr
        ,SRC.RegionName
        ,SRC.VPRegionAbbr
        ,SRC.VPRegionName
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimRegionBranch OFF;
GO

/* AAS.DimSegmentSolution */
SET IDENTITY_INSERT AAS.DimSegmentSolution ON;
MERGE AAS.DimSegmentSolution AS TGT
USING
(
    VALUES
    (
        -1
        ,'N/A'
        ,'N/A'
        ,'N/A'
        ,'N/A'
        ,'N/A'
        ,'N/A'
        ,'N/A'
        ,'N/A'
        ,0
        ,HASHBYTES('SHA2_256', 'N/A')
        ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimSegmentSolutionId
    ,SolutionCode
    ,SolutionName
    ,PracticeAbbr
    ,PracticeName
    ,SubSegmentAbbr
    ,SubSegmentName
    ,SegmentAbbr
    ,SegmentName
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimSegmentSolutionId = SRC.DimSegmentSolutionId
WHEN MATCHED THEN
    UPDATE SET
        SolutionCode        = SRC.SolutionCode
        ,SolutionName       = SRC.SolutionName
        ,PracticeAbbr       = SRC.PracticeAbbr
        ,PracticeName       = SRC.PracticeName
        ,SubSegmentAbbr     = SRC.SubSegmentAbbr
        ,SubSegmentName     = SRC.SubSegmentName
        ,SegmentAbbr        = SRC.SegmentAbbr
        ,SegmentName        = SRC.SegmentName
        ,_CurrentFlag       = SRC._CurrentFlag
        ,_KeyHash           = SRC._KeyHash
        ,_ValueHash         = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimSegmentSolutionId
        ,SolutionCode
        ,SolutionName
        ,PracticeAbbr
        ,PracticeName
        ,SubSegmentAbbr
        ,SubSegmentName
        ,SegmentAbbr
        ,SegmentName
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimSegmentSolutionId
        ,SRC.SolutionCode
        ,SRC.SolutionName
        ,SRC.PracticeAbbr
        ,SRC.PracticeName
        ,SRC.SubSegmentAbbr
        ,SRC.SubSegmentName
        ,SRC.SegmentAbbr
        ,SRC.SegmentName
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimSegmentSolution OFF;
GO

/* AAS.DimProject */
SET IDENTITY_INSERT AAS.DimProject ON;
MERGE AAS.DimProject AS TGT
USING
(
    VALUES
    (
        -1
        ,'N/A'
        ,'N/A'
        ,0
        ,HASHBYTES('SHA2_256', 'N/A')
        ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimProjectId
    ,ProjectCode
    ,ProjectName
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimProjectId = SRC.DimProjectId
WHEN MATCHED THEN
    UPDATE SET
        ProjectCode         = SRC.ProjectCode
        ,ProjectName        = SRC.ProjectName
        ,_CurrentFlag       = SRC._CurrentFlag
        ,_KeyHash           = SRC._KeyHash
        ,_ValueHash         = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimProjectId
        ,ProjectCode
        ,ProjectName
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimProjectId
        ,SRC.ProjectCode
        ,SRC.ProjectName
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimProject OFF;
GO

/* AAS.DimProjectJobFamily */
SET IDENTITY_INSERT AAS.DimProjectJobFamily ON;
MERGE AAS.DimProjectJobFamily AS TGT
USING
(
    VALUES
    (
        -1
        ,'N/A'
        ,'N/A'
        ,0
        ,HASHBYTES('SHA2_256', 'N/A')
        ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimProjectJobFamilyId
    ,ProjectJobFamilyCode
    ,ProjectJobFamilyName
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimProjectJobFamilyId = SRC.DimProjectJobFamilyId
WHEN MATCHED THEN
    UPDATE SET
        ProjectJobFamilyCode    = SRC.ProjectJobFamilyCode
        ,ProjectJobFamilyName   = SRC.ProjectJobFamilyName
        ,_CurrentFlag           = SRC._CurrentFlag
        ,_KeyHash               = SRC._KeyHash
        ,_ValueHash             = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimProjectJobFamilyId
        ,ProjectJobFamilyCode
        ,ProjectJobFamilyName
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimProjectJobFamilyId
        ,SRC.ProjectJobFamilyCode
        ,SRC.ProjectJobFamilyName
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimProjectJobFamily OFF;
GO

/* AAS.DimProjectState */
SET IDENTITY_INSERT AAS.DimProjectState ON;
MERGE AAS.DimProjectState AS TGT
USING
(
    VALUES
    (
        -1
        ,'N/A'
        ,'N/A'
        ,0
        ,HASHBYTES('SHA2_256', 'N/A')
        ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimProjectStateId
    ,ProjectStateCode
    ,ProjectStateName
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimProjectStateId = SRC.DimProjectStateId
WHEN MATCHED THEN
    UPDATE SET
        ProjectStateCode    = SRC.ProjectStateCode
        ,ProjectStateName   = SRC.ProjectStateName
        ,_CurrentFlag       = SRC._CurrentFlag
        ,_KeyHash           = SRC._KeyHash
        ,_ValueHash         = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimProjectStateId
        ,ProjectStateCode
        ,ProjectStateName
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimProjectStateId
        ,SRC.ProjectStateCode
        ,SRC.ProjectStateName
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimProjectState OFF;
GO

/* AAS.DimProjectStatus */
SET IDENTITY_INSERT AAS.DimProjectStatus ON;
MERGE AAS.DimProjectStatus AS TGT
USING
(
    VALUES
    (
        -1
        ,'N/A'
        ,'N/A'
        ,0
        ,HASHBYTES('SHA2_256', 'N/A')
        ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimProjectStatusId
    ,ProjectStatusCode
    ,ProjectStatusName
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimProjectStatusId = SRC.DimProjectStatusId
WHEN MATCHED THEN
    UPDATE SET
        ProjectStatusCode   = SRC.ProjectStatusCode
        ,ProjectStatusName  = SRC.ProjectStatusName
        ,_CurrentFlag       = SRC._CurrentFlag
        ,_KeyHash           = SRC._KeyHash
        ,_ValueHash         = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimProjectStatusId
        ,ProjectStatusCode
        ,ProjectStatusName
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimProjectStatusId
        ,SRC.ProjectStatusCode
        ,SRC.ProjectStatusName
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimProjectStatus OFF;
GO

/* AAS.DimProjectType */
SET IDENTITY_INSERT AAS.DimProjectType ON;
MERGE AAS.DimProjectType AS TGT
USING
(
    VALUES
    (
        -1
        ,'N/A'
        ,'N/A'
        ,0
        ,HASHBYTES('SHA2_256', 'N/A')
        ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimProjectTypeId
    ,ProjectTypeCode
    ,ProjectTypeName
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimProjectTypeId = SRC.DimProjectTypeId
WHEN MATCHED THEN
    UPDATE SET
        ProjectTypeCode     = SRC.ProjectTypeCode
        ,ProjectTypeName    = SRC.ProjectTypeName
        ,_CurrentFlag       = SRC._CurrentFlag
        ,_KeyHash           = SRC._KeyHash
        ,_ValueHash         = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimProjectTypeId
        ,ProjectTypeCode
        ,ProjectTypeName
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimProjectTypeId
        ,SRC.ProjectTypeCode
        ,SRC.ProjectTypeName
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimProjectType OFF;
GO

/* AAS.DimProjectWorkflow */
SET IDENTITY_INSERT AAS.DimProjectWorkflow ON;
MERGE AAS.DimProjectWorkflow AS TGT
USING
(
    VALUES
    (
        -1
        ,'N/A'
        ,'N/A'
        ,'N/A'
        ,'N/A'
        ,0
        ,HASHBYTES('SHA2_256', 'N/A')
        ,HASHBYTES('SHA2_256', 'N/A')
    )
)
AS SRC
(
    DimProjectWorkflowId
    ,ProjectWorkflowCode
    ,ProjectWorkflowSource
    ,ProjectWorkflowDestination
    ,ProjectWorkflowAction
    ,_CurrentFlag
    ,_KeyHash
    ,_ValueHash
)
ON TGT.DimProjectWorkflowId = SRC.DimProjectWorkflowId
WHEN MATCHED THEN
    UPDATE SET
        ProjectWorkflowCode         = SRC.ProjectWorkflowCode
        ,ProjectWorkflowSource      = SRC.ProjectWorkflowSource
        ,ProjectWorkflowDestination = SRC.ProjectWorkflowDestination
        ,ProjectWorkflowAction      = SRC.ProjectWorkflowAction
        ,_CurrentFlag               = SRC._CurrentFlag
        ,_KeyHash                   = SRC._KeyHash
        ,_ValueHash                 = SRC._ValueHash
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        DimProjectWorkflowId
        ,ProjectWorkflowCode
        ,ProjectWorkflowSource
        ,ProjectWorkflowDestination
        ,ProjectWorkflowAction
        ,_CurrentFlag
        ,_KeyHash
        ,_ValueHash
    )
    VALUES
    (
        SRC.DimProjectWorkflowId
        ,SRC.ProjectWorkflowCode
        ,SRC.ProjectWorkflowSource
        ,SRC.ProjectWorkflowDestination
        ,SRC.ProjectWorkflowAction
        ,SRC._CurrentFlag
        ,SRC._KeyHash
        ,SRC._ValueHash
    );
SET IDENTITY_INSERT AAS.DimProjectWorkflow OFF;
GO
