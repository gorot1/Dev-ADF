﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-05
-- Description: Table script for AdsWatermarks
-- =============================================
CREATE TABLE [dbo].[AdsWatermarks](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[TableName] [varchar](255) NOT NULL,
	[ModifiedOn] [datetime2](7) NOT NULL
) ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX [IX_AdsWatermarks_TableName] ON [dbo].[AdsWatermarks]
(
	[TableName] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO
