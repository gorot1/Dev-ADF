﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-06
-- Description: Table script for DimKeyDimOperatingUnit
-- =============================================
CREATE TABLE [dbo].[DimKeyDimOperatingUnit] (
	[DimKey] [int] IDENTITY(1,1) NOT NULL
	,[Buid] [varchar](40) NOT NULL
	,[AdminDeptId] [varchar](4) NOT NULL
	,[InsertedDate] datetime NULL
	,[ModifiedDate] datetime NULL
)
GO

CREATE UNIQUE NONCLUSTERED INDEX [IX_DimKeyDimOperatingUnit_Buid] ON [dbo].[DimKeyDimOperatingUnit]
(
	[Buid] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO
