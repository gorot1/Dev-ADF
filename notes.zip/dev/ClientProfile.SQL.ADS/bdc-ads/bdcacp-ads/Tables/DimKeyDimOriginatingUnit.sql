﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-06
-- Description: Table script for DimKeyDimOriginatingUnit
-- =============================================
CREATE TABLE [dbo].[DimKeyDimOriginatingUnit] (
	[DimKey] [int] IDENTITY(1,1) NOT NULL
	,[Buid] [varchar](40) NOT NULL
	,[OriginatingUnitNumberCREM] [varchar](4) NOT NULL
	,[InsertedDate] datetime NULL
	,[ModifiedDate] datetime NULL
)
GO

CREATE UNIQUE NONCLUSTERED INDEX [IX_DimKeyDimOriginatingUnit_Buid] ON [dbo].[DimKeyDimOriginatingUnit]
(
	[Buid] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO
