

CREATE TABLE [dbo].[DimCustomer]
( 
	[DimCustomerKey]     [Integer]  NOT NULL  IDENTITY ,
	[DimCustomerDurableKey] [Integer]  NOT NULL ,
	[StartDateDimCustomerKey] [Integer] ,
	[EndDateDimCustomerKey] [Integer] ,
	[DimCustomerCurrentFlag] bit  NULL ,
	[CustomerNumber]     [Integer] ,
	[ProspectIndicator]  varchar(20)  NULL ,
	[CustomerBusinessName] varchar(100)  NULL ,
	[CustomerCompleteName] varchar(100)  NULL ,
	[CustomerTradeName]  varchar(100)  NULL ,
	[CustomerBillingName] varchar(100)  NULL ,
	[CustomerBillingName1] varchar(100)  NULL ,
	[CustomerBillingName2] varchar(100)  NULL ,
	[CustomerAddress1]   varchar(100)  NULL ,
	[CustomerAddress2]   varchar(100)  NULL ,
	[CustomerCity]       varchar(50)  NULL ,
	[CustomerProvinceCode] char(2)  NULL ,
	[CustomerProvinceNameEN] varchar(50)  NULL ,
	[CustomerProvinceNameFR] varchar(50)  NULL ,
	[PostalCode]         varchar(10)  NULL ,
	[CustomerCountryName] varchar(200)  NULL ,
	[CustomerCompleteAddress] varchar(200)  NULL ,
	[FSACode]            varchar(3)  NULL ,
	[FSADescrEN]         varchar(50)  NULL ,
	[FSADescrFR]         varchar(50)  NULL ,
	[TerritoryCode]      varchar(20)  NULL ,
	[TerritoryDescrEN]   varchar(50)  NULL ,
	[TerritoryDescrFR]   varchar(50)  NULL ,
	[CustomerWebSite]    varchar(200)  NULL ,
	[CustomerAnnualSales] integer  NULL ,
	[BusinessYearEstablished] varchar(20)  NULL ,
	[CustomerYearsinBusinessCount] [Integer] ,
	[CustomerStatusCode] [Integer] ,
	[CustomerStatusDescrEN] varchar(50)  NULL ,
	[CustomerStatusDescrFR] varchar(50)  NULL ,
	[CustomerStatusEffectiveDate] datetime  NULL ,
	[CustomerStateCode]  [Integer] ,
	[CustomerStateDescrEN] varchar(50)  NULL ,
	[CustomerStateDescrFR] varchar(50)  NULL ,
	[CustomerStatusHistoryCode] [Integer] ,
	[CustomerStatusHistoryDescrEN] varchar(50)  NULL ,
	[CustomerStatusHistoryDescrFR] varchar(50)  NULL ,
	[NumberofEmployees]  integer  NULL ,
	[EmployeeSizeGroupCode] [Integer] ,
	[EmployeeSizeGroupDescrEN] varchar(50)  NULL ,
	[EmployeeSizeGroupDescrFR] varchar(50)  NULL ,
	[EnvironmentalRiskMonitoringCode] varchar(50)  NULL ,
	[EnvironmentalRiskMonitoringDescrEN] varchar(50)  NULL ,
	[EnvironmentalRiskMonitoringDescrFR] varchar(50)  NULL ,
	[ExportMarketPrimaryCode] varchar(20)  NULL ,
	[ExportMarketPrimaryDescrEN] varchar(50)  NULL ,
	[ExportMarketPrimaryDescrFR] varchar(50)  NULL ,
	[ExportMarketSecondaryCode] varchar(20)  NULL ,
	[ExportMarketSecondaryDescrEN] varchar(50)  NULL ,
	[ExportMarketSecondaryDescrFR] varchar(50)  NULL ,
	[ExportFlagCustomer] bit  NULL ,
	[ExportSalesPercentage] integer  NULL ,
	[ExporterSalesPercentage] integer  NULL ,
	[ExportToTouristsPct] integer  NULL ,
	[AgeGroupCode]       varchar(20)  NULL ,
	[AgeGroupDescrEN]    varchar(50)  NULL ,
	[AgeGroupDescrFR]    varchar(50)  NULL ,
	[AgeGroupingCode]    varchar(20)  NULL ,
	[AgeGroupingDescrEN] varchar(50)  NULL ,
	[AgeGroupingDescrFR] varchar(50)  NULL ,
	[NativeStatusCode]   varchar(20)  NULL ,
	[NativeStatusDescrEN] varchar(50)  NULL ,
	[NativeStatusDescrFR] varchar(50)  NULL ,
	[NativeStatusGroupCode] varchar(50)  NULL ,
	[NativeStatusGroupDescrEN] varchar(50)  NULL ,
	[NativeStatusGroupDescrFR] varchar(50)  NULL ,
	[OwnershipGenderCode] varchar(20)  NULL ,
	[OwnershipGenderDescrEN] varchar(50)  NULL ,
	[OwnershipGenderDescrFR] varchar(50)  NULL ,
	[OwnershipGenderCompositionGroupCode] varchar(20)  NULL ,
	[OwnershipGenderCompositionGroupDescrEN] varchar(50)  NULL ,
	[OwnershipGenderCompositionGroupDescrFR] varchar(50)  NULL ,
	[StageOfDevelopmentCode] varchar(20)  NULL ,
	[StageOfDevelopmentDescrEN] varchar(50)  NULL ,
	[StageOfDevelopmentDescrFR] varchar(50)  NULL ,
	[CustomerSegmentCode] varchar(20)  NULL ,
	[CustomerSegmentDescrEN] varchar(50)  NULL ,
	[CustomerSegmentDescrFR] varchar(50)  NULL ,
	[OwnsFlag]           bit  NULL ,
	[SolicitationFlag]   bit  NULL ,
	[RentsFlag]          bit  NULL ,
	[ManufacturesFlag]   bit  NULL ,
	[ExportsFlag]        bit  NULL ,
	[ImportsFlag]        bit  NULL ,
	[RDExpensesPct]      decimal(18,2)  NULL ,
	[UrbanRuralAreaCode] varchar(20)  NULL ,
	[UrbanRuralAreaDescrFR] varchar(50)  NULL ,
	[UrbanRuralAreaDescrEN] varchar(50)  NULL ,
	[BeaconScoreAvg]     [Integer] ,
	[OwnershipTypeCode]  [Integer] ,
	[OwnershipTypeDescrEN] varchar(50)  NULL ,
	[OwnershipTypeDescrFR] varchar(50)  NULL ,
	[LegalStatusCode]    [Integer] ,
	[LegalStatusDescrEN] varchar(50)  NULL ,
	[LegalStatusDescrFR] varchar(50)  NULL ,
	[ConditionInBreachFlag] bit  NULL ,
	[ConditionToMonitorFlag] bit  NULL ,
	[ConditionWithFinancialStatementNotReceivedFlag] bit  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(20)  NULL ,
	[RowSignature]       varchar(40)  NULL ,
	[RowUid]             varchar(40)  NULL 
)
go

ALTER TABLE [dbo].[DimCustomer]
	ADD CONSTRAINT [XPKDimCustomer] PRIMARY KEY  CLUSTERED ([DimCustomerKey] ASC,[DimCustomerDurableKey] ASC)
go

ALTER TABLE [dbo].[DimCustomer]
	ADD CONSTRAINT [XAK1DimCustomer] UNIQUE ([CustomerNumber]  ASC,[StartDateDimCustomerKey]  ASC)
go

--CREATE TABLE [dbo].[DimDate]
--( 
--	[Date]               date  NOT NULL ,
--	[DayOfWeekNameEN]    varchar(20)  NULL ,
--	[DayOfWeekNameFR]    varchar(20)  NULL ,
--	[DayOfMonth]         [Integer] ,
--	[DayOfYear]          [Integer] ,
--	[WeekdayWeekendEN]   varchar(20)  NULL ,
--	[WeekdayWeekendFR]   varchar(20)  NULL ,
--	[WeekofYear]         [Integer] ,
--	[MonthNameEN]        varchar(20)  NULL ,
--	[MonthNameFR]        varchar(20)  NULL ,
--	[MonthOfYear]        [Integer] ,
--	[LastDayOfMonthFlag] bit  NULL ,
--	[CalendarQuarter]    [Integer] ,
--	[CalendarYear]       [Integer] ,
--	[CalendarYearMonth]  [Integer] ,
--	[CalendarYearQuarter] [Integer] ,
--	[FiscalMonthOfYear]  [Integer] ,
--	[FiscalQuarter]      [Integer] ,
--	[FiscalYear]         [Integer] ,
--	[FiscalYearMonth]    [Integer] ,
--	[FiscalYearQuarter]  [Integer] ,
--	[InsertedDate]       datetime  NULL ,
--	[ModifiedDate]       datetime  NULL ,
--	[DimDateKey]         [Integer]  NOT NULL ,
--	[DayOfWeek]          [Integer] 
--)
--go

--ALTER TABLE [dbo].[DimDate]
--	ADD CONSTRAINT [XPKDimDate] PRIMARY KEY  CLUSTERED ([DimDateKey] ASC)
--go

--ALTER TABLE [dbo].[DimDate]
--	ADD CONSTRAINT [XAK1DimDate] UNIQUE ([Date]  ASC)
--go

CREATE TABLE [dbo].[DimIndustry]
( 
	[DimIndustryKey]     [Integer]  NOT NULL ,
	[IndustryCode]       varchar(10)  NOT NULL ,
	[IndustryType]       varchar(10)  NOT NULL ,
	[ExporterIndicator]  bit  NOT NULL ,
	[IndustryDescrEN]    varchar(100)  NULL ,
	[IndustryDescrFR]    varchar(100)  NULL ,
	[IndustryBDCGroupCode] varchar(10)  NOT NULL ,
	[IndustryBDCGroupDescrEN] varchar(100)  NULL ,
	[IndustryBDCGroupDescrFR] varchar(100)  NULL ,
	[IndustryBDCGroupDescrENShort] varchar(100)  NULL ,
	[IndustryBDCGroupDescrFRShort] varchar(100)  NULL ,
	[IndustryMarketingGroupCode] varchar(10)  NOT NULL ,
	[IndustryMarketingGroupDescrEN] varchar(100)  NULL ,
	[IndustryMarketingGroupDescrFR] varchar(100)  NULL ,
	[IndustryAnalytixGroupCode] varchar(10)  NULL ,
	[IndustryAnalytixGroupDescrEN] varchar(100)  NULL ,
	[IndustryAnalytixGroupDescrFR] varchar(100)  NULL ,
	[IndustryFinanceGroupCode] varchar(10)  NOT NULL ,
	[IndustryFinanceGroupDescrEN] varchar(100)  NULL ,
	[IndustryFinanceGroupDescrFR] varchar(100)  NULL ,
	[NAICSL5Code]        varchar(10)  NULL ,
	[NAICSL5DescrEN]     varchar(200)  NULL ,
	[NAICSL5DescrFR]     varchar(200)  NULL ,
	[NAICSL4Code]        varchar(10)  NULL ,
	[NAICSL4DescrEN]     varchar(200)  NULL ,
	[NAICSL4DescrFR]     varchar(200)  NULL ,
	[NAICSL3Code]        varchar(10)  NULL ,
	[NAICSL3DescrEN]     varchar(200)  NULL ,
	[NAICSL3DescrFR]     varchar(200)  NULL ,
	[NAICSL2Code]        varchar(10)  NULL ,
	[NAICSL2DescrEN]     varchar(200)  NULL ,
	[NAICSL2DescrFR]     varchar(200)  NULL ,
	[NAICSUSFlag]        bit  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL
)
go

ALTER TABLE [dbo].[DimIndustry]
	ADD CONSTRAINT [XPKDimIndustry] PRIMARY KEY  CLUSTERED ([DimIndustryKey] ASC)
go

ALTER TABLE [dbo].[DimIndustry]
	ADD CONSTRAINT [XAK1DimIndustry] UNIQUE ([IndustryCode]  ASC)
go

CREATE TABLE [dbo].[DimLineOfBusiness]
( 
	[DimLineOfBusinessKey] integer  NOT NULL ,
	[LineOfBusinessCode] integer  NULL ,
	[LineOfBusinessDescrEN] varchar(50)  NULL ,
	[LineOfBusinessDescrFR] varchar(50)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL
)
go

ALTER TABLE [dbo].[DimLineOfBusiness]
	ADD CONSTRAINT [XPKDimLineOfBusiness] PRIMARY KEY  CLUSTERED ([DimLineOfBusinessKey] ASC)
go

ALTER TABLE [dbo].[DimLineOfBusiness]
	ADD CONSTRAINT [XAK1DimLineOfBusiness] UNIQUE ([LineOfBusinessCode]  ASC)
go

CREATE TABLE [dbo].[DimLoan]
( 
	[DimLoanKey]         [Integer]  NOT NULL  IDENTITY ,
	[DimLoanDurableKey]  [Integer]  NOT NULL ,
	[StartDateDimLoanKey] [Integer]  NOT NULL ,
	[EndDateDimLoanKey]  [Integer] ,
	[DimLoanCurrentFlag] bit  NULL ,
	[LoanAuthorizationFlag] bit  NULL ,
	[AccountNumber]      char(9)  NULL ,
	[AbacusNumber]       char(6)  NULL ,
	[MultipleNumber]     char(2)  NULL ,
	[ActiveLoanFlag]     bit  NULL ,
	[ActiveLoanDisbursedFlag] bit  NULL ,
	[NextInterestAdjustmentDate] datetime  NULL ,
	[MaturityDate]       datetime  NULL ,
	[BalloonPaymentDate] datetime  NULL ,
	[DateInactive]       datetime  NULL ,
	[DateAccountingImpaired] datetime  NULL ,
	[DateAccountingPerforming] datetime  NULL ,
	[DiscountingInterestRateImpaired] decimal(6,5)  NULL ,
	[DiscountingMonthsToRealization] integer  NULL ,
	[DiscountingNumberOfPaymentsImpaired] integer  NULL ,
	[BlendedFlag]        bit  NULL ,
	[PaymentModeCode]    varchar(20)  NULL ,
	[PaymentModeDescrEN] varchar(20)  NULL ,
	[PaymentModeDescrFR] varchar(20)  NULL ,
	[RepaymentTypeCode]  varchar(20)  NULL ,
	[RepaymentTypeDescrEN] varchar(20)  NULL ,
	[RepaymentTypeDescrFR] varchar(20)  NULL ,
	[AccountingStatusCode] varchar(20)  NULL ,
	[AccountingStatusDescrEN] varchar(20)  NULL ,
	[AccountingStatusDescrFR] varchar(20)  NULL ,
	[AccountingStatusCodePreviousMonth] varchar(20)  NULL ,
	[AccountingStatusChangeFlag] bit  NULL ,
	[StandbyFeeDate]     datetime  NULL ,
	[StandbyFeeDatePreviousMonth] datetime  NULL ,
	[StandbyFeeRate]     decimal(6,5)  NULL ,
	[StandbyFeeRatePreviousMonth] decimal(6,5)  NULL ,
	[DisbursementStatusCode] varchar(10)  NULL ,
	[DisbursementStatusDescrEN] varchar(50)  NULL ,
	[DisbursementStatusDescrFR] varchar(50)  NULL ,
	[SwitchCode]         varchar(20)  NULL ,
	[SwitchDescrEN]      varchar(20)  NULL ,
	[SwitchDescrFR]      varchar(20)  NULL ,
	[RepaymentScheduleStartDate] datetime  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(20)  NULL ,
	[RowSignature]       varchar(40)  NULL ,
	[RowUid]             varchar(40)  NULL 
)
go

ALTER TABLE [dbo].[DimLoan]
	ADD CONSTRAINT [XPKDimLoan] PRIMARY KEY  CLUSTERED ([DimLoanKey] ASC,[DimLoanDurableKey] ASC)
go

ALTER TABLE [dbo].[DimLoan]
	ADD CONSTRAINT [XAK1DimLoan] UNIQUE ([AccountNumber]  ASC,[StartDateDimLoanKey]  ASC)
go

CREATE TABLE [DimLoanAtOrigination]
( 
	[DimLoanAtOriginationDurableKey] [Integer]  NOT NULL ,
	[AccountNumber]      char(9)  NULL ,
	[AbacusNumber]       char(6)  NULL ,
	[MultipleNumber]     char(2)  NULL ,
	[OpportunityId]      [Integer] ,
	[FinancingProductId] [Integer] ,
	[LoanAuthorizationDate] datetime  NULL ,
	[LoanAuthorizationDateBooked] char(18)  NULL ,
	[AcceptanceDate]     datetime  NULL ,
	[TotalCommitmentCloselyRelatedAtAuthorization] integer  NULL ,
	[LoanMultipleTypeCode] varchar(20)  NULL ,
	[LoanMultipleTypeDescrEN] varchar(20)  NULL ,
	[LoanMultipleTypeDescrFR] varchar(20)  NULL ,
	[ExportExpansionCode] varchar(20)  NULL ,
	[ExportExpansionCodeDescrFR] varchar(20)  NULL ,
	[ExportExpansionCodeDescrEN] varchar(20)  NULL ,
	[ExportFlagLoan]     bit  NULL ,
	[ProcessTypeCode]    varchar(20)  NULL ,
	[ProcessTypeDescrEN] varchar(20)  NULL ,
	[ProcessTypeDescrFR] varchar(20)  NULL ,
	[StudentBusinessLoanFlag] bit  NULL ,
	[ProductIntiativeTypeCode] varchar(10)  NULL ,
	[ProductIntiativeTypeDescrEN] varchar(50)  NULL ,
	[ProductIntiativeTypeDescrFR] varchar(50)  NULL ,
	[AlliancePortfolioGLCode] varchar(20)  NULL ,
	[AlliancePortfolioGLDescrEN] varchar(100)  NULL ,
	[AlliancePortfolioGLDescrFR] varchar(100)  NULL ,
	[AdministrativeTypeCode] varchar(10)  NULL ,
	[AdministrativeTypeDescrEN] varchar(50)  NULL ,
	[AdministrativeTypeDescrFR] varchar(50)  NULL ,
	[AlliancePortfolioCode] varchar(10)  NULL ,
	[AlliancePortfolioDescrEN] varchar(50)  NULL ,
	[AlliancePortfolioDescrFR] varchar(50)  NULL ,
	[LoanProductCode]    varchar(10)  NULL ,
	[LoanProductDescrEN] varchar(50)  NULL ,
	[LoanProductDescrFR] varchar(50)  NULL ,
	[OverallRiskRating]  integer  NULL ,
	[OverallRiskOverriddenRating] decimal(5,1)  NULL ,
	[OverallRiskRatingSuggested] decimal(5,1)  NULL ,
	[OverallRiskRatingSuggestedBase] decimal(5,1)  NULL ,
	[OverriddenFlag]     bit  NULL ,
	[FinancialStrengthFactorRating] integer  NULL ,
	[FinancialStrengthFactorRatingSuggested] decimal(5,1)  NULL ,
	[FinancialFlexibilityFactorRating] integer  NULL ,
	[FinancialFlexibilityFactorRatingSuggested] decimal(5,1)  NULL ,
	[CompetitiveStrengthFactorRating] integer  NULL ,
	[CompetitiveStrengthFactorRatingSuggested] decimal(5,1)  NULL ,
	[ManagementFactorRating] integer  NULL ,
	[ManagementFactorRatingSuggested] decimal(5,1)  NULL ,
	[BeaconScore]        [Integer] ,
	[CreditScore]        [Integer] ,
	[ProbabilityOfDowngradingToImpairedPctFinal] decimal(5,4)  NULL ,
	[ProbabilityOfDowngradingToImpairedOverriddenPct] decimal(5,4)  NULL ,
	[ProbabilityOfDowngradingToImpairedSuggestedPct] decimal(5,4)  NULL ,
	[ProbabilityOfDowngradingBasePct] decimal(5,4)  NULL ,
	[ProbabilityOfDowngradingAdjustmentCRCommitmentSize] decimal(5,4)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL
)
go

ALTER TABLE [DimLoanAtOrigination]
	ADD CONSTRAINT [XPKDimLoanAtOrigination] PRIMARY KEY  CLUSTERED ([DimLoanAtOriginationDurableKey] ASC)
go

ALTER TABLE [DimLoanAtOrigination]
	ADD CONSTRAINT [XAK1DimLoanAtOrigination] UNIQUE ([AccountNumber]  ASC)
go

CREATE TABLE [dbo].[DimLoanCancellationReason]
( 
	[DimLoanCancellationReasonKey] [Integer]  NOT NULL ,
	[LoanCancellationReasonCode] varchar(20)  NULL ,
	[LoanCancellationReasonDescrEN] varchar(50)  NULL ,
	[LoanCancellationReasonDescrFR] varchar(100)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(20)  NULL ,
	[RowSignature]       varchar(40)  NULL
)
go

ALTER TABLE [dbo].[DimLoanCancellationReason]
	ADD CONSTRAINT [XPKDimLoanCancellationReason] PRIMARY KEY  CLUSTERED ([DimLoanCancellationReasonKey] ASC)
go

ALTER TABLE [dbo].[DimLoanCancellationReason]
	ADD CONSTRAINT [XAK1DimLoanCancellationReason] UNIQUE ([LoanCancellationReasonCode]  ASC)
go

CREATE TABLE [dbo].[DimLoanPurpose]
( 
	[DimLoanPurposeKey]  [Integer]  NOT NULL ,
	[LoanPurposeCode]    varchar(2)  NULL ,
	[LoanPurposeDescrEN] varchar(50)  NULL ,
	[LoanPurposeDescrFR] varchar(50)  NULL ,
	[LoanPurposeGroupId] varchar(2)  NULL ,
	[LoanPurposeGroupDescrEN] varchar(50)  NULL ,
	[LoanPurposeGroupDescrFR] varchar(50)  NULL ,
	[LoanPurposeGroupMarketingId] varchar(2)  NULL ,
	[LoanPurposeGroupMarketingDescrEN] varchar(50)  NULL ,
	[LoanPurposeGroupMarketingDescrFR] varchar(50)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL
)
go

ALTER TABLE [dbo].[DimLoanPurpose]
	ADD CONSTRAINT [XPKDimLoanPurpose] PRIMARY KEY  CLUSTERED ([DimLoanPurposeKey] ASC)
go

ALTER TABLE [dbo].[DimLoanPurpose]
	ADD CONSTRAINT [XAK1DimLoanPurpose] UNIQUE ([LoanPurposeCode]  ASC)
go

CREATE TABLE [dbo].[DimLoanSolutionGrouping]
( 
	[DimLoanSolutionGroupingKey] [Integer]  NOT NULL ,
	[AlliancePortfolioCode] varchar(10)  NULL ,
	[LoanProductCode]    varchar(10)  NULL ,
	[AdministrativeTypeCode] varchar(10)  NULL ,
	[SolutionSubGroupCode] varchar(10)  NULL ,
	[SolutionSubGroupDescrEN] varchar(50)  NULL ,
	[SolutionSubGroupDescrFR] varchar(50)  NULL ,
	[SolutionGroupCode]  varchar(10)  NULL ,
	[SolutionGroupDescrEN] varchar(50)  NULL ,
	[SolutionGroupDescrFR] varchar(50)  NULL ,
	[SolutionGroupingCode] varchar(10)  NULL ,
	[SolutionGroupingDescrEN] varchar(50)  NULL ,
	[SolutionGroupingDescrFR] varchar(50)  NULL ,
	[LoanSolutionSubFinLTIFlag] bit  NULL ,
	[LoanSolutionCurrencyCode] varchar(10)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL
)
go

ALTER TABLE [dbo].[DimLoanSolutionGrouping]
	ADD CONSTRAINT [XPKDimLoanSolutionGrouping] PRIMARY KEY  CLUSTERED ([DimLoanSolutionGroupingKey] ASC)
go

ALTER TABLE [dbo].[DimLoanSolutionGrouping]
	ADD CONSTRAINT [XAK1DimLoanSolutionGrouping] UNIQUE ([AlliancePortfolioCode]  ASC,[LoanProductCode]  ASC,[AdministrativeTypeCode]  ASC)
go

CREATE TABLE [dbo].[DimLoanTranche]
( 
	[DimLoanTrancheKey]  [Integer]  NOT NULL  IDENTITY ,
	[DimLoanTrancheDurableKey] [Integer]  NOT NULL ,
	[StartDateDimLoanInterestRateKey] [Integer] ,
	[EndDateDimLoanInterestRateKey] [Integer] ,
	[AccounNumber]       varchar(10)  NULL ,
	[TrancheNumber]      varchar(2)  NULL ,
	[LoanTrancheCurrentFlag] bit  NULL ,
	[InterestRate]       decimal(6,5)  NULL ,
	[InterestRateChangeFlag] bit  NULL ,
	[BaseRate]           decimal(6,5)  NULL ,
	[InterestRateVariance] decimal(6,5)  NULL ,
	[InterestRateVarianceChangeFlag] bit  NULL ,
	[InterestRatePlanCode] varchar(20)  NULL ,
	[InterestRatePlanDescrEN] varchar(20)  NULL ,
	[InterestRatePlanDescrFR] varchar(20)  NULL ,
	[InterestRatePlanGroupId] varchar(20)  NULL ,
	[InterestRatePlanGroupDescrEN] varchar(20)  NULL ,
	[InterestRatePlanGroupDescrFR] varchar(20)  NULL ,
	[CostofFundRate]     decimal(6,5)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(20)  NULL ,
	[RowSignature]       varchar(40)  NULL
)
go

ALTER TABLE [dbo].[DimLoanTranche]
	ADD CONSTRAINT [XPKDimLoanTranche] PRIMARY KEY  CLUSTERED ([DimLoanTrancheKey] ASC,[DimLoanTrancheDurableKey] ASC)
go

ALTER TABLE [dbo].[DimLoanTranche]
	ADD CONSTRAINT [XAK1DimLoanTranche] UNIQUE ([StartDateDimLoanInterestRateKey]  ASC,[AccounNumber]  ASC,[TrancheNumber]  ASC)
go

CREATE TABLE [dbo].[DimNewRepeatBusiness]
( 
	[DimNewRepeatBusinessKey] integer  NOT NULL ,
	[NewRepeatLoanTypeCode] [Integer] ,
	[NewRepeatLoanTypeDescrEN] varchar(50)  NULL ,
	[NewRepeatLoanTypeDescrFR] varchar(50)  NULL ,
	[NewRepeatGroupCode] [Integer] ,
	[NewRepeatGroupDescrEN] varchar(50)  NULL ,
	[NewRepeatGroupDescrFR] varchar(50)  NULL ,
	[NewRepeatSubGroupCode] [Integer] ,
	[NewRepeatSubGroupDescrEN] varchar(50)  NULL ,
	[NewRepeatSubGroupDescrFR] varchar(50)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[RowSignature]       varchar(40)  NULL
)
go

ALTER TABLE [dbo].[DimNewRepeatBusiness]
	ADD CONSTRAINT [XPKDimNewRepeatBusiness] PRIMARY KEY  CLUSTERED ([DimNewRepeatBusinessKey] ASC)
go

ALTER TABLE [dbo].[DimNewRepeatBusiness]
	ADD CONSTRAINT [XAK1DimNewRepeatBusiness] UNIQUE ([NewRepeatLoanTypeCode]  ASC)
go

CREATE TABLE [dbo].[DimOperatingUnit]
( 
	[DimOperatingUnitKey] [Integer]  NOT NULL ,
	[OperatingUnitNumber] varchar(10)  NULL ,
	[OperatingUnitNameEN] varchar(100)  NULL ,
	[OperatingUnitNameFR] varchar(100)  NULL ,
	[OperatingUnitAreaNumber] varchar(10)  NULL ,
	[OperatingUnitAreaNameEN] varchar(100)  NULL ,
	[OperatingUnitAreaNameFR] varchar(100)  NULL ,
	[OperatingUnitRegionNumber] varchar(10)  NULL ,
	[OperatingUnitRegionNameEN] varchar(100)  NULL ,
	[OperatingUnitRegionNameFR] varchar(100)  NULL ,
	[OperatingUnitGroupNumber] varchar(10)  NULL ,
	[OperatingUnitGroupNameEN] varchar(100)  NULL ,
	[OperatingUnitGroupNameFR] varchar(100)  NULL ,
	[OperatingUnitTypeCode] varchar(10)  NULL ,
	[OperatingUnitTypeDescrEN] varchar(100)  NULL ,
	[OperatingUnitTypeDescrFR] varchar(100)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL
)
go

ALTER TABLE [dbo].[DimOperatingUnit]
	ADD CONSTRAINT [XPKDimOperatingUnit] PRIMARY KEY  CLUSTERED ([DimOperatingUnitKey] ASC)
go

ALTER TABLE [dbo].[DimOperatingUnit]
	ADD CONSTRAINT [XAK1DimOperatingUnit] UNIQUE ([OperatingUnitNumber]  ASC)
go

CREATE TABLE [dbo].[DimOriginatingUnit]
( 
	[DimOriginatingUnitKey] [Integer]  NOT NULL ,
	[OriginatingUnitNumber] varchar(10)  NULL ,
	[OriginatingUnitNameEN] varchar(100)  NULL ,
	[OriginatingUnitNameFR] varchar(100)  NULL ,
	[DepartmentNumber]   varchar(10)  NULL ,
	[DepartmentNameEN]   varchar(100)  NULL ,
	[DepartmentNameFR]   varchar(100)  NULL ,
	[ConsolidatedOriginatingUnitNumber] varchar(10)  NULL ,
	[ConsolidatedOriginatingUnitNameEN] varchar(100)  NULL ,
	[ConsolidatedOriginatingUnitNameFR] varchar(100)  NULL ,
	[DistrictNumber]     varchar(10)  NULL ,
	[DistrictNameEN]     varchar(100)  NULL ,
	[DistrictNameFR]     varchar(100)  NULL ,
	[AreaNumber]         varchar(10)  NULL ,
	[AreaNameEN]         varchar(100)  NULL ,
	[AreaNameFR]         varchar(100)  NULL ,
	[SubRegionNumber]    varchar(10)  NULL ,
	[SubRegionNameEN]    varchar(100)  NULL ,
	[SubRegionNameFR]    varchar(100)  NULL ,
	[OperatingRegionNumber] varchar(10)  NULL ,
	[OperatingRegionNameEN] varchar(100)  NULL ,
	[OperatingRegionNameFR] varchar(100)  NULL ,
	[TotalBankCode]      varchar(10)  NULL ,
	[TotalBankName]      varchar(100)  NULL ,
	[OriginatingUnitStatusCode] varchar(10)  NULL ,
	[OriginatingUnitStatusDescrEN] varchar(100)  NULL ,
	[OriginatingUnitStatusDescrFR] varchar(100)  NULL ,
	[OriginatingUnitTypeCode] varchar(10)  NULL ,
	[OriginatingUnitTypeDescrEN] varchar(100)  NULL ,
	[OriginatingUnitTypeDescrFR] varchar(100)  NULL ,
	[OriginationUnitProvinceTerritoryCode] varchar(10)  NULL ,
	[OriginationUnitProvinceTerritoryNameEN] varchar(100)  NULL ,
	[OriginationUnitProvinceTerritoryNameFR] varchar(100)  NULL ,
	[OriginatingUnitDisplayFlag] bit  NULL ,
	[ConsolidatedOriginatingUnitDisplayFlag] bit  NULL ,
	[DistrictDisplayFlag] bit  NULL ,
	[AreaDisplayFlag]    bit  NULL ,
	[RegionDisplayFlag]  bit  NULL ,
	[OperatingRegionDisplayFlag] bit  NULL ,
	[OriginatingUnitSequenceNumber] varchar(10)  NULL ,
	[ConsolidatedOriginatingUnitSequenceNumber] varchar(10)  NULL ,
	[DistrictSequenceNumber] varchar(10)  NULL ,
	[AreaSequenceNumber] varchar(10)  NULL ,
	[RegionSequenceNumber] varchar(10)  NULL ,
	[OperatingRegionSequenceNumber] varchar(10)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL
)
go

ALTER TABLE [dbo].[DimOriginatingUnit]
	ADD CONSTRAINT [XPKDimOriginatingUnit] PRIMARY KEY  CLUSTERED ([DimOriginatingUnitKey] ASC)
go

ALTER TABLE [dbo].[DimOriginatingUnit]
	ADD CONSTRAINT [XAK1DimOriginatingUnit] UNIQUE ([OriginatingUnitNumber]  ASC)
go

CREATE TABLE [dbo].[DimSourceOfReference]
( 
	[DimSourceOfReferenceKey] [Integer]  NOT NULL ,
	[SourceOfReferenceCode] varchar(10)  NULL ,
	[SourceOfReferenceDescrEN] varchar(50)  NULL ,
	[SourceOfReferenceDescrFR] varchar(50)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL
)
go

ALTER TABLE [dbo].[DimSourceOfReference]
	ADD CONSTRAINT [XPKDimSourceOfReference] PRIMARY KEY  CLUSTERED ([DimSourceOfReferenceKey] ASC)
go

ALTER TABLE [dbo].[DimSourceOfReference]
	ADD CONSTRAINT [XAK1DimSourceOfReference] UNIQUE ([SourceOfReferenceCode]  ASC)
go

CREATE TABLE [dbo].[FactLoanOrigination]
( 
	[DimLoanKey]         [Integer]  NOT NULL ,
	[DimLoanDurableKey]  [Integer]  NOT NULL ,
	[DimCustomerKey]     [Integer]  NOT NULL ,
	[DimCustomerDurableKey] [Integer]  NOT NULL ,
	[DimDateKey]         [Integer]  NOT NULL ,
	[DimLoanTrancheKey]  [Integer]  NOT NULL ,
	[DimLoanTrancheDurableKey] [Integer]  NOT NULL ,
	[DimLoanAtOriginationDurableKey] [Integer]  NOT NULL ,
	[DimOriginatingUnitKey] [Integer]  NOT NULL ,
	[DimOriginatingUnitAtAuthKey] [Integer]  NOT NULL ,
	[DimOperatingUnitKey] [Integer]  NOT NULL ,
	[DimOperatingUnitAtAuthKey] [Integer]  NOT NULL ,
	[DimLoanPurposeKey]  [Integer]  NOT NULL ,
	[DimNewRepeatBusinessKey] [Integer]  NOT NULL ,
	[DimIndustryKey]     [Integer]  NOT NULL ,
	[DimLineOfBusinessKey] [Integer]  NOT NULL ,
	[DimLoanSolutionGroupingKey] [Integer]  NOT NULL ,
	[DimSourceOfReferenceKey] [Integer]  NOT NULL ,
	[DimLoanCancellationReasonKey] [Integer]  NOT NULL ,
	[AuthorizationGrossLoanAmount] decimal(18,2)  NULL ,
	[AuthorizationGrossLoanCount] [Integer] ,
	[AuthorizationGrossNewMoneyAmount] decimal(18,2)  NULL ,
	[AuthorizationGrossNewMoneyCount] [Integer] ,
	[AuthorizationNetNewMoney] decimal(18,2)  NULL ,
	[AuthorizationNetNewMoneyCount] [Integer] ,
	[AuthorizationFiscalNet] decimal(18,2)  NULL ,
	[AuthorizationFiscalNetCount] [Integer] ,
	[AuthorizationNetLoan] decimal(18,2)  NULL ,
	[AcceptedGrossNewMoney] decimal(18,2)  NULL ,
	[AcceptedGrossNewMoneyCount] [Integer] ,
	[AcceptedNetNewMoney] decimal(18,2)  NULL ,
	[AcceptedNetNewMoneyCount] [Integer] ,
	[AcceptedNetLoan]    decimal(18,2)  NULL ,
	[AcceptedNetLoanCount] [Integer] ,
	[CancellationReductionTotal] decimal(18,2)  NULL ,
	[Cancellation]       decimal(18,2)  NULL ,
	[Reduction]          decimal(18,2)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL
)
go

ALTER TABLE [dbo].[FactLoanOrigination]
	ADD CONSTRAINT [XPKFactLoanOrigination] PRIMARY KEY  CLUSTERED ([DimLoanKey] ASC,[DimLoanDurableKey] ASC,[DimCustomerKey] ASC,[DimCustomerDurableKey] ASC,[DimDateKey] ASC,[DimLoanTrancheKey] ASC,[DimLoanTrancheDurableKey] ASC)
go

CREATE TABLE [dbo].[FactLoanOriginationDaily]
( 
	[DimLoanKey]         [Integer]  NOT NULL ,
	[DimLoanDurableKey]  [Integer]  NOT NULL ,
	[DimCustomerKey]     [Integer]  NOT NULL ,
	[DimCustomerDurableKey] [Integer]  NOT NULL ,
	[DimDateKey]         [Integer]  NOT NULL ,
	[DimLoanTrancheKey]  [Integer]  NOT NULL ,
	[DimLoanTrancheDurableKey] [Integer]  NOT NULL ,
	[DimLoanAtOriginationDurableKey] [Integer]  NOT NULL ,
	[DimOriginatingUnitKey] [Integer]  NOT NULL ,
	[DimOriginatingUnitAtAuthKey] [Integer]  NOT NULL ,
	[DimOperatingUnitKey] [Integer]  NOT NULL ,
	[DimLoanPurposeKey]  [Integer]  NOT NULL ,
	[DimNewRepeatBusinessKey] [Integer]  NOT NULL ,
	[DimIndustryKey]     [Integer]  NOT NULL ,
	[DimLineOfBusinessKey] [Integer]  NOT NULL ,
	[DimLoanSolutionGroupingKey] [Integer]  NOT NULL ,
	[DimSourceOfReferenceKey] [Integer]  NOT NULL ,
	[DimLoanCancellationReasonKey] [Integer]  NOT NULL ,
	[AuthorizationGrossLoanAmount] decimal(18,2)  NULL ,
	[AuthorizationGrossLoanCount] [Integer] ,
	[AuthorizationGrossNewMoneyAmount] decimal(18,2)  NULL ,
	[AuthorizationGrossNewMoneyCount] [Integer] ,
	[AuthorizationNetNewMoney] decimal(18,2)  NULL ,
	[AuthorizationNetNewMoneyCount] [Integer] ,
	[AuthorizationFiscalNet] decimal(18,2)  NULL ,
	[AuthorizationFiscalNetCount] [Integer] ,
	[AuthorizationNetLoan] decimal(18,2)  NULL ,
	[AcceptedGrossNewMoney] decimal(18,2)  NULL ,
	[AcceptedGrossNewMoneyCount] [Integer] ,
	[AcceptedNetNewMoney] decimal(18,2)  NULL ,
	[AcceptedNetNewMoneyCount] [Integer] ,
	[AcceptedNetLoan]    decimal(18,2)  NULL ,
	[AcceptedNetLoanCount] [Integer] ,
	[CancellationReductionTotal] decimal(18,2)  NULL ,
	[Cancellation]       decimal(18,2)  NULL ,
	[Reduction]          decimal(18,2)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL ,
	[DimOperatingUnitAtAuthKey] [Integer]  NOT NULL 
)
go

ALTER TABLE [dbo].[FactLoanOriginationDaily]
	ADD CONSTRAINT [XPKFactLoanOriginationDaily] PRIMARY KEY  CLUSTERED ([DimLoanKey] ASC,[DimLoanDurableKey] ASC,[DimCustomerKey] ASC,[DimCustomerDurableKey] ASC,[DimDateKey] ASC,[DimLoanTrancheKey] ASC,[DimLoanTrancheDurableKey] ASC)
go

ALTER TABLE [dbo].[FactLoanOriginationDaily]
	ADD CONSTRAINT [XAK1FactLoanOriginationDaily] UNIQUE ([DimLoanDurableKey]  ASC,[DimDateKey]  ASC)
go

CREATE TABLE [dbo].[FactLoanPortfolio]
( 
	[DimLoanKey]         [Integer]  NOT NULL ,
	[DimLoanDurableKey]  [Integer]  NOT NULL ,
	[CustomerDimKey]     [Integer]  NOT NULL ,
	[DimCustomerDurableKey] [Integer]  NOT NULL ,
	[DimDateKey]         [Integer]  NOT NULL ,
	[DimLoanTrancheKey]  [Integer]  NOT NULL ,
	[DimLoanTrancheDurableKey] [Integer]  NOT NULL ,
	[DimLoanAtOriginationDurableKey] [Integer] ,
	[DimOriginatingUnitKey] integer  NOT NULL ,
	[DimOriginatingUnitAtAuthKey] integer  NOT NULL ,
	[DimOperatingUnitKey] integer  NOT NULL ,
	[DimOperatingUnitAtAuthKey] integer  NOT NULL ,
	[DimLoanPurposeKey]  [Integer]  NOT NULL ,
	[DimNewRepeatBusinessKey] integer  NOT NULL ,
	[DimIndustryKey]     [Integer]  NOT NULL ,
	[DimLineOfBusinessKey] integer  NOT NULL ,
	[DimLoanSolutionGroupingKey] [Integer]  NOT NULL ,
	[PrincipalOutstanding] decimal(18,2)  NULL ,
	[ProtectiveDisbursementsOutstanding] decimal(18,2)  NULL ,
	[PPDOS]              decimal(18,2)  NULL ,
	[PPDOSPreviousMonth] decimal(18,2)  NULL ,
	[PrincipalOutstandingAvg] decimal(18,2)  NULL ,
	[PPDOSLoansCount]    [Integer] ,
	[PPDOSOpenBalance]   decimal(18,2)  NULL ,
	[Undisbursed]        decimal(18,2)  NULL ,
	[LoansOutstanding]   decimal(18,2)  NULL ,
	[LoansOutstandingCount] [Integer] ,
	[CommitmentLoan]     decimal(18,2)  NULL ,
	[LoansCommittedCount] [Integer] ,
	[CommitmentLoanTotal] decimal(18,2)  NULL ,
	[CommitmentAbacusCustomer] decimal(18,2)  NULL ,
	[CommitmentCloselyRelated] decimal(18,2)  NULL ,
	[TotalCommitmentCustomer] decimal(18,2)  NULL ,
	[TotalCommitmentCloselyRelated] decimal(18,2)  NULL ,
	[InterestOutstanding] decimal(18,2)  NULL ,
	[InterestRateContribution] decimal(18,2)  NULL ,
	[InterestRateVarianceContribution] decimal(18,2)  NULL ,
	[ScheduledRepayment] decimal(18,2)  NULL ,
	[UpgradetoPerformingMonth] decimal(18,2)  NULL ,
	[DowngradetoImpairedMonth] decimal(18,2)  NULL ,
	[BalloonAmount]      decimal(18,2)  NULL ,
	[CurrentPrincipalDue] decimal(18,2)  NULL ,
	[InterestReceivableAccrued] decimal(18,2)  NULL ,
	[SpecificAllowance]  decimal(18,2)  NULL ,
	[LoanLossExperienceGross] decimal(18,2)  NULL ,
	[LoanLossExperienceNet] decimal(18,2)  NULL ,
	[SpecificProvisionExpenseAbacus] decimal(18,2)  NULL ,
	[MonthstoMaturityorNextInterestAdjDateCount] decimal(18,2)  NULL ,
	[MonthsToMaturityCount] decimal(18,2)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL 
)
go

ALTER TABLE [dbo].[FactLoanPortfolio]
	ADD CONSTRAINT [XPKFactLoanPortfolio] PRIMARY KEY  CLUSTERED ([DimLoanKey] ASC,[DimLoanDurableKey] ASC,[CustomerDimKey] ASC,[DimCustomerDurableKey] ASC,[DimDateKey] ASC,[DimLoanTrancheKey] ASC,[DimLoanTrancheDurableKey] ASC)
go

ALTER TABLE [dbo].[FactLoanPortfolio]
	ADD CONSTRAINT [XAK1FactLoanPortfolio] UNIQUE ([DimLoanDurableKey]  ASC,[DimDateKey]  ASC)
go


ALTER TABLE [dbo].[DimCustomer]
	ADD CONSTRAINT [FK_DimDate_DimCustomer_StartDate] FOREIGN KEY ([StartDateDimCustomerKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[DimCustomer]
	ADD CONSTRAINT [FK_DimDate_DimCustomer_EndDate] FOREIGN KEY ([EndDateDimCustomerKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [dbo].[DimLoan]
	ADD CONSTRAINT [FK_DimDate_DimLoan_StartDate] FOREIGN KEY ([StartDateDimLoanKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[DimLoan]
	ADD CONSTRAINT [FK_DimDate_DimLoan_EndDate] FOREIGN KEY ([EndDateDimLoanKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [dbo].[FactLoanOrigination]
	ADD CONSTRAINT [FK_DimLoan_FactLoanOrigination] FOREIGN KEY ([DimLoanKey],[DimLoanDurableKey]) REFERENCES [dbo].[DimLoan]([DimLoanKey],[DimLoanDurableKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOrigination]
	ADD CONSTRAINT [FK_DimCustomer_FactLoanOrigination] FOREIGN KEY ([DimCustomerKey],[DimCustomerDurableKey]) REFERENCES [dbo].[DimCustomer]([DimCustomerKey],[DimCustomerDurableKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOrigination]
	ADD CONSTRAINT [FK_DimDate_FactLoanOrigination] FOREIGN KEY ([DimDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOrigination]
	ADD CONSTRAINT [FK_DimLoanTranche_FactLoanOrigination] FOREIGN KEY ([DimLoanTrancheKey],[DimLoanTrancheDurableKey]) REFERENCES [dbo].[DimLoanTranche]([DimLoanTrancheKey],[DimLoanTrancheDurableKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOrigination]
	ADD CONSTRAINT [FK_DimLoanAtOrigination_FactLoanOrigination] FOREIGN KEY ([DimLoanAtOriginationDurableKey]) REFERENCES [DimLoanAtOrigination]([DimLoanAtOriginationDurableKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOrigination]
	ADD CONSTRAINT [FK_DimOriginatingUnit_FactLoanOrigination_Curr] FOREIGN KEY ([DimOriginatingUnitKey]) REFERENCES [dbo].[DimOriginatingUnit]([DimOriginatingUnitKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOrigination]
	ADD CONSTRAINT [FK_DimOriginatingUnit_FactLoanOrigination_AtAuth] FOREIGN KEY ([DimOriginatingUnitAtAuthKey]) REFERENCES [dbo].[DimOriginatingUnit]([DimOriginatingUnitKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOrigination]
	ADD CONSTRAINT [FK_DimOperatingUnit_FactLoanOrigination_Curr] FOREIGN KEY ([DimOperatingUnitKey]) REFERENCES [dbo].[DimOperatingUnit]([DimOperatingUnitKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOrigination]
	ADD CONSTRAINT [FK_DimOperatingUnit_FactLoanOrigination_AtAuth] FOREIGN KEY ([DimOperatingUnitAtAuthKey]) REFERENCES [dbo].[DimOperatingUnit]([DimOperatingUnitKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOrigination]
	ADD CONSTRAINT [FK_DimLoanPurpose_FactLoanOrigination] FOREIGN KEY ([DimLoanPurposeKey]) REFERENCES [dbo].[DimLoanPurpose]([DimLoanPurposeKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOrigination]
	ADD CONSTRAINT [FK_DimNewRepeatBusiness_FactLoanOrigination] FOREIGN KEY ([DimNewRepeatBusinessKey]) REFERENCES [dbo].[DimNewRepeatBusiness]([DimNewRepeatBusinessKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOrigination]
	ADD CONSTRAINT [FK_DimIndustry_FactLoanOrigination] FOREIGN KEY ([DimIndustryKey]) REFERENCES [dbo].[DimIndustry]([DimIndustryKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOrigination]
	ADD CONSTRAINT [FK_DimLineOfBusiness_FactLoanOrigination] FOREIGN KEY ([DimLineOfBusinessKey]) REFERENCES [dbo].[DimLineOfBusiness]([DimLineOfBusinessKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOrigination]
	ADD CONSTRAINT [FK_DimLoanSolutionGrouping_FactLoanOrigination] FOREIGN KEY ([DimLoanSolutionGroupingKey]) REFERENCES [dbo].[DimLoanSolutionGrouping]([DimLoanSolutionGroupingKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOrigination]
	ADD CONSTRAINT [FK_DimSourceOfReference_FactLoanOrigination] FOREIGN KEY ([DimSourceOfReferenceKey]) REFERENCES [dbo].[DimSourceOfReference]([DimSourceOfReferenceKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOrigination]
	ADD CONSTRAINT [FK_DimLoanCancellationReason_FactLoanOrigination] FOREIGN KEY ([DimLoanCancellationReasonKey]) REFERENCES [dbo].[DimLoanCancellationReason]([DimLoanCancellationReasonKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [dbo].[FactLoanOriginationDaily]
	ADD CONSTRAINT [FK_DimLoanTranche_FactLoanOriginationDaily] FOREIGN KEY ([DimLoanTrancheKey],[DimLoanTrancheDurableKey]) REFERENCES [dbo].[DimLoanTranche]([DimLoanTrancheKey],[DimLoanTrancheDurableKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOriginationDaily]
	ADD CONSTRAINT [FK_DimLoanAtOrigination_FactLoanOriginationDaily] FOREIGN KEY ([DimLoanAtOriginationDurableKey]) REFERENCES [DimLoanAtOrigination]([DimLoanAtOriginationDurableKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOriginationDaily]
	ADD CONSTRAINT [FK_DimCustomer_FactLoanOriginationDaily] FOREIGN KEY ([DimCustomerKey],[DimCustomerDurableKey]) REFERENCES [dbo].[DimCustomer]([DimCustomerKey],[DimCustomerDurableKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOriginationDaily]
	ADD CONSTRAINT [FK_DimIndustry_FactLoanOriginationDaily] FOREIGN KEY ([DimIndustryKey]) REFERENCES [dbo].[DimIndustry]([DimIndustryKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOriginationDaily]
	ADD CONSTRAINT [FK_DateDimension_FactLoanOrigination] FOREIGN KEY ([DimDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOriginationDaily]
	ADD CONSTRAINT [FK_DimOriginatingUnit_FactLoanOriginationDaily_Curr] FOREIGN KEY ([DimOriginatingUnitKey]) REFERENCES [dbo].[DimOriginatingUnit]([DimOriginatingUnitKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOriginationDaily]
	ADD CONSTRAINT [FK_DimOriginatingUnit_FactLoanOriginationDaily_AtAuth] FOREIGN KEY ([DimOriginatingUnitAtAuthKey]) REFERENCES [dbo].[DimOriginatingUnit]([DimOriginatingUnitKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOriginationDaily]
	ADD CONSTRAINT [FK_DimLineOfBusiness_FactLoanOriginationDaily] FOREIGN KEY ([DimLineOfBusinessKey]) REFERENCES [dbo].[DimLineOfBusiness]([DimLineOfBusinessKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOriginationDaily]
	ADD CONSTRAINT [FK_DimLoan_FactLoanOriginationDaily] FOREIGN KEY ([DimLoanKey],[DimLoanDurableKey]) REFERENCES [dbo].[DimLoan]([DimLoanKey],[DimLoanDurableKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOriginationDaily]
	ADD CONSTRAINT [FK_DimLoanCancellationReason_FactLoanOriginationDaily] FOREIGN KEY ([DimLoanCancellationReasonKey]) REFERENCES [dbo].[DimLoanCancellationReason]([DimLoanCancellationReasonKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOriginationDaily]
	ADD CONSTRAINT [FK_DimSourceOfReference_FactLoanOriginationDaily] FOREIGN KEY ([DimSourceOfReferenceKey]) REFERENCES [dbo].[DimSourceOfReference]([DimSourceOfReferenceKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOriginationDaily]
	ADD CONSTRAINT [FK_DimNewRepeatBusiness_FactLoanOriginationDaily] FOREIGN KEY ([DimNewRepeatBusinessKey]) REFERENCES [dbo].[DimNewRepeatBusiness]([DimNewRepeatBusinessKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOriginationDaily]
	ADD CONSTRAINT [FK_DimLoanPurpose_FactLoanOriginationDaily] FOREIGN KEY ([DimLoanPurposeKey]) REFERENCES [dbo].[DimLoanPurpose]([DimLoanPurposeKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOriginationDaily]
	ADD CONSTRAINT [FK_DimLoanSolutionGrouping_FactLoanOriginationDaily] FOREIGN KEY ([DimLoanSolutionGroupingKey]) REFERENCES [dbo].[DimLoanSolutionGrouping]([DimLoanSolutionGroupingKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOriginationDaily]
	ADD CONSTRAINT [FK_DimOperatingUnit_FactLoanOriginationDaily_AtAuth] FOREIGN KEY ([DimOperatingUnitAtAuthKey]) REFERENCES [dbo].[DimOperatingUnit]([DimOperatingUnitKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanOriginationDaily]
	ADD CONSTRAINT [FK_DimOperatingUnit_FactLoanOriginationDaily_Curr] FOREIGN KEY ([DimOperatingUnitKey]) REFERENCES [dbo].[DimOperatingUnit]([DimOperatingUnitKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [dbo].[FactLoanPortfolio]
	ADD CONSTRAINT [FK_DimLoanTranche_FactLoanPortfolio] FOREIGN KEY ([DimLoanTrancheKey],[DimLoanTrancheDurableKey]) REFERENCES [dbo].[DimLoanTranche]([DimLoanTrancheKey],[DimLoanTrancheDurableKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanPortfolio]
	ADD CONSTRAINT [FK_DimLoanAtOrigination_FactLoanPortfolio] FOREIGN KEY ([DimLoanAtOriginationDurableKey]) REFERENCES [DimLoanAtOrigination]([DimLoanAtOriginationDurableKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanPortfolio]
	ADD CONSTRAINT [FK_DimCustomer_FactLoanPortfolio] FOREIGN KEY ([CustomerDimKey],[DimCustomerDurableKey]) REFERENCES [dbo].[DimCustomer]([DimCustomerKey],[DimCustomerDurableKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanPortfolio]
	ADD CONSTRAINT [FK_DimIndustry_FactLoanPortfolio] FOREIGN KEY ([DimIndustryKey]) REFERENCES [dbo].[DimIndustry]([DimIndustryKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanPortfolio]
	ADD CONSTRAINT [FK_DateDimension_FactLoanPortfolio] FOREIGN KEY ([DimDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanPortfolio]
	ADD CONSTRAINT [FK_DimOriginatingUnit_FactLoanPortfolio_Curr] FOREIGN KEY ([DimOriginatingUnitKey]) REFERENCES [dbo].[DimOriginatingUnit]([DimOriginatingUnitKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanPortfolio]
	ADD CONSTRAINT [FK_DimOriginatingUnit_FactLoanPortfolio_AtAuth] FOREIGN KEY ([DimOriginatingUnitAtAuthKey]) REFERENCES [dbo].[DimOriginatingUnit]([DimOriginatingUnitKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanPortfolio]
	ADD CONSTRAINT [FK_DimLineOfBusiness_FactLoanPortfolio] FOREIGN KEY ([DimLineOfBusinessKey]) REFERENCES [dbo].[DimLineOfBusiness]([DimLineOfBusinessKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanPortfolio]
	ADD CONSTRAINT [FK_DimLoan_FactLoanPortfolio] FOREIGN KEY ([DimLoanKey],[DimLoanDurableKey]) REFERENCES [dbo].[DimLoan]([DimLoanKey],[DimLoanDurableKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanPortfolio]
	ADD CONSTRAINT [FK_DimOperatingUnit_FactLoanPortfolio_AtAuth] FOREIGN KEY ([DimOperatingUnitKey]) REFERENCES [dbo].[DimOperatingUnit]([DimOperatingUnitKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanPortfolio]
	ADD CONSTRAINT [FK_DimOperatingUnit_FactLoanPortfolio_Curr] FOREIGN KEY ([DimOperatingUnitAtAuthKey]) REFERENCES [dbo].[DimOperatingUnit]([DimOperatingUnitKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanPortfolio]
	ADD CONSTRAINT [FK_DimNewRepeatBusiness_FactLoanPortfolio] FOREIGN KEY ([DimNewRepeatBusinessKey]) REFERENCES [dbo].[DimNewRepeatBusiness]([DimNewRepeatBusinessKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanPortfolio]
	ADD CONSTRAINT [FK_DimLoanPurpose_FactLoanPortfolio] FOREIGN KEY ([DimLoanPurposeKey]) REFERENCES [dbo].[DimLoanPurpose]([DimLoanPurposeKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [dbo].[FactLoanPortfolio]
	ADD CONSTRAINT [FK_DimLoanSolutionGrouping_FactLoanPortfolio] FOREIGN KEY ([DimLoanSolutionGroupingKey]) REFERENCES [dbo].[DimLoanSolutionGrouping]([DimLoanSolutionGroupingKey])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go
