﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-06
-- Description: Table script for DimKeyDimLoanPurpose
-- =============================================
CREATE TABLE [dbo].[DimKeyDimLoanPurpose] (
	[DimKey] [int] IDENTITY(1,1) NOT NULL
	,[Buid] [varchar](40) NOT NULL
	,[LoanPurposeCode] [varchar](2) NOT NULL
	,[InsertedDate] datetime NULL
	,[ModifiedDate] datetime NULL
)
GO

CREATE UNIQUE NONCLUSTERED INDEX [IX_DimKeyDimLoanPurpose_Buid] ON [dbo].[DimKeyDimLoanPurpose]
(
	[Buid] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO
