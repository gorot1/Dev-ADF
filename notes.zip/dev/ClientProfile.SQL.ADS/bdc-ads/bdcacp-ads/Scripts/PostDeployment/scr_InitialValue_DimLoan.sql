﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-16
-- Description: Inserts initial values to DimLoan
-- =============================================
DECLARE @TMP_DimLoan TABLE
(
	[DimLoanKey]         [Integer]  NOT NULL ,
	[DimLoanDurableKey]  [Integer]  NOT NULL ,
	[StartDateDimLoanKey] [Integer]  NOT NULL ,
	[EndDateDimLoanKey]  [Integer] ,
	[DimLoanCurrentFlag] bit  NULL ,
	[LoanAuthorizationFlag] bit  NULL ,
	[AccountNumber]      char(8)  NULL ,
	[AbacusNumber]       char(6)  NULL ,
	[MultipleNumber]     char(2)  NULL ,
	[ActiveLoanFlag]     bit  NULL ,
	[ActiveLoanDisbursedFlag] bit  NULL ,
	[NextInterestAdjustmentDate] datetime  NULL ,
	[MaturityDate]       datetime  NULL ,
	[BalloonPaymentDate] datetime  NULL ,
	[DateInactive]       datetime  NULL ,
	[DateAccountingImpaired] datetime  NULL ,
	[DateAccountingPerforming] datetime  NULL ,
	[DiscountingInterestRateImpaired] decimal(6,5)  NULL ,
	[DiscountingMonthsToRealization] integer  NULL ,
	[DiscountingNumberOfPaymentsImpaired] integer  NULL ,
	[BlendedFlag]        bit  NULL ,
	[PaymentModeCode]    varchar(20)  NULL ,
	[PaymentModeDescrEN] varchar(20)  NULL ,
	[PaymentModeDescrFR] varchar(20)  NULL ,
	[RepaymentTypeCode]  varchar(20)  NULL ,
	[RepaymentTypeDescrEN] varchar(20)  NULL ,
	[RepaymentTypeDescrFR] varchar(20)  NULL ,
	[AccountingStatusCode] varchar(20)  NULL ,
	[AccountingStatusDescrEN] varchar(20)  NULL ,
	[AccountingStatusDescrFR] varchar(20)  NULL ,
	[AccountingStatusCodePreviousMonth] varchar(20)  NULL ,
	[AccountingStatusChangeFlag] bit  NULL ,
	[StandbyFeeDate]     datetime  NULL ,
	[StandbyFeeDatePreviousMonth] datetime  NULL ,
	[StandbyFeeRate]     decimal(6,5)  NULL ,
	[StandbyFeeRatePreviousMonth] decimal(6,5)  NULL ,
	[DisbursementStatusCode] varchar(10)  NULL ,
	[DisbursementStatusDescrEN] varchar(50)  NULL ,
	[DisbursementStatusDescrFR] varchar(50)  NULL ,
	[SwitchCode]         varchar(20)  NULL ,
	[SwitchDescrEN]      varchar(20)  NULL ,
	[SwitchDescrFR]      varchar(20)  NULL ,
	[RepaymentScheduleStartDate] datetime  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(20)  NULL ,
	[RowSignature]       varchar(40)  NULL ,
	[RowUid]             varchar(40)  NULL 
)

INSERT INTO @TMP_DimLoan (
	DimLoanKey
	,DimLoanDurableKey
	,StartDateDimLoanKey
	,EndDateDimLoanKey
	,DimLoanCurrentFlag
	,LoanAuthorizationFlag
	,AccountNumber
	,AbacusNumber
	,MultipleNumber
	,ActiveLoanFlag
	,ActiveLoanDisbursedFlag
	,NextInterestAdjustmentDate
	,MaturityDate
	,BalloonPaymentDate
	,DateInactive
	,DateAccountingImpaired
	,DateAccountingPerforming
	,DiscountingInterestRateImpaired
	,DiscountingMonthsToRealization
	,DiscountingNumberOfPaymentsImpaired
	,BlendedFlag
	,PaymentModeCode
	,PaymentModeDescrEN
	,PaymentModeDescrFR
	,RepaymentTypeCode
	,RepaymentTypeDescrEN
	,RepaymentTypeDescrFR
	,AccountingStatusCode
	,AccountingStatusDescrEN
	,AccountingStatusDescrFR
	,AccountingStatusCodePreviousMonth
	,AccountingStatusChangeFlag
	,StandbyFeeDate
	,StandbyFeeDatePreviousMonth
	,StandbyFeeRate
	,StandbyFeeRatePreviousMonth
	,DisbursementStatusCode
	,DisbursementStatusDescrEN
	,DisbursementStatusDescrFR
	,SwitchCode
	,SwitchDescrEN
	,SwitchDescrFR
	,RepaymentScheduleStartDate
	,InsertedDate
	,ModifiedDate
	,ModifiedBy
	,RowSignature
	,RowUid
)
VALUES (
	-1
	,-1
	,19000101
	,19000101
	,0
	,0
	,'N/A'
	,'N/A'
	,'NA'
	,0
	,0
	,NULL
	,NULL
	,NULL
	,NULL
	,NULL
	,NULL
	,NULL
	,0
	,0
	,0
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,0
	,NULL
	,NULL
	,NULL
	,NULL
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,NULL
    ,GETDATE()
    ,GETDATE()
    ,'Initial load'
    ,'0000000000000000000000000000000000000000'
    ,'0000000000000000000000000000000000000000'
)
BEGIN TRANSACTION
    SET IDENTITY_INSERT dbo.DimLoan ON
    MERGE dbo.DimLoan AS dst
    USING @TMP_DimLoan as src
        ON dst.DimLoanKey = src.DimLoanKey
    WHEN MATCHED AND (dst.DimLoanDurableKey <> src.DimLoanDurableKey) THEN
        UPDATE SET
			DimLoanDurableKey = src.DimLoanDurableKey
			,StartDateDimLoanKey = src.StartDateDimLoanKey
			,EndDateDimLoanKey = src.EndDateDimLoanKey
			,DimLoanCurrentFlag = src.DimLoanCurrentFlag
			,LoanAuthorizationFlag = src.LoanAuthorizationFlag
			,AccountNumber = src.AccountNumber
			,AbacusNumber = src.AbacusNumber
			,MultipleNumber = src.MultipleNumber
			,ActiveLoanFlag = src.ActiveLoanFlag
			,ActiveLoanDisbursedFlag = src.ActiveLoanDisbursedFlag
			,NextInterestAdjustmentDate = src.NextInterestAdjustmentDate
			,MaturityDate = src.MaturityDate
			,BalloonPaymentDate = src.BalloonPaymentDate
			,DateInactive = src.DateInactive
			,DateAccountingImpaired = src.DateAccountingImpaired
			,DateAccountingPerforming = src.DateAccountingPerforming
			,DiscountingInterestRateImpaired = src.DiscountingInterestRateImpaired
			,DiscountingMonthsToRealization = src.DiscountingMonthsToRealization
			,DiscountingNumberOfPaymentsImpaired = src.DiscountingNumberOfPaymentsImpaired
			,BlendedFlag = src.BlendedFlag
			,PaymentModeCode = src.PaymentModeCode
			,PaymentModeDescrEN = src.PaymentModeDescrEN
			,PaymentModeDescrFR = src.PaymentModeDescrFR
			,RepaymentTypeCode = src.RepaymentTypeCode
			,RepaymentTypeDescrEN = src.RepaymentTypeDescrEN
			,RepaymentTypeDescrFR = src.RepaymentTypeDescrFR
			,AccountingStatusCode = src.AccountingStatusCode
			,AccountingStatusDescrEN = src.AccountingStatusDescrEN
			,AccountingStatusDescrFR = src.AccountingStatusDescrFR
			,AccountingStatusCodePreviousMonth = src.AccountingStatusCodePreviousMonth
			,AccountingStatusChangeFlag = src.AccountingStatusChangeFlag
			,StandbyFeeDate = src.StandbyFeeDate
			,StandbyFeeDatePreviousMonth = src.StandbyFeeDatePreviousMonth
			,StandbyFeeRate = src.StandbyFeeRate
			,StandbyFeeRatePreviousMonth = src.StandbyFeeRatePreviousMonth
			,DisbursementStatusCode = src.DisbursementStatusCode
			,DisbursementStatusDescrEN = src.DisbursementStatusDescrEN
			,DisbursementStatusDescrFR = src.DisbursementStatusDescrFR
			,SwitchCode = src.SwitchCode
			,SwitchDescrEN = src.SwitchDescrEN
			,SwitchDescrFR = src.SwitchDescrFR
			,RepaymentScheduleStartDate = src.RepaymentScheduleStartDate
			,ModifiedDate = GETDATE()
			,ModifiedBy = src.ModifiedBy
			,RowSignature = src.RowSignature
			,RowUid = src.RowUid
    WHEN NOT MATCHED THEN
		INSERT (
			DimLoanKey
			,DimLoanDurableKey
			,StartDateDimLoanKey
			,EndDateDimLoanKey
			,DimLoanCurrentFlag
			,LoanAuthorizationFlag
			,AccountNumber
			,AbacusNumber
			,MultipleNumber
			,ActiveLoanFlag
			,ActiveLoanDisbursedFlag
			,NextInterestAdjustmentDate
			,MaturityDate
			,BalloonPaymentDate
			,DateInactive
			,DateAccountingImpaired
			,DateAccountingPerforming
			,DiscountingInterestRateImpaired
			,DiscountingMonthsToRealization
			,DiscountingNumberOfPaymentsImpaired
			,BlendedFlag
			,PaymentModeCode
			,PaymentModeDescrEN
			,PaymentModeDescrFR
			,RepaymentTypeCode
			,RepaymentTypeDescrEN
			,RepaymentTypeDescrFR
			,AccountingStatusCode
			,AccountingStatusDescrEN
			,AccountingStatusDescrFR
			,AccountingStatusCodePreviousMonth
			,AccountingStatusChangeFlag
			,StandbyFeeDate
			,StandbyFeeDatePreviousMonth
			,StandbyFeeRate
			,StandbyFeeRatePreviousMonth
			,DisbursementStatusCode
			,DisbursementStatusDescrEN
			,DisbursementStatusDescrFR
			,SwitchCode
			,SwitchDescrEN
			,SwitchDescrFR
			,RepaymentScheduleStartDate
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
			,RowUid
		)
		VALUES (
			src.DimLoanKey
			,src.DimLoanDurableKey
			,src.StartDateDimLoanKey
			,src.EndDateDimLoanKey
			,src.DimLoanCurrentFlag
			,src.LoanAuthorizationFlag
			,src.AccountNumber
			,src.AbacusNumber
			,src.MultipleNumber
			,src.ActiveLoanFlag
			,src.ActiveLoanDisbursedFlag
			,src.NextInterestAdjustmentDate
			,src.MaturityDate
			,src.BalloonPaymentDate
			,src.DateInactive
			,src.DateAccountingImpaired
			,src.DateAccountingPerforming
			,src.DiscountingInterestRateImpaired
			,src.DiscountingMonthsToRealization
			,src.DiscountingNumberOfPaymentsImpaired
			,src.BlendedFlag
			,src.PaymentModeCode
			,src.PaymentModeDescrEN
			,src.PaymentModeDescrFR
			,src.RepaymentTypeCode
			,src.RepaymentTypeDescrEN
			,src.RepaymentTypeDescrFR
			,src.AccountingStatusCode
			,src.AccountingStatusDescrEN
			,src.AccountingStatusDescrFR
			,src.AccountingStatusCodePreviousMonth
			,src.AccountingStatusChangeFlag
			,src.StandbyFeeDate
			,src.StandbyFeeDatePreviousMonth
			,src.StandbyFeeRate
			,src.StandbyFeeRatePreviousMonth
			,src.DisbursementStatusCode
			,src.DisbursementStatusDescrEN
			,src.DisbursementStatusDescrFR
			,src.SwitchCode
			,src.SwitchDescrEN
			,src.SwitchDescrFR
			,src.RepaymentScheduleStartDate
			,GETDATE()
			,GETDATE()
			,src.ModifiedBy
			,src.RowSignature
			,src.RowUid
		)
    OUTPUT $ACTION as ActionType, src.*;
    SET IDENTITY_INSERT dbo.DimLoan OFF
COMMIT TRANSACTION
