﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-07
-- Description: Inserts initial values to DimOperatingUnit
-- =============================================
DECLARE @TMP_DimOperatingUnit TABLE
(
	[DimOperatingUnitKey] [Integer]  NOT NULL ,
	[OperatingUnitNumber] varchar(10)  NULL ,
	[OperatingUnitNameEN] varchar(100)  NULL ,
	[OperatingUnitNameFR] varchar(100)  NULL ,
	[OperatingUnitAreaNumber] varchar(10)  NULL ,
	[OperatingUnitAreaNameEN] varchar(100)  NULL ,
	[OperatingUnitAreaNameFR] varchar(100)  NULL ,
	[OperatingUnitRegionNumber] varchar(10)  NULL ,
	[OperatingUnitRegionNameEN] varchar(100)  NULL ,
	[OperatingUnitRegionNameFR] varchar(100)  NULL ,
	[OperatingUnitGroupNumber] varchar(10)  NULL ,
	[OperatingUnitGroupNameEN] varchar(100)  NULL ,
	[OperatingUnitGroupNameFR] varchar(100)  NULL ,
	[OperatingUnitTypeCode] varchar(10)  NULL ,
	[OperatingUnitTypeDescrEN] varchar(100)  NULL ,
	[OperatingUnitTypeDescrFR] varchar(100)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL
)

INSERT INTO @TMP_DimOperatingUnit (
	DimOperatingUnitKey
	,OperatingUnitNumber
	,OperatingUnitNameEN
	,OperatingUnitNameFR
	,OperatingUnitAreaNumber
	,OperatingUnitAreaNameEN
	,OperatingUnitAreaNameFR
	,OperatingUnitRegionNumber
	,OperatingUnitRegionNameEN
	,OperatingUnitRegionNameFR
	,OperatingUnitGroupNumber
	,OperatingUnitGroupNameEN
	,OperatingUnitGroupNameFR
	,OperatingUnitTypeCode
	,OperatingUnitTypeDescrEN
	,OperatingUnitTypeDescrFR
	,InsertedDate
	,ModifiedDate
	,ModifiedBy
	,RowSignature
)
VALUES (
	-1
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
    ,GETDATE()
    ,GETDATE()
    ,'Initial load'
    ,'0000000000000000000000000000000000000000'
)
BEGIN TRANSACTION
    --SET IDENTITY_INSERT dbo.DimOperatingUnit ON
    MERGE dbo.DimOperatingUnit AS dst
    USING @TMP_DimOperatingUnit as src
        ON dst.DimOperatingUnitKey = src.DimOperatingUnitKey
    WHEN MATCHED AND (dst.OperatingUnitNumber <> src.OperatingUnitNumber) THEN
        UPDATE SET
			OperatingUnitNumber = src.OperatingUnitNumber
			,OperatingUnitNameEN = src.OperatingUnitNameEN
			,OperatingUnitNameFR = src.OperatingUnitNameFR
			,OperatingUnitAreaNumber = src.OperatingUnitAreaNumber
			,OperatingUnitAreaNameEN = src.OperatingUnitAreaNameEN
			,OperatingUnitAreaNameFR = src.OperatingUnitAreaNameFR
			,OperatingUnitRegionNumber = src.OperatingUnitRegionNumber
			,OperatingUnitRegionNameEN = src.OperatingUnitRegionNameEN
			,OperatingUnitRegionNameFR = src.OperatingUnitRegionNameFR
			,OperatingUnitGroupNumber = src.OperatingUnitGroupNumber
			,OperatingUnitGroupNameEN = src.OperatingUnitGroupNameEN
			,OperatingUnitGroupNameFR = src.OperatingUnitGroupNameFR
			,OperatingUnitTypeCode = src.OperatingUnitTypeCode
			,OperatingUnitTypeDescrEN = src.OperatingUnitTypeDescrEN
			,OperatingUnitTypeDescrFR = src.OperatingUnitTypeDescrFR
			,ModifiedDate = GETDATE()
			,ModifiedBy = src.ModifiedBy
			,RowSignature = src.RowSignature
    WHEN NOT MATCHED THEN
		INSERT (
			DimOperatingUnitKey
			,OperatingUnitNumber
			,OperatingUnitNameEN
			,OperatingUnitNameFR
			,OperatingUnitAreaNumber
			,OperatingUnitAreaNameEN
			,OperatingUnitAreaNameFR
			,OperatingUnitRegionNumber
			,OperatingUnitRegionNameEN
			,OperatingUnitRegionNameFR
			,OperatingUnitGroupNumber
			,OperatingUnitGroupNameEN
			,OperatingUnitGroupNameFR
			,OperatingUnitTypeCode
			,OperatingUnitTypeDescrEN
			,OperatingUnitTypeDescrFR
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
		)
		VALUES (
			src.DimOperatingUnitKey
			,src.OperatingUnitNumber
			,src.OperatingUnitNameEN
			,src.OperatingUnitNameFR
			,src.OperatingUnitAreaNumber
			,src.OperatingUnitAreaNameEN
			,src.OperatingUnitAreaNameFR
			,src.OperatingUnitRegionNumber
			,src.OperatingUnitRegionNameEN
			,src.OperatingUnitRegionNameFR
			,src.OperatingUnitGroupNumber
			,src.OperatingUnitGroupNameEN
			,src.OperatingUnitGroupNameFR
			,src.OperatingUnitTypeCode
			,src.OperatingUnitTypeDescrEN
			,src.OperatingUnitTypeDescrFR
			,GETDATE()
			,GETDATE()
			,src.ModifiedBy
			,src.RowSignature
		)
    OUTPUT $ACTION as ActionType, src.*;
    --SET IDENTITY_INSERT dbo.DimOperatingUnit OFF
COMMIT TRANSACTION
