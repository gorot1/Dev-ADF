﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-22
-- Description: Inserts initial values to DimCustomer
-- =============================================
DECLARE @TMP_DimCustomer TABLE
(
	[DimCustomerKey]     [Integer]  NOT NULL ,
	[DimCustomerDurableKey] [Integer]  NOT NULL ,
	[StartDateDimCustomerKey] [Integer] ,
	[EndDateDimCustomerKey] [Integer] ,
	[DimCustomerCurrentFlag] bit  NULL ,
	[CustomerNumber]     [Integer] ,
	[ProspectIndicator]  varchar(20)  NULL ,
	[CustomerBusinessName] varchar(100)  NULL ,
	[CustomerCompleteName] varchar(100)  NULL ,
	[CustomerTradeName]  varchar(100)  NULL ,
	[CustomerBillingName] varchar(100)  NULL ,
	[CustomerBillingName1] varchar(100)  NULL ,
	[CustomerBillingName2] varchar(100)  NULL ,
	[CustomerAddress1]   varchar(100)  NULL ,
	[CustomerAddress2]   varchar(100)  NULL ,
	[CustomerCity]       varchar(50)  NULL ,
	[CustomerProvinceCode] char(2)  NULL ,
	[CustomerProvinceNameEN] varchar(50)  NULL ,
	[CustomerProvinceNameFR] varchar(50)  NULL ,
	[PostalCode]         varchar(10)  NULL ,
	[CustomerCountryName] varchar(200)  NULL ,
	[CustomerCompleteAddress] varchar(200)  NULL ,
	[FSACode]            varchar(3)  NULL ,
	[FSADescrEN]         varchar(50)  NULL ,
	[FSADescrFR]         varchar(50)  NULL ,
	[TerritoryCode]      varchar(20)  NULL ,
	[TerritoryDescrEN]   varchar(50)  NULL ,
	[TerritoryDescrFR]   varchar(50)  NULL ,
	[CustomerWebSite]    varchar(200)  NULL ,
	[CustomerAnnualSales] integer  NULL ,
	[BusinessYearEstablished] varchar(20)  NULL ,
	[CustomerYearsinBusinessCount] [Integer] ,
	[CustomerStatusCode] [Integer] ,
	[CustomerStatusDescrEN] varchar(50)  NULL ,
	[CustomerStatusDescrFR] varchar(50)  NULL ,
	[CustomerStatusEffectiveDate] datetime  NULL ,
	[CustomerStateCode]  [Integer] ,
	[CustomerStateDescrEN] varchar(50)  NULL ,
	[CustomerStateDescrFR] varchar(50)  NULL ,
	[CustomerStatusHistoryCode] [Integer] ,
	[CustomerStatusHistoryDescrEN] varchar(50)  NULL ,
	[CustomerStatusHistoryDescrFR] varchar(50)  NULL ,
	[NumberofEmployees]  integer  NULL ,
	[EmployeeSizeGroupCode] [Integer] ,
	[EmployeeSizeGroupDescrEN] varchar(50)  NULL ,
	[EmployeeSizeGroupDescrFR] varchar(50)  NULL ,
	[EnvironmentalRiskMonitoringCode] varchar(50)  NULL ,
	[EnvironmentalRiskMonitoringDescrEN] varchar(50)  NULL ,
	[EnvironmentalRiskMonitoringDescrFR] varchar(50)  NULL ,
	[ExportMarketPrimaryCode] varchar(20)  NULL ,
	[ExportMarketPrimaryDescrEN] varchar(50)  NULL ,
	[ExportMarketPrimaryDescrFR] varchar(50)  NULL ,
	[ExportMarketSecondaryCode] varchar(20)  NULL ,
	[ExportMarketSecondaryDescrEN] varchar(50)  NULL ,
	[ExportMarketSecondaryDescrFR] varchar(50)  NULL ,
	[ExportFlagCustomer] bit  NULL ,
	[ExportSalesPercentage] integer  NULL ,
	[ExporterSalesPercentage] integer  NULL ,
	[ExportToTouristsPct] integer  NULL ,
	[AgeGroupCode]       varchar(20)  NULL ,
	[AgeGroupDescrEN]    varchar(50)  NULL ,
	[AgeGroupDescrFR]    varchar(50)  NULL ,
	[AgeGroupingCode]    varchar(20)  NULL ,
	[AgeGroupingDescrEN] varchar(50)  NULL ,
	[AgeGroupingDescrFR] varchar(50)  NULL ,
	[NativeStatusCode]   varchar(20)  NULL ,
	[NativeStatusDescrEN] varchar(50)  NULL ,
	[NativeStatusDescrFR] varchar(50)  NULL ,
	[NativeStatusGroupCode] varchar(50)  NULL ,
	[NativeStatusGroupDescrEN] varchar(50)  NULL ,
	[NativeStatusGroupDescrFR] varchar(50)  NULL ,
	[OwnershipGenderCode] varchar(20)  NULL ,
	[OwnershipGenderDescrEN] varchar(50)  NULL ,
	[OwnershipGenderDescrFR] varchar(50)  NULL ,
	[OwnershipGenderCompositionGroupCode] varchar(20)  NULL ,
	[OwnershipGenderCompositionGroupDescrEN] varchar(50)  NULL ,
	[OwnershipGenderCompositionGroupDescrFR] varchar(50)  NULL ,
	[StageOfDevelopmentCode] varchar(20)  NULL ,
	[StageOfDevelopmentDescrEN] varchar(50)  NULL ,
	[StageOfDevelopmentDescrFR] varchar(50)  NULL ,
	[CustomerSegmentCode] varchar(20)  NULL ,
	[CustomerSegmentDescrEN] varchar(50)  NULL ,
	[CustomerSegmentDescrFR] varchar(50)  NULL ,
	[OwnsFlag]           bit  NULL ,
	[SolicitationFlag]   bit  NULL ,
	[RentsFlag]          bit  NULL ,
	[ManufacturesFlag]   bit  NULL ,
	[ExportsFlag]        bit  NULL ,
	[ImportsFlag]        bit  NULL ,
	[RDExpensesPct]      decimal(18,2)  NULL ,
	[UrbanRuralAreaCode] varchar(20)  NULL ,
	[UrbanRuralAreaDescrFR] varchar(50)  NULL ,
	[UrbanRuralAreaDescrEN] varchar(50)  NULL ,
	[BeaconScoreAvg]     [Integer] ,
	[OwnershipTypeCode]  [Integer] ,
	[OwnershipTypeDescrEN] varchar(50)  NULL ,
	[OwnershipTypeDescrFR] varchar(50)  NULL ,
	[LegalStatusCode]    [Integer] ,
	[LegalStatusDescrEN] varchar(50)  NULL ,
	[LegalStatusDescrFR] varchar(50)  NULL ,
	[ConditionInBreachFlag] bit  NULL ,
	[ConditionToMonitorFlag] bit  NULL ,
	[ConditionWithFinancialStatementNotReceivedFlag] bit  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(20)  NULL ,
	[RowSignature]       varchar(40)  NULL ,
	[RowUid]              varchar(40)  NULL 
)

INSERT INTO @TMP_DimCustomer (
	DimCustomerKey
	,DimCustomerDurableKey
	,StartDateDimCustomerKey
	,EndDateDimCustomerKey
	,DimCustomerCurrentFlag
	,CustomerNumber
	,ProspectIndicator
	,CustomerBusinessName
	,CustomerCompleteName
	,CustomerTradeName
	,CustomerBillingName
	,CustomerBillingName1
	,CustomerBillingName2
	,CustomerAddress1
	,CustomerAddress2
	,CustomerCity
	,CustomerProvinceCode
	,CustomerProvinceNameEN
	,CustomerProvinceNameFR
	,PostalCode
	,CustomerCountryName
	,CustomerCompleteAddress
	,FSACode
	,FSADescrEN
	,FSADescrFR
	,TerritoryCode
	,TerritoryDescrEN
	,TerritoryDescrFR
	,CustomerWebSite
	,CustomerAnnualSales
	,BusinessYearEstablished
	,CustomerYearsinBusinessCount
	,CustomerStatusCode
	,CustomerStatusDescrEN
	,CustomerStatusDescrFR
	,CustomerStatusEffectiveDate
	,CustomerStateCode
	,CustomerStateDescrEN
	,CustomerStateDescrFR
	,CustomerStatusHistoryCode
	,CustomerStatusHistoryDescrEN
	,CustomerStatusHistoryDescrFR
	,NumberofEmployees
	,EmployeeSizeGroupCode
	,EmployeeSizeGroupDescrEN
	,EmployeeSizeGroupDescrFR
	,EnvironmentalRiskMonitoringCode
	,EnvironmentalRiskMonitoringDescrEN
	,EnvironmentalRiskMonitoringDescrFR
	,ExportMarketPrimaryCode
	,ExportMarketPrimaryDescrEN
	,ExportMarketPrimaryDescrFR
	,ExportMarketSecondaryCode
	,ExportMarketSecondaryDescrEN
	,ExportMarketSecondaryDescrFR
	,ExportFlagCustomer
	,ExportSalesPercentage
	,ExporterSalesPercentage
	,ExportToTouristsPct
	,AgeGroupCode
	,AgeGroupDescrEN
	,AgeGroupDescrFR
	,AgeGroupingCode
	,AgeGroupingDescrEN
	,AgeGroupingDescrFR
	,NativeStatusCode
	,NativeStatusDescrEN
	,NativeStatusDescrFR
	,NativeStatusGroupCode
	,NativeStatusGroupDescrEN
	,NativeStatusGroupDescrFR
	,OwnershipGenderCode
	,OwnershipGenderDescrEN
	,OwnershipGenderDescrFR
	,OwnershipGenderCompositionGroupCode
	,OwnershipGenderCompositionGroupDescrEN
	,OwnershipGenderCompositionGroupDescrFR
	,StageOfDevelopmentCode
	,StageOfDevelopmentDescrEN
	,StageOfDevelopmentDescrFR
	,CustomerSegmentCode
	,CustomerSegmentDescrEN
	,CustomerSegmentDescrFR
	,OwnsFlag
	,SolicitationFlag
	,RentsFlag
	,ManufacturesFlag
	,ExportsFlag
	,ImportsFlag
	,RDExpensesPct
	,UrbanRuralAreaCode
	,UrbanRuralAreaDescrFR
	,UrbanRuralAreaDescrEN
	,BeaconScoreAvg
	,OwnershipTypeCode
	,OwnershipTypeDescrEN
	,OwnershipTypeDescrFR
	,LegalStatusCode
	,LegalStatusDescrEN
	,LegalStatusDescrFR
	,ConditionInBreachFlag
	,ConditionToMonitorFlag
	,ConditionWithFinancialStatementNotReceivedFlag
	,InsertedDate
	,ModifiedDate
	,ModifiedBy
	,RowSignature
	,RowUid
)
VALUES (
	-1
	,-1
	,19000101
	,99991231
	,1
	,0
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'NA'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,0
	,'N/A'
	,0
	,0
	,'N/A'
	,'N/A'
	,NULL
	,0
	,'N/A'
	,'N/A'
	,0
	,'N/A'
	,'N/A'
	,0
	,0
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,0
	,0
	,0
	,0
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,0
	,0
	,0
	,0
	,0
	,0
	,NULL
	,'N/A'
	,'N/A'
	,'N/A'
	,0
	,0
	,'N/A'
	,'N/A'
	,0
	,'N/A'
	,'N/A'
	,0
	,0
	,0
    ,GETDATE()
    ,GETDATE()
    ,'Initial load'
    ,'0000000000000000000000000000000000000000'
    ,'0000000000000000000000000000000000000000'
)
BEGIN TRANSACTION
    SET IDENTITY_INSERT dbo.DimCustomer ON
    MERGE dbo.DimCustomer AS dst
    USING @TMP_DimCustomer as src
        ON dst.DimCustomerKey = src.DimCustomerKey
    WHEN MATCHED AND (dst.dimCustomerDurableKey <> src.DimCustomerDurableKey) THEN
        UPDATE SET
			DimCustomerDurableKey = src.DimCustomerDurableKey
			,StartDateDimCustomerKey = src.StartDateDimCustomerKey
			,EndDateDimCustomerKey = src.EndDateDimCustomerKey
			,DimCustomerCurrentFlag = src.DimCustomerCurrentFlag
			,CustomerNumber = src.CustomerNumber
			,ProspectIndicator = src.ProspectIndicator
			,CustomerBusinessName = src.CustomerBusinessName
			,CustomerCompleteName = src.CustomerCompleteName
			,CustomerTradeName = src.CustomerTradeName
			,CustomerBillingName = src.CustomerBillingName
			,CustomerBillingName1 = src.CustomerBillingName1
			,CustomerBillingName2 = src.CustomerBillingName2
			,CustomerAddress1 = src.CustomerAddress1
			,CustomerAddress2 = src.CustomerAddress2
			,CustomerCity = src.CustomerCity
			,CustomerProvinceCode = src.CustomerProvinceCode
			,CustomerProvinceNameEN = src.CustomerProvinceNameEN
			,CustomerProvinceNameFR = src.CustomerProvinceNameFR
			,PostalCode = src.PostalCode
			,CustomerCountryName = src.CustomerCountryName
			,CustomerCompleteAddress = src.CustomerCompleteAddress
			,FSACode = src.FSACode
			,FSADescrEN = src.FSADescrEN
			,FSADescrFR = src.FSADescrFR
			,TerritoryCode = src.TerritoryCode
			,TerritoryDescrEN = src.TerritoryDescrEN
			,TerritoryDescrFR = src.TerritoryDescrFR
			,CustomerWebSite = src.CustomerWebSite
			,CustomerAnnualSales = src.CustomerAnnualSales
			,BusinessYearEstablished = src.BusinessYearEstablished
			,CustomerYearsinBusinessCount = src.CustomerYearsinBusinessCount
			,CustomerStatusCode = src.CustomerStatusCode
			,CustomerStatusDescrEN = src.CustomerStatusDescrEN
			,CustomerStatusDescrFR = src.CustomerStatusDescrFR
			,CustomerStatusEffectiveDate = src.CustomerStatusEffectiveDate
			,CustomerStateCode = src.CustomerStateCode
			,CustomerStateDescrEN = src.CustomerStateDescrEN
			,CustomerStateDescrFR = src.CustomerStateDescrFR
			,CustomerStatusHistoryCode = src.CustomerStatusHistoryCode
			,CustomerStatusHistoryDescrEN = src.CustomerStatusHistoryDescrEN
			,CustomerStatusHistoryDescrFR = src.CustomerStatusHistoryDescrFR
			,NumberofEmployees = src.NumberofEmployees
			,EmployeeSizeGroupCode = src.EmployeeSizeGroupCode
			,EmployeeSizeGroupDescrEN = src.EmployeeSizeGroupDescrEN
			,EmployeeSizeGroupDescrFR = src.EmployeeSizeGroupDescrFR
			,EnvironmentalRiskMonitoringCode = src.EnvironmentalRiskMonitoringCode
			,EnvironmentalRiskMonitoringDescrEN = src.EnvironmentalRiskMonitoringDescrEN
			,EnvironmentalRiskMonitoringDescrFR = src.EnvironmentalRiskMonitoringDescrFR
			,ExportMarketPrimaryCode = src.ExportMarketPrimaryCode
			,ExportMarketPrimaryDescrEN = src.ExportMarketPrimaryDescrEN
			,ExportMarketPrimaryDescrFR = src.ExportMarketPrimaryDescrFR
			,ExportMarketSecondaryCode = src.ExportMarketSecondaryCode
			,ExportMarketSecondaryDescrEN = src.ExportMarketSecondaryDescrEN
			,ExportMarketSecondaryDescrFR = src.ExportMarketSecondaryDescrFR
			,ExportFlagCustomer = src.ExportFlagCustomer
			,ExportSalesPercentage = src.ExportSalesPercentage
			,ExporterSalesPercentage = src.ExporterSalesPercentage
			,ExportToTouristsPct = src.ExportToTouristsPct
			,AgeGroupCode = src.AgeGroupCode
			,AgeGroupDescrEN = src.AgeGroupDescrEN
			,AgeGroupDescrFR = src.AgeGroupDescrFR
			,AgeGroupingCode = src.AgeGroupingCode
			,AgeGroupingDescrEN = src.AgeGroupingDescrEN
			,AgeGroupingDescrFR = src.AgeGroupingDescrFR
			,NativeStatusCode = src.NativeStatusCode
			,NativeStatusDescrEN = src.NativeStatusDescrEN
			,NativeStatusDescrFR = src.NativeStatusDescrFR
			,NativeStatusGroupCode = src.NativeStatusGroupCode
			,NativeStatusGroupDescrEN = src.NativeStatusGroupDescrEN
			,NativeStatusGroupDescrFR = src.NativeStatusGroupDescrFR
			,OwnershipGenderCode = src.OwnershipGenderCode
			,OwnershipGenderDescrEN = src.OwnershipGenderDescrEN
			,OwnershipGenderDescrFR = src.OwnershipGenderDescrFR
			,OwnershipGenderCompositionGroupCode = src.OwnershipGenderCompositionGroupCode
			,OwnershipGenderCompositionGroupDescrEN = src.OwnershipGenderCompositionGroupDescrEN
			,OwnershipGenderCompositionGroupDescrFR = src.OwnershipGenderCompositionGroupDescrFR
			,StageOfDevelopmentCode = src.StageOfDevelopmentCode
			,StageOfDevelopmentDescrEN = src.StageOfDevelopmentDescrEN
			,StageOfDevelopmentDescrFR = src.StageOfDevelopmentDescrFR
			,CustomerSegmentCode = src.CustomerSegmentCode
			,CustomerSegmentDescrEN = src.CustomerSegmentDescrEN
			,CustomerSegmentDescrFR = src.CustomerSegmentDescrFR
			,OwnsFlag = src.OwnsFlag
			,SolicitationFlag = src.SolicitationFlag
			,RentsFlag = src.RentsFlag
			,ManufacturesFlag = src.ManufacturesFlag
			,ExportsFlag = src.ExportsFlag
			,ImportsFlag = src.ImportsFlag
			,RDExpensesPct = src.RDExpensesPct
			,UrbanRuralAreaCode = src.UrbanRuralAreaCode
			,UrbanRuralAreaDescrFR = src.UrbanRuralAreaDescrFR
			,UrbanRuralAreaDescrEN = src.UrbanRuralAreaDescrEN
			,BeaconScoreAvg = src.BeaconScoreAvg
			,OwnershipTypeCode = src.OwnershipTypeCode
			,OwnershipTypeDescrEN = src.OwnershipTypeDescrEN
			,OwnershipTypeDescrFR = src.OwnershipTypeDescrFR
			,LegalStatusCode = src.LegalStatusCode
			,LegalStatusDescrEN = src.LegalStatusDescrEN
			,LegalStatusDescrFR = src.LegalStatusDescrFR
			,ConditionInBreachFlag = src.ConditionInBreachFlag
			,ConditionToMonitorFlag = src.ConditionToMonitorFlag
			,ConditionWithFinancialStatementNotReceivedFlag = src.ConditionWithFinancialStatementNotReceivedFlag
			,InsertedDate = src.InsertedDate
			,ModifiedDate = src.ModifiedDate
			,ModifiedBy = src.ModifiedBy
			,RowSignature = src.RowSignature
			,RowUid = src.RowUid
    WHEN NOT MATCHED THEN
		INSERT (
			DimCustomerKey
			,DimCustomerDurableKey
			,StartDateDimCustomerKey
			,EndDateDimCustomerKey
			,DimCustomerCurrentFlag
			,CustomerNumber
			,ProspectIndicator
			,CustomerBusinessName
			,CustomerCompleteName
			,CustomerTradeName
			,CustomerBillingName
			,CustomerBillingName1
			,CustomerBillingName2
			,CustomerAddress1
			,CustomerAddress2
			,CustomerCity
			,CustomerProvinceCode
			,CustomerProvinceNameEN
			,CustomerProvinceNameFR
			,PostalCode
			,CustomerCountryName
			,CustomerCompleteAddress
			,FSACode
			,FSADescrEN
			,FSADescrFR
			,TerritoryCode
			,TerritoryDescrEN
			,TerritoryDescrFR
			,CustomerWebSite
			,CustomerAnnualSales
			,BusinessYearEstablished
			,CustomerYearsinBusinessCount
			,CustomerStatusCode
			,CustomerStatusDescrEN
			,CustomerStatusDescrFR
			,CustomerStatusEffectiveDate
			,CustomerStateCode
			,CustomerStateDescrEN
			,CustomerStateDescrFR
			,CustomerStatusHistoryCode
			,CustomerStatusHistoryDescrEN
			,CustomerStatusHistoryDescrFR
			,NumberofEmployees
			,EmployeeSizeGroupCode
			,EmployeeSizeGroupDescrEN
			,EmployeeSizeGroupDescrFR
			,EnvironmentalRiskMonitoringCode
			,EnvironmentalRiskMonitoringDescrEN
			,EnvironmentalRiskMonitoringDescrFR
			,ExportMarketPrimaryCode
			,ExportMarketPrimaryDescrEN
			,ExportMarketPrimaryDescrFR
			,ExportMarketSecondaryCode
			,ExportMarketSecondaryDescrEN
			,ExportMarketSecondaryDescrFR
			,ExportFlagCustomer
			,ExportSalesPercentage
			,ExporterSalesPercentage
			,ExportToTouristsPct
			,AgeGroupCode
			,AgeGroupDescrEN
			,AgeGroupDescrFR
			,AgeGroupingCode
			,AgeGroupingDescrEN
			,AgeGroupingDescrFR
			,NativeStatusCode
			,NativeStatusDescrEN
			,NativeStatusDescrFR
			,NativeStatusGroupCode
			,NativeStatusGroupDescrEN
			,NativeStatusGroupDescrFR
			,OwnershipGenderCode
			,OwnershipGenderDescrEN
			,OwnershipGenderDescrFR
			,OwnershipGenderCompositionGroupCode
			,OwnershipGenderCompositionGroupDescrEN
			,OwnershipGenderCompositionGroupDescrFR
			,StageOfDevelopmentCode
			,StageOfDevelopmentDescrEN
			,StageOfDevelopmentDescrFR
			,CustomerSegmentCode
			,CustomerSegmentDescrEN
			,CustomerSegmentDescrFR
			,OwnsFlag
			,SolicitationFlag
			,RentsFlag
			,ManufacturesFlag
			,ExportsFlag
			,ImportsFlag
			,RDExpensesPct
			,UrbanRuralAreaCode
			,UrbanRuralAreaDescrFR
			,UrbanRuralAreaDescrEN
			,BeaconScoreAvg
			,OwnershipTypeCode
			,OwnershipTypeDescrEN
			,OwnershipTypeDescrFR
			,LegalStatusCode
			,LegalStatusDescrEN
			,LegalStatusDescrFR
			,ConditionInBreachFlag
			,ConditionToMonitorFlag
			,ConditionWithFinancialStatementNotReceivedFlag
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
			,RowUid
		)
		VALUES (
			src.DimCustomerKey
			,src.DimCustomerDurableKey
			,src.StartDateDimCustomerKey
			,src.EndDateDimCustomerKey
			,src.DimCustomerCurrentFlag
			,src.CustomerNumber
			,src.ProspectIndicator
			,src.CustomerBusinessName
			,src.CustomerCompleteName
			,src.CustomerTradeName
			,src.CustomerBillingName
			,src.CustomerBillingName1
			,src.CustomerBillingName2
			,src.CustomerAddress1
			,src.CustomerAddress2
			,src.CustomerCity
			,src.CustomerProvinceCode
			,src.CustomerProvinceNameEN
			,src.CustomerProvinceNameFR
			,src.PostalCode
			,src.CustomerCountryName
			,src.CustomerCompleteAddress
			,src.FSACode
			,src.FSADescrEN
			,src.FSADescrFR
			,src.TerritoryCode
			,src.TerritoryDescrEN
			,src.TerritoryDescrFR
			,src.CustomerWebSite
			,src.CustomerAnnualSales
			,src.BusinessYearEstablished
			,src.CustomerYearsinBusinessCount
			,src.CustomerStatusCode
			,src.CustomerStatusDescrEN
			,src.CustomerStatusDescrFR
			,src.CustomerStatusEffectiveDate
			,src.CustomerStateCode
			,src.CustomerStateDescrEN
			,src.CustomerStateDescrFR
			,src.CustomerStatusHistoryCode
			,src.CustomerStatusHistoryDescrEN
			,src.CustomerStatusHistoryDescrFR
			,src.NumberofEmployees
			,src.EmployeeSizeGroupCode
			,src.EmployeeSizeGroupDescrEN
			,src.EmployeeSizeGroupDescrFR
			,src.EnvironmentalRiskMonitoringCode
			,src.EnvironmentalRiskMonitoringDescrEN
			,src.EnvironmentalRiskMonitoringDescrFR
			,src.ExportMarketPrimaryCode
			,src.ExportMarketPrimaryDescrEN
			,src.ExportMarketPrimaryDescrFR
			,src.ExportMarketSecondaryCode
			,src.ExportMarketSecondaryDescrEN
			,src.ExportMarketSecondaryDescrFR
			,src.ExportFlagCustomer
			,src.ExportSalesPercentage
			,src.ExporterSalesPercentage
			,src.ExportToTouristsPct
			,src.AgeGroupCode
			,src.AgeGroupDescrEN
			,src.AgeGroupDescrFR
			,src.AgeGroupingCode
			,src.AgeGroupingDescrEN
			,src.AgeGroupingDescrFR
			,src.NativeStatusCode
			,src.NativeStatusDescrEN
			,src.NativeStatusDescrFR
			,src.NativeStatusGroupCode
			,src.NativeStatusGroupDescrEN
			,src.NativeStatusGroupDescrFR
			,src.OwnershipGenderCode
			,src.OwnershipGenderDescrEN
			,src.OwnershipGenderDescrFR
			,src.OwnershipGenderCompositionGroupCode
			,src.OwnershipGenderCompositionGroupDescrEN
			,src.OwnershipGenderCompositionGroupDescrFR
			,src.StageOfDevelopmentCode
			,src.StageOfDevelopmentDescrEN
			,src.StageOfDevelopmentDescrFR
			,src.CustomerSegmentCode
			,src.CustomerSegmentDescrEN
			,src.CustomerSegmentDescrFR
			,src.OwnsFlag
			,src.SolicitationFlag
			,src.RentsFlag
			,src.ManufacturesFlag
			,src.ExportsFlag
			,src.ImportsFlag
			,src.RDExpensesPct
			,src.UrbanRuralAreaCode
			,src.UrbanRuralAreaDescrFR
			,src.UrbanRuralAreaDescrEN
			,src.BeaconScoreAvg
			,src.OwnershipTypeCode
			,src.OwnershipTypeDescrEN
			,src.OwnershipTypeDescrFR
			,src.LegalStatusCode
			,src.LegalStatusDescrEN
			,src.LegalStatusDescrFR
			,src.ConditionInBreachFlag
			,src.ConditionToMonitorFlag
			,src.ConditionWithFinancialStatementNotReceivedFlag
			,src.InsertedDate
			,src.ModifiedDate
			,src.ModifiedBy
			,src.RowSignature
			,src.RowUid
		)
    OUTPUT $ACTION as ActionType, src.*;
    SET IDENTITY_INSERT dbo.DimCustomer OFF
COMMIT TRANSACTION
