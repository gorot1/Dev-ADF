﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-30
-- Description: Inserts initial values to DimLoanCancellationReason
-- =============================================
DECLARE @TMP_DimLoanCancellationReason TABLE
(
	[DimLoanCancellationReasonKey] [Integer]  NOT NULL ,
	[LoanCancellationReasonCode] varchar(20)  NULL ,
	[LoanCancellationReasonDescrEN] varchar(50)  NULL ,
	[LoanCancellationReasonDescrFR] varchar(100)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(20)  NULL ,
	[RowSignature]       varchar(40)  NULL
)

INSERT INTO @TMP_DimLoanCancellationReason (
	DimLoanCancellationReasonKey
	,LoanCancellationReasonCode
	,LoanCancellationReasonDescrEN
	,LoanCancellationReasonDescrFR
	,InsertedDate
	,ModifiedDate
	,ModifiedBy
	,RowSignature
)
VALUES (
	-1
	,0
	,'N/A'
	,'N/A'
    ,GETDATE()
    ,GETDATE()
    ,'Initial load'
    ,'0000000000000000000000000000000000000000'
)

BEGIN TRANSACTION
    --SET IDENTITY_INSERT dbo.DimLoanCancellationReason ON
    MERGE dbo.DimLoanCancellationReason AS dst
    USING @TMP_DimLoanCancellationReason as src
        ON dst.DimLoanCancellationReasonKey = src.DimLoanCancellationReasonKey
    WHEN MATCHED AND (dst.LoanCancellationReasonCode <> src.LoanCancellationReasonCode) THEN
        UPDATE SET
			LoanCancellationReasonCode = src.LoanCancellationReasonCode
			,LoanCancellationReasonDescrEN = src.LoanCancellationReasonDescrEN
			,LoanCancellationReasonDescrFR = src.LoanCancellationReasonDescrFR
			,InsertedDate = src.InsertedDate
			,ModifiedDate = src.ModifiedDate
			,ModifiedBy = src.ModifiedBy
			,RowSignature = src.RowSignature
    WHEN NOT MATCHED THEN
		INSERT (
			DimLoanCancellationReasonKey
			,LoanCancellationReasonCode
			,LoanCancellationReasonDescrEN
			,LoanCancellationReasonDescrFR
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
		)
		VALUES (
			src.DimLoanCancellationReasonKey
			,src.LoanCancellationReasonCode
			,src.LoanCancellationReasonDescrEN
			,src.LoanCancellationReasonDescrFR
			,src.InsertedDate
			,src.ModifiedDate
			,src.ModifiedBy
			,src.RowSignature
		)
    OUTPUT $ACTION as ActionType, src.*;
    --SET IDENTITY_INSERT dbo.DimLoanCancellationReason OFF
COMMIT TRANSACTION
