﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-30
-- Description: Inserts initial values to DimLoanSolutionGrouping
-- =============================================
DECLARE @TMP_DimLoanSolutionGrouping TABLE
(
	[DimLoanSolutionGroupingKey] [Integer]  NOT NULL ,
	[AlliancePortfolioCode] varchar(10)  NULL ,
	[LoanProductCode]    varchar(10)  NULL ,
	[AdministrativeTypeCode] varchar(10)  NULL ,
	[SolutionSubGroupCode] varchar(10)  NULL ,
	[SolutionSubGroupDescrEN] varchar(50)  NULL ,
	[SolutionSubGroupDescrFR] varchar(50)  NULL ,
	[SolutionGroupCode]  varchar(10)  NULL ,
	[SolutionGroupDescrEN] varchar(50)  NULL ,
	[SolutionGroupDescrFR] varchar(50)  NULL ,
	[SolutionGroupingCode] varchar(10)  NULL ,
	[SolutionGroupingDescrEN] varchar(50)  NULL ,
	[SolutionGroupingDescrFR] varchar(50)  NULL ,
	[LoanSolutionSubFinLTIFlag] bit  NULL ,
	[LoanSolutionCurrencyCode] varchar(10)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL
)

INSERT INTO @TMP_DimLoanSolutionGrouping (
	DimLoanSolutionGroupingKey
	,AlliancePortfolioCode
	,LoanProductCode
	,AdministrativeTypeCode
	,SolutionSubGroupCode
	,SolutionSubGroupDescrEN
	,SolutionSubGroupDescrFR
	,SolutionGroupCode
	,SolutionGroupDescrEN
	,SolutionGroupDescrFR
	,SolutionGroupingCode
	,SolutionGroupingDescrEN
	,SolutionGroupingDescrFR
	,LoanSolutionSubFinLTIFlag
	,LoanSolutionCurrencyCode
	,InsertedDate
	,ModifiedDate
	,ModifiedBy
	,RowSignature
)
VALUES (
	-1
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,0
	,'N/A'
    ,GETDATE()
    ,GETDATE()
    ,'Initial load'
    ,'0000000000000000000000000000000000000000'
)

BEGIN TRANSACTION
    --SET IDENTITY_INSERT dbo.DimLoanSolutionGrouping ON
    MERGE dbo.DimLoanSolutionGrouping AS dst
    USING @TMP_DimLoanSolutionGrouping as src
        ON dst.DimLoanSolutionGroupingKey = src.DimLoanSolutionGroupingKey
    WHEN MATCHED AND (dst.AlliancePortfolioCode <> src.AlliancePortfolioCode) THEN
        UPDATE SET
			AlliancePortfolioCode = src.AlliancePortfolioCode
			,LoanProductCode = src.LoanProductCode
			,AdministrativeTypeCode = src.AdministrativeTypeCode
			,SolutionSubGroupCode = src.SolutionSubGroupCode
			,SolutionSubGroupDescrEN = src.SolutionSubGroupDescrEN
			,SolutionSubGroupDescrFR = src.SolutionSubGroupDescrFR
			,SolutionGroupCode = src.SolutionGroupCode
			,SolutionGroupDescrEN = src.SolutionGroupDescrEN
			,SolutionGroupDescrFR = src.SolutionGroupDescrFR
			,SolutionGroupingCode = src.SolutionGroupingCode
			,SolutionGroupingDescrEN = src.SolutionGroupingDescrEN
			,SolutionGroupingDescrFR = src.SolutionGroupingDescrFR
			,LoanSolutionSubFinLTIFlag = src.LoanSolutionSubFinLTIFlag
			,LoanSolutionCurrencyCode = src.LoanSolutionCurrencyCode
			,InsertedDate = src.InsertedDate
			,ModifiedDate = src.ModifiedDate
			,ModifiedBy = src.ModifiedBy
			,RowSignature  = src.RowSignature
    WHEN NOT MATCHED THEN
		INSERT (
			DimLoanSolutionGroupingKey
			,AlliancePortfolioCode
			,LoanProductCode
			,AdministrativeTypeCode
			,SolutionSubGroupCode
			,SolutionSubGroupDescrEN
			,SolutionSubGroupDescrFR
			,SolutionGroupCode
			,SolutionGroupDescrEN
			,SolutionGroupDescrFR
			,SolutionGroupingCode
			,SolutionGroupingDescrEN
			,SolutionGroupingDescrFR
			,LoanSolutionSubFinLTIFlag
			,LoanSolutionCurrencyCode
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
		)
		VALUES (
			src.DimLoanSolutionGroupingKey
			,src.AlliancePortfolioCode
			,src.LoanProductCode
			,src.AdministrativeTypeCode
			,src.SolutionSubGroupCode
			,src.SolutionSubGroupDescrEN
			,src.SolutionSubGroupDescrFR
			,src.SolutionGroupCode
			,src.SolutionGroupDescrEN
			,src.SolutionGroupDescrFR
			,src.SolutionGroupingCode
			,src.SolutionGroupingDescrEN
			,src.SolutionGroupingDescrFR
			,src.LoanSolutionSubFinLTIFlag
			,src.LoanSolutionCurrencyCode
			,src.InsertedDate
			,src.ModifiedDate
			,src.ModifiedBy
			,src.RowSignature
		)
    OUTPUT $ACTION as ActionType, src.*;
    --SET IDENTITY_INSERT dbo.DimLoanSolutionGrouping OFF
COMMIT TRANSACTION
