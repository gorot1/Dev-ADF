﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-07
-- Description: Inserts initial values to DimOriginatingUnit
-- =============================================
DECLARE @TMP_DimOriginatingUnit TABLE
(
	[DimOriginatingUnitKey] [Integer]  NOT NULL,
	[OriginatingUnitNumber] varchar(10)  NULL ,
	[OriginatingUnitNameEN] varchar(100)  NULL ,
	[OriginatingUnitNameFR] varchar(100)  NULL ,
	[ConsolidatedOriginatingUnitNumber] varchar(10)  NULL ,
	[ConsolidatedOriginatingUnitNameEN] varchar(100)  NULL ,
	[ConsolidatedOriginatingUnitNameFR] varchar(100)  NULL ,
	[DepartmentNumber]   varchar(10)  NULL ,
	[DepartmentNameEN]   varchar(100)  NULL ,
	[DepartmentNameFR]   varchar(100)  NULL ,
	[DistrictNumber]     varchar(10)  NULL ,
	[DistrictNameEN]     varchar(100)  NULL ,
	[DistrictNameFR]     varchar(100)  NULL ,
	[AreaNumber]         varchar(10)  NULL ,
	[AreaNameEN]         varchar(100)  NULL ,
	[AreaNameFR]         varchar(100)  NULL ,
	[SubRegionNumber]    varchar(10)  NULL ,
	[SubRegionNameEN]    varchar(100)  NULL ,
	[SubRegionNameFR]    varchar(100)  NULL ,
	[OperatingRegionNumber] varchar(10)  NULL ,
	[OperatingRegionNameEN] varchar(100)  NULL ,
	[OperatingRegionNameFR] varchar(100)  NULL ,
	[OriginatingUnitStatusCode] varchar(10)  NULL ,
	[OriginatingUnitStatusDescrEN] varchar(100)  NULL ,
	[OriginatingUnitStatusDescrFR] varchar(100)  NULL ,
	[OriginatingUnitTypeCode] varchar(10)  NULL ,
	[OriginatingUnitTypeDescrEN] varchar(100)  NULL ,
	[OriginatingUnitTypeDescrFR] varchar(100)  NULL ,
	[OriginationUnitProvinceTerritoryCode] varchar(10)  NULL ,
	[OriginationUnitProvinceTerritoryNameEN] varchar(100)  NULL ,
	[OriginationUnitProvinceTerritoryNameFR] varchar(100)  NULL ,
	[TotalBankCode]      varchar(10)  NULL ,
	[TotalBankName]      varchar(100)  NULL ,
	[OriginatingUnitDisplayFlag] bit  NULL ,
	[ConsolidatedOriginatingUnitDisplayFlag] bit  NULL ,
	[DistrictDisplayFlag] bit  NULL ,
	[RegionDisplayFlag]  bit  NULL ,
	[OperatingRegionDisplayFlag] bit  NULL ,
	[AreaDisplayFlag]    bit  NULL ,
	[OriginatingUnitSequenceNumber] varchar(10)  NULL ,
	[ConsolidatedOriginatingUnitSequenceNumber] varchar(10)  NULL ,
	[DistrictSequenceNumber] varchar(10)  NULL ,
	[AreaSequenceNumber] varchar(10)  NULL ,
	[RegionSequenceNumber] varchar(10)  NULL ,
	[OperatingRegionSequenceNumber] varchar(10)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL
)

INSERT INTO @TMP_DimOriginatingUnit (
	DimOriginatingUnitKey
	,OriginatingUnitNumber
	,OriginatingUnitNameEN
	,OriginatingUnitNameFR
	,ConsolidatedOriginatingUnitNumber
	,ConsolidatedOriginatingUnitNameEN
	,ConsolidatedOriginatingUnitNameFR
	,DepartmentNumber
	,DepartmentNameEN
	,DepartmentNameFR
	,DistrictNumber
	,DistrictNameEN
	,DistrictNameFR
	,AreaNumber
	,AreaNameEN
	,AreaNameFR
	,SubRegionNumber
	,SubRegionNameEN
	,SubRegionNameFR
	,OperatingRegionNumber
	,OperatingRegionNameEN
	,OperatingRegionNameFR
	,OriginatingUnitStatusCode
	,OriginatingUnitStatusDescrEN
	,OriginatingUnitStatusDescrFR
	,OriginatingUnitTypeCode
	,OriginatingUnitTypeDescrEN
	,OriginatingUnitTypeDescrFR
	,OriginationUnitProvinceTerritoryCode
	,OriginationUnitProvinceTerritoryNameEN
	,OriginationUnitProvinceTerritoryNameFR
	,TotalBankCode
	,TotalBankName
	,OriginatingUnitDisplayFlag
	,ConsolidatedOriginatingUnitDisplayFlag
	,DistrictDisplayFlag
	,RegionDisplayFlag
	,OperatingRegionDisplayFlag
	,AreaDisplayFlag
	,OriginatingUnitSequenceNumber
	,ConsolidatedOriginatingUnitSequenceNumber
	,DistrictSequenceNumber
	,AreaSequenceNumber
	,RegionSequenceNumber
	,OperatingRegionSequenceNumber
	,InsertedDate
	,ModifiedDate
	,ModifiedBy
	,RowSignature 
)
VALUES (
	-1
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,0
	,0
	,0
	,0
	,0
	,0
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
    ,GETDATE()
    ,GETDATE()
    ,'Initial load'
    ,'0000000000000000000000000000000000000000'
)
BEGIN TRANSACTION
    --SET IDENTITY_INSERT dbo.DimOriginatingUnit ON
    MERGE dbo.DimOriginatingUnit AS dst
    USING @TMP_DimOriginatingUnit as src
        ON dst.DimOriginatingUnitKey = src.DimOriginatingUnitKey
    WHEN MATCHED AND (dst.OriginatingUnitNumber <> src.OriginatingUnitNumber) THEN
        UPDATE SET
			DimOriginatingUnitKey = src.DimOriginatingUnitKey
			,OriginatingUnitNumber = src.OriginatingUnitNumber
			,OriginatingUnitNameEN = src.OriginatingUnitNameEN
			,OriginatingUnitNameFR = src.OriginatingUnitNameFR
			,ConsolidatedOriginatingUnitNumber = src.ConsolidatedOriginatingUnitNumber
			,ConsolidatedOriginatingUnitNameEN = src.ConsolidatedOriginatingUnitNameEN
			,ConsolidatedOriginatingUnitNameFR = src.ConsolidatedOriginatingUnitNameFR
			,DepartmentNumber = src.DepartmentNumber
			,DepartmentNameEN = src.DepartmentNameEN
			,DepartmentNameFR = src.DepartmentNameFR
			,DistrictNumber = src.DistrictNumber
			,DistrictNameEN = src.DistrictNameEN
			,DistrictNameFR = src.DistrictNameFR
			,AreaNumber = src.AreaNumber
			,AreaNameEN = src.AreaNameEN
			,AreaNameFR = src.AreaNameFR
			,SubRegionNumber = src.SubRegionNumber
			,SubRegionNameEN = src.SubRegionNameEN
			,SubRegionNameFR = src.SubRegionNameFR
			,OperatingRegionNumber = src.OperatingRegionNumber
			,OperatingRegionNameEN = src.OperatingRegionNameEN
			,OperatingRegionNameFR = src.OperatingRegionNameFR
			,OriginatingUnitStatusCode = src.OriginatingUnitStatusCode
			,OriginatingUnitStatusDescrEN = src.OriginatingUnitStatusDescrEN
			,OriginatingUnitStatusDescrFR = src.OriginatingUnitStatusDescrFR
			,OriginatingUnitTypeCode = src.OriginatingUnitTypeCode
			,OriginatingUnitTypeDescrEN = src.OriginatingUnitTypeDescrEN
			,OriginatingUnitTypeDescrFR = src.OriginatingUnitTypeDescrFR
			,OriginationUnitProvinceTerritoryCode = src.OriginationUnitProvinceTerritoryCode
			,OriginationUnitProvinceTerritoryNameEN = src.OriginationUnitProvinceTerritoryNameEN
			,OriginationUnitProvinceTerritoryNameFR = src.OriginationUnitProvinceTerritoryNameFR
			,TotalBankCode = src.TotalBankCode
			,TotalBankName = src.TotalBankName
			,OriginatingUnitDisplayFlag = src.OriginatingUnitDisplayFlag
			,ConsolidatedOriginatingUnitDisplayFlag = src.ConsolidatedOriginatingUnitDisplayFlag
			,DistrictDisplayFlag = src.DistrictDisplayFlag
			,RegionDisplayFlag = src.RegionDisplayFlag
			,OperatingRegionDisplayFlag = src.OperatingRegionDisplayFlag
			,AreaDisplayFlag = src.AreaDisplayFlag
			,OriginatingUnitSequenceNumber = src.OriginatingUnitSequenceNumber
			,ConsolidatedOriginatingUnitSequenceNumber = src.ConsolidatedOriginatingUnitSequenceNumber
			,DistrictSequenceNumber = src.DistrictSequenceNumber
			,AreaSequenceNumber = src.AreaSequenceNumber
			,RegionSequenceNumber = src.RegionSequenceNumber
			,OperatingRegionSequenceNumber = src.OperatingRegionSequenceNumber
			,ModifiedDate = GETDATE()
			,ModifiedBy = src.ModifiedBy
			,RowSignature = src.RowSignature
    WHEN NOT MATCHED THEN
		INSERT (
			DimOriginatingUnitKey
			,OriginatingUnitNumber
			,OriginatingUnitNameEN
			,OriginatingUnitNameFR
			,ConsolidatedOriginatingUnitNumber
			,ConsolidatedOriginatingUnitNameEN
			,ConsolidatedOriginatingUnitNameFR
			,DepartmentNumber
			,DepartmentNameEN
			,DepartmentNameFR
			,DistrictNumber
			,DistrictNameEN
			,DistrictNameFR
			,AreaNumber
			,AreaNameEN
			,AreaNameFR
			,SubRegionNumber
			,SubRegionNameEN
			,SubRegionNameFR
			,OperatingRegionNumber
			,OperatingRegionNameEN
			,OperatingRegionNameFR
			,OriginatingUnitStatusCode
			,OriginatingUnitStatusDescrEN
			,OriginatingUnitStatusDescrFR
			,OriginatingUnitTypeCode
			,OriginatingUnitTypeDescrEN
			,OriginatingUnitTypeDescrFR
			,OriginationUnitProvinceTerritoryCode
			,OriginationUnitProvinceTerritoryNameEN
			,OriginationUnitProvinceTerritoryNameFR
			,TotalBankCode
			,TotalBankName
			,OriginatingUnitDisplayFlag
			,ConsolidatedOriginatingUnitDisplayFlag
			,DistrictDisplayFlag
			,RegionDisplayFlag
			,OperatingRegionDisplayFlag
			,AreaDisplayFlag
			,OriginatingUnitSequenceNumber
			,ConsolidatedOriginatingUnitSequenceNumber
			,DistrictSequenceNumber
			,AreaSequenceNumber
			,RegionSequenceNumber
			,OperatingRegionSequenceNumber
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
		)
		VALUES (
			src.DimOriginatingUnitKey
			,src.OriginatingUnitNumber
			,src.OriginatingUnitNameEN
			,src.OriginatingUnitNameFR
			,src.ConsolidatedOriginatingUnitNumber
			,src.ConsolidatedOriginatingUnitNameEN
			,src.ConsolidatedOriginatingUnitNameFR
			,src.DepartmentNumber
			,src.DepartmentNameEN
			,src.DepartmentNameFR
			,src.DistrictNumber
			,src.DistrictNameEN
			,src.DistrictNameFR
			,src.AreaNumber
			,src.AreaNameEN
			,src.AreaNameFR
			,src.SubRegionNumber
			,src.SubRegionNameEN
			,src.SubRegionNameFR
			,src.OperatingRegionNumber
			,src.OperatingRegionNameEN
			,src.OperatingRegionNameFR
			,src.OriginatingUnitStatusCode
			,src.OriginatingUnitStatusDescrEN
			,src.OriginatingUnitStatusDescrFR
			,src.OriginatingUnitTypeCode
			,src.OriginatingUnitTypeDescrEN
			,src.OriginatingUnitTypeDescrFR
			,src.OriginationUnitProvinceTerritoryCode
			,src.OriginationUnitProvinceTerritoryNameEN
			,src.OriginationUnitProvinceTerritoryNameFR
			,src.TotalBankCode
			,src.TotalBankName
			,src.OriginatingUnitDisplayFlag
			,src.ConsolidatedOriginatingUnitDisplayFlag
			,src.DistrictDisplayFlag
			,src.RegionDisplayFlag
			,src.OperatingRegionDisplayFlag
			,src.AreaDisplayFlag
			,src.OriginatingUnitSequenceNumber
			,src.ConsolidatedOriginatingUnitSequenceNumber
			,src.DistrictSequenceNumber
			,src.AreaSequenceNumber
			,src.RegionSequenceNumber
			,src.OperatingRegionSequenceNumber
			,GETDATE()
			,GETDATE()
			,src.ModifiedBy
			,src.RowSignature
		)
    OUTPUT $ACTION as ActionType, src.*;
    --SET IDENTITY_INSERT dbo.DimOriginatingUnit OFF
COMMIT TRANSACTION
