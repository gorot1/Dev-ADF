﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-07
-- Description: Inserts initial values to DimIndustry
-- =============================================
DECLARE @TMP_DimIndustry TABLE
(
	[DimIndustryKey]     [Integer]  NOT NULL ,
	[IndustryCode]       varchar(10)  NOT NULL ,
	[IndustryType]       varchar(10)  NOT NULL ,
	[ExporterIndicator]  bit  NOT NULL ,
	[IndustryDescrEN]    varchar(100)  NULL ,
	[IndustryDescrFR]    varchar(100)  NULL ,
	[IndustryBDCGroupCode] varchar(10)  NOT NULL ,
	[IndustryBDCGroupDescrEN] varchar(100)  NULL ,
	[IndustryBDCGroupDescrFR] varchar(100)  NULL ,
	[IndustryBDCGroupDescrENShort] varchar(100)  NULL ,
	[IndustryBDCGroupDescrFRShort] varchar(100)  NULL ,
	[IndustryMarketingGroupCode] varchar(10)  NOT NULL ,
	[IndustryMarketingGroupDescrEN] varchar(100)  NULL ,
	[IndustryMarketingGroupDescrFR] varchar(100)  NULL ,
	[IndustryAnalytixGroupCode] varchar(10)  NULL ,
	[IndustryAnalytixGroupDescrEN] varchar(100)  NULL ,
	[IndustryAnalytixGroupDescrFR] varchar(100)  NULL ,
	[IndustryFinanceGroupCode] varchar(10)  NOT NULL ,
	[IndustryFinanceGroupDescrEN] varchar(100)  NULL ,
	[IndustryFinanceGroupDescrFR] varchar(100)  NULL ,
	[NAICSL5Code]        varchar(10)  NULL ,
	[NAICSL5DescrEN]     varchar(200)  NULL ,
	[NAICSL5DescrFR]     varchar(200)  NULL ,
	[NAICSL4Code]        varchar(10)  NULL ,
	[NAICSL4DescrEN]     varchar(200)  NULL ,
	[NAICSL4DescrFR]     varchar(200)  NULL ,
	[NAICSL3Code]        varchar(10)  NULL ,
	[NAICSL3DescrEN]     varchar(200)  NULL ,
	[NAICSL3DescrFR]     varchar(200)  NULL ,
	[NAICSL2Code]        varchar(10)  NULL ,
	[NAICSL2DescrEN]     varchar(200)  NULL ,
	[NAICSL2DescrFR]     varchar(200)  NULL ,
	[NAICSUSFlag]        bit  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL
)

INSERT INTO @TMP_DimIndustry (
	DimIndustryKey
	,IndustryCode
	,IndustryType
	,ExporterIndicator
	,IndustryDescrEN
	,IndustryDescrFR
	,IndustryBDCGroupCode
	,IndustryBDCGroupDescrEN
	,IndustryBDCGroupDescrFR
	,IndustryBDCGroupDescrENShort
	,IndustryBDCGroupDescrFRShort
	,IndustryMarketingGroupCode
	,IndustryMarketingGroupDescrEN
	,IndustryMarketingGroupDescrFR
	,IndustryAnalytixGroupCode
	,IndustryAnalytixGroupDescrEN
	,IndustryAnalytixGroupDescrFR
	,IndustryFinanceGroupCode
	,IndustryFinanceGroupDescrEN
	,IndustryFinanceGroupDescrFR
	,NAICSL5Code
	,NAICSL5DescrEN
	,NAICSL5DescrFR
	,NAICSL4Code
	,NAICSL4DescrEN
	,NAICSL4DescrFR
	,NAICSL3Code
	,NAICSL3DescrEN
	,NAICSL3DescrFR
	,NAICSL2Code
	,NAICSL2DescrEN
	,NAICSL2DescrFR
	,NAICSUSFlag
	,InsertedDate
	,ModifiedDate
	,ModifiedBy
	,RowSignature
)
VALUES (
	-1
	,'N/A'
	,'N/A'
	,0
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,0
    ,GETDATE()
    ,GETDATE()
    ,'Initial load'
    ,'0000000000000000000000000000000000000000'
)
BEGIN TRANSACTION
    --SET IDENTITY_INSERT dbo.DimIndustry ON
    MERGE dbo.DimIndustry AS dst
    USING @TMP_DimIndustry as src
        ON dst.DimIndustryKey = src.DimIndustryKey
    WHEN MATCHED AND (dst.IndustryCode <> src.IndustryCode) THEN
        UPDATE SET
			IndustryCode = src.IndustryCode
			,IndustryType = src.IndustryType
			,ExporterIndicator = src.ExporterIndicator
			,IndustryDescrEN = src.IndustryDescrEN
			,IndustryDescrFR = src.IndustryDescrFR
			,IndustryBDCGroupCode = src.IndustryBDCGroupCode
			,IndustryBDCGroupDescrEN = src.IndustryBDCGroupDescrEN
			,IndustryBDCGroupDescrFR = src.IndustryBDCGroupDescrFR
			,IndustryBDCGroupDescrENShort = src.IndustryBDCGroupDescrENShort
			,IndustryBDCGroupDescrFRShort = src.IndustryBDCGroupDescrFRShort
			,IndustryMarketingGroupCode = src.IndustryMarketingGroupCode
			,IndustryMarketingGroupDescrEN = src.IndustryMarketingGroupDescrEN
			,IndustryMarketingGroupDescrFR = src.IndustryMarketingGroupDescrFR
			,IndustryAnalytixGroupCode = src.IndustryAnalytixGroupCode
			,IndustryAnalytixGroupDescrEN = src.IndustryAnalytixGroupDescrEN
			,IndustryAnalytixGroupDescrFR = src.IndustryAnalytixGroupDescrFR
			,IndustryFinanceGroupCode = src.IndustryFinanceGroupCode
			,IndustryFinanceGroupDescrEN = src.IndustryFinanceGroupDescrEN
			,IndustryFinanceGroupDescrFR = src.IndustryFinanceGroupDescrFR
			,NAICSL5Code = src.NAICSL5Code
			,NAICSL5DescrEN = src.NAICSL5DescrEN
			,NAICSL5DescrFR = src.NAICSL5DescrFR
			,NAICSL4Code = src.NAICSL4Code
			,NAICSL4DescrEN = src.NAICSL4DescrEN
			,NAICSL4DescrFR = src.NAICSL4DescrFR
			,NAICSL3Code = src.NAICSL3Code
			,NAICSL3DescrEN = src.NAICSL3DescrEN
			,NAICSL3DescrFR = src.NAICSL3DescrFR
			,NAICSL2Code = src.NAICSL2Code
			,NAICSL2DescrEN = src.NAICSL2DescrEN
			,NAICSL2DescrFR = src.NAICSL2DescrFR
			,NAICSUSFlag = src.NAICSUSFlag
			,ModifiedDate = GETDATE()
			,ModifiedBy = src.ModifiedBy
			,RowSignature = src.RowSignature
    WHEN NOT MATCHED THEN
		INSERT (
			DimIndustryKey
			,IndustryCode
			,IndustryType
			,ExporterIndicator
			,IndustryDescrEN
			,IndustryDescrFR
			,IndustryBDCGroupCode
			,IndustryBDCGroupDescrEN
			,IndustryBDCGroupDescrFR
			,IndustryBDCGroupDescrENShort
			,IndustryBDCGroupDescrFRShort
			,IndustryMarketingGroupCode
			,IndustryMarketingGroupDescrEN
			,IndustryMarketingGroupDescrFR
			,IndustryAnalytixGroupCode
			,IndustryAnalytixGroupDescrEN
			,IndustryAnalytixGroupDescrFR
			,IndustryFinanceGroupCode
			,IndustryFinanceGroupDescrEN
			,IndustryFinanceGroupDescrFR
			,NAICSL5Code
			,NAICSL5DescrEN
			,NAICSL5DescrFR
			,NAICSL4Code
			,NAICSL4DescrEN
			,NAICSL4DescrFR
			,NAICSL3Code
			,NAICSL3DescrEN
			,NAICSL3DescrFR
			,NAICSL2Code
			,NAICSL2DescrEN
			,NAICSL2DescrFR
			,NAICSUSFlag
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
		)
		VALUES (
			src.DimIndustryKey
			,src.IndustryCode
			,src.IndustryType
			,src.ExporterIndicator
			,src.IndustryDescrEN
			,src.IndustryDescrFR
			,src.IndustryBDCGroupCode
			,src.IndustryBDCGroupDescrEN
			,src.IndustryBDCGroupDescrFR
			,src.IndustryBDCGroupDescrENShort
			,src.IndustryBDCGroupDescrFRShort
			,src.IndustryMarketingGroupCode
			,src.IndustryMarketingGroupDescrEN
			,src.IndustryMarketingGroupDescrFR
			,src.IndustryAnalytixGroupCode
			,src.IndustryAnalytixGroupDescrEN
			,src.IndustryAnalytixGroupDescrFR
			,src.IndustryFinanceGroupCode
			,src.IndustryFinanceGroupDescrEN
			,src.IndustryFinanceGroupDescrFR
			,src.NAICSL5Code
			,src.NAICSL5DescrEN
			,src.NAICSL5DescrFR
			,src.NAICSL4Code
			,src.NAICSL4DescrEN
			,src.NAICSL4DescrFR
			,src.NAICSL3Code
			,src.NAICSL3DescrEN
			,src.NAICSL3DescrFR
			,src.NAICSL2Code
			,src.NAICSL2DescrEN
			,src.NAICSL2DescrFR
			,src.NAICSUSFlag
			,GETDATE()
			,GETDATE()
			,src.ModifiedBy
			,src.RowSignature
		)
    OUTPUT $ACTION as ActionType, src.*;
    --SET IDENTITY_INSERT dbo.DimIndustry OFF
COMMIT TRANSACTION
