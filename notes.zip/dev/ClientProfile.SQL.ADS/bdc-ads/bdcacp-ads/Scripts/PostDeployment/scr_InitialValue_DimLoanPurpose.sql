﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-07
-- Description: Inserts initial values to DimLoanPurpose
-- =============================================
DECLARE @TMP_DimLoanPurpose TABLE
(
	[DimLoanPurposeKey]  [Integer]  NOT NULL,
	[LoanPurposeCode]    varchar(2)  NULL ,
	[LoanPurposeDescrEN] varchar(50)  NULL ,
	[LoanPurposeDescrFR] varchar(50)  NULL ,
	[LoanPurposeGroupId] varchar(2)  NULL ,
	[LoanPurposeGroupDescrEN] varchar(50)  NULL ,
	[LoanPurposeGroupDescrFR] varchar(50)  NULL ,
	[LoanPurposeGroupMarketingId] varchar(2)  NULL ,
	[LoanPurposeGroupMarketingDescrEN] varchar(50)  NULL ,
	[LoanPurposeGroupMarketingDescrFR] varchar(50)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL
)

INSERT INTO @TMP_DimLoanPurpose (
	DimLoanPurposeKey
	,LoanPurposeCode
	,LoanPurposeDescrEN
	,LoanPurposeDescrFR
	,LoanPurposeGroupId
	,LoanPurposeGroupDescrEN
    ,LoanPurposeGroupDescrFR
    ,LoanPurposeGroupMarketingId
    ,LoanPurposeGroupMarketingDescrEN
    ,LoanPurposeGroupMarketingDescrFR
    ,InsertedDate
    ,ModifiedDate
    ,ModifiedBy
    ,RowSignature)
VALUES (
	-1
    ,'NA'
    ,'N/A'
    ,'N/A'
    ,'NA'
    ,'N/A'
    ,'N/A'
    ,'NA'
    ,'N/A'
    ,'N/A'
    ,GETDATE()
    ,GETDATE()
    ,'Initial load'
    ,'0000000000000000000000000000000000000000'
)
BEGIN TRANSACTION
    --SET IDENTITY_INSERT dbo.DimLoanPurpose ON
    MERGE dbo.DimLoanPurpose AS dst
    USING @TMP_DimLoanPurpose as src
        ON dst.DimLoanPurposeKey = src.DimLoanPurposeKey
    WHEN MATCHED AND (dst.LoanPurposeCode <> src.LoanPurposeCode) THEN
        UPDATE SET
			LoanPurposeCode = src.LoanPurposeCode
			,LoanPurposeDescrEN = src.LoanPurposeDescrEN
			,LoanPurposeDescrFR = src.LoanPurposeDescrFR
			,LoanPurposeGroupId = src.LoanPurposeGroupId
			,LoanPurposeGroupDescrEN = src.LoanPurposeGroupDescrEN
			,LoanPurposeGroupDescrFR = src.LoanPurposeGroupDescrFR
			,LoanPurposeGroupMarketingId = src.LoanPurposeGroupMarketingId
			,LoanPurposeGroupMarketingDescrEN = src.LoanPurposeGroupMarketingDescrEN
			,LoanPurposeGroupMarketingDescrFR = src.LoanPurposeGroupMarketingDescrFR
			,ModifiedDate = GETDATE()
			,ModifiedBy = src.ModifiedBy
			,RowSignature = src.RowSignature
    WHEN NOT MATCHED THEN
		INSERT (
			DimLoanPurposeKey
			,LoanPurposeCode
			,LoanPurposeDescrEN
			,LoanPurposeDescrFR
			,LoanPurposeGroupId
			,LoanPurposeGroupDescrEN
			,LoanPurposeGroupDescrFR
			,LoanPurposeGroupMarketingId
			,LoanPurposeGroupMarketingDescrEN
			,LoanPurposeGroupMarketingDescrFR
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
		)
		VALUES (
			src.DimLoanPurposeKey
			,src.LoanPurposeCode
			,src.LoanPurposeDescrEN
			,src.LoanPurposeDescrFR
			,src.LoanPurposeGroupId
			,src.LoanPurposeGroupDescrEN
			,src.LoanPurposeGroupDescrFR
			,src.LoanPurposeGroupMarketingId
			,src.LoanPurposeGroupMarketingDescrEN
			,src.LoanPurposeGroupMarketingDescrFR
			,GETDATE()
			,GETDATE()
			,src.ModifiedBy
			,src.RowSignature
		)
    OUTPUT $ACTION as ActionType, src.*;
    --SET IDENTITY_INSERT dbo.DimLoanPurpose OFF
COMMIT TRANSACTION
