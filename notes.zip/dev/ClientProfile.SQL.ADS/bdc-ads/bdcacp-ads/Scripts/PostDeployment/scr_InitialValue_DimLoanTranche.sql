﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-27
-- Description: Inserts initial values to DimLoanTranche
-- =============================================
DECLARE @TMP_DimLoanTranche TABLE
(
	[DimLoanTrancheKey] [int] NOT NULL,
	[DimLoanTrancheDurableKey] [int] NOT NULL,
	[StartDateDimLoanInterestRateKey] [int] NULL,
	[EndDateDimLoanInterestRateKey] [int] NULL,
	[AccounNumber] [varchar](10) NULL,
	[TrancheNumber] [varchar](2) NULL,
	[LoanTrancheCurrentFlag] [bit] NULL,
	[InterestRate] [decimal](6, 5) NULL,
	[InterestRateChangeFlag] [bit] NULL,
	[BaseRate] [decimal](6, 5) NULL,
	[InterestRateVariance] [decimal](6, 5) NULL,
	[InterestRateVarianceChangeFlag] [bit] NULL,
	[InterestRatePlanCode] [varchar](20) NULL,
	[InterestRatePlanDescrEN] [varchar](20) NULL,
	[InterestRatePlanDescrFR] [varchar](20) NULL,
	[InterestRatePlanGroupId] [varchar](20) NULL,
	[InterestRatePlanGroupDescrEN] [varchar](20) NULL,
	[InterestRatePlanGroupDescrFR] [varchar](20) NULL,
	[CostofFundRate] [decimal](6, 5) NULL,
	[InsertedDate] [datetime] NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedBy] [varchar](20) NULL,
	[RowSignature] [varchar](40) NULL
)

INSERT INTO @TMP_DimLoanTranche (
	DimLoanTrancheKey
	,DimLoanTrancheDurableKey
	,StartDateDimLoanInterestRateKey
	,EndDateDimLoanInterestRateKey
	,AccounNumber
	,TrancheNumber
	,LoanTrancheCurrentFlag
	,InterestRate
	,InterestRateChangeFlag
	,BaseRate
	,InterestRateVariance
	,InterestRateVarianceChangeFlag
	,InterestRatePlanCode
	,InterestRatePlanDescrEN
	,InterestRatePlanDescrFR
	,InterestRatePlanGroupId
	,InterestRatePlanGroupDescrEN
	,InterestRatePlanGroupDescrFR
	,CostofFundRate
	,InsertedDate
	,ModifiedDate
	,ModifiedBy
	,RowSignature
)
VALUES (
	-1
	,-1
	,19000101
	,99991231
	,'N/A'
	,'NA'
	,0
	,NULL
	,0
	,NULL
	,NULL
	,0
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,NULL
    ,GETDATE()
    ,GETDATE()
    ,'Initial load'
    ,'0000000000000000000000000000000000000000'
)
BEGIN TRANSACTION
    SET IDENTITY_INSERT dbo.DimLoanTranche ON
    MERGE dbo.DimLoanTranche AS dst
    USING @TMP_DimLoanTranche as src
        ON dst.DimLoanTrancheKey = src.DimLoanTrancheKey
    WHEN MATCHED AND (dst.dimLoanTrancheDurableKey <> src.DimLoanTrancheDurableKey) THEN
        UPDATE SET
			DimLoanTrancheDurableKey = src.DimLoanTrancheDurableKey
			,StartDateDimLoanInterestRateKey = src.StartDateDimLoanInterestRateKey
			,EndDateDimLoanInterestRateKey = src.EndDateDimLoanInterestRateKey
			,AccounNumber = src.AccounNumber
			,TrancheNumber = src.TrancheNumber
			,LoanTrancheCurrentFlag = src.LoanTrancheCurrentFlag
			,InterestRate = src.InterestRate
			,InterestRateChangeFlag = src.InterestRateChangeFlag
			,BaseRate = src.BaseRate
			,InterestRateVariance = src.InterestRateVariance
			,InterestRateVarianceChangeFlag = src.InterestRateVarianceChangeFlag
			,InterestRatePlanCode = src.InterestRatePlanCode
			,InterestRatePlanDescrEN = src.InterestRatePlanDescrEN
			,InterestRatePlanDescrFR = src.InterestRatePlanDescrFR
			,InterestRatePlanGroupId = src.InterestRatePlanGroupId
			,InterestRatePlanGroupDescrEN = src.InterestRatePlanGroupDescrEN
			,InterestRatePlanGroupDescrFR = src.InterestRatePlanGroupDescrFR
			,CostofFundRate = src.CostofFundRate
			,InsertedDate = src.InsertedDate
			,ModifiedDate = src.ModifiedDate
			,ModifiedBy = src.ModifiedBy
			,RowSignature = src.RowSignature
    WHEN NOT MATCHED THEN
		INSERT (
			DimLoanTrancheKey
			,DimLoanTrancheDurableKey
			,StartDateDimLoanInterestRateKey
			,EndDateDimLoanInterestRateKey
			,AccounNumber
			,TrancheNumber
			,LoanTrancheCurrentFlag
			,InterestRate
			,InterestRateChangeFlag
			,BaseRate
			,InterestRateVariance
			,InterestRateVarianceChangeFlag
			,InterestRatePlanCode
			,InterestRatePlanDescrEN
			,InterestRatePlanDescrFR
			,InterestRatePlanGroupId
			,InterestRatePlanGroupDescrEN
			,InterestRatePlanGroupDescrFR
			,CostofFundRate
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
		)
		VALUES (
			src.DimLoanTrancheKey
			,src.DimLoanTrancheDurableKey
			,src.StartDateDimLoanInterestRateKey
			,src.EndDateDimLoanInterestRateKey
			,src.AccounNumber
			,src.TrancheNumber
			,src.LoanTrancheCurrentFlag
			,src.InterestRate
			,src.InterestRateChangeFlag
			,src.BaseRate
			,src.InterestRateVariance
			,src.InterestRateVarianceChangeFlag
			,src.InterestRatePlanCode
			,src.InterestRatePlanDescrEN
			,src.InterestRatePlanDescrFR
			,src.InterestRatePlanGroupId
			,src.InterestRatePlanGroupDescrEN
			,src.InterestRatePlanGroupDescrFR
			,src.CostofFundRate
			,src.InsertedDate
			,src.ModifiedDate
			,src.ModifiedBy
			,src.RowSignature
		)
    OUTPUT $ACTION as ActionType, src.*;
    SET IDENTITY_INSERT dbo.DimLoanTranche OFF
COMMIT TRANSACTION
