﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

--:r .\scr_InitialValue_DimDate.sql

:r .\scr_InitialValue_DimCustomer.sql
:r .\scr_InitialValue_DimIndustry.sql
:r .\scr_InitialValue_DimLineOfBusiness.sql
:r .\scr_InitialValue_DimLoan.sql
:r .\scr_InitialValue_DimLoanAtOrigination.sql
:r .\scr_InitialValue_DimLoanCancellationReason.sql
:r .\scr_InitialValue_DimLoanPurpose.sql
:r .\scr_InitialValue_DimLoanSolutionGrouping.sql
:r .\scr_InitialValue_DimLoanTranche.sql
:r .\scr_InitialValue_DimNewRepeatBusiness.sql
:r .\scr_InitialValue_DimOperatingUnit.sql
:r .\scr_InitialValue_DimOriginatingUnit.sql
:r .\scr_InitialValue_DimSourceOfReference.sql
