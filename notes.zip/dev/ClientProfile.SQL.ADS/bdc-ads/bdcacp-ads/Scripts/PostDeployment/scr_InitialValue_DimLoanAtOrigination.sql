﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-16
-- Description: Inserts initial values to DimLoanAtOrigination
-- =============================================
DECLARE @TMP_DimLoanAtOrigination TABLE
(
	[DimLoanAtOriginationDurableKey] [Integer]  NOT NULL ,
	[AccountNumber]      char(8)  NULL ,
	[AbacusNumber]       char(6)  NULL ,
	[MultipleNumber]     char(2)  NULL ,
	[OpportunityId]      [Integer] ,
	[FinancingProductId] [Integer] ,
	[LoanAuthorizationDate] datetime  NULL ,
	[LoanAuthorizationDateBooked] char(18)  NULL ,
	[AcceptanceDate]     datetime  NULL ,
	[TotalCommitmentCloselyRelatedAtAuthorization] integer  NULL ,
	[LoanMultipleTypeCode] varchar(20)  NULL ,
	[LoanMultipleTypeDescrEN] varchar(20)  NULL ,
	[LoanMultipleTypeDescrFR] varchar(20)  NULL ,
	[ExportExpansionCode] varchar(20)  NULL ,
	[ExportExpansionCodeDescrFR] varchar(20)  NULL ,
	[ExportExpansionCodeDescrEN] varchar(20)  NULL ,
	[ExportFlagLoan]     bit  NULL ,
	[ProcessTypeCode]    varchar(20)  NULL ,
	[ProcessTypeDescrEN] varchar(20)  NULL ,
	[ProcessTypeDescrFR] varchar(20)  NULL ,
	[StudentBusinessLoanFlag] bit  NULL ,
	[ProductIntiativeTypeCode] varchar(10)  NULL ,
	[ProductIntiativeTypeDescrEN] varchar(50)  NULL ,
	[ProductIntiativeTypeDescrFR] varchar(50)  NULL ,
	[AlliancePortfolioGLCode] varchar(20)  NULL ,
	[AlliancePortfolioGLDescrEN] varchar(100)  NULL ,
	[AlliancePortfolioGLDescrFR] varchar(100)  NULL ,
	[AdministrativeTypeCode] varchar(10)  NULL ,
	[AdministrativeTypeDescrEN] varchar(50)  NULL ,
	[AdministrativeTypeDescrFR] varchar(50)  NULL ,
	[AlliancePortfolioCode] varchar(10)  NULL ,
	[AlliancePortfolioDescrEN] varchar(50)  NULL ,
	[AlliancePortfolioDescrFR] varchar(50)  NULL ,
	[LoanProductCode]    varchar(10)  NULL ,
	[LoanProductDescrEN] varchar(50)  NULL ,
	[LoanProductDescrFR] varchar(50)  NULL ,
	[OverallRiskRating]  integer  NULL ,
	[OverallRiskOverriddenRating] decimal(5,1)  NULL ,
	[OverallRiskRatingSuggested] decimal(5,1)  NULL ,
	[OverallRiskRatingSuggestedBase] decimal(5,1)  NULL ,
	[OverriddenFlag]     bit  NULL ,
	[FinancialStrengthFactorRating] integer  NULL ,
	[FinancialStrengthFactorRatingSuggested] decimal(5,1)  NULL ,
	[FinancialFlexibilityFactorRating] integer  NULL ,
	[FinancialFlexibilityFactorRatingSuggested] decimal(5,1)  NULL ,
	[CompetitiveStrengthFactorRating] integer  NULL ,
	[CompetitiveStrengthFactorRatingSuggested] decimal(5,1)  NULL ,
	[ManagementFactorRating] integer  NULL ,
	[ManagementFactorRatingSuggested] decimal(5,1)  NULL ,
	[BeaconScore]        [Integer] ,
	[CreditScore]        [Integer] ,
	[ProbabilityOfDowngradingToImpairedPctFinal] decimal(5,4)  NULL ,
	[ProbabilityOfDowngradingToImpairedOverriddenPct] decimal(5,4)  NULL ,
	[ProbabilityOfDowngradingToImpairedSuggestedPct] decimal(5,4)  NULL ,
	[ProbabilityOfDowngradingBasePct] decimal(5,4)  NULL ,
	[ProbabilityOfDowngradingAdjustmentCRCommitmentSize] decimal(5,4)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL
)

INSERT INTO @TMP_DimLoanAtOrigination (
	DimLoanAtOriginationDurableKey
	,AccountNumber
	,AbacusNumber
	,MultipleNumber
	,OpportunityId
	,FinancingProductId
	,LoanAuthorizationDate
	,LoanAuthorizationDateBooked
	,AcceptanceDate
	,TotalCommitmentCloselyRelatedAtAuthorization
	,LoanMultipleTypeCode
	,LoanMultipleTypeDescrEN
	,LoanMultipleTypeDescrFR
	,ExportExpansionCode
	,ExportExpansionCodeDescrFR
	,ExportExpansionCodeDescrEN
	,ExportFlagLoan
	,ProcessTypeCode
	,ProcessTypeDescrEN
	,ProcessTypeDescrFR
	,StudentBusinessLoanFlag
	,ProductIntiativeTypeCode
	,ProductIntiativeTypeDescrEN
	,ProductIntiativeTypeDescrFR
	,AlliancePortfolioGLCode
	,AlliancePortfolioGLDescrEN
	,AlliancePortfolioGLDescrFR
	,AdministrativeTypeCode
	,AdministrativeTypeDescrEN
	,AdministrativeTypeDescrFR
	,AlliancePortfolioCode
	,AlliancePortfolioDescrEN
	,AlliancePortfolioDescrFR
	,LoanProductCode
	,LoanProductDescrEN
	,LoanProductDescrFR
	,OverallRiskRating
	,OverallRiskOverriddenRating
	,OverallRiskRatingSuggested
	,OverallRiskRatingSuggestedBase
	,OverriddenFlag
	,FinancialStrengthFactorRating
	,FinancialStrengthFactorRatingSuggested
	,FinancialFlexibilityFactorRating
	,FinancialFlexibilityFactorRatingSuggested
	,CompetitiveStrengthFactorRating
	,CompetitiveStrengthFactorRatingSuggested
	,ManagementFactorRating
	,ManagementFactorRatingSuggested
	,BeaconScore
	,CreditScore
	,ProbabilityOfDowngradingToImpairedPctFinal
	,ProbabilityOfDowngradingToImpairedOverriddenPct
	,ProbabilityOfDowngradingToImpairedSuggestedPct
	,ProbabilityOfDowngradingBasePct
	,ProbabilityOfDowngradingAdjustmentCRCommitmentSize
	,InsertedDate
	,ModifiedDate
	,ModifiedBy
	,RowSignature
)
VALUES (
	-1
	,'N/A'
	,'N/A'
	,'NA'
	,0
	,0
	,NULL
	,'N/A'
	,NULL
	,0
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,0
	,'N/A'
	,'N/A'
	,'N/A'
	,0
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,'N/A'
	,0
	,NULL
	,NULL
	,NULL
	,0
	,0
	,NULL
	,0
	,0
	,0
	,NULL
	,0
	,NULL
	,0
	,0
	,NULL
	,NULL
	,NULL
	,NULL
	,NULL
    ,GETDATE()
    ,GETDATE()
    ,'Initial load'
    ,'0000000000000000000000000000000000000000'
)
BEGIN TRANSACTION
    --SET IDENTITY_INSERT dbo.DimLoanAtOrigination ON
    MERGE dbo.DimLoanAtOrigination AS dst
    USING @TMP_DimLoanAtOrigination as src
        ON dst.DimLoanAtOriginationDurableKey = src.DimLoanAtOriginationDurableKey
    WHEN MATCHED AND (dst.AccountNumber <> src.AccountNumber) THEN
        UPDATE SET
			AccountNumber = src.AccountNumber
			,AbacusNumber = src.AbacusNumber
			,MultipleNumber = src.MultipleNumber
			,OpportunityId = src.OpportunityId
			,FinancingProductId = src.FinancingProductId
			,LoanAuthorizationDate = src.LoanAuthorizationDate
			,LoanAuthorizationDateBooked = src.LoanAuthorizationDateBooked
			,AcceptanceDate = src.AcceptanceDate
			,TotalCommitmentCloselyRelatedAtAuthorization = src.TotalCommitmentCloselyRelatedAtAuthorization
			,LoanMultipleTypeCode = src.LoanMultipleTypeCode
			,LoanMultipleTypeDescrEN = src.LoanMultipleTypeDescrEN
			,LoanMultipleTypeDescrFR = src.LoanMultipleTypeDescrFR
			,ExportExpansionCode = src.ExportExpansionCode
			,ExportExpansionCodeDescrFR = src.ExportExpansionCodeDescrFR
			,ExportExpansionCodeDescrEN = src.ExportExpansionCodeDescrEN
			,ExportFlagLoan = src.ExportFlagLoan
			,ProcessTypeCode = src.ProcessTypeCode
			,ProcessTypeDescrEN = src.ProcessTypeDescrEN
			,ProcessTypeDescrFR = src.ProcessTypeDescrFR
			,StudentBusinessLoanFlag = src.StudentBusinessLoanFlag
			,ProductIntiativeTypeCode = src.ProductIntiativeTypeCode
			,ProductIntiativeTypeDescrEN = src.ProductIntiativeTypeDescrEN
			,ProductIntiativeTypeDescrFR = src.ProductIntiativeTypeDescrFR
			,AlliancePortfolioGLCode = src.AlliancePortfolioGLCode
			,AlliancePortfolioGLDescrEN = src.AlliancePortfolioGLDescrEN
			,AlliancePortfolioGLDescrFR = src.AlliancePortfolioGLDescrFR
			,AdministrativeTypeCode = src.AdministrativeTypeCode
			,AdministrativeTypeDescrEN = src.AdministrativeTypeDescrEN
			,AdministrativeTypeDescrFR = src.AdministrativeTypeDescrFR
			,AlliancePortfolioCode = src.AlliancePortfolioCode
			,AlliancePortfolioDescrEN = src.AlliancePortfolioDescrEN
			,AlliancePortfolioDescrFR = src.AlliancePortfolioDescrFR
			,LoanProductCode = src.LoanProductCode
			,LoanProductDescrEN = src.LoanProductDescrEN
			,LoanProductDescrFR = src.LoanProductDescrFR
			,OverallRiskRating = src.OverallRiskRating
			,OverallRiskOverriddenRating = src.OverallRiskOverriddenRating
			,OverallRiskRatingSuggested = src.OverallRiskRatingSuggested
			,OverallRiskRatingSuggestedBase = src.OverallRiskRatingSuggestedBase
			,OverriddenFlag = src.OverriddenFlag
			,FinancialStrengthFactorRating = src.FinancialStrengthFactorRating
			,FinancialStrengthFactorRatingSuggested = src.FinancialStrengthFactorRatingSuggested
			,FinancialFlexibilityFactorRating = src.FinancialFlexibilityFactorRating
			,FinancialFlexibilityFactorRatingSuggested = src.FinancialFlexibilityFactorRatingSuggested
			,CompetitiveStrengthFactorRating = src.CompetitiveStrengthFactorRating
			,CompetitiveStrengthFactorRatingSuggested = src.CompetitiveStrengthFactorRatingSuggested
			,ManagementFactorRating = src.ManagementFactorRating
			,ManagementFactorRatingSuggested = src.ManagementFactorRatingSuggested
			,BeaconScore = src.BeaconScore
			,CreditScore = src.CreditScore
			,ProbabilityOfDowngradingToImpairedPctFinal = src.ProbabilityOfDowngradingToImpairedPctFinal
			,ProbabilityOfDowngradingToImpairedOverriddenPct = src.ProbabilityOfDowngradingToImpairedOverriddenPct
			,ProbabilityOfDowngradingToImpairedSuggestedPct = src.ProbabilityOfDowngradingToImpairedSuggestedPct
			,ProbabilityOfDowngradingBasePct = src.ProbabilityOfDowngradingBasePct
			,ProbabilityOfDowngradingAdjustmentCRCommitmentSize = src.ProbabilityOfDowngradingAdjustmentCRCommitmentSize
			,ModifiedDate = GETDATE()
			,ModifiedBy = src.ModifiedBy
			,RowSignature = src.RowSignature
    WHEN NOT MATCHED THEN
		INSERT (
			DimLoanAtOriginationDurableKey
			,AccountNumber
			,AbacusNumber
			,MultipleNumber
			,OpportunityId
			,FinancingProductId
			,LoanAuthorizationDate
			,LoanAuthorizationDateBooked
			,AcceptanceDate
			,TotalCommitmentCloselyRelatedAtAuthorization
			,LoanMultipleTypeCode
			,LoanMultipleTypeDescrEN
			,LoanMultipleTypeDescrFR
			,ExportExpansionCode
			,ExportExpansionCodeDescrFR
			,ExportExpansionCodeDescrEN
			,ExportFlagLoan
			,ProcessTypeCode
			,ProcessTypeDescrEN
			,ProcessTypeDescrFR
			,StudentBusinessLoanFlag
			,ProductIntiativeTypeCode
			,ProductIntiativeTypeDescrEN
			,ProductIntiativeTypeDescrFR
			,AlliancePortfolioGLCode
			,AlliancePortfolioGLDescrEN
			,AlliancePortfolioGLDescrFR
			,AdministrativeTypeCode
			,AdministrativeTypeDescrEN
			,AdministrativeTypeDescrFR
			,AlliancePortfolioCode
			,AlliancePortfolioDescrEN
			,AlliancePortfolioDescrFR
			,LoanProductCode
			,LoanProductDescrEN
			,LoanProductDescrFR
			,OverallRiskRating
			,OverallRiskOverriddenRating
			,OverallRiskRatingSuggested
			,OverallRiskRatingSuggestedBase
			,OverriddenFlag
			,FinancialStrengthFactorRating
			,FinancialStrengthFactorRatingSuggested
			,FinancialFlexibilityFactorRating
			,FinancialFlexibilityFactorRatingSuggested
			,CompetitiveStrengthFactorRating
			,CompetitiveStrengthFactorRatingSuggested
			,ManagementFactorRating
			,ManagementFactorRatingSuggested
			,BeaconScore
			,CreditScore
			,ProbabilityOfDowngradingToImpairedPctFinal
			,ProbabilityOfDowngradingToImpairedOverriddenPct
			,ProbabilityOfDowngradingToImpairedSuggestedPct
			,ProbabilityOfDowngradingBasePct
			,ProbabilityOfDowngradingAdjustmentCRCommitmentSize
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
		)
		VALUES (
			src.DimLoanAtOriginationDurableKey
			,src.AccountNumber
			,src.AbacusNumber
			,src.MultipleNumber
			,src.OpportunityId
			,src.FinancingProductId
			,src.LoanAuthorizationDate
			,src.LoanAuthorizationDateBooked
			,src.AcceptanceDate
			,src.TotalCommitmentCloselyRelatedAtAuthorization
			,src.LoanMultipleTypeCode
			,src.LoanMultipleTypeDescrEN
			,src.LoanMultipleTypeDescrFR
			,src.ExportExpansionCode
			,src.ExportExpansionCodeDescrFR
			,src.ExportExpansionCodeDescrEN
			,src.ExportFlagLoan
			,src.ProcessTypeCode
			,src.ProcessTypeDescrEN
			,src.ProcessTypeDescrFR
			,src.StudentBusinessLoanFlag
			,src.ProductIntiativeTypeCode
			,src.ProductIntiativeTypeDescrEN
			,src.ProductIntiativeTypeDescrFR
			,src.AlliancePortfolioGLCode
			,src.AlliancePortfolioGLDescrEN
			,src.AlliancePortfolioGLDescrFR
			,src.AdministrativeTypeCode
			,src.AdministrativeTypeDescrEN
			,src.AdministrativeTypeDescrFR
			,src.AlliancePortfolioCode
			,src.AlliancePortfolioDescrEN
			,src.AlliancePortfolioDescrFR
			,src.LoanProductCode
			,src.LoanProductDescrEN
			,src.LoanProductDescrFR
			,src.OverallRiskRating
			,src.OverallRiskOverriddenRating
			,src.OverallRiskRatingSuggested
			,src.OverallRiskRatingSuggestedBase
			,src.OverriddenFlag
			,src.FinancialStrengthFactorRating
			,src.FinancialStrengthFactorRatingSuggested
			,src.FinancialFlexibilityFactorRating
			,src.FinancialFlexibilityFactorRatingSuggested
			,src.CompetitiveStrengthFactorRating
			,src.CompetitiveStrengthFactorRatingSuggested
			,src.ManagementFactorRating
			,src.ManagementFactorRatingSuggested
			,src.BeaconScore
			,src.CreditScore
			,src.ProbabilityOfDowngradingToImpairedPctFinal
			,src.ProbabilityOfDowngradingToImpairedOverriddenPct
			,src.ProbabilityOfDowngradingToImpairedSuggestedPct
			,src.ProbabilityOfDowngradingBasePct
			,src.ProbabilityOfDowngradingAdjustmentCRCommitmentSize
			,GETDATE()
			,GETDATE()
			,src.ModifiedBy
			,src.RowSignature
		)
    OUTPUT $ACTION as ActionType, src.*;
    --SET IDENTITY_INSERT dbo.DimLoanAtOrigination OFF
COMMIT TRANSACTION
