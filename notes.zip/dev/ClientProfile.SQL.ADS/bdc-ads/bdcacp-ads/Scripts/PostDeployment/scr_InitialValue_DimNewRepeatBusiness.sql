﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-30
-- Description: Inserts initial values to DimNewRepeatBusiness
-- =============================================
DECLARE @TMP_DimNewRepeatBusiness TABLE
(
	[DimNewRepeatBusinessKey] integer  NOT NULL ,
	[NewRepeatLoanTypeCode] [Integer] ,
	[NewRepeatLoanTypeDescrEN] varchar(50)  NULL ,
	[NewRepeatLoanTypeDescrFR] varchar(50)  NULL ,
	[NewRepeatGroupCode] [Integer] ,
	[NewRepeatGroupDescrEN] varchar(50)  NULL ,
	[NewRepeatGroupDescrFR] varchar(50)  NULL ,
	[NewRepeatSubGroupCode] [Integer] ,
	[NewRepeatSubGroupDescrEN] varchar(50)  NULL ,
	[NewRepeatSubGroupDescrFR] varchar(50)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL
)

INSERT INTO @TMP_DimNewRepeatBusiness (
	DimNewRepeatBusinessKey
	,NewRepeatLoanTypeCode
	,NewRepeatLoanTypeDescrEN
	,NewRepeatLoanTypeDescrFR
	,NewRepeatGroupCode
	,NewRepeatGroupDescrEN
	,NewRepeatGroupDescrFR
	,NewRepeatSubGroupCode
	,NewRepeatSubGroupDescrEN
	,NewRepeatSubGroupDescrFR
	,InsertedDate
	,ModifiedDate
	,ModifiedBy
	,RowSignature
)
VALUES (
	-1
	,0
	,'N/A'
	,'N/A'
	,0
	,'N/A'
	,'N/A'
	,0
	,'N/A'
	,'N/A'
    ,GETDATE()
    ,GETDATE()
    ,'Initial load'
    ,'0000000000000000000000000000000000000000'
)

BEGIN TRANSACTION
    --SET IDENTITY_INSERT dbo.DimNewRepeatBusiness ON
    MERGE dbo.DimNewRepeatBusiness AS dst
    USING @TMP_DimNewRepeatBusiness as src
        ON dst.DimNewRepeatBusinessKey = src.DimNewRepeatBusinessKey
    WHEN MATCHED AND (dst.NewRepeatLoanTypeCode <> src.NewRepeatLoanTypeCode) THEN
        UPDATE SET
			NewRepeatLoanTypeCode = src.NewRepeatLoanTypeCode
			,NewRepeatLoanTypeDescrEN = src.NewRepeatLoanTypeDescrEN
			,NewRepeatLoanTypeDescrFR = src.NewRepeatLoanTypeDescrFR
			,NewRepeatGroupCode = src.NewRepeatGroupCode
			,NewRepeatGroupDescrEN = src.NewRepeatGroupDescrEN
			,NewRepeatGroupDescrFR = src.NewRepeatGroupDescrFR
			,NewRepeatSubGroupCode = src.NewRepeatSubGroupCode
			,NewRepeatSubGroupDescrEN = src.NewRepeatSubGroupDescrEN
			,NewRepeatSubGroupDescrFR = src.NewRepeatSubGroupDescrFR
			,InsertedDate = src.InsertedDate
			,ModifiedDate = src.ModifiedDate
			,ModifiedBy = src.ModifiedBy
			,RowSignature  = src.RowSignature
    WHEN NOT MATCHED THEN
		INSERT (
			DimNewRepeatBusinessKey
			,NewRepeatLoanTypeCode
			,NewRepeatLoanTypeDescrEN
			,NewRepeatLoanTypeDescrFR
			,NewRepeatGroupCode
			,NewRepeatGroupDescrEN
			,NewRepeatGroupDescrFR
			,NewRepeatSubGroupCode
			,NewRepeatSubGroupDescrEN
			,NewRepeatSubGroupDescrFR
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
		)
		VALUES (
			src.DimNewRepeatBusinessKey
			,src.NewRepeatLoanTypeCode
			,src.NewRepeatLoanTypeDescrEN
			,src.NewRepeatLoanTypeDescrFR
			,src.NewRepeatGroupCode
			,src.NewRepeatGroupDescrEN
			,src.NewRepeatGroupDescrFR
			,src.NewRepeatSubGroupCode
			,src.NewRepeatSubGroupDescrEN
			,src.NewRepeatSubGroupDescrFR
			,src.InsertedDate
			,src.ModifiedDate
			,src.ModifiedBy
			,src.RowSignature
		)
    OUTPUT $ACTION as ActionType, src.*;
    --SET IDENTITY_INSERT dbo.DimNewRepeatBusiness OFF
COMMIT TRANSACTION
