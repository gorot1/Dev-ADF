﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-30
-- Description: Inserts initial values to DimSourceOfReference
-- =============================================
DECLARE @TMP_DimSourceOfReference TABLE
(
	[DimSourceOfReferenceKey] [Integer]  NOT NULL ,
	[SourceOfReferenceCode] varchar(10)  NULL ,
	[SourceOfReferenceDescrEN] varchar(50)  NULL ,
	[SourceOfReferenceDescrFR] varchar(50)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL
)

INSERT INTO @TMP_DimSourceOfReference (
	DimSourceOfReferenceKey
	,SourceOfReferenceCode
	,SourceOfReferenceDescrEN
	,SourceOfReferenceDescrFR
	,InsertedDate
	,ModifiedDate
	,ModifiedBy
	,RowSignature
)
VALUES (
	-1
	,'N/A'
	,'N/A'
	,'N/A'
    ,GETDATE()
    ,GETDATE()
    ,'Initial load'
    ,'0000000000000000000000000000000000000000'
)

BEGIN TRANSACTION
    --SET IDENTITY_INSERT dbo.DimSourceOfReference ON
    MERGE dbo.DimSourceOfReference AS dst
    USING @TMP_DimSourceOfReference as src
        ON dst.DimSourceOfReferenceKey = src.DimSourceOfReferenceKey
    WHEN MATCHED AND (dst.SourceOfReferenceCode <> src.SourceOfReferenceCode) THEN
        UPDATE SET
			SourceOfReferenceCode = src.SourceOfReferenceCode
			,SourceOfReferenceDescrEN = src.SourceOfReferenceDescrEN
			,SourceOfReferenceDescrFR = src.SourceOfReferenceDescrFR
			,InsertedDate = src.InsertedDate
			,ModifiedDate = src.ModifiedDate
			,ModifiedBy = src.ModifiedBy
			,RowSignature  = src.RowSignature
    WHEN NOT MATCHED THEN
		INSERT (
			DimSourceOfReferenceKey
			,SourceOfReferenceCode
			,SourceOfReferenceDescrEN
			,SourceOfReferenceDescrFR
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
		)
		VALUES (
			src.DimSourceOfReferenceKey
			,src.SourceOfReferenceCode
			,src.SourceOfReferenceDescrEN
			,src.SourceOfReferenceDescrFR
			,src.InsertedDate
			,src.ModifiedDate
			,src.ModifiedBy
			,src.RowSignature
		)
    OUTPUT $ACTION as ActionType, src.*;
    --SET IDENTITY_INSERT dbo.DimSourceOfReference OFF
COMMIT TRANSACTION
