﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-30
-- Description: Inserts initial values to DimLineOfBusiness
-- =============================================
DECLARE @TMP_DimLineOfBusiness TABLE
(
	[DimLineOfBusinessKey] integer  NOT NULL ,
	[LineOfBusinessCode] integer  NULL ,
	[LineOfBusinessDescrEN] varchar(50)  NULL ,
	[LineOfBusinessDescrFR] varchar(50)  NULL ,
	[InsertedDate]       datetime  NULL ,
	[ModifiedDate]       datetime  NULL ,
	[ModifiedBy]         varchar(50)  NULL ,
	[RowSignature]       varchar(40)  NULL
)

INSERT INTO @TMP_DimLineOfBusiness (
	DimLineOfBusinessKey
	,LineOfBusinessCode
	,LineOfBusinessDescrEN
	,LineOfBusinessDescrFR
	,InsertedDate
	,ModifiedDate
	,ModifiedBy
	,RowSignature
)
VALUES (
	-1
	,0
	,'N/A'
	,'N/A'
    ,GETDATE()
    ,GETDATE()
    ,'Initial load'
    ,'0000000000000000000000000000000000000000'
)

BEGIN TRANSACTION
    --SET IDENTITY_INSERT dbo.DimLineOfBusiness ON
    MERGE dbo.DimLineOfBusiness AS dst
    USING @TMP_DimLineOfBusiness as src
        ON dst.DimLineOfBusinessKey = src.DimLineOfBusinessKey
    WHEN MATCHED AND (dst.LineOfBusinessCode <> src.LineOfBusinessCode) THEN
        UPDATE SET
			LineOfBusinessCode = src.LineOfBusinessCode
			,LineOfBusinessDescrEN = src.LineOfBusinessDescrEN
			,LineOfBusinessDescrFR = src.LineOfBusinessDescrFR
			,InsertedDate = src.InsertedDate
			,ModifiedDate = src.ModifiedDate
			,ModifiedBy = src.ModifiedBy
			,RowSignature  = src.RowSignature
    WHEN NOT MATCHED THEN
		INSERT (
			DimLineOfBusinessKey
			,LineOfBusinessCode
			,LineOfBusinessDescrEN
			,LineOfBusinessDescrFR
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
		)
		VALUES (
			src.DimLineOfBusinessKey
			,src.LineOfBusinessCode
			,src.LineOfBusinessDescrEN
			,src.LineOfBusinessDescrFR
			,src.InsertedDate
			,src.ModifiedDate
			,src.ModifiedBy
			,src.RowSignature
		)
    OUTPUT $ACTION as ActionType, src.*;
    --SET IDENTITY_INSERT dbo.DimLineOfBusiness OFF
COMMIT TRANSACTION
