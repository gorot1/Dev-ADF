﻿CREATE TABLE [dbo].[DimWebAdInfo]
( 
	[WebAdInfoKey]		int  NOT NULL IDENTITY,
	[AdContent]		nvarchar(50)  NULL ,
	[AdKeyword]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[DimWebAdInfo]
       ADD CONSTRAINT [XPKDimWebAdInfo] PRIMARY KEY  CLUSTERED ([WebAdInfoKey] ASC)
GO
ALTER TABLE [dbo].[DimWebAdInfo]
       ADD CONSTRAINT [XAK1DimWebAdInfo] UNIQUE ([AdContent] ASC, [AdKeyword] ASC)