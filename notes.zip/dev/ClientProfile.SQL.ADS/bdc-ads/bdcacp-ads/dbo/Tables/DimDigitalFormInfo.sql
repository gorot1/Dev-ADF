﻿CREATE TABLE [dbo].[DimDigitalFormInfo]
( 
	[DigitalFormInfoKey]		int  NOT NULL IDENTITY,
	[FormName]		nvarchar(50)  NULL ,
	[FormType]		nvarchar(50)  NULL ,
	[FormTitle]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[DimDigitalFormInfo]
       ADD CONSTRAINT [XPKDimDigitalFormInfo] PRIMARY KEY  CLUSTERED ([DigitalFormInfoKey] ASC)
GO
ALTER TABLE [dbo].[DimDigitalFormInfo]
       ADD CONSTRAINT [XAK1DimDigitalFormInfo] UNIQUE ([FormName] ASC)