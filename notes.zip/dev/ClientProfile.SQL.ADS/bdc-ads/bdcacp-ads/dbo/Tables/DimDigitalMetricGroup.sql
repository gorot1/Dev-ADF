﻿CREATE TABLE [dbo].[DimDigitalMetricGroup]
( 
	[DigitalMetricGroupKey]		int  NOT NULL IDENTITY,
	[MetricSourceTableName]		nvarchar(50)  NULL ,
	[MetricGroupName]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[DimDigitalMetricGroup]
       ADD CONSTRAINT [XPKDimDigitalMetricGroup] PRIMARY KEY  CLUSTERED ([DigitalMetricGroupKey] ASC)
GO
ALTER TABLE [dbo].[DimDigitalMetricGroup]
       ADD CONSTRAINT [XAK1DimDigitalMetricGroup] UNIQUE ([MetricSourceTableName] ASC)