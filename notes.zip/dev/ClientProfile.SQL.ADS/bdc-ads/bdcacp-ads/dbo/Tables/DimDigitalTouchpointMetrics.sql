﻿CREATE TABLE [dbo].[DimDigitalTouchpointMetrics]
( 
	[DigitalTouchpointMetricKey]		int  NOT NULL IDENTITY,
	[MetricName1]		nvarchar(50)  NULL ,
	[MetricName2]		nvarchar(50)  NULL ,
	[MetricName3]		nvarchar(50)  NULL ,
	[MetricName4]		nvarchar(50)  NULL ,
	[MetricName5]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[DimDigitalTouchpointMetrics]
       ADD CONSTRAINT [XPKDimDigitalTouchpointMetrics] PRIMARY KEY  CLUSTERED ([DigitalTouchpointMetricKey] ASC)
GO
ALTER TABLE [dbo].[DimDigitalTouchpointMetrics]
       ADD CONSTRAINT [XAK1DimDigitalTouchpointMetrics] UNIQUE ([MetricName1] ASC, [MetricName2] ASC, [MetricName3] ASC, [MetricName4] ASC, [MetricName5] ASC)