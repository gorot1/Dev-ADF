﻿CREATE TABLE [dbo].[DimDigitalMetricInfo]
( 
	[DigitalMetricInfoKey]		int  NOT NULL IDENTITY,
	[MetricName]		nvarchar(50)  NULL ,
	[MetricDescription]		nvarchar(50)  NULL ,
	[MetricUnit]		nvarchar(50)  NULL ,
	[MetricCriteria]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[DimDigitalMetricInfo]
       ADD CONSTRAINT [XPKDimDigitalMetricInfo] PRIMARY KEY  CLUSTERED ([DigitalMetricInfoKey] ASC)
GO
ALTER TABLE [dbo].[DimDigitalMetricInfo]
       ADD CONSTRAINT [XAK1DimDigitalMetricInfo] UNIQUE ([MetricName] ASC, [MetricUnit] ASC, [MetricCriteria] ASC)