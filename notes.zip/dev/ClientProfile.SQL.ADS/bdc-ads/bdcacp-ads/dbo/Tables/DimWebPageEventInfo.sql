﻿CREATE TABLE [dbo].[DimWebPageEventInfo]
( 
	[WebPageEventInfoKey]		int  NOT NULL IDENTITY,
	[EventCategory]		nvarchar(50)  NULL ,
	[EventAction]		nvarchar(50)  NULL ,
	[EventLabel]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[DimWebPageEventInfo]
       ADD CONSTRAINT [XPKDimWebPageEventInfo] PRIMARY KEY  CLUSTERED ([WebPageEventInfoKey] ASC)
GO
ALTER TABLE [dbo].[DimWebPageEventInfo]
       ADD CONSTRAINT [XAK1DimWebPageEventInfo] UNIQUE ([EventCategory] ASC, [EventAction] ASC, [EventLabel] ASC)