﻿CREATE TABLE [dbo].[DimWebContent]
( 
	[WebContentKey]		int  NOT NULL IDENTITY,
	[ContentTypeName]		nvarchar(50)  NULL ,
	[ContentGroupName]		nvarchar(50)  NULL ,
	[ContentDetails]		nvarchar(50)  NULL ,
	[ContentLanguage]		nvarchar(50)  NULL ,
	[ContentTitle]		nvarchar(50)  NULL ,
	[ContentSeoTitle]		nvarchar(50)  NULL ,
	[ContentName]		nvarchar(50)  NULL ,
	[ContentCreatedDateKey]		int  NULL ,
	[ContentLastUpdateDateKey]		int  NULL ,
	[ContentIsGated]		bit  NULL ,
	[ContentIsCovid19]		bit  NULL ,
	[ContentIsSmeResearch]		bit  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[DimWebContent]
       ADD CONSTRAINT [FK_DimDate_DimWebContent_ContentCreatedDateKey] FOREIGN KEY ([ContentCreatedDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[DimWebContent]
       ADD CONSTRAINT [FK_DimDate_DimWebContent_ContentLastUpdateDateKey] FOREIGN KEY ([ContentLastUpdateDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[DimWebContent]
       ADD CONSTRAINT [XPKDimWebContent] PRIMARY KEY  CLUSTERED ([WebContentKey] ASC)
GO
ALTER TABLE [dbo].[DimWebContent]
       ADD CONSTRAINT [XAK1DimWebContent] UNIQUE ([ContentTypeName] ASC, [ContentGroupName] ASC, [ContentDetails] ASC, [ContentLanguage] ASC, [ContentTitle] ASC, [ContentSeoTitle] ASC, [ContentName] ASC)