﻿CREATE TABLE [dbo].[DimDigitalTouchpointMetadata]
( 
	[DigitalTouchpointMetadataKey]		int  NOT NULL IDENTITY,
	[DigitalChannelKey]		int  NULL ,
	[TouchpointAccountId]		int  NULL ,
	[TouchpointProfileId]		int  NULL ,
	[TouchpointSegment]		int  NULL ,
	[DigitalDeviceCategoryKey]		int  NULL ,
	[TouchpointCityId]		int  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[DimDigitalTouchpointMetadata]
       ADD CONSTRAINT [FK_DimDigitalChannel_DimDigitalTouchpointMetadata_DigitalChannelkey] FOREIGN KEY ([DigitalChannelkey]) REFERENCES [dbo].[DimDigitalChannel]([DigitalChannelkey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[DimDigitalTouchpointMetadata]
       ADD CONSTRAINT [FK_DimDigitalDeviceCategory_DimDigitalTouchpointMetadata_DigitalDeviceCategorykey] FOREIGN KEY ([DigitalDeviceCategorykey]) REFERENCES [dbo].[DimDigitalDeviceCategory]([DigitalDeviceCategorykey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[DimDigitalTouchpointMetadata]
       ADD CONSTRAINT [XPKDimDigitalTouchpointMetadata] PRIMARY KEY  CLUSTERED ([DigitalTouchpointMetadataKey] ASC)
GO
ALTER TABLE [dbo].[DimDigitalTouchpointMetadata]
       ADD CONSTRAINT [XAK1DimDigitalTouchpointMetadata] UNIQUE ([DigitalChannelKey] ASC, [TouchpointAccountId] ASC, [TouchpointProfileId] ASC, [TouchpointSegment] ASC, [DigitalDeviceCategoryKey] ASC, [TouchpointCityId] ASC)