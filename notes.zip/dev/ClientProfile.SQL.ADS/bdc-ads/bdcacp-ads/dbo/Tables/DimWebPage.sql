﻿CREATE TABLE [dbo].[DimWebPage]
( 
	[WebPageKey]		int  NOT NULL IDENTITY,
	[PageFullPath]		nvarchar(50)  NULL ,
	[PageDomain]		nvarchar(50)  NULL ,
	[PageRelativePath]		nvarchar(50)  NULL ,
	[PageLevel1]		nvarchar(50)  NULL ,
	[PageLevel2]		nvarchar(50)  NULL ,
	[PageLevel3]		nvarchar(50)  NULL ,
	[PageLevel4]		nvarchar(50)  NULL ,
	[PageLevel5]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[DimWebPage]
       ADD CONSTRAINT [XPKDimWebPage] PRIMARY KEY  CLUSTERED ([WebPageKey] ASC)
GO
ALTER TABLE [dbo].[DimWebPage]
       ADD CONSTRAINT [XAK1DimWebPage] UNIQUE ([PageFullPath] ASC)