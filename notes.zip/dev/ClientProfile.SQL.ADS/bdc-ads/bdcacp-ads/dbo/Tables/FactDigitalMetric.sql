﻿CREATE TABLE [dbo].[FactDigitalMetric]
( 
	[DigitalMetricKey]		int  NOT NULL IDENTITY,
	[MetricStartDateKey]		int  NULL ,
	[MetricEndDateKey]		int  NULL ,
	[DigitalMetricGroupKey]		int  NULL ,
	[DigitalMetricInfoKey]		int  NULL ,
	[MetricRowKey]		int  NULL ,
	[MetricActualValue]		decimal(18,2)  NULL ,
	[MetricTargetValue]		decimal(18,2)  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[FactDigitalMetric]
       ADD CONSTRAINT [FK_DimDigitalMetricGroup_FactDigitalMetric_DigitalMetricGroupkey] FOREIGN KEY ([DigitalMetricGroupkey]) REFERENCES [dbo].[DimDigitalMetricGroup]([DigitalMetricGroupkey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactDigitalMetric]
       ADD CONSTRAINT [FK_DimDigitalMetricInfo_FactDigitalMetric_DigitalMetricInfokey] FOREIGN KEY ([DigitalMetricInfokey]) REFERENCES [dbo].[DimDigitalMetricInfo]([DigitalMetricInfokey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactDigitalMetric]
       ADD CONSTRAINT [FK_DimDate_FactDigitalMetric_MetricStartDateKey] FOREIGN KEY ([MetricStartDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactDigitalMetric]
       ADD CONSTRAINT [FK_DimDate_FactDigitalMetric_MetricEndDateKey] FOREIGN KEY ([MetricEndDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactDigitalMetric]
       ADD CONSTRAINT [XPKFactDigitalMetric] PRIMARY KEY  CLUSTERED ([DigitalMetricKey] ASC)
GO
ALTER TABLE [dbo].[FactDigitalMetric]
       ADD CONSTRAINT [XAK1FactDigitalMetric] UNIQUE ([MetricStartDateKey] ASC, [MetricEndDateKey] ASC, [DigitalMetricGroupKey] ASC, [DigitalMetricInfoKey] ASC, [MetricRowKey] ASC)