﻿CREATE TABLE [dbo].[FactDigitalForm]
( 
	[DigitalFormKey]		int  NOT NULL IDENTITY,
	[DigitalFormInfoKey]		int  NULL ,
	[FormCreationDateKey]		int  NULL ,
	[FormSubmissionDateKey]		int  NULL ,
	[FormLastModificationDateKey]		int  NULL ,
	[FormIndividualFirstName]		nvarchar(50)  NULL ,
	[FormIndividualLastName]		nvarchar(50)  NULL ,
	[FormBusinessName]		nvarchar(50)  NULL ,
	[FormRegion]		nvarchar(50)  NULL ,
	[FormEmail]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[FactDigitalForm]
       ADD CONSTRAINT [FK_DimDigitalFormInfo_FactDigitalForm_DigitalFormInfokey] FOREIGN KEY ([DigitalFormInfokey]) REFERENCES [dbo].[DimDigitalFormInfo]([DigitalFormInfokey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactDigitalForm]
       ADD CONSTRAINT [FK_DimDate_FactDigitalForm_FormCreationDateKey] FOREIGN KEY ([FormCreationDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactDigitalForm]
       ADD CONSTRAINT [FK_DimDate_FactDigitalForm_FormSubmissionDateKey] FOREIGN KEY ([FormSubmissionDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactDigitalForm]
       ADD CONSTRAINT [FK_DimDate_FactDigitalForm_FormLastModificationDateKey] FOREIGN KEY ([FormLastModificationDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactDigitalForm]
       ADD CONSTRAINT [XPKFactDigitalForm] PRIMARY KEY  CLUSTERED ([DigitalFormKey] ASC)
GO
ALTER TABLE [dbo].[FactDigitalForm]
       ADD CONSTRAINT [XAK1FactDigitalForm] UNIQUE ([DigitalFormInfoKey] ASC, [FormCreationDateKey] ASC, [FormSubmissionDateKey] ASC, [FormLastModificationDateKey] ASC, [FormIndividualFirstName] ASC, [FormIndividualLastName] ASC)