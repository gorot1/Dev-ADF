﻿CREATE TABLE [dbo].[FactDigitalTouchpoint]
( 
	[DigitalTouchpointKey]		int  NOT NULL IDENTITY,
	[TouchpointDateKey]		int  NULL ,
	[DigitalTouchpointGroupKey]		int  NULL ,
	[TouchpointRowKey]		int  NULL ,
	[DigitalTouchpointMetricKey]		int  NULL ,
	[DigitalTouchpointMetadataKey]		int  NULL ,
	[MetricValue1]		nvarchar(50)  NULL ,
	[MetricValue2]		nvarchar(50)  NULL ,
	[MetricValue3]		nvarchar(50)  NULL ,
	[MetricValue4]		nvarchar(50)  NULL ,
	[MetricValue5]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[FactDigitalTouchpoint]
       ADD CONSTRAINT [FK_DimDigitalTouchpointGroup_FactDigitalTouchpoint_DigitalTouchpointGroupkey] FOREIGN KEY ([DigitalTouchpointGroupkey]) REFERENCES [dbo].[DimDigitalTouchpointGroup]([DigitalTouchpointGroupkey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactDigitalTouchpoint]
       ADD CONSTRAINT [FK_DimDigitalTouchpointMetadata_FactDigitalTouchpoint_DigitalTouchpointMetadatakey] FOREIGN KEY ([DigitalTouchpointMetadatakey]) REFERENCES [dbo].[DimDigitalTouchpointMetadata]([DigitalTouchpointMetadatakey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactDigitalTouchpoint]
       ADD CONSTRAINT [FK_DimDigitalTouchpointMetrics_FactDigitalTouchpoint_DigitalTouchpointMetricKey] FOREIGN KEY ([DigitalTouchpointMetricKey]) REFERENCES [dbo].[DimDigitalTouchpointMetrics]([DigitalTouchpointMetrickey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactDigitalTouchpoint]
       ADD CONSTRAINT [FK_FactEmailsSent_FactDigitalTouchpoint_TouchpointRowKey] FOREIGN KEY ([TouchpointRowKey]) REFERENCES [dbo].[FactEmailsSent]([EmailsSentkey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactDigitalTouchpoint]
       ADD CONSTRAINT [FK_DimDate_FactDigitalTouchpoint_TouchpointDateKey] FOREIGN KEY ([TouchpointDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactDigitalTouchpoint]
       ADD CONSTRAINT [XPKFactDigitalTouchpoint] PRIMARY KEY  CLUSTERED ([DigitalTouchpointKey] ASC)
GO
ALTER TABLE [dbo].[FactDigitalTouchpoint]
       ADD CONSTRAINT [XAK1FactDigitalTouchpoint] UNIQUE ([TouchpointDateKey] ASC, [DigitalTouchpointGroupKey] ASC, [TouchpointRowKey] ASC, [DigitalTouchpointMetricKey] ASC, [DigitalTouchpointMetadataKey] ASC)