﻿CREATE TABLE [dbo].[FactWebAd]
( 
	[WebAdKey]		int  NOT NULL IDENTITY,
	[WebAdInfoKey]		int  NULL ,
	[AdStartDateKey]		int  NULL ,
	[DigitalTouchpointMetadataKey]		int  NULL ,
	[AdCost]		nvarchar(50)  NULL ,
	[AdClickCount]		int  NULL ,
	[AdImpressionCount]		int  NULL ,
	[AdSecondsOnPage]		int  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[FactWebAd]
       ADD CONSTRAINT [FK_DimDigitalTouchpointMetadata_FactWebAd_DigitalTouchpointMetadatakey] FOREIGN KEY ([DigitalTouchpointMetadatakey]) REFERENCES [dbo].[DimDigitalTouchpointMetadata]([DigitalTouchpointMetadatakey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebAd]
       ADD CONSTRAINT [FK_DimWebAdInfo_FactWebAd_WebAdInfokey] FOREIGN KEY ([WebAdInfokey]) REFERENCES [dbo].[DimWebAdInfo]([WebAdInfokey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebAd]
       ADD CONSTRAINT [FK_DimDate_FactWebAd_AdStartDateKey] FOREIGN KEY ([AdStartDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebAd]
       ADD CONSTRAINT [XPKFactWebAd] PRIMARY KEY  CLUSTERED ([WebAdKey] ASC)
GO
ALTER TABLE [dbo].[FactWebAd]
       ADD CONSTRAINT [XAK1FactWebAd] UNIQUE ([WebAdInfoKey] ASC, [AdStartDateKey] ASC, [DigitalTouchpointMetadataKey] ASC)