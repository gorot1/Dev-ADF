﻿CREATE TABLE [dbo].[FactWebPageView]
( 
	[WebPageViewKey]		int  NOT NULL IDENTITY,
	[WebPageKey]		int  NULL ,
	[PageViewDateKey]		int  NULL ,
	[DigitalTouchpointMetadataKey]		int  NULL ,
	[WebPageParameterGroupKey]		int  NULL ,
	[PageViewParameters]		nvarchar(50)  NULL ,
	[PageViewCount]		int  NULL ,
	[PageViewUniqueCount]		int  NULL ,
	[PageViewExits]		int  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[FactWebPageview]
       ADD CONSTRAINT [FK_DimDigitalTouchpointMetadata_FactWebPageview_DigitalTouchpointMetadatakey] FOREIGN KEY ([DigitalTouchpointMetadatakey]) REFERENCES [dbo].[DimDigitalTouchpointMetadata]([DigitalTouchpointMetadatakey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebPageview]
       ADD CONSTRAINT [FK_DimWebPage_FactWebPageview_WebPagekey] FOREIGN KEY ([WebPagekey]) REFERENCES [dbo].[DimWebPage]([WebPagekey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebPageview]
       ADD CONSTRAINT [FK_DimWebPageParameterGroup_FactWebPageview_WebPageParameterGroupkey] FOREIGN KEY ([WebPageParameterGroupkey]) REFERENCES [dbo].[DimWebPageParameterGroup]([WebPageParameterGroupkey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebPageview]
       ADD CONSTRAINT [FK_DimDate_FactWebPageview_PageviewDateKey] FOREIGN KEY ([PageviewDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebPageView]
       ADD CONSTRAINT [XPKFactWebPageView] PRIMARY KEY  CLUSTERED ([WebPageViewKey] ASC)
GO
ALTER TABLE [dbo].[FactWebPageView]
       ADD CONSTRAINT [XAK1FactWebPageView] UNIQUE ([WebPageKey] ASC, [PageViewDateKey] ASC, [DigitalTouchpointMetadataKey] ASC, [WebPageParameterGroupKey] ASC)