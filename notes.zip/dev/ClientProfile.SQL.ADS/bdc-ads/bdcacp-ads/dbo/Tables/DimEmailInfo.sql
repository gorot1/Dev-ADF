﻿CREATE TABLE [dbo].[DimEmailInfo]
( 
	[EmailInfoKey]		int  NOT NULL IDENTITY,
	[EmailName]		nvarchar(50)  NULL ,
	[EmailGroup]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[DimEmailInfo]
       ADD CONSTRAINT [XPKDimEmailInfo] PRIMARY KEY  CLUSTERED ([EmailInfoKey] ASC)
GO
ALTER TABLE [dbo].[DimEmailInfo]
       ADD CONSTRAINT [XAK1DimEmailInfo] UNIQUE ([EmailName] ASC)