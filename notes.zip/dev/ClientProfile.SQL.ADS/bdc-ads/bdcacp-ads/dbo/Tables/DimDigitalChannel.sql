﻿CREATE TABLE [dbo].[DimDigitalChannel]
( 
	[DigitalChannelKey]		int  NOT NULL IDENTITY,
	[DigitalChannelGroupKey]		int  NULL ,
	[ChannelSource]		nvarchar(50)  NULL ,
	[ChannelMedium]		nvarchar(50)  NULL ,
	[ChannelCampaign]		nvarchar(50)  NULL ,
	[ChannelIsBranded]		bit  NULL ,
	[ChannelBusinessLine]		nvarchar(50)  NULL ,
	[ChannelProductType]		nvarchar(50)  NULL ,
	[ChannelTargetAudience]		nvarchar(50)  NULL ,
	[ChannelReferringSite]		nvarchar(50)  NULL ,
	[ChannelEmailGroup]		nvarchar(50)  NULL ,
	[ChannelLeadNurturingGroup]		nvarchar(50)  NULL ,
	[ChannelLeadNurturingStage]		nvarchar(50)  NULL ,
	[ChannelMeledition]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[DimDigitalChannel]
       ADD CONSTRAINT [FK_DimDigitalChannelGroup_DimDigitalChannel_DigitalChannelGroupkey] FOREIGN KEY ([DigitalChannelGroupkey]) REFERENCES [dbo].[DimDigitalChannelGroup]([DigitalChannelGroupkey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[DimDigitalChannel]
       ADD CONSTRAINT [XPKDimDigitalChannel] PRIMARY KEY  CLUSTERED ([DigitalChannelKey] ASC)
GO
ALTER TABLE [dbo].[DimDigitalChannel]
       ADD CONSTRAINT [XAK1DimDigitalChannel] UNIQUE ([ChannelSource] ASC, [ChannelMedium] ASC, [ChannelCampaign] ASC)