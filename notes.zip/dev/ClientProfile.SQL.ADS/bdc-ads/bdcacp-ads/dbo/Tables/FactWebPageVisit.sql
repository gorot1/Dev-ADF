﻿CREATE TABLE [dbo].[FactWebPageVisit]
( 
	[WebPageVisitKey]		int  NOT NULL IDENTITY,
	[VisitDateKey]		int  NULL ,
	[VisitLandingWebPageKey]		int  NULL ,
	[VisitWebPageKey]		int  NULL ,
	[WebAdKey]		int  NULL ,
	[DigitalTouchpointMetadataKey]		int  NULL ,
	[VisitSessionCount]		int  NULL ,
	[VisitSessionDurationSeconds]		int  NULL ,
	[VisitBouncesCount]		int  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[FactWebPageVisit]
       ADD CONSTRAINT [FK_DimDigitalTouchpointMetadata_FactWebPageVisit_DigitalTouchpointMetadatakey] FOREIGN KEY ([DigitalTouchpointMetadatakey]) REFERENCES [dbo].[DimDigitalTouchpointMetadata]([DigitalTouchpointMetadatakey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebPageVisit]
       ADD CONSTRAINT [FK_DimWebPage_FactWebPageVisit_VisitWebPagekey] FOREIGN KEY ([VisitWebPagekey]) REFERENCES [dbo].[DimWebPage]([WebPagekey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebPageVisit]
       ADD CONSTRAINT [FK_FactWebAd_FactWebPageVisit_WebAdkey] FOREIGN KEY ([WebAdkey]) REFERENCES [dbo].[FactWebAd]([WebAdkey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebPageVisit]
       ADD CONSTRAINT [FK_DimDate_FactWebPageVisit_VisitDateKey] FOREIGN KEY ([VisitDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebPageVisit]
       ADD CONSTRAINT [FK_DimWebPage_FactWebPageVisit_VisitLandingWebPageKey] FOREIGN KEY ([VisitLandingWebPageKey]) REFERENCES [dbo].[DimWebPage]([WebPagekey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebPageVisit]
       ADD CONSTRAINT [XPKFactWebPageVisit] PRIMARY KEY  CLUSTERED ([WebPageVisitKey] ASC)
GO
ALTER TABLE [dbo].[FactWebPageVisit]
       ADD CONSTRAINT [XAK1FactWebPageVisit] UNIQUE ([VisitDateKey] ASC, [VisitLandingWebPageKey] ASC, [VisitWebPageKey] ASC, [WebAdKey] ASC, [DigitalTouchpointMetadataKey] ASC)