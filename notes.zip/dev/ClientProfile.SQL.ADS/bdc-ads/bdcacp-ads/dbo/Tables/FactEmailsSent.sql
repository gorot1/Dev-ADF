﻿CREATE TABLE [dbo].[FactEmailsSent]
( 
	[EmailsSentKey]		int  NOT NULL IDENTITY,
	[EmailOnDateKey]		int  NULL ,
	[EmailInfoKey]		int  NULL ,
	[DigitalTouchpointMetadataKey]		int  NULL ,
	[EmailsSent]		int  NULL ,
	[EmailsDelivered]		int  NULL ,
	[EmailsHardBouncebackTotal]		int  NULL ,
	[EmailsSoftBouncebackTotal]		int  NULL ,
	[EmailsOpenTotal]		int  NULL ,
	[EmailsOpenUnique]		int  NULL ,
	[EmailsClickthroughsTotal]		int  NULL ,
	[EmailsExistingVisitorClickthroughs]		int  NULL ,
	[EmailsNewVisitorClickthroughs]		int  NULL ,
	[EmailsPossibleForwardsTotal]		int  NULL ,
	[EmailsPossibleForwardersTotal]		int  NULL ,
	[EmaillsUnsubscribesByEmailTotal]		int  NULL ,
	[EmailsFormSubmissionsFromEmailTotal]		int  NULL ,
	[EmailsFormSubmissionsFromEmailUnique]		int  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[FactEmailsSent]
       ADD CONSTRAINT [FK_DimEmailInfo_FactEmailsSent_EmailInfokey] FOREIGN KEY ([EmailInfokey]) REFERENCES [dbo].[DimEmailInfo]([EmailInfokey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactEmailsSent]
       ADD CONSTRAINT [FK_DimDigitalTouchpointMetadata_FactEmailsSent_DigitalTouchpointMetadatakey] FOREIGN KEY ([DigitalTouchpointMetadatakey]) REFERENCES [dbo].[DimDigitalTouchpointMetadata]([DigitalTouchpointMetadatakey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactEmailsSent]
       ADD CONSTRAINT [FK_DimDate_FactEmailsSent_EmailOnDateKey] FOREIGN KEY ([EmailOnDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactEmailsSent]
       ADD CONSTRAINT [XPKFactEmailsSent] PRIMARY KEY  CLUSTERED ([EmailsSentKey] ASC)
GO
ALTER TABLE [dbo].[FactEmailsSent]
       ADD CONSTRAINT [XAK1FactEmailsSent] UNIQUE ([EmailOnDateKey] ASC, [EmailInfoKey] ASC, [DigitalTouchpointMetadataKey] ASC)