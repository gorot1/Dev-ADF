﻿CREATE TABLE [dbo].[DimWebPageParameterGroup]
( 
	[WebPageParameterGroupKey]		int  NOT NULL IDENTITY,
	[PageParametersGroupName]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[DimWebPageParameterGroup]
       ADD CONSTRAINT [XPKDimWebPageParameterGroup] PRIMARY KEY  CLUSTERED ([WebPageParameterGroupKey] ASC)
GO
ALTER TABLE [dbo].[DimWebPageParameterGroup]
       ADD CONSTRAINT [XAK1DimWebPageParameterGroup] UNIQUE ([PageParametersGroupName] ASC)