﻿CREATE TABLE [dbo].[DimDigitalChannelGroup]
( 
	[DigitalChannelGroupKey]		int  NOT NULL IDENTITY,
	[ChannelGroupName]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[DimDigitalChannelGroup]
       ADD CONSTRAINT [XPKDimDigitalChannelGroup] PRIMARY KEY  CLUSTERED ([DigitalChannelGroupKey] ASC)
GO
ALTER TABLE [dbo].[DimDigitalChannelGroup]
       ADD CONSTRAINT [XAK1DimDigitalChannelGroup] UNIQUE ([ChannelGroupName] ASC)