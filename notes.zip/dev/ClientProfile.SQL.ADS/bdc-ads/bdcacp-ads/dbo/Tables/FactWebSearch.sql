﻿CREATE TABLE [dbo].[FactWebSearch]
( 
	[WebSearchKey]		int  NOT NULL IDENTITY,
	[SearchDateKey]		int  NULL ,
	[WebPageKey]		int  NULL ,
	[DigitalTouchpointMetadataKey]		int  NULL ,
	[SearchQuery]		nvarchar(50)  NULL ,
	[SearchCountry]		nvarchar(50)  NULL ,
	[SearchType]		nvarchar(50)  NULL ,
	[SearchClickCount]		int  NULL ,
	[SearchImpressionCount]		int  NULL ,
	[SearchPosition]		int  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[FactWebSearch]
       ADD CONSTRAINT [FK_DimDigitalTouchpointMetadata_FactWebSearch_DigitalTouchpointMetadatakey] FOREIGN KEY ([DigitalTouchpointMetadatakey]) REFERENCES [dbo].[DimDigitalTouchpointMetadata]([DigitalTouchpointMetadatakey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebSearch]
       ADD CONSTRAINT [FK_DimWebPage_FactWebSearch_WebPagekey] FOREIGN KEY ([WebPagekey]) REFERENCES [dbo].[DimWebPage]([WebPagekey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebSearch]
       ADD CONSTRAINT [FK_DimDate_FactWebSearch_SearchDateKey] FOREIGN KEY ([SearchDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebSearch]
       ADD CONSTRAINT [XPKFactWebSearch] PRIMARY KEY  CLUSTERED ([WebSearchKey] ASC)
GO
ALTER TABLE [dbo].[FactWebSearch]
       ADD CONSTRAINT [XAK1FactWebSearch] UNIQUE ([SearchDateKey] ASC, [WebPageKey] ASC, [DigitalTouchpointMetadataKey] ASC)