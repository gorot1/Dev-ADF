﻿CREATE TABLE [dbo].[DimDigitalDeviceCategory]
( 
	[DigitalDeviceCategoryKey]		int  NOT NULL IDENTITY,
	[DeviceCategoryName]		nvarchar(50)  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[DimDigitalDeviceCategory]
       ADD CONSTRAINT [XPKDimDigitalDeviceCategory] PRIMARY KEY  CLUSTERED ([DigitalDeviceCategoryKey] ASC)
GO
ALTER TABLE [dbo].[DimDigitalDeviceCategory]
       ADD CONSTRAINT [XAK1DimDigitalDeviceCategory] UNIQUE ([DeviceCategoryName] ASC)