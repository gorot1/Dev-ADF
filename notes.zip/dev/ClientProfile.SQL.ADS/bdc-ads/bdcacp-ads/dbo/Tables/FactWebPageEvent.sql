﻿CREATE TABLE [dbo].[FactWebPageEvent]
( 
	[PageEventKey]		int  NOT NULL IDENTITY,
	[PageEventDateKey]		int  NULL ,
	[WebPageKey]		int  NULL ,
	[DigitalTouchpointMetadataKey]		int  NULL ,
	[WebPageEventInfoKey]		int  NULL ,
	[EventCount]		int  NULL ,
	[EventUniqueCount]		int  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[FactWebPageEvent]
       ADD CONSTRAINT [FK_DimDigitalTouchpointMetadata_FactWebPageEvent_DigitalTouchpointMetadatakey] FOREIGN KEY ([DigitalTouchpointMetadatakey]) REFERENCES [dbo].[DimDigitalTouchpointMetadata]([DigitalTouchpointMetadatakey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebPageEvent]
       ADD CONSTRAINT [FK_DimWebPage_FactWebPageEvent_WebPagekey] FOREIGN KEY ([WebPagekey]) REFERENCES [dbo].[DimWebPage]([WebPagekey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebPageEvent]
       ADD CONSTRAINT [FK_DimDate_FactWebPageEvent_PageEventDateKey] FOREIGN KEY ([PageEventDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebPageEvent]
       ADD CONSTRAINT [FK_DimWebPageEventInfo_FactWebPageEvent_WebPageEventInfoKey] FOREIGN KEY ([WebPageEventInfoKey]) REFERENCES [dbo].[DimWebPageEventInfo]([WebPageEventInfoKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebPageEvent]
       ADD CONSTRAINT [XPKFactWebPageEvent] PRIMARY KEY  CLUSTERED ([PageEventKey] ASC)
GO
ALTER TABLE [dbo].[FactWebPageEvent]
       ADD CONSTRAINT [XAK1FactWebPageEvent] UNIQUE ([PageEventDateKey] ASC, [WebPageKey] ASC, [DigitalTouchpointMetadataKey] ASC, [WebPageEventInfoKey] ASC)