﻿CREATE TABLE [dbo].[FactPublishedWebPage]
( 
	[PublishedWebPageKey]		int  NOT NULL IDENTITY,
	[WebPageKey]		int  NULL ,
	[WebContentKey]		int  NULL ,
	[PublishDateKey]		int  NULL ,
	[RemoveDateKey]		int  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[FactPublishedWebPage]
       ADD CONSTRAINT [FK_DimWebContent_FactPublishedWebPage_WebContentkey] FOREIGN KEY ([WebContentkey]) REFERENCES [dbo].[DimWebContent]([WebContentkey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactPublishedWebPage]
       ADD CONSTRAINT [FK_DimWebPage_FactPublishedWebPage_WebPagekey] FOREIGN KEY ([WebPagekey]) REFERENCES [dbo].[DimWebPage]([WebPagekey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactPublishedWebPage]
       ADD CONSTRAINT [FK_DimDate_FactPublishedWebPage_PublishDateKey] FOREIGN KEY ([PublishDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactPublishedWebPage]
       ADD CONSTRAINT [FK_DimDate_FactPublishedWebPage_RemoveDateKey] FOREIGN KEY ([RemoveDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactPublishedWebPage]
       ADD CONSTRAINT [XPKFactPublishedWebPage] PRIMARY KEY  CLUSTERED ([PublishedWebPageKey] ASC)
GO
ALTER TABLE [dbo].[FactPublishedWebPage]
       ADD CONSTRAINT [XAK1FactPublishedWebPage] UNIQUE ([WebPageKey] ASC, [WebContentKey] ASC, [PublishDateKey] ASC)