﻿CREATE TABLE [dbo].[FactWebGoal]
( 
	[WebGoalKey]		int  NOT NULL IDENTITY,
	[WebGoalDateKey]		int  NULL ,
	[WebPageKey]		int  NULL ,
	[DigitalTouchpointMetadataKey]		int  NULL ,
	[GoalNumber]		int  NULL ,
	[GoalCompletionsValue]		int  NULL ,
	[GoalStartsValue]		int  NULL ,
	[InsertedDate]		datetime	NULL,
	[ModifiedDate]		datetime	NULL,
	[ModifiedBy]		varchar(50)	NULL

)
GO
ALTER TABLE [dbo].[FactWebGoal]
       ADD CONSTRAINT [FK_DimDigitalTouchpointMetadata_FactWebGoal_DigitalTouchpointMetadatakey] FOREIGN KEY ([DigitalTouchpointMetadatakey]) REFERENCES [dbo].[DimDigitalTouchpointMetadata]([DigitalTouchpointMetadatakey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebGoal]
       ADD CONSTRAINT [FK_DimWebPage_FactWebGoal_WebPagekey] FOREIGN KEY ([WebPagekey]) REFERENCES [dbo].[DimWebPage]([WebPagekey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebGoal]
       ADD CONSTRAINT [FK_DimDate_FactWebGoal_WebGoalDateKey] FOREIGN KEY ([WebGoalDateKey]) REFERENCES [dbo].[DimDate]([DimDateKey])
              ON DELETE NO ACTION
              ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[FactWebGoal]
       ADD CONSTRAINT [XPKFactWebGoal] PRIMARY KEY  CLUSTERED ([WebGoalKey] ASC)
GO
ALTER TABLE [dbo].[FactWebGoal]
       ADD CONSTRAINT [XAK1FactWebGoal] UNIQUE ([WebGoalDateKey] ASC, [WebPageKey] ASC, [DigitalTouchpointMetadataKey] ASC)