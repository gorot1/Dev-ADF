﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-07
-- Description: Updates DimOriginatingUnit from tmp_DimOriginatingUnit
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_DimOriginatingUnit
AS
BEGIN
	-- =============================================
	-- Updates DimKey table first
	-- =============================================
	MERGE dbo.DimKeyDimOriginatingUnit AS dst
	USING (
		SELECT DISTINCT
			OrganizationRefEntity_buid
			,LEFT(OriginatingUnitNumberCREM, 4) AS OriginatingUnitNumberCREM
		FROM dbo.tmp_DimOriginatingUnit
	) AS src
	ON dst.Buid = src.OrganizationRefEntity_buid

	WHEN MATCHED THEN
		UPDATE SET
			OriginatingUnitNumberCREM = src.OriginatingUnitNumberCREM
			,ModifiedDate = GETDATE()

	WHEN NOT MATCHED THEN
		INSERT (
            Buid
            ,OriginatingUnitNumberCREM
			,InsertedDate
			,ModifiedDate
		)
		VALUES (
            src.OrganizationRefEntity_buid
            ,src.OriginatingUnitNumberCREM
			,GETDATE()
			,GETDATE()
		);

	-- =============================================
	-- Then updates Dimension table
	-- =============================================
	MERGE dbo.DimOriginatingUnit AS dst
	USING (
		SELECT
			dim.DimKey AS DimOriginatingUnitKey
			,LEFT(tmp.OriginatingUnitNumberCREM, 10) AS OriginatingUnitNumber
			,LEFT(tmp.OriginatingUnitNameEnglish, 100) AS OriginatingUnitNameEN
			,LEFT(tmp.OriginatingUnitNameFrench, 100) AS OriginatingUnitNameFR
			,LEFT(tmp.ConsolidatedOriginatingUnitNumber, 10) AS ConsolidatedOriginatingUnitNumber
			,LEFT(tmp.ConsolidatedOriginatingUnit, 100) AS ConsolidatedOriginatingUnitNameEN
			,LEFT(tmp.ConsolidatedOriginatingUnitFrench, 100) AS ConsolidatedOriginatingUnitNameFR
			,NULL AS DepartmentNumber
			,NULL AS DepartmentNameEN
			,NULL AS DepartmentNameFR
			,LEFT(tmp.DistrictNumber, 10) AS DistrictNumber
			,LEFT(tmp.DistrictNameEnglish, 100) AS DistrictNameEN
			,LEFT(tmp.DistrictNameFrench, 100) AS DistrictNameFR
			,LEFT(tmp.AreaNumber, 10) AS AreaNumber
			,LEFT(tmp.AreaNameEnglish, 100) AS AreaNameEN
			,LEFT(tmp.AreaNameFrench, 100) AS AreaNameFR
			,LEFT(tmp.SubRegionNumber, 10) AS SubRegionNumber
			,LEFT(tmp.SubRegionName, 100) AS SubRegionNameEN
			,LEFT(tmp.SubRegionNameFrench, 100) AS SubRegionNameFR
			,LEFT(tmp.OperationRegionNumber, 10) AS OperatingRegionNumber
			,LEFT(tmp.OperationRegionName, 100) AS OperatingRegionNameEN
			,LEFT(tmp.OperationRegionNameFrench, 100) AS OperatingRegionNameFR
			,LEFT(tmp.StatusId, 10) AS OriginatingUnitStatusCode
			,LEFT(tmp.StatusDescr, 100) AS OriginatingUnitStatusDescrEN
			,NULL AS OriginatingUnitStatusDescrFR
			,LEFT(TypeId, 10) AS OriginatingUnitTypeCode
			,LEFT(TypeDescr, 100) AS OriginatingUnitTypeDescrEN
			,NULL AS OriginatingUnitTypeDescrFR
			,LEFT(tmp.ProvinceTerritoryId, 10) AS OriginationUnitProvinceTerritoryCode
			,LEFT(tmp.[Province/Territory], 100) AS OriginationUnitProvinceTerritoryNameEN
			,NULL AS OriginationUnitProvinceTerritoryNameFR
			,LEFT(tmp.TotalBankNumber, 10) AS TotalBankCode
			,LEFT(tmp.TotalBankName, 100) AS TotalBankName
			,OriginatingUnitDisplayFlag=CASE LEFT(tmp.DisplayFlagOriginatingUnit, 1) WHEN 'Y' THEN 1 ELSE 0 END
			,ConsolidatedOriginatingUnitDisplayFlag=CASE LEFT(tmp.DisplayFlagConsolidatedUnit, 1) WHEN 'Y' THEN 1 ELSE 0 END
			,DistrictDisplayFlag=CASE LEFT(tmp.DisplayFlagDistrict, 1) WHEN 'Y' THEN 1 ELSE 0 END
			,RegionDisplayFlag=CASE LEFT(tmp.DisplayFlagSubRegion, 1) WHEN 'Y' THEN 1 ELSE 0 END
			,OperatingRegionDisplayFlag=CASE LEFT(tmp.DisplayFlagOperatingRegion, 1) WHEN 'Y' THEN 1 ELSE 0 END
			,AreaDisplayFlag=CASE LEFT(tmp.DisplayFlagArea, 1) WHEN 'Y' THEN 1 ELSE 0 END
			,LEFT(tmp.SeqOriginatingUnit, 10) AS OriginatingUnitSequenceNumber
			,LEFT(tmp.SeqConsolidatedUnit, 10) AS ConsolidatedOriginatingUnitSequenceNumber
			,LEFT(tmp.SeqDistrict, 10) AS DistrictSequenceNumber
			,LEFT(tmp.SeqArea, 10) AS AreaSequenceNumber
			,LEFT(tmp.SeqSubRegion, 10) AS RegionSequenceNumber
			,LEFT(tmp.SeqOperatingReg, 10) AS OperatingRegionSequenceNumber
			,NULL AS ModifiedBy
			,tmp.OrganizationRefEntity_oid AS RowSignature
		FROM dbo.tmp_DimOriginatingUnit tmp
		INNER JOIN dbo.DimKeyDimOriginatingUnit dim ON tmp.OrganizationRefEntity_buid = dim.Buid
	) AS src
	ON (dst.DimOriginatingUnitKey = src.DimOriginatingUnitKey)

	WHEN MATCHED THEN
		UPDATE SET
			OriginatingUnitNumber = src.OriginatingUnitNumber
			,OriginatingUnitNameEN = src.OriginatingUnitNameEN
			,OriginatingUnitNameFR = src.OriginatingUnitNameFR
			,ConsolidatedOriginatingUnitNumber = src.ConsolidatedOriginatingUnitNumber
			,ConsolidatedOriginatingUnitNameEN = src.ConsolidatedOriginatingUnitNameEN
			,ConsolidatedOriginatingUnitNameFR = src.ConsolidatedOriginatingUnitNameFR
			,DepartmentNumber = src.DepartmentNumber
			,DepartmentNameEN = src.DepartmentNameEN
			,DepartmentNameFR = src.DepartmentNameFR
			,DistrictNumber = src.DistrictNumber
			,DistrictNameEN = src.DistrictNameEN
			,DistrictNameFR = src.DistrictNameFR
			,AreaNumber = src.AreaNumber
			,AreaNameEN = src.AreaNameEN
			,AreaNameFR = src.AreaNameFR
			,SubRegionNumber = src.SubRegionNumber
			,SubRegionNameEN = src.SubRegionNameEN
			,SubRegionNameFR = src.SubRegionNameFR
			,OperatingRegionNumber = src.OperatingRegionNumber
			,OperatingRegionNameEN = src.OperatingRegionNameEN
			,OperatingRegionNameFR = src.OperatingRegionNameFR
			,OriginatingUnitStatusCode = src.OriginatingUnitStatusCode
			,OriginatingUnitStatusDescrEN = src.OriginatingUnitStatusDescrEN
			,OriginatingUnitStatusDescrFR = src.OriginatingUnitStatusDescrFR
			,OriginatingUnitTypeCode = src.OriginatingUnitTypeCode
			,OriginatingUnitTypeDescrEN = src.OriginatingUnitTypeDescrEN
			,OriginatingUnitTypeDescrFR = src.OriginatingUnitTypeDescrFR
			,OriginationUnitProvinceTerritoryCode = src.OriginationUnitProvinceTerritoryCode
			,OriginationUnitProvinceTerritoryNameEN = src.OriginationUnitProvinceTerritoryNameEN
			,OriginationUnitProvinceTerritoryNameFR = src.OriginationUnitProvinceTerritoryNameFR
			,TotalBankCode = src.TotalBankCode
			,TotalBankName = src.TotalBankName
			,OriginatingUnitDisplayFlag = src.OriginatingUnitDisplayFlag
			,ConsolidatedOriginatingUnitDisplayFlag = src.ConsolidatedOriginatingUnitDisplayFlag
			,DistrictDisplayFlag = src.DistrictDisplayFlag
			,RegionDisplayFlag = src.RegionDisplayFlag
			,OperatingRegionDisplayFlag = src.OperatingRegionDisplayFlag
			,AreaDisplayFlag = src.AreaDisplayFlag
			,OriginatingUnitSequenceNumber = src.OriginatingUnitSequenceNumber
			,ConsolidatedOriginatingUnitSequenceNumber = src.ConsolidatedOriginatingUnitSequenceNumber
			,DistrictSequenceNumber = src.DistrictSequenceNumber
			,AreaSequenceNumber = src.AreaSequenceNumber
			,RegionSequenceNumber = src.RegionSequenceNumber
			,OperatingRegionSequenceNumber = src.OperatingRegionSequenceNumber
			,ModifiedDate = GETDATE()
			,ModifiedBy = src.ModifiedBy
			,RowSignature = src.RowSignature

	WHEN NOT MATCHED THEN
		INSERT (
			DimOriginatingUnitKey
			,OriginatingUnitNumber
			,OriginatingUnitNameEN
			,OriginatingUnitNameFR
			,ConsolidatedOriginatingUnitNumber
			,ConsolidatedOriginatingUnitNameEN
			,ConsolidatedOriginatingUnitNameFR
			,DepartmentNumber
			,DepartmentNameEN
			,DepartmentNameFR
			,DistrictNumber
			,DistrictNameEN
			,DistrictNameFR
			,AreaNumber
			,AreaNameEN
			,AreaNameFR
			,SubRegionNumber
			,SubRegionNameEN
			,SubRegionNameFR
			,OperatingRegionNumber
			,OperatingRegionNameEN
			,OperatingRegionNameFR
			,OriginatingUnitStatusCode
			,OriginatingUnitStatusDescrEN
			,OriginatingUnitStatusDescrFR
			,OriginatingUnitTypeCode
			,OriginatingUnitTypeDescrEN
			,OriginatingUnitTypeDescrFR
			,OriginationUnitProvinceTerritoryCode
			,OriginationUnitProvinceTerritoryNameEN
			,OriginationUnitProvinceTerritoryNameFR
			,TotalBankCode
			,TotalBankName
			,OriginatingUnitDisplayFlag
			,ConsolidatedOriginatingUnitDisplayFlag
			,DistrictDisplayFlag
			,RegionDisplayFlag
			,OperatingRegionDisplayFlag
			,AreaDisplayFlag
			,OriginatingUnitSequenceNumber
			,ConsolidatedOriginatingUnitSequenceNumber
			,DistrictSequenceNumber
			,AreaSequenceNumber
			,RegionSequenceNumber
			,OperatingRegionSequenceNumber
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
		)
		VALUES (
			src.DimOriginatingUnitKey
			,src.OriginatingUnitNumber
			,src.OriginatingUnitNameEN
			,src.OriginatingUnitNameFR
			,src.ConsolidatedOriginatingUnitNumber
			,src.ConsolidatedOriginatingUnitNameEN
			,src.ConsolidatedOriginatingUnitNameFR
			,src.DepartmentNumber
			,src.DepartmentNameEN
			,src.DepartmentNameFR
			,src.DistrictNumber
			,src.DistrictNameEN
			,src.DistrictNameFR
			,src.AreaNumber
			,src.AreaNameEN
			,src.AreaNameFR
			,src.SubRegionNumber
			,src.SubRegionNameEN
			,src.SubRegionNameFR
			,src.OperatingRegionNumber
			,src.OperatingRegionNameEN
			,src.OperatingRegionNameFR
			,src.OriginatingUnitStatusCode
			,src.OriginatingUnitStatusDescrEN
			,src.OriginatingUnitStatusDescrFR
			,src.OriginatingUnitTypeCode
			,src.OriginatingUnitTypeDescrEN
			,src.OriginatingUnitTypeDescrFR
			,src.OriginationUnitProvinceTerritoryCode
			,src.OriginationUnitProvinceTerritoryNameEN
			,src.OriginationUnitProvinceTerritoryNameFR
			,src.TotalBankCode
			,src.TotalBankName
			,src.OriginatingUnitDisplayFlag
			,src.ConsolidatedOriginatingUnitDisplayFlag
			,src.DistrictDisplayFlag
			,src.RegionDisplayFlag
			,src.OperatingRegionDisplayFlag
			,src.AreaDisplayFlag
			,src.OriginatingUnitSequenceNumber
			,src.ConsolidatedOriginatingUnitSequenceNumber
			,src.DistrictSequenceNumber
			,src.AreaSequenceNumber
			,src.RegionSequenceNumber
			,src.OperatingRegionSequenceNumber
			,GETDATE()
			,GETDATE()
			,src.ModifiedBy
			,src.RowSignature
		);
END
GO
