﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-07
-- Description: Updates DimOperatingUnit from tmp_DimOperatingUnit
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_DimOperatingUnit
AS
BEGIN
	-- =============================================
	-- Updates DimKey table first
	-- =============================================
	MERGE dbo.DimKeyDimOperatingUnit AS dst
	USING (
		SELECT DISTINCT
			OperatingUnitRefEntity_buid
			,LEFT(AdminDeptId, 4) AS AdminDeptId
		FROM dbo.tmp_DimOperatingUnit
	) AS src
	ON dst.Buid = src.OperatingUnitRefEntity_buid

	WHEN MATCHED THEN
		UPDATE SET
			AdminDeptId = src.AdminDeptId
			,ModifiedDate = GETDATE()

	WHEN NOT MATCHED THEN
		INSERT (
            Buid
            ,AdminDeptId
			,InsertedDate
			,ModifiedDate
		)
		VALUES (
            src.OperatingUnitRefEntity_buid
            ,src.AdminDeptId
			,GETDATE()
			,GETDATE()
		);

	-- =============================================
	-- Then updates Dimension table
	-- =============================================
	MERGE dbo.DimOperatingUnit AS dst
	USING (
		SELECT
			dim.DimKey AS DimOperatingUnitKey
			,LEFT(tmp.AdminDeptId, 10) AS OperatingUnitNumber
			,LEFT(tmp.AdminDeptName, 100) AS OperatingUnitNameEN
			,NULL AS OperatingUnitNameFR
			,LEFT(tmp.AdminDeptAreaId, 10) AS OperatingUnitAreaNumber
			,LEFT(tmp.AdminDeptAreaName, 100) AS OperatingUnitAreaNameEN
			,NULL AS OperatingUnitAreaNameFR
			,LEFT(tmp.AdminDeptRegionId, 10) AS OperatingUnitRegionNumber
			,LEFT(tmp.AdminDeptRegionName, 100) AS OperatingUnitRegionNameEN
			,NULL AS OperatingUnitRegionNameFR
			,NULL AS OperatingUnitGroupNumber
			,NULL AS OperatingUnitGroupNameEN
			,NULL AS OperatingUnitGroupNameFR
			,LEFT(tmp.AdminDeptType, 10) AS OperatingUnitTypeCode
			,NULL AS OperatingUnitTypeDescrEN
			,NULL AS OperatingUnitTypeDescrFR
			,NULL AS ModifiedBy
			,tmp.OperatingUnitRefEntity_oid AS RowSignature
		FROM dbo.tmp_DimOperatingUnit tmp
		INNER JOIN dbo.DimKeyDimOperatingUnit dim ON tmp.OperatingUnitRefEntity_buid = dim.Buid
	) AS src
	ON (dst.DimOperatingUnitKey = src.DimOperatingUnitKey)

	WHEN MATCHED THEN
		UPDATE SET
			OperatingUnitNumber = src.OperatingUnitNumber
			,OperatingUnitNameEN = src.OperatingUnitNameEN
			,OperatingUnitNameFR = src.OperatingUnitNameFR
			,OperatingUnitAreaNumber = src.OperatingUnitAreaNumber
			,OperatingUnitAreaNameEN = src.OperatingUnitAreaNameEN
			,OperatingUnitAreaNameFR = src.OperatingUnitAreaNameFR
			,OperatingUnitRegionNumber = src.OperatingUnitRegionNumber
			,OperatingUnitRegionNameEN = src.OperatingUnitRegionNameEN
			,OperatingUnitRegionNameFR = src.OperatingUnitRegionNameFR
			,OperatingUnitGroupNumber = src.OperatingUnitGroupNumber
			,OperatingUnitGroupNameEN = src.OperatingUnitGroupNameEN
			,OperatingUnitGroupNameFR = src.OperatingUnitGroupNameFR
			,OperatingUnitTypeCode = src.OperatingUnitTypeCode
			,OperatingUnitTypeDescrEN = src.OperatingUnitTypeDescrEN
			,OperatingUnitTypeDescrFR = src.OperatingUnitTypeDescrFR
			,ModifiedDate = GETDATE()
			,ModifiedBy = src.ModifiedBy
			,RowSignature = src.RowSignature

	WHEN NOT MATCHED THEN
		INSERT (
			DimOperatingUnitKey
			,OperatingUnitNumber
			,OperatingUnitNameEN
			,OperatingUnitNameFR
			,OperatingUnitAreaNumber
			,OperatingUnitAreaNameEN
			,OperatingUnitAreaNameFR
			,OperatingUnitRegionNumber
			,OperatingUnitRegionNameEN
			,OperatingUnitRegionNameFR
			,OperatingUnitGroupNumber
			,OperatingUnitGroupNameEN
			,OperatingUnitGroupNameFR
			,OperatingUnitTypeCode
			,OperatingUnitTypeDescrEN
			,OperatingUnitTypeDescrFR
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
		)
		VALUES (
			src.DimOperatingUnitKey
			,src.OperatingUnitNumber
			,src.OperatingUnitNameEN
			,src.OperatingUnitNameFR
			,src.OperatingUnitAreaNumber
			,src.OperatingUnitAreaNameEN
			,src.OperatingUnitAreaNameFR
			,src.OperatingUnitRegionNumber
			,src.OperatingUnitRegionNameEN
			,src.OperatingUnitRegionNameFR
			,src.OperatingUnitGroupNumber
			,src.OperatingUnitGroupNameEN
			,src.OperatingUnitGroupNameFR
			,src.OperatingUnitTypeCode
			,src.OperatingUnitTypeDescrEN
			,src.OperatingUnitTypeDescrFR
			,GETDATE()
			,GETDATE()
			,src.ModifiedBy
			,src.RowSignature
		);
END
GO
