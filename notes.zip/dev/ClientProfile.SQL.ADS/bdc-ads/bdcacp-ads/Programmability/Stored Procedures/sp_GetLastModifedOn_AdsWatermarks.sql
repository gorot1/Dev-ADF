﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-05
-- Description: Gets lastModifiedOn from AdsWatermarks
-- =============================================
CREATE PROCEDURE dbo.sp_GetLastModifedOn_AdsWatermarks
(
    @tableName VARCHAR(255)
)
AS
BEGIN
	SELECT CONVERT(VARCHAR(20), ISNULL(MAX(ModifiedOn), '1900-01-01'), 20) AS ModifiedOn FROM dbo.AdsWatermarks WHERE TableName = @tableName
END
GO
