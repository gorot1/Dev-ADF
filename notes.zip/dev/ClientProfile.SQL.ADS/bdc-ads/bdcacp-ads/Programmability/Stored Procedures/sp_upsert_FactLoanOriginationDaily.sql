﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-11-02
-- Description: Updates FactLoanOriginationDaily from tmp_FactLoanOriginationDaily
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_FactLoanOriginationDaily
AS
BEGIN
	-- =============================================
	-- FactLoanOriginationDaily is normaly an Append table, but we use Scd1 just in case of ingestion duplicates
	-- =============================================
	MERGE dbo.FactLoanOriginationDaily AS dst
	USING (
		SELECT
			dl.DimLoanKey AS DimLoanKey
			,dl.DimLoanDurableKey AS DimLoanDurableKey
			,-1 AS DimCustomerKey
			,-1 AS DimCustomerDurableKey
			,tmp.DimDateKey AS DimDateKey
			,-1 AS DimLoanTrancheKey
			,-1 AS DimLoanTrancheDurableKey
			,-1 AS DimLoanAtOriginationDurableKey
			,ISNULL(dori.DimKey, -1) AS DimOriginatingUnitAtAuthKey
			,-1 AS DimOriginatingUnitKey
			,ISNULL(dope.DimKey, -1) AS DimOperatingUnitAtAuthKey
			,-1 AS DimOperatingUnitKey
			,ISNULL(dlp.DimKey, -1) AS DimLoanPurposeKey
			,-1 AS DimNewRepeatBusinessKey
			,ISNULL(dind.DimKey, -1) AS DimIndustryKey
			,-1 AS DimLineOfBusinessKey
			,-1 AS DimLoanSolutionGroupingKey
			,-1 AS DimSourceOfReferenceKey
			,-1 AS DimLoanCancellationReasonKey
			,tmp.AuthorizationGrossLoanAmount AS AuthorizationGrossLoanAmount
			,tmp.AuthorizationGrossLoanCount AS AuthorizationGrossLoanCount
			,tmp.AuthorizationGrossNewMoneyAmount AS AuthorizationGrossNewMoneyAmount
			,tmp.AuthorizationGrossNewMoneyCount AS AuthorizationGrossNewMoneyCount
			,tmp.AuthorizationGrossNewMoneyAmount - tmp.CancellationReductionTotal AS AuthorizationNetNewMoney
			,AuthorizationNetNewMoneyCount = CASE WHEN tmp.AuthorizationGrossNewMoneyAmount - tmp.CancellationReductionTotal > 0 THEN 1 ELSE 0 END
			,tmp.AuthorizationFiscalNet AS AuthorizationFiscalNet
			,AuthorizationFiscalNetCount = CASE WHEN tmp.AuthorizationFiscalNet > 0 THEN 1 ELSE 0 END 
			,tmp.AuthorizationNetLoan AS AuthorizationNetLoan
			,tmp.AcceptedGrossNewMoney AS AcceptedGrossNewMoney
			,tmp.AcceptedGrossNewMoneyCount AS AcceptedGrossNewMoneyCount
			,tmp.AcceptedNetNewMoney AS AcceptedNetNewMoney
			,tmp.AcceptedNetNewMoneyCount AS AcceptedNetNewMoneyCount
			,tmp.AcceptedNetLoan AS AcceptedNetLoan
			,tmp.AcceptedNetLoanCount AS AcceptedNetLoanCount
			,tmp.CancellationReductionTotal AS CancellationReductionTotal
			,tmp.Cancellation AS Cancellation
			,tmp.Reduction AS Reduction
			,NULL AS ModifiedBy
			,CONVERT(VARCHAR(40), HASHBYTES('SHA1', CONCAT(tmp.AccountNumber, CAST(tmp.DimDateKey AS CHAR(8)))), 2) AS RowSignature
		FROM dbo.tmp_FactLoanOriginationDaily tmp
		INNER JOIN dbo.DimLoan dl ON tmp.AccountNumber = dl.AccountNumber AND tmp.DimDateKey BETWEEN dl.StartDateDimLoanKey AND dl.EndDateDimLoanKey
		LEFT JOIN dbo.DimKeyDimLoanPurpose dlp ON tmp.LoanPurposeCode = dlp.LoanPurposeCode
		LEFT JOIN dbo.DimKeyDimOperatingUnit dope ON tmp.OperatingUnitNumberAtAuthorization = dope.AdminDeptId
		LEFT JOIN dbo.DimKeyDimOriginatingUnit dori ON tmp.OriginatingUnitNumberAtAuthorization = dori.OriginatingUnitNumberCREM
		LEFT JOIN dbo.DimKeyDimIndustry dind ON tmp.PrimaryNaicsCode = dind.SicN
	) AS src
	ON (dst.DimLoanDurableKey = src.DimLoanDurableKey AND dst.DimDateKey = src.DimDateKey)

	WHEN MATCHED THEN
		UPDATE SET
			DimLoanKey = src.DimLoanKey
			--,DimLoanDurableKey = src.DimLoanDurableKey
			,DimCustomerKey = src.DimCustomerKey
			,DimCustomerDurableKey = src.DimCustomerDurableKey
			--,DimDateKey = src.DimDateKey
			,DimLoanTrancheKey = src.DimLoanTrancheKey
			,DimLoanTrancheDurableKey = src.DimLoanTrancheDurableKey
			,DimLoanAtOriginationDurableKey = src.DimLoanAtOriginationDurableKey
			,DimOriginatingUnitKey = src.DimOriginatingUnitKey
			,DimOriginatingUnitAtAuthKey = src.DimOriginatingUnitAtAuthKey
			,DimOperatingUnitKey = src.DimOperatingUnitKey
			,DimLoanPurposeKey = src.DimLoanPurposeKey
			,DimNewRepeatBusinessKey = src.DimNewRepeatBusinessKey
			,DimIndustryKey = src.DimIndustryKey
			,DimLineOfBusinessKey = src.DimLineOfBusinessKey
			,DimLoanSolutionGroupingKey = src.DimLoanSolutionGroupingKey
			,DimSourceOfReferenceKey = src.DimSourceOfReferenceKey
			,DimLoanCancellationReasonKey = src.DimLoanCancellationReasonKey
			,DimOperatingUnitAtAuthKey = src.DimOperatingUnitAtAuthKey
			,AuthorizationGrossLoanAmount = src.AuthorizationGrossLoanAmount
			,AuthorizationGrossLoanCount = src.AuthorizationGrossLoanCount
			,AuthorizationGrossNewMoneyAmount = src.AuthorizationGrossNewMoneyAmount
			,AuthorizationGrossNewMoneyCount = src.AuthorizationGrossNewMoneyCount
			,AuthorizationNetNewMoney = src.AuthorizationNetNewMoney
			,AuthorizationNetNewMoneyCount = src.AuthorizationNetNewMoneyCount
			,AuthorizationFiscalNet = src.AuthorizationFiscalNet
			,AuthorizationFiscalNetCount = src.AuthorizationFiscalNetCount
			,AuthorizationNetLoan = src.AuthorizationNetLoan
			,AcceptedGrossNewMoney = src.AcceptedGrossNewMoney
			,AcceptedGrossNewMoneyCount = src.AcceptedGrossNewMoneyCount
			,AcceptedNetNewMoney = src.AcceptedNetNewMoney
			,AcceptedNetNewMoneyCount = src.AcceptedNetNewMoneyCount
			,AcceptedNetLoan = src.AcceptedNetLoan
			,AcceptedNetLoanCount = src.AcceptedNetLoanCount
			,CancellationReductionTotal = src.CancellationReductionTotal
			,Cancellation = src.Cancellation
			,Reduction = src.Reduction
			,ModifiedDate = GETDATE()
			,ModifiedBy = src.ModifiedBy
			,RowSignature = src.RowSignature

	WHEN NOT MATCHED THEN
		INSERT (
			DimLoanKey
			,DimLoanDurableKey
			,DimCustomerKey
			,DimCustomerDurableKey
			,DimDateKey
			,DimLoanTrancheKey
			,DimLoanTrancheDurableKey
			,DimLoanAtOriginationDurableKey
			,DimOriginatingUnitKey
			,DimOriginatingUnitAtAuthKey
			,DimOperatingUnitKey
			,DimLoanPurposeKey
			,DimNewRepeatBusinessKey
			,DimIndustryKey
			,DimLineOfBusinessKey
			,DimLoanSolutionGroupingKey
			,DimSourceOfReferenceKey
			,DimLoanCancellationReasonKey
			,DimOperatingUnitAtAuthKey
			,AuthorizationGrossLoanAmount
			,AuthorizationGrossLoanCount
			,AuthorizationGrossNewMoneyAmount
			,AuthorizationGrossNewMoneyCount
			,AuthorizationNetNewMoney
			,AuthorizationNetNewMoneyCount
			,AuthorizationFiscalNet
			,AuthorizationFiscalNetCount
			,AuthorizationNetLoan
			,AcceptedGrossNewMoney
			,AcceptedGrossNewMoneyCount
			,AcceptedNetNewMoney
			,AcceptedNetNewMoneyCount
			,AcceptedNetLoan
			,AcceptedNetLoanCount
			,CancellationReductionTotal
			,Cancellation
			,Reduction
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
		)
		VALUES (
			src.DimLoanKey
			,src.DimLoanDurableKey
			,src.DimCustomerKey
			,src.DimCustomerDurableKey
			,src.DimDateKey
			,src.DimLoanTrancheKey
			,src.DimLoanTrancheDurableKey
			,src.DimLoanAtOriginationDurableKey
			,src.DimOriginatingUnitKey
			,src.DimOriginatingUnitAtAuthKey
			,src.DimOperatingUnitKey
			,src.DimLoanPurposeKey
			,src.DimNewRepeatBusinessKey
			,src.DimIndustryKey
			,src.DimLineOfBusinessKey
			,src.DimLoanSolutionGroupingKey
			,src.DimSourceOfReferenceKey
			,src.DimLoanCancellationReasonKey
			,src.DimOperatingUnitAtAuthKey
			,src.AuthorizationGrossLoanAmount
			,src.AuthorizationGrossLoanCount
			,src.AuthorizationGrossNewMoneyAmount
			,src.AuthorizationGrossNewMoneyCount
			,src.AuthorizationNetNewMoney
			,src.AuthorizationNetNewMoneyCount
			,src.AuthorizationFiscalNet
			,src.AuthorizationFiscalNetCount
			,src.AuthorizationNetLoan
			,src.AcceptedGrossNewMoney
			,src.AcceptedGrossNewMoneyCount
			,src.AcceptedNetNewMoney
			,src.AcceptedNetNewMoneyCount
			,src.AcceptedNetLoan
			,src.AcceptedNetLoanCount
			,src.CancellationReductionTotal
			,src.Cancellation
			,src.Reduction
			,GETDATE()
			,GETDATE()
			,src.ModifiedBy
			,src.RowSignature
		)
    OUTPUT $ACTION as ActionType, src.*;
END
GO
