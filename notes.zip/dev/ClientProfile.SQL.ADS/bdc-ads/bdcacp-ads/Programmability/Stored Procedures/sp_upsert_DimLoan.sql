﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-19
-- Description: Updates DimLoan from tmp_DimLoan
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_DimLoan
AS
BEGIN
	-- =============================================
	-- Updates DimKey table first
	-- =============================================
	MERGE dbo.DimKeyDimLoan AS dst
	USING (
		SELECT DISTINCT
			LoanEntity_buid
			,LEFT(AccountNumber, 10) AS AccountNumber
		FROM dbo.tmp_DimLoan
	) AS src
	ON dst.Buid = src.LoanEntity_buid

	WHEN MATCHED THEN
		UPDATE SET
			AccountNumber = src.AccountNumber
			,ModifiedDate = GETDATE()

	WHEN NOT MATCHED THEN
		INSERT (
            Buid
            ,AccountNumber
			,InsertedDate
			,ModifiedDate
		)
		VALUES (
            src.LoanEntity_buid
            ,src.AccountNumber
			,GETDATE()
			,GETDATE()
		);

	-- =============================================
	-- Then updates DimLoan table
	-- =============================================
	MERGE dbo.DimLoan AS dst
	USING (
		SELECT
			dim.DimKey AS DimLoanDurableKey
			,LEFT(tmp.AbacusCustomerNumber, 6) AS AbacusNumber
			,LEFT(tmp.AccountNumber, 9) AS AccountNumber
			,tmp.DateInactive AS DateInactive
			,LoanAuthorizationFlag=CASE WHEN tmp.LoanAuthorizationDateBooked BETWEEN entity_start_date AND entity_end_date THEN 1 ELSE 0 END
			,tmp.MaturityDate AS MaturityDate
			,LEFT(tmp.LoanMultiple, 2) AS MultipleNumber
			,YEAR(tmp.entity_start_date) * 10000 + MONTH(tmp.entity_start_date) * 100 + DAY(tmp.entity_start_date) AS StartDateDimLoanKey
			,EndDateDimLoanKey = CASE WHEN entity_end_date = '9999-12-31 23:59:59' THEN 99991231
				ELSE YEAR(DATEADD(DAY, -1, tmp.entity_end_date)) * 10000 + MONTH(DATEADD(DAY, -1, tmp.entity_end_date)) * 100 + DAY(DATEADD(DAY, -1, tmp.entity_end_date))
				END
			,tmp.entity_is_current AS DimLoanCurrentFlag
			,NULL AS ModifiedBy
			,tmp.LoanEntity_oid AS RowSignature
			,tmp.LoanEntity_uid AS RowUid
		FROM dbo.tmp_DimLoan tmp
		INNER JOIN dbo.DimKeyDimLoan dim ON tmp.LoanEntity_buid = dim.Buid
	) AS src
	ON (dst.RowUid = src.RowUid)

	WHEN MATCHED THEN
		UPDATE SET
			DimLoanDurableKey = src.DimLoanDurableKey
			,AbacusNumber = src.AbacusNumber
			,AccountNumber = src.AccountNumber
			,DateInactive = src.DateInactive
			,LoanAuthorizationFlag = src.LoanAuthorizationFlag
			,MaturityDate = src.MaturityDate
			,MultipleNumber = src.MultipleNumber
			,StartDateDimLoanKey = src.StartDateDimLoanKey
			,EndDateDimLoanKey = src.EndDateDimLoanKey
			,DimLoanCurrentFlag = src.DimLoanCurrentFlag
			,ModifiedDate = GETDATE()
			,ModifiedBy = src.ModifiedBy
			,RowSignature = src.RowSignature

	WHEN NOT MATCHED THEN
		INSERT (
			DimLoanDurableKey
			,AbacusNumber
			,AccountNumber
			,DateInactive
			,LoanAuthorizationFlag
			,MaturityDate
			,MultipleNumber
			,StartDateDimLoanKey
			,EndDateDimLoanKey
			,DimLoanCurrentFlag
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
			,RowUid
		)
		VALUES (
			src.DimLoanDurableKey
			,src.AbacusNumber
			,src.AccountNumber
			,src.DateInactive
			,src.LoanAuthorizationFlag
			,src.MaturityDate
			,src.MultipleNumber
			,src.StartDateDimLoanKey
			,src.EndDateDimLoanKey
			,src.DimLoanCurrentFlag
			,GETDATE()
			,GETDATE()
			,src.ModifiedBy
			,src.RowSignature
			,src.RowUid
		);

	-- =============================================
	-- Then updates DimLoanAtOrigination table
	-- =============================================
	MERGE dbo.DimLoanAtOrigination AS dst
	USING (
		SELECT
			DimLoanAtOriginationDurableKey
			,AccountNumber
			,AbacusNumber
			,MultipleNumber
			,LoanAuthorizationDate
			,LoanAuthorizationDateBooked
			,AcceptanceDate
			,TotalCommitmentCloselyRelatedAtAuthorization
			,ProductIntiativeTypeCode
			,ProductIntiativeTypeDescrEN
			,AdministrativeTypeCode
			,AdministrativeTypeDescrEN
			,AlliancePortfolioGLCode
			,AlliancePortfolioCode
			,AlliancePortfolioDescrEN
			,LoanProductCode
			,LoanProductDescrEN
			,ModifiedBy
			,RowSignature
		FROM 
		(
			SELECT 
				ROW_NUMBER() OVER(PARTITION BY tmp.AccountNumber ORDER BY tmp.entity_start_date DESC) AS RowNum
				,dim.DimKey AS DimLoanAtOriginationDurableKey
				,LEFT(tmp.AccountNumber, 9) AS AccountNumber
				,LEFT(tmp.AbacusCustomerNumber, 6) AS AbacusNumber
				,LEFT(tmp.LoanMultiple, 2) AS MultipleNumber
				,tmp.AuthorizationDate AS LoanAuthorizationDate
				,LEFT(tmp.LoanAuthorizationDateBooked, 18) AS LoanAuthorizationDateBooked
				,tmp.acceptancedate AS AcceptanceDate
				,tmp.TotalCommitmentCloselyRelatedAtAuthorization
				,LEFT(tmp.LoanInitiativeTypeCode, 20) AS ProductIntiativeTypeCode
				,LEFT(tmp.LoanInitiativeDescr, 20) AS ProductIntiativeTypeDescrEN
				,LEFT(tmp.AdministrativeTypeCode, 10) AS AdministrativeTypeCode
				,LEFT(tmp.AdministrativeTypeDescr, 50) AS AdministrativeTypeDescrEN
				,LEFT(tmp.GLAlliancePortfolioCode, 20) AS AlliancePortfolioGLCode
				,LEFT(tmp.AllianceCode, 10) AS AlliancePortfolioCode
				,LEFT(tmp.AllianceDescr, 50) AS AlliancePortfolioDescrEN
				,LEFT(tmp.LoanProductCode, 10) AS LoanProductCode
				,LEFT(tmp.LoanProductDescr, 50) AS LoanProductDescrEN
				,NULL AS ModifiedBy
				,tmp.LoanEntity_oid AS RowSignature
			FROM dbo.tmp_DimLoan tmp
			INNER JOIN dbo.DimKeyDimLoan dim ON tmp.LoanEntity_buid = dim.Buid
			WHERE tmp.entity_start_date = tmp.AuthorizationDate OR entity_is_current = 1
		) r
		WHERE RowNum = 1
	) AS src
	ON (dst.DimLoanAtOriginationDurableKey = src.DimLoanAtOriginationDurableKey)

	WHEN MATCHED THEN
		UPDATE SET
			AccountNumber = src.AccountNumber
			,AbacusNumber = src.AbacusNumber
			,MultipleNumber = src.MultipleNumber
			,LoanAuthorizationDate = src.LoanAuthorizationDate
			,LoanAuthorizationDateBooked = src.LoanAuthorizationDateBooked
			,AcceptanceDate = src.AcceptanceDate
			,TotalCommitmentCloselyRelatedAtAuthorization = src.TotalCommitmentCloselyRelatedAtAuthorization
			,ProductIntiativeTypeCode = src.ProductIntiativeTypeCode
			,ProductIntiativeTypeDescrEN = src.ProductIntiativeTypeDescrEN
			,AdministrativeTypeCode = src.AdministrativeTypeCode
			,AdministrativeTypeDescrEN = src.AdministrativeTypeDescrEN
			,AlliancePortfolioGLCode = src.AlliancePortfolioGLCode
			,AlliancePortfolioCode = src.AlliancePortfolioCode
			,AlliancePortfolioDescrEN = src.AlliancePortfolioDescrEN
			,LoanProductCode = src.LoanProductCode
			,LoanProductDescrEN = src.LoanProductDescrEN
			,ModifiedDate = GETDATE()
			,ModifiedBy = src.ModifiedBy
			,RowSignature = src.RowSignature

	WHEN NOT MATCHED THEN
		INSERT (
			DimLoanAtOriginationDurableKey
			,AccountNumber
			,AbacusNumber
			,MultipleNumber
			,LoanAuthorizationDate
			,LoanAuthorizationDateBooked
			,AcceptanceDate
			,TotalCommitmentCloselyRelatedAtAuthorization
			,ProductIntiativeTypeCode
			,ProductIntiativeTypeDescrEN
			,AdministrativeTypeCode
			,AdministrativeTypeDescrEN
			,AlliancePortfolioGLCode
			,AlliancePortfolioCode
			,AlliancePortfolioDescrEN
			,LoanProductCode
			,LoanProductDescrEN
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
		)
		VALUES (
			src.DimLoanAtOriginationDurableKey
			,src.AccountNumber
			,src.AbacusNumber
			,src.MultipleNumber
			,src.LoanAuthorizationDate
			,src.LoanAuthorizationDateBooked
			,src.AcceptanceDate
			,src.TotalCommitmentCloselyRelatedAtAuthorization
			,src.ProductIntiativeTypeCode
			,src.ProductIntiativeTypeDescrEN
			,src.AdministrativeTypeCode
			,src.AdministrativeTypeDescrEN
			,src.AlliancePortfolioGLCode
			,src.AlliancePortfolioCode
			,src.AlliancePortfolioDescrEN
			,src.LoanProductCode
			,src.LoanProductDescrEN
			,GETDATE()
			,GETDATE()
			,src.ModifiedBy
			,src.RowSignature
		);
END
GO
