﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-07
-- Description: Updates DimIndustry from tmp_DimIndustry
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_DimIndustry
AS
BEGIN
	-- =============================================
	-- Updates DimKey table first
	-- =============================================
	MERGE dbo.DimKeyDimIndustry AS dst
	USING (
		SELECT DISTINCT
			IndustryRefEntity_buid
			,LEFT(SicN, 10) AS SicN
		FROM dbo.tmp_DimIndustry
	) AS src
	ON dst.Buid = src.IndustryRefEntity_buid

	WHEN MATCHED THEN
		UPDATE SET
			SicN = src.SicN
			,ModifiedDate = GETDATE()

	WHEN NOT MATCHED THEN
		INSERT (
            Buid
            ,SicN
			,InsertedDate
			,ModifiedDate
		)
		VALUES (
            src.IndustryRefEntity_buid
            ,src.SicN
			,GETDATE()
			,GETDATE()
		);

	-- =============================================
	-- Then updates Dimension table
	-- =============================================
	MERGE dbo.DimIndustry AS dst
	USING (
		SELECT
			dim.DimKey AS DimIndustryKey
			,LEFT(tmp.SicN, 10) AS IndustryCode
			,LEFT(tmp.IndustryType, 10) AS IndustryType
			,ExporterIndicator=CASE LEFT(tmp.Exporter, 1) WHEN 'Y' THEN 1 ELSE 0 END  
			,LEFT(tmp.IndustryDescEnglish, 100) AS IndustryDescrEN
			,LEFT(tmp.IndustryDescFrench, 100) AS IndustryDescrFR
			,LEFT(tmp.IndustrySubGroupCode, 10) AS IndustryBDCGroupCode
			,LEFT(tmp.IndustrySubGroupDescrEN, 100) AS IndustryBDCGroupDescrEN
			,LEFT(tmp.IndustrySubGroupDescrFR, 100) AS IndustryBDCGroupDescrFR
			,LEFT(tmp.IndustrySubGroupShortDescrEN, 100) AS IndustryBDCGroupDescrENShort
			,LEFT(tmp.IndustrySubGroupShortDescrFR, 100) AS IndustryBDCGroupDescrFRShort
			,LEFT(tmp.MarketingGroup17Code, 10) AS IndustryMarketingGroupCode
			,LEFT(tmp.MarketingGroup17English, 100) AS IndustryMarketingGroupDescrEN
			,LEFT(tmp.MarketingGroup17French, 100) AS IndustryMarketingGroupDescrFR
			,LEFT(tmp.IndustryPRMGroupCode, 10) AS IndustryAnalytixGroupCode
			,LEFT(tmp.IndustryPRMGroupDescrEN, 100) AS IndustryAnalytixGroupDescrEN
			,LEFT(tmp.IndustryPRMGroupDescrFR, 100) AS IndustryAnalytixGroupDescrFR
			,LEFT(tmp.FinanceGroup10, 10) AS IndustryFinanceGroupCode
			,LEFT(tmp.FinanceGroupDescription10English, 100) AS IndustryFinanceGroupDescrEN
			,LEFT(tmp.FinanceGroupDescription10French, 100) AS IndustryFinanceGroupDescrFR
			,NULL AS NAICSL5Code
			,NULL AS NAICSL5DescrEN
			,NULL AS NAICSL5DescrFR
			,NULL AS NAICSL4Code
			,NULL AS NAICSL4DescrEN
			,NULL AS NAICSL4DescrFR
			,NULL AS NAICSL3Code
			,NULL AS NAICSL3DescrEN
			,NULL AS NAICSL3DescrFR
			,NULL AS NAICSL2Code
			,NULL AS NAICSL2DescrEN
			,NULL AS NAICSL2DescrFR
			,NAICSUSFlag=CASE LEFT(tmp.NAICSUSFlag, 1) WHEN 'Y' THEN 1 ELSE 0 END
			,NULL AS ModifiedBy
			,tmp.IndustryRefEntity_oid AS RowSignature
		FROM dbo.tmp_DimIndustry tmp
		INNER JOIN dbo.DimKeyDimIndustry dim ON tmp.IndustryRefEntity_buid = dim.Buid
	) AS src
	ON (dst.DimIndustryKey = src.DimIndustryKey)

	WHEN MATCHED THEN
		UPDATE SET
			IndustryCode = src.IndustryCode
			,IndustryType = src.IndustryType
			,ExporterIndicator = src.ExporterIndicator
			,IndustryDescrEN = src.IndustryDescrEN
			,IndustryDescrFR = src.IndustryDescrFR
			,IndustryBDCGroupCode = src.IndustryBDCGroupCode
			,IndustryBDCGroupDescrEN = src.IndustryBDCGroupDescrEN
			,IndustryBDCGroupDescrFR = src.IndustryBDCGroupDescrFR
			,IndustryBDCGroupDescrENShort = src.IndustryBDCGroupDescrENShort
			,IndustryBDCGroupDescrFRShort = src.IndustryBDCGroupDescrFRShort
			,IndustryMarketingGroupCode = src.IndustryMarketingGroupCode
			,IndustryMarketingGroupDescrEN = src.IndustryMarketingGroupDescrEN
			,IndustryMarketingGroupDescrFR = src.IndustryMarketingGroupDescrFR
			,IndustryAnalytixGroupCode = src.IndustryAnalytixGroupCode
			,IndustryAnalytixGroupDescrEN = src.IndustryAnalytixGroupDescrEN
			,IndustryAnalytixGroupDescrFR = src.IndustryAnalytixGroupDescrFR
			,IndustryFinanceGroupCode = src.IndustryFinanceGroupCode
			,IndustryFinanceGroupDescrEN = src.IndustryFinanceGroupDescrEN
			,IndustryFinanceGroupDescrFR = src.IndustryFinanceGroupDescrFR
			,NAICSL5Code = src.NAICSL5Code
			,NAICSL5DescrEN = src.NAICSL5DescrEN
			,NAICSL5DescrFR = src.NAICSL5DescrFR
			,NAICSL4Code = src.NAICSL4Code
			,NAICSL4DescrEN = src.NAICSL4DescrEN
			,NAICSL4DescrFR = src.NAICSL4DescrFR
			,NAICSL3Code = src.NAICSL3Code
			,NAICSL3DescrEN = src.NAICSL3DescrEN
			,NAICSL3DescrFR = src.NAICSL3DescrFR
			,NAICSL2Code = src.NAICSL2Code
			,NAICSL2DescrEN = src.NAICSL2DescrEN
			,NAICSL2DescrFR = src.NAICSL2DescrFR
			,NAICSUSFlag = src.NAICSUSFlag
			,ModifiedDate = GETDATE()
			,ModifiedBy = src.ModifiedBy
			,RowSignature = src.RowSignature

	WHEN NOT MATCHED THEN
		INSERT (
			DimIndustryKey
			,IndustryCode
			,IndustryType
			,ExporterIndicator
			,IndustryDescrEN
			,IndustryDescrFR
			,IndustryBDCGroupCode
			,IndustryBDCGroupDescrEN
			,IndustryBDCGroupDescrFR
			,IndustryBDCGroupDescrENShort
			,IndustryBDCGroupDescrFRShort
			,IndustryMarketingGroupCode
			,IndustryMarketingGroupDescrEN
			,IndustryMarketingGroupDescrFR
			,IndustryAnalytixGroupCode
			,IndustryAnalytixGroupDescrEN
			,IndustryAnalytixGroupDescrFR
			,IndustryFinanceGroupCode
			,IndustryFinanceGroupDescrEN
			,IndustryFinanceGroupDescrFR
			,NAICSL5Code
			,NAICSL5DescrEN
			,NAICSL5DescrFR
			,NAICSL4Code
			,NAICSL4DescrEN
			,NAICSL4DescrFR
			,NAICSL3Code
			,NAICSL3DescrEN
			,NAICSL3DescrFR
			,NAICSL2Code
			,NAICSL2DescrEN
			,NAICSL2DescrFR
			,NAICSUSFlag
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
		)
		VALUES (
			src.DimIndustryKey
			,src.IndustryCode
			,src.IndustryType
			,src.ExporterIndicator
			,src.IndustryDescrEN
			,src.IndustryDescrFR
			,src.IndustryBDCGroupCode
			,src.IndustryBDCGroupDescrEN
			,src.IndustryBDCGroupDescrFR
			,src.IndustryBDCGroupDescrENShort
			,src.IndustryBDCGroupDescrFRShort
			,src.IndustryMarketingGroupCode
			,src.IndustryMarketingGroupDescrEN
			,src.IndustryMarketingGroupDescrFR
			,src.IndustryAnalytixGroupCode
			,src.IndustryAnalytixGroupDescrEN
			,src.IndustryAnalytixGroupDescrFR
			,src.IndustryFinanceGroupCode
			,src.IndustryFinanceGroupDescrEN
			,src.IndustryFinanceGroupDescrFR
			,src.NAICSL5Code
			,src.NAICSL5DescrEN
			,src.NAICSL5DescrFR
			,src.NAICSL4Code
			,src.NAICSL4DescrEN
			,src.NAICSL4DescrFR
			,src.NAICSL3Code
			,src.NAICSL3DescrEN
			,src.NAICSL3DescrFR
			,src.NAICSL2Code
			,src.NAICSL2DescrEN
			,src.NAICSL2DescrFR
			,src.NAICSUSFlag
			,GETDATE()
			,GETDATE()
			,src.ModifiedBy
			,src.RowSignature
		);
END
GO
