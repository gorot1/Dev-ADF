﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-07
-- Description: Updates DimLoanPurpose from tmp_DimLoanPurpose
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_DimLoanPurpose
AS
BEGIN
	-- =============================================
	-- Updates DimKey table first
	-- =============================================
	MERGE dbo.DimKeyDimLoanPurpose AS dst
	USING (
		SELECT DISTINCT
			LoanPurposeTableRefEntity_buid
			,LEFT(LoanPurposeCode, 2) AS LoanPurposeCode
		FROM dbo.tmp_DimLoanPurpose
	) AS src
	ON dst.Buid = src.LoanPurposeTableRefEntity_buid

	WHEN MATCHED THEN
		UPDATE SET
			LoanPurposeCode = src.LoanPurposeCode
			,ModifiedDate = GETDATE()

	WHEN NOT MATCHED THEN
		INSERT (
            Buid
            ,LoanPurposeCode
			,InsertedDate
			,ModifiedDate
		)
		VALUES (
            src.LoanPurposeTableRefEntity_buid
            ,src.LoanPurposeCode
			,GETDATE()
			,GETDATE()
		);

	-- =============================================
	-- Then updates Dimension table
	-- =============================================
	MERGE dbo.DimLoanPurpose AS dst
	USING (
		SELECT
			dim.DimKey AS DimLoanPurposeKey
			,LEFT(tmp.LoanPurposeCode, 2) AS LoanPurposeCode
			,LEFT(tmp.LoanPurposeDescription, 50) AS LoanPurposeDescrEN
			,NULL AS LoanPurposeDescrFR
			,LEFT(tmp.LoanPurposeGroupId, 2) AS LoanPurposeGroupId
			,LEFT(tmp.LoanPurposeGroupDescr, 50) AS LoanPurposeGroupDescrEN
			,LEFT(tmp.LoanPurposeGroupDescrFr, 50) AS LoanPurposeGroupDescrFR
			,LEFT(tmp.LoanPurpGrpMarketingId, 2) AS LoanPurposeGroupMarketingId
			,LEFT(tmp.LoanPurpGrpMarketingDescrEn, 50) AS LoanPurposeGroupMarketingDescrEN
			,LEFT(tmp.LoanPurpGrpMarketingDescrFr, 50) AS LoanPurposeGroupMarketingDescrFR
			,NULL AS ModifiedBy
			,tmp.LoanPurposeTableRefEntity_oid AS RowSignature
		  FROM dbo.tmp_DimLoanPurpose tmp
		  INNER JOIN dbo.DimKeyDimLoanPurpose dim ON tmp.LoanPurposeTableRefEntity_buid = dim.Buid
	) AS src
	ON (dst.DimLoanPurposeKey = src.DimLoanPurposeKey)

	WHEN MATCHED THEN
		UPDATE SET
			LoanPurposeCode = src.LoanPurposeCode
			,LoanPurposeDescrEN = src.LoanPurposeDescrEN
			,LoanPurposeDescrFR = src.LoanPurposeDescrFR
			,LoanPurposeGroupId = src.LoanPurposeGroupId
			,LoanPurposeGroupDescrEN = src.LoanPurposeGroupDescrEN
			,LoanPurposeGroupDescrFR = src.LoanPurposeGroupDescrFR
			,LoanPurposeGroupMarketingId = src.LoanPurposeGroupMarketingId
			,LoanPurposeGroupMarketingDescrEN = src.LoanPurposeGroupMarketingDescrEN
			,LoanPurposeGroupMarketingDescrFR = src.LoanPurposeGroupMarketingDescrFR
			,ModifiedDate = GETDATE()
			,ModifiedBy = src.ModifiedBy
			,RowSignature = src.RowSignature

	WHEN NOT MATCHED THEN
		INSERT (
			DimLoanPurposeKey
			,LoanPurposeCode
			,LoanPurposeDescrEN
			,LoanPurposeDescrFR
			,LoanPurposeGroupId
			,LoanPurposeGroupDescrEN
			,LoanPurposeGroupDescrFR
			,LoanPurposeGroupMarketingId
			,LoanPurposeGroupMarketingDescrEN
			,LoanPurposeGroupMarketingDescrFR
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
		)
		VALUES (
			src.DimLoanPurposeKey
			,src.LoanPurposeCode
			,src.LoanPurposeDescrEN
			,src.LoanPurposeDescrFR
			,src.LoanPurposeGroupId
			,src.LoanPurposeGroupDescrEN
			,src.LoanPurposeGroupDescrFR
			,src.LoanPurposeGroupMarketingId
			,src.LoanPurposeGroupMarketingDescrEN
			,src.LoanPurposeGroupMarketingDescrFR
			,GETDATE()
			,GETDATE()
			,src.ModifiedBy
			,src.RowSignature
		);
END
GO
