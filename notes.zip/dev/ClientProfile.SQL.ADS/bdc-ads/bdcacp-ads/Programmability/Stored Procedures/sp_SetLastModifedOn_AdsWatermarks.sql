﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-10-05
-- Description: Sets lastModifiedOn to AdsWatermarks
-- =============================================
CREATE PROCEDURE dbo.sp_SetLastModifedOn_AdsWatermarks
(
    @tableName		VARCHAR(255),
	@lastModifiedOn	datetime
)
AS
BEGIN

	MERGE dbo.AdsWatermarks AS dst
	USING (SELECT * FROM (VALUES (@tableName, @lastModifiedOn)) AS s (TableName, ModifiedOn)) AS src
	ON dst.TableName = src.TableName

	WHEN MATCHED THEN
		UPDATE SET ModifiedOn = src.ModifiedOn

	WHEN NOT MATCHED THEN
		INSERT (TableName, ModifiedOn)
		VALUES (src.TableName, src.ModifiedOn);
END
GO
