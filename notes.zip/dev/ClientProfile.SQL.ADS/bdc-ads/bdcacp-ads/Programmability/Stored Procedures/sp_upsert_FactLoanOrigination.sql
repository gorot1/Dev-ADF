﻿-- =============================================
-- Author:      Luc Vaillant
-- Create Date: 2020-11-09
-- Description: Updates FactLoanOrigination from FactLoanOriginationDaily
-- =============================================
CREATE PROCEDURE dbo.sp_upsert_FactLoanOrigination
AS
BEGIN
	DECLARE @lastModifedOn DATETIME
	DECLARE @newLastModifiedOn DATETIME

	SET @newLastModifiedOn = (SELECT ISNULL(MAX(ModifiedDate), CONVERT(DATETIME, '1900-01-01 00:00:00', 20)) FROM dbo.FactLoanOriginationDaily)
	SET @lastModifedOn = (SELECT ISNULL(MAX(ModifiedOn), CONVERT(DATETIME, '1900-01-01 00:00:00', 20)) FROM dbo.AdsWatermarks WHERE TableName = 'FactLoanOrigination')

	BEGIN TRANSACTION

	-- =============================================
	-- FactLoanOrigination is Scd1
	-- =============================================
	MERGE dbo.FactLoanOrigination AS dst
	USING (
		SELECT
			MAX(flod.DimLoanKey) AS DimLoanKey
			,MAX(flod.DimLoanDurableKey) AS DimLoanDurableKey
			,MAX(flod.DimCustomerKey) AS DimCustomerKey
			,MAX(flod.DimCustomerDurableKey) AS DimCustomerDurableKey
			,MAX(flod.DimDateKey) AS DimDateKey
			,MAX(flod.DimLoanTrancheKey) AS DimLoanTrancheKey
			,MAX(flod.DimLoanTrancheDurableKey) AS DimLoanTrancheDurableKey
			,MAX(flod.DimLoanAtOriginationDurableKey) AS DimLoanAtOriginationDurableKey
			,MAX(flod.DimOriginatingUnitKey) AS DimOriginatingUnitKey
			,MAX(flod.DimOriginatingUnitAtAuthKey) AS DimOriginatingUnitAtAuthKey
			,MAX(flod.DimOperatingUnitKey) AS DimOperatingUnitKey
			,MAX(flod.DimOperatingUnitAtAuthKey) AS DimOperatingUnitAtAuthKey
			,MAX(flod.DimLoanPurposeKey) AS DimLoanPurposeKey
			,MAX(flod.DimNewRepeatBusinessKey) AS DimNewRepeatBusinessKey
			,MAX(flod.DimIndustryKey) AS DimIndustryKey
			,MAX(flod.DimLineOfBusinessKey) AS DimLineOfBusinessKey
			,MAX(flod.DimLoanSolutionGroupingKey) AS DimLoanSolutionGroupingKey
			,MAX(flod.DimSourceOfReferenceKey) AS DimSourceOfReferenceKey
			,MAX(flod.DimLoanCancellationReasonKey) AS DimLoanCancellationReasonKey
			,SUM(flod.AuthorizationGrossLoanAmount) AS AuthorizationGrossLoanAmount
			,SUM(flod.AuthorizationGrossLoanCount) AS AuthorizationGrossLoanCount
			,SUM(flod.AuthorizationGrossNewMoneyAmount) AS AuthorizationGrossNewMoneyAmount
			,SUM(flod.AuthorizationGrossNewMoneyCount) AS AuthorizationGrossNewMoneyCount
			,SUM(flod.AuthorizationNetNewMoney) AS AuthorizationNetNewMoney
			,SUM(flod.AuthorizationNetNewMoneyCount) AS AuthorizationNetNewMoneyCount
			,SUM(flod.AuthorizationFiscalNet) AS AuthorizationFiscalNet
			,SUM(flod.AuthorizationFiscalNetCount) AS AuthorizationFiscalNetCount
			,SUM(flod.AuthorizationNetLoan) AS AuthorizationNetLoan
			,SUM(flod.AcceptedGrossNewMoney) AS AcceptedGrossNewMoney
			,SUM(flod.AcceptedGrossNewMoneyCount) AS AcceptedGrossNewMoneyCount
			,SUM(flod.AcceptedNetNewMoney) AS AcceptedNetNewMoney
			,SUM(flod.AcceptedNetNewMoneyCount) AS AcceptedNetNewMoneyCount
			,SUM(flod.AcceptedNetLoan) AS AcceptedNetLoan
			,SUM(flod.AcceptedNetLoanCount) AS AcceptedNetLoanCount
			,SUM(flod.CancellationReductionTotal) AS CancellationReductionTotal
			,SUM(flod.Cancellation) AS Cancellation
			,SUM(flod.Reduction) AS Reduction
			,MAX(flod.ModifiedBy) AS ModifiedBy
			,MAX(flod.RowSignature) AS RowSignature
		FROM (
			SELECT
				LAST_VALUE(s.DimLoanKey) OVER(PARTITION BY s.DimLoanDurableKey, CAST(s.DimDateKey / 100 AS INT) ORDER BY s.DimDateKey) AS DimLoanKey
				,s.DimLoanDurableKey
				,s.DimCustomerKey
				,s.DimCustomerDurableKey
				,CAST(s.DimDateKey / 100 AS INT) * 100 + DAY(EOMONTH(CAST(CAST(s.DimDateKey AS VARCHAR(8)) AS DATE))) AS DimDateKey
				,s.DimLoanTrancheKey
				,s.DimLoanTrancheDurableKey
				,s.DimLoanAtOriginationDurableKey
				,s.DimOriginatingUnitKey
				,s.DimOriginatingUnitAtAuthKey
				,s.DimOperatingUnitKey
				,s.DimOperatingUnitAtAuthKey
				,s.DimLoanPurposeKey
				,s.DimNewRepeatBusinessKey
				,s.DimIndustryKey
				,s.DimLineOfBusinessKey
				,s.DimLoanSolutionGroupingKey
				,s.DimSourceOfReferenceKey
				,s.DimLoanCancellationReasonKey
				,s.AuthorizationGrossLoanAmount
				,s.AuthorizationGrossLoanCount
				,s.AuthorizationGrossNewMoneyAmount
				,s.AuthorizationGrossNewMoneyCount
				,s.AuthorizationNetNewMoney
				,s.AuthorizationNetNewMoneyCount
				,s.AuthorizationFiscalNet
				,s.AuthorizationFiscalNetCount
				,s.AuthorizationNetLoan
				,s.AcceptedGrossNewMoney
				,s.AcceptedGrossNewMoneyCount
				,s.AcceptedNetNewMoney
				,s.AcceptedNetNewMoneyCount
				,s.AcceptedNetLoan
				,s.AcceptedNetLoanCount
				,s.CancellationReductionTotal
				,s.Cancellation
				,s.Reduction
				,s.ModifiedBy
				,s.RowSignature
			FROM dbo.FactLoanOriginationDaily s
			INNER JOIN (
				SELECT DISTINCT
					DimLoanDurableKey
					,CAST(DimDateKey / 100 AS INT) MonthKey
				FROM dbo.FactLoanOriginationDaily
				WHERE ModifiedDate > @lastModifedOn
			) keys ON s.DimLoanDurableKey = keys.DimLoanDurableKey AND CAST(s.DimDateKey / 100 AS INT) = keys.MonthKey
		) AS flod
		GROUP BY flod.DimLoanDurableKey, flod.DimDateKey
	) AS src
	ON (dst.DimLoanDurableKey = src.DimLoanDurableKey AND dst.DimDateKey = src.DimDateKey)

	WHEN MATCHED THEN
		UPDATE SET
			DimLoanKey = src.DimLoanKey
			--,DimLoanDurableKey = src.DimLoanDurableKey
			,DimCustomerKey = src.DimCustomerKey
			,DimCustomerDurableKey = src.DimCustomerDurableKey
			--,DimDateKey = src.DimDateKey
			,DimLoanTrancheKey = src.DimLoanTrancheKey
			,DimLoanTrancheDurableKey = src.DimLoanTrancheDurableKey
			,DimLoanAtOriginationDurableKey = src.DimLoanAtOriginationDurableKey
			,DimOriginatingUnitKey = src.DimOriginatingUnitKey
			,DimOriginatingUnitAtAuthKey = src.DimOriginatingUnitAtAuthKey
			,DimOperatingUnitKey = src.DimOperatingUnitKey
			,DimLoanPurposeKey = src.DimLoanPurposeKey
			,DimNewRepeatBusinessKey = src.DimNewRepeatBusinessKey
			,DimIndustryKey = src.DimIndustryKey
			,DimLineOfBusinessKey = src.DimLineOfBusinessKey
			,DimLoanSolutionGroupingKey = src.DimLoanSolutionGroupingKey
			,DimSourceOfReferenceKey = src.DimSourceOfReferenceKey
			,DimLoanCancellationReasonKey = src.DimLoanCancellationReasonKey
			,DimOperatingUnitAtAuthKey = src.DimOperatingUnitAtAuthKey
			,AuthorizationGrossLoanAmount = src.AuthorizationGrossLoanAmount
			,AuthorizationGrossLoanCount = src.AuthorizationGrossLoanCount
			,AuthorizationGrossNewMoneyAmount = src.AuthorizationGrossNewMoneyAmount
			,AuthorizationGrossNewMoneyCount = src.AuthorizationGrossNewMoneyCount
			,AuthorizationNetNewMoney = src.AuthorizationNetNewMoney
			,AuthorizationNetNewMoneyCount = src.AuthorizationNetNewMoneyCount
			,AuthorizationFiscalNet = src.AuthorizationFiscalNet
			,AuthorizationFiscalNetCount = src.AuthorizationFiscalNetCount
			,AuthorizationNetLoan = src.AuthorizationNetLoan
			,AcceptedGrossNewMoney = src.AcceptedGrossNewMoney
			,AcceptedGrossNewMoneyCount = src.AcceptedGrossNewMoneyCount
			,AcceptedNetNewMoney = src.AcceptedNetNewMoney
			,AcceptedNetNewMoneyCount = src.AcceptedNetNewMoneyCount
			,AcceptedNetLoan = src.AcceptedNetLoan
			,AcceptedNetLoanCount = src.AcceptedNetLoanCount
			,CancellationReductionTotal = src.CancellationReductionTotal
			,Cancellation = src.Cancellation
			,Reduction = src.Reduction
			,ModifiedDate = @newLastModifiedOn
			,ModifiedBy = src.ModifiedBy
			,RowSignature = src.RowSignature

	WHEN NOT MATCHED THEN
		INSERT (
			DimLoanKey
			,DimLoanDurableKey
			,DimCustomerKey
			,DimCustomerDurableKey
			,DimDateKey
			,DimLoanTrancheKey
			,DimLoanTrancheDurableKey
			,DimLoanAtOriginationDurableKey
			,DimOriginatingUnitKey
			,DimOriginatingUnitAtAuthKey
			,DimOperatingUnitKey
			,DimLoanPurposeKey
			,DimNewRepeatBusinessKey
			,DimIndustryKey
			,DimLineOfBusinessKey
			,DimLoanSolutionGroupingKey
			,DimSourceOfReferenceKey
			,DimLoanCancellationReasonKey
			,DimOperatingUnitAtAuthKey
			,AuthorizationGrossLoanAmount
			,AuthorizationGrossLoanCount
			,AuthorizationGrossNewMoneyAmount
			,AuthorizationGrossNewMoneyCount
			,AuthorizationNetNewMoney
			,AuthorizationNetNewMoneyCount
			,AuthorizationFiscalNet
			,AuthorizationFiscalNetCount
			,AuthorizationNetLoan
			,AcceptedGrossNewMoney
			,AcceptedGrossNewMoneyCount
			,AcceptedNetNewMoney
			,AcceptedNetNewMoneyCount
			,AcceptedNetLoan
			,AcceptedNetLoanCount
			,CancellationReductionTotal
			,Cancellation
			,Reduction
			,InsertedDate
			,ModifiedDate
			,ModifiedBy
			,RowSignature
		)
		VALUES (
			src.DimLoanKey
			,src.DimLoanDurableKey
			,src.DimCustomerKey
			,src.DimCustomerDurableKey
			,src.DimDateKey
			,src.DimLoanTrancheKey
			,src.DimLoanTrancheDurableKey
			,src.DimLoanAtOriginationDurableKey
			,src.DimOriginatingUnitKey
			,src.DimOriginatingUnitAtAuthKey
			,src.DimOperatingUnitKey
			,src.DimLoanPurposeKey
			,src.DimNewRepeatBusinessKey
			,src.DimIndustryKey
			,src.DimLineOfBusinessKey
			,src.DimLoanSolutionGroupingKey
			,src.DimSourceOfReferenceKey
			,src.DimLoanCancellationReasonKey
			,src.DimOperatingUnitAtAuthKey
			,src.AuthorizationGrossLoanAmount
			,src.AuthorizationGrossLoanCount
			,src.AuthorizationGrossNewMoneyAmount
			,src.AuthorizationGrossNewMoneyCount
			,src.AuthorizationNetNewMoney
			,src.AuthorizationNetNewMoneyCount
			,src.AuthorizationFiscalNet
			,src.AuthorizationFiscalNetCount
			,src.AuthorizationNetLoan
			,src.AcceptedGrossNewMoney
			,src.AcceptedGrossNewMoneyCount
			,src.AcceptedNetNewMoney
			,src.AcceptedNetNewMoneyCount
			,src.AcceptedNetLoan
			,src.AcceptedNetLoanCount
			,src.CancellationReductionTotal
			,src.Cancellation
			,src.Reduction
			,@newLastModifiedOn
			,@newLastModifiedOn
			,src.ModifiedBy
			,src.RowSignature
		)
    OUTPUT $ACTION as ActionType, src.*;

	EXEC dbo.sp_SetLastModifedOn_AdsWatermarks 'FactLoanOrigination', @newLastModifiedOn

	COMMIT TRANSACTION
END
GO
