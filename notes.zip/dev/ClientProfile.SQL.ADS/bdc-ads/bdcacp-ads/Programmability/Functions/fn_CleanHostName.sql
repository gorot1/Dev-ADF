﻿-- =============================================
-- Author:      David Sun
-- Create Date: 2021-02-23
-- Description: remove unnecessary characters from hostname
-- =============================================
CREATE FUNCTION [dbo].[fn_CleanHostName]
(
    @hostname nvarchar(100)
)
RETURNS nvarchar(100)
AS
BEGIN
    RETURN REPLACE(REPLACE(REPLACE(REPLACE(@hostname,'/', '' ), 'https:', ''), 'www.', '') , ' ','');
END;
GO