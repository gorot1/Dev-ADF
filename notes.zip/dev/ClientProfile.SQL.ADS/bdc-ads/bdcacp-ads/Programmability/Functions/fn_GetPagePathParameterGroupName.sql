﻿-- =============================================
-- Author:      David Sun
-- Create Date: 2021-01-18
-- Description: get parameter group names for pagepaths
-- =============================================
CREATE FUNCTION [dbo].[fn_GetPagePathParameterGroupName]
(

    @parameter NVARCHAR(2000)
)
RETURNS NVARCHAR(200)
AS
BEGIN
RETURN CASE 
	WHEN @parameter LIKE '%financing_form_step_1_of_5%' THEN 'financing_form_step_1_of_5' 
	WHEN @parameter LIKE '%financing_form_step_2_of_5%' THEN 'financing_form_step_2_of_5' 
	WHEN @parameter LIKE '%financing_form_step_3_of_5%' THEN 'financing_form_step_3_of_5' 
	WHEN @parameter LIKE '%financing_form_step_4_of_5%' THEN 'financing_form_step_4_of_5' 
	WHEN @parameter LIKE '%financing_form_step_5_of_5%' THEN 'financing_form_step_5_of_5' 
	WHEN @parameter LIKE '%financing_form_step_1_of_3%' THEN 'financing_form_step_1_of_3' 
	WHEN @parameter LIKE '%financing_form_step_2_of_3%' THEN 'financing_form_step_2_of_3' 
	WHEN @parameter LIKE '%financing_form_step_3_of_3%' THEN 'financing_form_step_3_of_3'  
  END
END
GO

