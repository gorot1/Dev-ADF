﻿-- =============================================
-- Author:      David Sun
-- Create Date: 2021-01-18
-- Description: get channel group name
-- =============================================
CREATE FUNCTION dbo.fn_GetChannelGroupName(
    @source                 NVARCHAR(MAX)
    , @medium               NVARCHAR(MAX)
    , @campaign             NVARCHAR(MAX)
) 
RETURNS NVARCHAR(MAX)

AS

BEGIN

RETURN (
    CASE
        WHEN 
            @campaign LIKE '%outreach%'
            AND @medium = 'display'
            AND
            (
                @source NOT LIKE '%facebook%'
                OR @source NOT LIKE '%twitter%'
            ) 
        THEN 'Native Ads'
        WHEN 
            @source = '(direct)' 
        THEN 'Direct'
        WHEN 
            (
                @medium LIKE '%social%'
                OR @medium LIKE '%organic_sm%'
            )
            OR
            (
                @source LIKE '%facebook%'
                OR @source LIKE '%twitter%'
                OR @source LIKE '%linkedin%'
                OR @source LIKE '%lnkd.in%'
                OR @source LIKE '%youtube%'
            )
            OR (@source = 't.co') 
        THEN 'Social Media'
        WHEN 
            (@medium LIKE '%organic%')
            OR
            (
                @source LIKE '%search.yahoo.com%'
                OR @source LIKE '%duckduckgo.com%'
                OR @source LIKE '%ca.search.com%'
            ) 
        THEN 'Non-Paid Search'
        WHEN 
            (
                @medium LIKE '%email%'
                OR @source LIKE '%mail%'
            )
            AND (@source NOT LIKE '%globeandmail%') 
        THEN 'Email'
        WHEN 
            @medium = 'cpc' 
        THEN 'Paid Search'
        WHEN 
            @medium LIKE '%referral%' 
        THEN 'Referral'
        WHEN
            (
                (
                    (
                        @campaign LIKE '%display%'
                        OR @campaign LIKE '%remarketing_dis%'
                        OR @campaign LIKE '%video_%'
                        OR
                        (
                            @campaign LIKE '%vid_%'
                            AND @campaign NOT LIKE '%covid%'
                        )
                        OR @campaign LIKE '%dis_%'
                    )
                    OR
                    (
                        (
                            @medium LIKE '%display%'
                            OR @medium LIKE '%programmatic%'
                        )
                        AND (@campaign NOT LIKE '%outreach%')
                    )
                    OR (@medium LIKE '%banner%')
                )
                AND
                (
                    @source NOT LIKE '%facebook%'
                    AND @source NOT LIKE '%twitter%'
                )
            ) 
        THEN 'Display'
        ELSE 'Other'
    END
)

END
GO