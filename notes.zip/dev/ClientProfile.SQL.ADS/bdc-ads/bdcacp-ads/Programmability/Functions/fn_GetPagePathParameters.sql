﻿-- =============================================
-- Author:      David Sun
-- Create Date: 2021-01-18
-- Description: get parameters of pagepaths
-- =============================================
CREATE FUNCTION [dbo].[fn_GetPagePathParameters]
(

    @pagePath NVARCHAR(MAX)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
RETURN CASE
               WHEN @pagePath LIKE '%?%' THEN
                   RIGHT(@pagePath, CHARINDEX('?', REVERSE(@pagePath)) - 1)
           END
END
GO