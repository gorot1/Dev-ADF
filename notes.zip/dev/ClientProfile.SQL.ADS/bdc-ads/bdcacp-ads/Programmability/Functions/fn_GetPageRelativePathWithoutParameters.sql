﻿-- =============================================
-- Author:      David Sun
-- Create Date: 2021-02-23
-- Description: get page relative path without parameters
-- =============================================
CREATE FUNCTION [dbo].[fn_GetPageRelativePathWithoutParameters]
(

    @pagePath NVARCHAR(MAX)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
    RETURN REPLACE(CASE
                                                WHEN CHARINDEX('?', @pagePath) > 0 THEN
                                                    LEFT(@pagePath, CHARINDEX('?', @pagePath) - 1)
                                                ELSE
                                                    @pagePath
                                            END, ' ','');
END;
GO