﻿-- =============================================
-- Author:      David Sun
-- Create Date: 2021-01-18
-- Description: check whether contain specific letters
-- =============================================
CREATE FUNCTION [dbo].[fn_ContainsAnyWord](@stringtosearch nvarchar(max), @arrayofwords nvarchar(max), @separator nvarchar(2))  
RETURNS int   
AS   
-- Returns the stock level for the product.  
BEGIN 
  
   DECLARE @ret int;  
		
   SET @ret = (SELECT CASE WHEN COUNT(value) <> 0 THEN 1 ELSE 0 END FROM STRING_SPLIT(@arrayofwords, @separator) WHERE  @stringtosearch LIKE '%' +value + '%');  
   
   RETURN @ret;  
END
GO